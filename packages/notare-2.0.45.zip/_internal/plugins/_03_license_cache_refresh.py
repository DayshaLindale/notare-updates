"""License cache self-heal — runs at startup before workspaces gate.

Stale cache symptom: local license.json has an `entitlements` object with empty
or missing `proof_profiles`/`workspaces` lists. The frontend gates strictly on
server-authoritative entitlements when the object is present (empty list = deny),
so a stale cache from before entitlements were properly populated will block
profiles and workspaces that the user is actually entitled to.

Fix: on startup, if license.json has an entitlements object with empty inner
lists AND the key is present in the fallback allowlist, REMOVE the entitlements
field. The fallback resolution path then grants the bundled profiles.

For keys NOT in the fallback allowlist (newer customers), re-query the server
once to refresh entitlements. Network-fail = leave alone; don't lock anyone out
on first-launch-with-no-internet.

Tracked once-per-startup via a stamp file so we don't hammer the server every
launch.
"""
import json
import os
import time
import urllib.request
from pathlib import Path

import app as _app

logger = _app.logger if hasattr(_app, "logger") else None


def _log(msg, level="info"):
    if logger:
        getattr(logger, level)(msg)
    else:
        print(f"[license_cache_refresh] {msg}")


def _stamp_path():
    return _app.BASE_DIR / "_internal" / "_license_refresh.stamp"


def _should_run():
    """Run at most once per 6 hours so we self-heal but don't spam."""
    stamp = _stamp_path()
    if not stamp.exists():
        return True
    try:
        last = float(stamp.read_text().strip())
        return (time.time() - last) > 6 * 3600
    except Exception:
        return True


def _mark_done():
    try:
        _stamp_path().write_text(str(time.time()))
    except Exception:
        pass


def _license_files():
    """Both potential locations for license.json — prefer the app-level one."""
    return [
        _app.BASE_DIR / "license.json",
        _app.BASE_DIR / "_internal" / "license.json",
    ]


def _entitlements_are_stale(data):
    """Stale = entitlements key present but inner lists are empty/missing."""
    ent = data.get("entitlements")
    if not isinstance(ent, dict):
        return False  # No entitlements field = use fallback, not stale
    profs = ent.get("proof_profiles")
    works = ent.get("workspaces")
    if not isinstance(profs, list) or not isinstance(works, list):
        return True
    if len(profs) == 0 and len(works) == 0:
        return True
    return False


def _query_server(key, machine_id=""):
    """Re-validate against the update server. Returns dict or None on failure."""
    try:
        payload = json.dumps({"key": key, "machine_id": machine_id}).encode()
        req = urllib.request.Request(
            "https://notare-updates.onrender.com/api/validate-license",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        _log(f"server query failed: {e}", "warning")
        return None


def _refresh_one(license_path):
    """Self-heal a single license.json. Returns (changed, reason)."""
    try:
        data = json.loads(license_path.read_text(encoding="utf-8"))
    except Exception:
        return (False, "could not read")

    key = (data.get("key") or "").strip().upper()
    if not key:
        return (False, "no key")

    if not _entitlements_are_stale(data):
        return (False, "entitlements already healthy")

    _log(f"detected stale entitlements for {key} — refreshing")

    # Strategy 1: re-query the server. Most accurate.
    fresh = _query_server(key, data.get("machine_id", ""))
    if fresh and fresh.get("valid") and isinstance(fresh.get("entitlements"), dict):
        new_ent = fresh["entitlements"]
        if (isinstance(new_ent.get("proof_profiles"), list) and
                len(new_ent["proof_profiles"]) > 0):
            data["entitlements"] = new_ent
            license_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            _log(f"refreshed entitlements from server for {key}: "
                 f"{new_ent.get('proof_profiles')}")
            return (True, "refreshed from server")

    # Strategy 2: server unreachable or returned no entitlements. Drop the
    # stale entitlements field so the fallback allowlist takes over. For keys
    # in the fallback table, this restores access. For others, it'll deny
    # until the next successful server check — same as before, no regression.
    data.pop("entitlements", None)
    license_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _log(f"removed stale entitlements field for {key}; fallback will resolve")
    return (True, "cleared stale entitlements; fallback active")


def _run():
    if not _should_run():
        return

    any_changed = False
    for lf in _license_files():
        if not lf.exists():
            continue
        try:
            changed, reason = _refresh_one(lf)
            if changed:
                any_changed = True
                _log(f"{lf.name}: {reason}")
        except Exception as e:
            _log(f"refresh failed for {lf.name}: {e}", "warning")

    _mark_done()
    if any_changed:
        _log("license cache refresh complete; restart Notare for changes to take effect")


# Run at plugin load time (startup). Wrap in try so a failure here never
# blocks app boot — license functionality survives this plugin failing.
try:
    _run()
except Exception as e:
    _log(f"plugin failed: {e}", "error")
