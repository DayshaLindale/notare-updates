"""Preview plugin — Generates temp PDF previews in the static folder.

Dropped into _internal/plugins/ via OTA. Loaded by the plugin loader at startup.
"""
import secrets as _secrets

@app.post("/api/preview/prepare")
async def preview_prepare(request: Request):
    """Copy an exported file to static/ as a temp file for iframe preview."""
    data = await request.json()
    source = Path(data.get("source_path", ""))
    if not source.exists():
        return JSONResponse({"error": "Source file not found"}, status_code=404)

    temp_name = f"_preview_{_secrets.token_urlsafe(8)}{source.suffix}"
    dest = BASE_DIR / "static" / temp_name
    shutil.copy2(str(source), str(dest))
    return JSONResponse({"ok": True, "temp_name": temp_name})


@app.post("/api/preview/cleanup")
async def preview_cleanup(request: Request):
    """Delete a temp preview file from static/."""
    data = await request.json()
    temp_name = data.get("temp_name", "")
    if not temp_name or not temp_name.startswith("_preview_"):
        return JSONResponse({"error": "Invalid temp file"}, status_code=400)
    temp_path = BASE_DIR / "static" / temp_name
    if temp_path.exists():
        temp_path.unlink()
    return JSONResponse({"ok": True})
