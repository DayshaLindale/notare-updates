"""Whisper Local Models plugin — Use bundled models before downloading.

Patches faster_whisper to check _internal/whisper_models/ first.
Bundled models: tiny.en (75MB), small.en (464MB)
"""
import os
import sys

_app_module = sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

# Set the HF cache to look at our bundled models first
_bundled = os.path.join(str(BASE_DIR), "_internal", "whisper_models")
if os.path.exists(_bundled):
    # Tell faster-whisper to check our bundled path
    os.environ.setdefault("WHISPER_MODELS_DIR", _bundled)

    # Monkey-patch WhisperModel to check bundled first
    try:
        import faster_whisper

        # WhisperModel location varies by version — find it
        _WhisperModel = None
        if hasattr(faster_whisper, 'WhisperModel'):
            _WhisperModel = faster_whisper.WhisperModel
        else:
            try:
                from faster_whisper.transcribe import WhisperModel as _WhisperModel
            except ImportError:
                pass

        if _WhisperModel is not None:
            _original_init = _WhisperModel.__init__

            def _patched_init(self, model_size_or_path, **kwargs):
                # Check if we have it bundled
                bundled_path = os.path.join(_bundled, model_size_or_path)
                if os.path.exists(bundled_path) and os.path.exists(os.path.join(bundled_path, "model.bin")):
                    # Use bundled model directly
                    _original_init(self, bundled_path, **kwargs)
                else:
                    # Fall back to download
                    _original_init(self, model_size_or_path, **kwargs)

            _WhisperModel.__init__ = _patched_init
            # Also ensure it's accessible on the module for other code
            if not hasattr(faster_whisper, 'WhisperModel'):
                faster_whisper.WhisperModel = _WhisperModel
            print(f"Whisper local models: {os.listdir(_bundled)}")
        else:
            print("Whisper local models: WhisperModel not found (plugin inactive)")
    except ImportError:
        pass
