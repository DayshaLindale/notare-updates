"""Engine Failover — ensures transcription works regardless of configuration.

ROOT CAUSE: Default settings ship with engine="whisper" and api_key="".
Neither faster-whisper nor assemblyai SDK are bundled in the exe.
The _cpu_env may or may not exist depending on installer tier.

This plugin replaces _run_transcription with resilient routing:
  1. Try the configured engine first
  2. If it fails, try the other engine
  3. If both fail, show a clear error with instructions

This runs AFTER assemblyai_shim.py and whisper_subprocess.py load
(alphabetical: 'e' comes after 'a' and before 'w').
"""
import sys
import logging
import threading

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")


def _can_use_assemblyai():
    """Check if AssemblyAI is usable (shim loaded + API key configured)."""
    api_key = _app.SETTINGS.get("api_key", "")
    if not api_key:
        return False
    try:
        import assemblyai
        return True
    except ImportError:
        return False


def _can_use_whisper():
    """Check if Whisper is usable (faster-whisper available or _cpu_env exists)."""
    # Check if whisper_subprocess patched the function
    # (it only patches if _cpu_env exists)
    try:
        from faster_whisper import WhisperModel
        return True
    except ImportError:
        pass

    # Check if _cpu_env exists (whisper_subprocess will install faster-whisper into it)
    from pathlib import Path
    import os
    base = _app.BASE_DIR
    manifest_path = base / "install_manifest.json"
    if manifest_path.exists():
        try:
            import json
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            tiers = manifest.get("installed_tiers", [])
            for tier_name, env_name in [("gpu", "_gpu_env"), ("cpu", "_cpu_env")]:
                if tier_name in tiers:
                    candidate = base / env_name / "Scripts" / "python.exe"
                    if candidate.exists():
                        return True
        except Exception:
            pass

    # Legacy env
    legacy = base / "_pyannote_env" / "Scripts" / "python.exe"
    if legacy.exists():
        return True

    return False


# Store original function
_original_run_transcription = _app._run_transcription if hasattr(_app, '_run_transcription') else None
_original_whisper = _app._run_transcription_whisper


def _resilient_transcription(job):
    """Resilient transcription — tries all available engines before failing."""
    engine = _app.SETTINGS.get("engine", "assemblyai")
    api_key = _app.SETTINGS.get("api_key", "")

    # Determine what's available
    has_aai = _can_use_assemblyai()
    has_whisper = _can_use_whisper()

    logger.info("Engine failover: configured=%s, assemblyai=%s (key=%s), whisper=%s",
                engine, has_aai, "set" if api_key else "empty", has_whisper)

    # Try configured engine first
    if engine == "whisper" and has_whisper:
        logger.info("Using configured engine: whisper")
        return _app._run_transcription_whisper(job)
    elif engine == "assemblyai" and has_aai:
        logger.info("Using configured engine: assemblyai")
        return _run_assemblyai(job)
    elif engine in ("deepgram", "rev"):
        # These use httpx which may not be available — try anyway
        if _original_run_transcription:
            try:
                return _original_run_transcription(job)
            except Exception as e:
                logger.warning("Configured engine %s failed: %s — trying fallbacks", engine, e)

    # Configured engine not available — try fallbacks
    if has_aai and engine != "assemblyai":
        logger.info("Configured engine unavailable, falling back to AssemblyAI")
        job["progress_message"] = "Using AssemblyAI (cloud)..."
        _app._save_job(job)
        return _run_assemblyai(job)

    if has_whisper and engine != "whisper":
        logger.info("Configured engine unavailable, falling back to local Whisper")
        job["progress_message"] = "Using local Whisper..."
        _app._save_job(job)
        return _app._run_transcription_whisper(job)

    # Nothing works — give a clear, actionable error
    if not api_key and not has_whisper:
        job["status"] = "error"
        job["error"] = (
            "No transcription engine available.\n\n"
            "To fix this, go to Settings and enter your AssemblyAI API key.\n"
            "Get a free key at assemblyai.com — includes free credits.\n\n"
            "Alternatively, if you installed the CPU or GPU package, "
            "local Whisper will be set up automatically on first use."
        )
    elif not api_key:
        job["status"] = "error"
        job["error"] = (
            "Please enter your AssemblyAI API key in Settings to enable transcription.\n"
            "Get a free key at assemblyai.com"
        )
    else:
        job["status"] = "error"
        job["error"] = (
            "Transcription engine failed to start. "
            "Please check your API key in Settings or restart Notare."
        )
    _app._save_job(job)
    logger.error("Engine failover: all engines failed. Error: %s", job.get("error", ""))


def _run_assemblyai(job):
    """Run the AssemblyAI transcription path from app.py."""
    # This replicates the assemblyai code path from _run_transcription
    # but calls it directly instead of going through the engine router
    try:
        import assemblyai as aai
    except ImportError:
        job["status"] = "error"
        job["error"] = "AssemblyAI engine not available"
        return

    aai.settings.api_key = _app.SETTINGS.get("api_key", "")
    if not aai.settings.api_key:
        job["status"] = "error"
        job["error"] = "No API key configured. Go to Settings to enter your AssemblyAI API key."
        return

    # Delegate to the original _run_transcription with engine forced to assemblyai
    # Save and restore the engine setting
    original_engine = _app.SETTINGS.get("engine")
    _app.SETTINGS["engine"] = "assemblyai"
    try:
        if _original_run_transcription:
            _original_run_transcription(job)
        else:
            job["status"] = "error"
            job["error"] = "Transcription function not found"
    finally:
        _app.SETTINGS["engine"] = original_engine


# Monkey-patch
_app._run_transcription = _resilient_transcription

logger.info("Engine failover: aai=%s, whisper=%s, configured=%s",
           _can_use_assemblyai(), _can_use_whisper(),
           _app.SETTINGS.get("engine", "unknown"))
print("Plugin loaded: engine_failover.py — resilient transcription routing active")
