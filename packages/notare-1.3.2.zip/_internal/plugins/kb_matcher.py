"""KB Matcher plugin — Monkey-patches the compiled _find_kb_answer function
with the improved version that uses question similarity, specificity, and fuzzy matching.
"""
import json as _json
import sys as _sys

# Get the compiled app module
_app_module = _sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

# Reload KB from disk (the compiled version may have loaded a stale copy)
_kb_path = BASE_DIR / "static" / "support_kb.json"
if not _kb_path.exists():
    _int = BASE_DIR / "_internal" / "static" / "support_kb.json"
    if _int.exists():
        _kb_path = _int

if _kb_path.exists():
    try:
        _app_module._support_kb = _json.loads(_kb_path.read_text(encoding="utf-8"))
    except Exception:
        pass


def _find_kb_answer_v2(question):
    """Improved KB matching with question similarity and fuzzy keywords."""
    kb = _app_module._support_kb
    if not kb:
        return None, 0
    q_lower = question.lower().strip()
    q_words = set(q_lower.split())

    best_match = None
    best_score = 0

    for entry in kb.get("entries", []):
        keywords = entry.get("keywords", [])
        entry_question = entry.get("question", "").lower()
        if not keywords:
            continue

        score = 0

        # 1. Question text similarity
        q_content_words = {w for w in q_words if len(w) > 2 and w not in ("what", "how", "does", "the", "is", "are", "can", "do", "my", "for", "and", "a", "an", "in", "to")}
        if q_content_words and entry_question:
            question_hits = sum(1 for w in q_content_words if w in entry_question)
            if question_hits > 0:
                question_ratio = question_hits / len(q_content_words)
                score += question_ratio * 5

        # 2. Exact keyword matches
        matched = sum(1 for kw in keywords if kw in q_lower)

        # 3. Multi-word keyword bonus
        for kw in keywords:
            if " " in kw and kw in q_lower:
                matched += 2

        # 4. Partial/fuzzy keyword matches
        if matched == 0:
            for kw in keywords:
                for qw in q_words:
                    if len(qw) >= 3 and (kw.startswith(qw) or qw.startswith(kw)):
                        matched += 0.5
                        break

        if matched == 0 and score == 0:
            continue

        specificity = matched / len(keywords) if keywords else 0
        score += matched + (specificity * 2)

        if score > best_score:
            best_score = score
            best_match = entry

    if best_match and best_score >= 1:
        confidence = min(best_score / 5.0, 1.0)
        return best_match, confidence
    return None, 0


# Monkey-patch: replace the compiled function on the module
_app_module._find_kb_answer = _find_kb_answer_v2
