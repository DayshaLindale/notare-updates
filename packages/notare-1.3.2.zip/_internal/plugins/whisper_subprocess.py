"""Whisper Subprocess plugin — runs faster-whisper in the _cpu_env via subprocess.

Solves: faster-whisper is not bundled in the PyInstaller frozen exe.
This plugin installs faster-whisper into the existing _cpu_env (one-time)
and monkey-patches _run_transcription_whisper to use subprocess execution,
matching the same pattern as pyannote_diarize.py.

Uses bundled models at _internal/whisper_models/ when available.
"""
import json
import logging
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

if 'BASE_DIR' not in dir():
    BASE_DIR = _app.BASE_DIR

logger = logging.getLogger("notare")

# ═══════════════════════════════════════════════════════════
# Discover Python env (same logic as pyannote_diarize.py)
# ═══════════════════════════════════════════════════════════
_whisper_python = None
_manifest_path = BASE_DIR / "install_manifest.json"
if _manifest_path.exists():
    try:
        _manifest = json.loads(_manifest_path.read_text(encoding="utf-8"))
        _tiers = _manifest.get("installed_tiers", [])
        if "gpu" in _tiers:
            _candidate = BASE_DIR / "_gpu_env" / "Scripts" / "python.exe"
            if _candidate.exists():
                _whisper_python = _candidate
        if not _whisper_python and "cpu" in _tiers:
            _candidate = BASE_DIR / "_cpu_env" / "Scripts" / "python.exe"
            if _candidate.exists():
                _whisper_python = _candidate
    except Exception:
        pass

if not _whisper_python:
    _legacy = BASE_DIR / "_pyannote_env" / "Scripts" / "python.exe"
    if _legacy.exists():
        _whisper_python = _legacy

if not _whisper_python:
    logger.info("Whisper subprocess: no Python env found — plugin inactive")
else:
    # ═══════════════════════════════════════════════════════════
    # Ensure faster-whisper is installed in the env (one-time)
    # ═══════════════════════════════════════════════════════════
    _fw_ready = False
    _fw_installing = False
    _fw_lock = threading.Lock()

    def _ensure_faster_whisper():
        """Install faster-whisper into the env if not already present."""
        global _fw_ready, _fw_installing
        with _fw_lock:
            if _fw_ready or _fw_installing:
                return _fw_ready
            _fw_installing = True

        try:
            # Check if already installed
            check = subprocess.run(
                [str(_whisper_python), "-c", "import faster_whisper; print('OK')"],
                capture_output=True, text=True, timeout=30,
            )
            if "OK" in check.stdout:
                _fw_ready = True
                logger.info("Whisper subprocess: faster-whisper already in env")
                return True

            # Install it
            logger.info("Whisper subprocess: installing faster-whisper into env...")
            pip = _whisper_python.parent / "pip.exe"
            result = subprocess.run(
                [str(pip), "install", "--no-cache-dir", "faster-whisper"],
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode == 0:
                _fw_ready = True
                logger.info("Whisper subprocess: faster-whisper installed successfully")
                return True
            else:
                logger.warning("Whisper subprocess: install failed: %s", result.stderr[-500:])
                return False
        except Exception as e:
            logger.warning("Whisper subprocess: install error: %s", e)
            return False
        finally:
            _fw_installing = False

    # Start install check in background so it's ready when needed
    threading.Thread(target=_ensure_faster_whisper, daemon=True).start()

    def _run_whisper_subprocess(job):
        """Replacement for _run_transcription_whisper using subprocess."""
        # Wait for faster-whisper install if still in progress
        for _ in range(60):
            if _fw_ready:
                break
            if not _fw_installing:
                if not _ensure_faster_whisper():
                    job["status"] = "error"
                    job["error"] = "Could not install Whisper engine. Check your internet connection."
                    return
                break
            time.sleep(1)
            job["progress_message"] = "Preparing Whisper engine..."
        else:
            job["status"] = "error"
            job["error"] = "Whisper engine installation timed out"
            return

        job["progress"] = 5
        job["progress_message"] = "Preparing audio..."

        job_dir = Path(job["dir"])
        audio_dir = job_dir / "audio"

        # Pre-processing: convert TRM and non-WAV files (uses ffmpeg, no faster-whisper needed)
        if hasattr(_app, '_convert_trm_files'):
            _app._convert_trm_files(job, audio_dir)

        ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
        for media_file in sorted(audio_dir.glob("*")):
            if media_file.suffix.lower() in (".webm", ".mp4", ".m4a", ".aac", ".flac"):
                wav_out = media_file.with_suffix(".wav")
                if not wav_out.exists():
                    try:
                        subprocess.run([ffmpeg_bin, "-y", "-i", str(media_file),
                                       "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                                       str(wav_out)], capture_output=True, text=True, timeout=600)
                    except Exception:
                        pass

        audio_files = sorted(audio_dir.glob("*.wav")) + sorted(audio_dir.glob("*.mp3"))
        if not audio_files:
            job["status"] = "error"
            job["error"] = "No audio files found"
            return

        # Concatenate multiple files if needed
        if len(audio_files) > 1 and len(job.get("speakers", [])) <= 1:
            concat_path = audio_dir / "full_session.wav"
            try:
                concat_list = audio_dir / "_concat.txt"
                with open(concat_list, "w") as f:
                    for af in audio_files:
                        f.write(f"file '{af.as_posix()}'\n")
                r = subprocess.run([ffmpeg_bin, "-y", "-f", "concat", "-safe", "0",
                                   "-i", str(concat_list), "-acodec", "pcm_s16le",
                                   "-ar", "16000", str(concat_path)],
                                  capture_output=True, text=True, timeout=1800)
                if r.returncode == 0:
                    audio_files = [concat_path]
                concat_list.unlink(missing_ok=True)
            except Exception as e:
                logger.warning("Concat failed: %s", e)

        # Multi-channel detection (uses stdlib wave)
        if len(audio_files) == 1 and audio_files[0].suffix.lower() == ".wav":
            try:
                import wave
                with wave.open(str(audio_files[0]), "rb") as wf:
                    nch = wf.getnchannels()
                if nch > 1:
                    logger.info("Multi-channel WAV detected: %d channels", nch)
                    job["audio_channels"] = nch
                    _transcribe_multichannel_subprocess(job, audio_files[0], nch)
                    return
            except Exception as e:
                logger.warning("Channel detection failed: %s", e)

        # Single-file transcription via subprocess
        model_size = _app.SETTINGS.get("whisper_model", "small.en")
        bundled_dir = str(BASE_DIR / "_internal" / "whisper_models")

        job["progress"] = 15
        job["progress_message"] = f"Loading Whisper {model_size}..."

        result_data = _run_whisper_script(str(audio_files[0]), model_size, bundled_dir, job)
        if result_data is None:
            return  # error already set on job

        job["transcript"] = result_data
        job["audio_file"] = audio_files[0].name

        # Speaker identification (same chain as original)
        job["progress_message"] = "Analyzing speakers..."
        _app._save_job(job)
        try:
            if not _app._diarize_with_pyannote(job):
                if hasattr(_app, '_diarize_audio') and not _app._diarize_audio(job):
                    if hasattr(_app, '_assign_speakers_heuristic'):
                        _app._assign_speakers_heuristic(job)
        except Exception as e:
            logger.warning("Diarization failed: %s", e)

        job["progress_message"] = "Identifying speakers from announcements..."
        _app._save_job(job)
        try:
            _app._identify_speakers_from_appearances(job)
        except Exception:
            pass
        try:
            _app._apply_channel_speaker_mapping(job)
        except Exception:
            pass
        try:
            if hasattr(_app, '_cleanup_speaker_names'):
                _app._cleanup_speaker_names(job)
        except Exception:
            pass

        # Save transcript
        if job.get("transcript"):
            with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
                json.dump(job["transcript"], f, indent=2)

        _app._auto_flag_issues(job)
        if hasattr(_app, '_auto_detect_styles'):
            _app._auto_detect_styles(job)
        _app._apply_proofing_rules(job)

        job["status"] = "complete"
        if hasattr(_app, '_feed_word_live_on_complete'):
            _app._feed_word_live_on_complete(job)
        job["progress"] = 100
        job["progress_message"] = "Complete"
        _app._save_job(job)
        logger.info("Job %s complete (Whisper subprocess): %d segments",
                    job["id"], len(job.get("transcript", {}).get("segments", [])))


    def _run_whisper_script(audio_path, model_size, bundled_dir, job):
        """Run faster-whisper transcription in subprocess. Returns transcript dict or None."""
        script = f'''
import warnings, os, sys, json
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"
# Redirect all non-JSON output to stderr
_real_stdout = sys.stdout
sys.stdout = sys.stderr
try:
    from faster_whisper import WhisperModel
    model_size = {repr(model_size)}
    bundled_dir = {repr(bundled_dir)}
    audio_path = {repr(audio_path)}

    # Check for bundled model
    bundled_model = os.path.join(bundled_dir, model_size)
    if os.path.exists(os.path.join(bundled_model, "model.bin")):
        model_path = bundled_model
    else:
        model_path = model_size  # will download from HuggingFace

    # Load model — CPU only in _cpu_env
    model = WhisperModel(model_path, device="cpu", compute_type="int8")

    segments_iter, info = model.transcribe(
        audio_path, language="en", beam_size=5,
        word_timestamps=True, vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=200),
    )

    segments = []
    for seg in segments_iter:
        seg_data = {{
            "start": round(seg.start * 1000),
            "end": round(seg.end * 1000),
            "text": seg.text.strip(),
            "avg_logprob": round(seg.avg_logprob, 4),
            "no_speech_prob": round(seg.no_speech_prob, 4),
            "speaker": "",
        }}
        if seg.words:
            seg_data["words"] = [
                {{"word": w.word, "start": round(w.start * 1000),
                  "end": round(w.end * 1000),
                  "confidence": round(w.probability, 3)}}
                for w in seg.words
            ]
            seg_data["confidence"] = round(
                sum(w.probability for w in seg.words) / len(seg.words), 3)
        segments.append(seg_data)

    result = {{
        "segments": segments,
        "full_text": " ".join(s["text"] for s in segments),
        "duration": round(info.duration * 1000),
        "language": info.language,
        "engine": f"whisper-{{model_size}}",
        "device": "cpu",
    }}
    sys.stdout = _real_stdout
    print(json.dumps(result))
except Exception as e:
    sys.stdout = _real_stdout
    print(json.dumps({{"error": str(e)}}))
    sys.exit(1)
'''
        try:
            job["progress"] = 25
            job["progress_message"] = "Transcribing with Whisper..."
            _app._save_job(job)

            script_file = Path(tempfile.mkdtemp(prefix="notare_")) / "run_whisper.py"
            script_file.write_text(script, encoding="utf-8")

            result = subprocess.run(
                [str(_whisper_python), str(script_file)],
                capture_output=True, text=True, timeout=1800,
            )

            if result.returncode != 0:
                err = result.stderr[-500:] if result.stderr else "no stderr"
                logger.warning("Whisper subprocess failed (rc=%d): %s", result.returncode, err)
                job["status"] = "error"
                job["error"] = f"Whisper transcription failed: {err[-200:]}"
                return None

            stdout = result.stdout.strip()
            json_start = stdout.rfind('{"')
            if json_start < 0:
                logger.warning("Whisper subprocess: no JSON output. stdout=%s stderr=%s",
                              stdout[-300:] if stdout else "empty",
                              result.stderr[-300:] if result.stderr else "empty")
                job["status"] = "error"
                job["error"] = "Whisper produced no output"
                return None

            # Extract just the JSON object (ignore trailing text)
            json_str = stdout[json_start:]
            # Find matching closing brace
            depth = 0
            json_end = len(json_str)
            for ci, ch in enumerate(json_str):
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        json_end = ci + 1
                        break
            data = json.loads(json_str[:json_end])
            if "error" in data:
                job["status"] = "error"
                job["error"] = f"Whisper error: {data['error']}"
                return None

            job["progress"] = 90
            job["progress_message"] = "Processing results..."
            return data

        except subprocess.TimeoutExpired:
            job["status"] = "error"
            job["error"] = "Whisper transcription timed out (30 min limit)"
            return None
        except Exception as e:
            job["status"] = "error"
            job["error"] = f"Whisper subprocess error: {e}"
            return None


    def _transcribe_multichannel_subprocess(job, audio_path, num_channels):
        """Handle multi-channel WAV by splitting and transcribing each channel."""
        job_dir = Path(job["dir"])
        audio_dir = job_dir / "audio"
        model_size = _app.SETTINGS.get("whisper_model", "small.en")
        bundled_dir = str(BASE_DIR / "_internal" / "whisper_models")
        speakers = job.get("speakers", [])

        ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
        all_segments = []

        for ch in range(num_channels):
            speaker_name = speakers[ch]["name"] if ch < len(speakers) else f"Channel {ch+1}"
            job["progress"] = 10 + int(70 * ch / num_channels)
            job["progress_message"] = f"Transcribing {speaker_name}..."
            _app._save_job(job)

            # Extract channel
            ch_path = audio_dir / f"_channel_{ch}.wav"
            try:
                r = subprocess.run([
                    ffmpeg_bin, "-y", "-i", str(audio_path),
                    "-filter_complex", f"[0:a]pan=mono|c0=c{ch}[out]",
                    "-map", "[out]", "-acodec", "pcm_s16le", "-ar", "16000",
                    str(ch_path),
                ], capture_output=True, text=True, timeout=600)
                if r.returncode != 0:
                    logger.warning("Channel %d extraction failed", ch)
                    continue
            except Exception as e:
                logger.warning("Channel %d extraction error: %s", ch, e)
                continue

            result_data = _run_whisper_script(str(ch_path), model_size, bundled_dir, job)
            if result_data and result_data.get("segments"):
                for seg in result_data["segments"]:
                    seg["speaker"] = speaker_name
                    seg["channel"] = ch
                all_segments.extend(result_data["segments"])

            # Cleanup temp channel file
            ch_path.unlink(missing_ok=True)

        all_segments.sort(key=lambda s: s["start"])

        job["transcript"] = {
            "segments": all_segments,
            "full_text": " ".join(s["text"] for s in all_segments),
            "duration": max((s["end"] for s in all_segments), default=0),
            "channels": num_channels,
            "engine": f"whisper-{model_size}",
            "device": "cpu",
        }
        job["audio_file"] = audio_path.name

        # Save and finalize
        if job.get("transcript"):
            with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
                json.dump(job["transcript"], f, indent=2)

        _app._auto_flag_issues(job)
        if hasattr(_app, '_auto_detect_styles'):
            _app._auto_detect_styles(job)
        _app._apply_proofing_rules(job)

        job["status"] = "complete"
        if hasattr(_app, '_feed_word_live_on_complete'):
            _app._feed_word_live_on_complete(job)
        job["progress"] = 100
        job["progress_message"] = "Complete"
        _app._save_job(job)
        logger.info("Job %s complete (Whisper multichannel subprocess): %d segments, %d channels",
                    job["id"], len(all_segments), num_channels)


    # ═══════════════════════════════════════════════════════════
    # Monkey-patch
    # ═══════════════════════════════════════════════════════════
    _app._run_transcription_whisper = _run_whisper_subprocess
    print("Plugin loaded: whisper_subprocess.py — subprocess Whisper active")
