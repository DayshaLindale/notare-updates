"""Attachments plugin — Upload/view/delete documents attached to a job.

These are reference documents alongside the transcript, not replacing it.
"""

@app.post("/api/job/{job_id}/attachment")
async def upload_attachment(job_id: str, file: UploadFile = File(...)):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    job_dir = Path(job["dir"])
    attach_dir = job_dir / "attachments"
    attach_dir.mkdir(parents=True, exist_ok=True)

    safe_name = re.sub(r'[^\w.\-]', '_', file.filename)
    dest = attach_dir / safe_name
    content = await file.read()
    with open(dest, "wb") as f:
        f.write(content)

    return JSONResponse({"ok": True, "filename": safe_name, "size": len(content)})


@app.get("/api/job/{job_id}/attachments")
async def list_attachments(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    attach_dir = Path(job["dir"]) / "attachments"
    if not attach_dir.exists():
        return JSONResponse({"attachments": []})

    files = []
    for f in sorted(attach_dir.iterdir()):
        if f.is_file():
            files.append({"filename": f.name, "size": f.stat().st_size})
    return JSONResponse({"attachments": files})


@app.get("/api/job/{job_id}/attachment/{filename}")
async def get_attachment(job_id: str, filename: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    file_path = Path(job["dir"]) / "attachments" / filename
    if not file_path.exists():
        return JSONResponse({"error": "Attachment not found"}, status_code=404)

    ext = file_path.suffix.lower()
    media_types = {
        '.pdf': 'application/pdf', '.txt': 'text/plain', '.rtf': 'application/rtf',
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
        '.tiff': 'image/tiff', '.bmp': 'image/bmp', '.csv': 'text/csv',
    }
    mt = media_types.get(ext, 'application/octet-stream')
    return FileResponse(str(file_path), filename=filename, media_type=mt)


@app.delete("/api/job/{job_id}/attachment/{filename}")
async def delete_attachment(job_id: str, filename: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    file_path = Path(job["dir"]) / "attachments" / filename
    if file_path.exists():
        file_path.unlink()
    return JSONResponse({"ok": True})
