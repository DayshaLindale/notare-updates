"""Fix Version Endpoint — patches the stale CURRENT_VERSION in app.py.

app.py has a hardcoded CURRENT_VERSION = "0.3.0" used by the local /api/update
endpoint. This causes the settings page to show a stale "Update available" banner.
The real OTA system uses the Render server via the auto_update plugin.

Fix: set CURRENT_VERSION to the actual version from settings.json so the
existing endpoint logic correctly returns update_available: False.
"""
import sys

_app_module = sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

_real_version = _app_module.SETTINGS.get("version", "1.0.0")
_old_version = getattr(_app_module, "CURRENT_VERSION", "unknown")

_app_module.CURRENT_VERSION = _real_version

print(f"Plugin loaded: fix_version_endpoint.py — CURRENT_VERSION {_old_version} -> {_real_version}")
