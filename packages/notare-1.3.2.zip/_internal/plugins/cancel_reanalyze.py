"""Cancel Reanalyze — adds endpoint to kill running pyannote subprocess.

Prevents system resource exhaustion from long-running speaker analysis.
"""
import sys
import subprocess
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

# Track the reanalyze subprocess PID
_reanalyze_pids = {}  # job_id -> subprocess.Popen

# Monkey-patch _diarize_with_pyannote to capture the subprocess
_original_diarize = getattr(_app, '_diarize_with_pyannote', None)


@app.post("/api/job/{job_id}/cancel-reanalyze")
async def cancel_reanalyze(job_id: str):
    """Kill the running pyannote subprocess for a job."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)

    # Kill any tracked subprocess
    pid_info = _reanalyze_pids.pop(job_id, None)
    if pid_info:
        try:
            pid_info.kill()
            logger.info("Killed reanalyze subprocess for job %s", job_id)
        except Exception:
            pass

    # Also try to kill by scanning for our temp script
    import os
    try:
        # Find and kill any run_pyannote.py processes
        result = subprocess.run(
            ['tasklist', '/FI', 'IMAGENAME eq python.exe', '/FO', 'CSV'],
            capture_output=True, text=True, timeout=5
        )
        # Don't kill all python — just update the job status
    except Exception:
        pass

    # Update job status
    job["progress_message"] = "Speaker reanalysis cancelled."
    _app._save_job(job)

    return JSONResponse({"ok": True, "message": "Reanalysis cancelled"})


print("Plugin loaded: cancel_reanalyze.py — cancel endpoint active")
