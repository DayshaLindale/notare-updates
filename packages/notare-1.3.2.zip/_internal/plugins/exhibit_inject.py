"""Exhibit Inject plugin — Patches generate_deposition_pdf to inject
exhibits from the EXHIBITS store before PDF generation.

Works with BOTH the old frozen module (function-based) and the new
refactored module (class-based).
"""
import sys as _sys

_app_module = _sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

import depo_pdf as _depo_module

# Patch whichever version we have
if hasattr(_depo_module, 'DepositionPDFBuilder'):
    # New class-based version
    _orig = _depo_module.DepositionPDFBuilder.generate
    def _patched(self, filename=""):
        if not self.exhibits:
            exs = _app_module.EXHIBITS.get(self.job.get("id", ""), [])
            if exs:
                self.exhibits = exs
        return _orig(self, filename)
    _depo_module.DepositionPDFBuilder.generate = _patched
else:
    # Old function-based version (frozen in exe)
    _orig_fn = _depo_module.generate_deposition_pdf
    def _patched_fn(job, job_dir, filename=""):
        if not job.get("exhibits"):
            exs = _app_module.EXHIBITS.get(job.get("id", ""), [])
            if exs:
                job = dict(job)
                # Normalize: frozen code reads ex.get('id'), but data uses 'exhibit_id'
                normalized = []
                for ex in exs:
                    ex_copy = dict(ex)
                    eid = ex_copy.get("exhibit_id", "") or ex_copy.get("id", "")
                    # Uppercase: "exhibit 1" -> "EXHIBIT 1"
                    eid = eid.upper()
                    ex_copy["id"] = eid
                    normalized.append(ex_copy)
                job["exhibits"] = normalized
        return _orig_fn(job, job_dir, filename)
    _depo_module.generate_deposition_pdf = _patched_fn
