"""Whisper Bootstrap plugin — Downloads tiny.en and small.en on first launch
if they aren't already cached. Runs in background, doesn't block startup.

This ensures every user has at least two models ready to go without
needing to wait during their first transcription job.
"""
import os
import sys
import threading

_app_module = sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

_models_dir = os.path.join(str(BASE_DIR), "_internal", "whisper_models")
os.makedirs(_models_dir, exist_ok=True)

def _bootstrap_models():
    """Download tiny.en and small.en in the background if not present."""
    models_to_check = ["tiny.en", "small.en"]

    # Check install manifest for GPU tier (large-v3-turbo already provided by installer)
    _manifest_path = os.path.join(str(BASE_DIR), "install_manifest.json")
    _gpu_installed = False
    if os.path.exists(_manifest_path):
        try:
            import json as _jm
            _m = _jm.loads(open(_manifest_path, encoding="utf-8").read())
            if "gpu" in _m.get("installed_tiers", []):
                _gpu_installed = True
        except Exception:
            pass

    if _gpu_installed:
        models_to_check.append("large-v3-turbo")
        print("Whisper bootstrap: GPU tier installed — including large-v3-turbo")
    else:
        # Fallback: try torch.cuda detection (works if torch is available)
        try:
            import torch
            if torch.cuda.is_available():
                vram = torch.cuda.get_device_properties(0).total_mem / 1024**3
                if vram >= 6:
                    models_to_check.append("large-v3-turbo")
                    print(f"Whisper bootstrap: GPU detected ({vram:.0f}GB) — including large-v3-turbo")
        except Exception:
            pass

    for model_name in models_to_check:
        model_path = os.path.join(_models_dir, model_name)
        model_bin = os.path.join(model_path, "model.bin")

        if os.path.exists(model_bin):
            print(f"Whisper {model_name}: already bundled")
            continue

        # Check HuggingFace cache too
        hf_cache = os.path.expanduser(f"~/.cache/huggingface/hub/models--Systran--faster-whisper-{model_name}")
        if os.path.exists(hf_cache):
            # Copy from cache to bundled location
            try:
                import glob
                snapshots = glob.glob(os.path.join(hf_cache, "snapshots", "*", "model.bin"))
                if snapshots:
                    snapshot_dir = os.path.dirname(snapshots[0])
                    os.makedirs(model_path, exist_ok=True)
                    import shutil
                    for f in os.listdir(snapshot_dir):
                        shutil.copy2(os.path.join(snapshot_dir, f), os.path.join(model_path, f))
                    print(f"Whisper {model_name}: copied from HF cache")
                    continue
            except Exception as e:
                print(f"Whisper {model_name}: cache copy failed: {e}")

        # Download fresh
        try:
            print(f"Whisper {model_name}: downloading...")
            from faster_whisper import WhisperModel
            # This triggers the download to HF cache
            _m = WhisperModel(model_name, device="cpu", compute_type="int8")
            del _m

            # Now copy from cache to bundled
            import glob
            snapshots = glob.glob(os.path.join(hf_cache, "snapshots", "*", "model.bin"))
            if snapshots:
                snapshot_dir = os.path.dirname(snapshots[0])
                os.makedirs(model_path, exist_ok=True)
                import shutil
                for f in os.listdir(snapshot_dir):
                    shutil.copy2(os.path.join(snapshot_dir, f), os.path.join(model_path, f))
                print(f"Whisper {model_name}: downloaded and bundled")
        except Exception as e:
            print(f"Whisper {model_name}: download failed: {e}")

# Run in background so it doesn't block startup
threading.Thread(target=_bootstrap_models, daemon=True).start()
