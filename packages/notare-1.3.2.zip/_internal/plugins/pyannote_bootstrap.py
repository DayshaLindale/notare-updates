"""Pyannote Bootstrap plugin — Ensures speaker diarization models are available.

If _pyannote_models/ was bundled with the installer, this does nothing.
If not (OTA update path), downloads the pre-packaged model archive from
the Notare update server. No HuggingFace account or token needed —
the models are hosted on our own infrastructure.

Runs in background, doesn't block startup.
"""
import os
import sys
import threading
import zipfile

_app_module = sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

_base = str(BASE_DIR)
_models_dir = os.path.join(_base, "_pyannote_models")
_internal_models = os.path.join(_base, "_internal", "_pyannote_models")

# Model archive hosted on the Notare update server
_MODEL_URL = "https://notare-updates.onrender.com/static/pyannote_models.zip"
_MODEL_SIZE_MB = 200  # approximate, for progress display


def _ensure_models():
    """Check for pyannote models, download from Notare server if missing."""
    # Already have models — either bundled or from a previous download
    for path in [_models_dir, _internal_models]:
        config = os.path.join(path, "config.yaml")
        pipeline_config = os.path.join(path, "pipeline", "config.yaml")
        if os.path.exists(config) or os.path.exists(pipeline_config):
            print(f"Pyannote models: found at {path}")
            return

    # Not present — download from our server
    print(f"Pyannote models: not found, downloading from Notare server (~{_MODEL_SIZE_MB}MB)...")

    try:
        import urllib.request
        zip_path = os.path.join(_base, "_pyannote_models.zip")

        urllib.request.urlretrieve(_MODEL_URL, zip_path)
        print("Pyannote models: download complete, extracting...")

        os.makedirs(_models_dir, exist_ok=True)
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(_models_dir)

        os.remove(zip_path)
        print(f"Pyannote models: ready at {_models_dir}")

    except Exception as e:
        print(f"Pyannote models: download failed: {e}")
        print("Speaker diarization will use fallback method until models are available.")


# Skip bootstrap if the smart installer already provided pyannote
_skip_bootstrap = False
_manifest_path = os.path.join(_base, "install_manifest.json")
if os.path.exists(_manifest_path):
    try:
        import json as _jm
        _m = _jm.loads(open(_manifest_path, encoding="utf-8").read())
        _installed = _m.get("installed_tiers", [])
        if "cpu" in _installed or "gpu" in _installed:
            _skip_bootstrap = True
            print("Pyannote models: handled by smart installer (skipping bootstrap)")
    except Exception:
        pass

if not _skip_bootstrap:
    threading.Thread(target=_ensure_models, daemon=True).start()
