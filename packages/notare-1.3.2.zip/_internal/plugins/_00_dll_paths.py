"""DLL + Import Fix — preloads ctranslate2 DLL and ensures WhisperModel is importable.

MUST load before any plugin that imports faster_whisper or ctranslate2.
Named _00_ to sort first alphabetically in the plugin loader.

Solves: In frozen PyInstaller exe, ctranslate2's .pyd can't find
ctranslate2.dll, AND faster_whisper's PYZ-compiled __init__.py
can't chain-import from its submodules correctly.
"""
import os
import sys
import ctypes

# Force CPU-only mode — CUDA DLLs (cublas64_12.dll etc.) not bundled in base installer
# Without this, ctranslate2 tries to load CUDA and crashes hard
os.environ["CUDA_VISIBLE_DEVICES"] = ""

# Find the _internal directory
if getattr(sys, 'frozen', False):
    _internal = os.path.join(os.path.dirname(sys.executable), '_internal')
else:
    _internal = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(_internal) == 'plugins':
        _internal = os.path.dirname(_internal)

_ct2_dir = os.path.join(_internal, 'ctranslate2')
_ct2_dll = os.path.join(_ct2_dir, 'ctranslate2.dll')
_iomp_dll = os.path.join(_ct2_dir, 'libiomp5md.dll')

# Step 1: Add DLL directories
if os.path.isdir(_ct2_dir):
    try:
        os.add_dll_directory(_ct2_dir)
        os.add_dll_directory(_internal)
    except (OSError, AttributeError):
        os.environ['PATH'] = _ct2_dir + os.pathsep + _internal + os.pathsep + os.environ.get('PATH', '')

# Step 2: Preload DLLs with ctypes (most reliable method)
_loaded = []
for dll_path in [_iomp_dll, _ct2_dll]:
    if os.path.exists(dll_path):
        try:
            ctypes.CDLL(dll_path)
            _loaded.append(os.path.basename(dll_path))
        except OSError as e:
            print(f"DLL preload failed for {os.path.basename(dll_path)}: {e}")

if _loaded:
    print(f"DLL preloaded: {', '.join(_loaded)}")

# Step 3: Try importing ctranslate2 first (before faster_whisper)
_ct2_ok = False
try:
    import ctranslate2
    _ct2_ok = True
except ImportError as e:
    print(f"ctranslate2 import failed: {e}")
except Exception as e:
    print(f"ctranslate2 error: {e}")

# Step 4: Try importing WhisperModel
_fw_ok = False
if _ct2_ok:
    try:
        from faster_whisper import WhisperModel
        _fw_ok = True
    except ImportError:
        # PYZ might have broken the chain — try direct submodule import
        try:
            from faster_whisper.transcribe import WhisperModel
            import faster_whisper
            faster_whisper.WhisperModel = WhisperModel
            _fw_ok = True
            print("WhisperModel imported via direct submodule path")
        except ImportError as e2:
            print(f"WhisperModel import failed (both paths): {e2}")
    except Exception as e:
        print(f"WhisperModel error: {e}")

if _fw_ok:
    # Check if CUDA is actually available (cublas DLL loadable)
    _cuda_available = False
    for _cuda_search in [_ct2_dir, _internal, os.path.join(_internal, 'torch', 'lib')]:
        _cublas = os.path.join(_cuda_search, 'cublas64_12.dll')
        if os.path.exists(_cublas):
            try:
                ctypes.CDLL(_cublas)
                _cuda_available = True
                print(f"CUDA available: cublas loaded from {_cuda_search}")
                break
            except OSError:
                pass
    # Also check system torch install
    if not _cuda_available:
        try:
            import torch
            if torch.cuda.is_available():
                _cuda_available = True
                print("CUDA available via torch")
        except (ImportError, Exception):
            pass

    if not _cuda_available:
        # Force CPU — no CUDA DLLs on this machine
        _OrigWhisperModel = WhisperModel
        class _CPUWhisperModel(_OrigWhisperModel):
            def __init__(self, model_size_or_path, device="cpu", compute_type="int8", **kwargs):
                kwargs.pop('device', None)
                kwargs.pop('compute_type', None)
                super().__init__(model_size_or_path, device="cpu", compute_type="int8", **kwargs)
        import faster_whisper
        import faster_whisper.transcribe
        faster_whisper.WhisperModel = _CPUWhisperModel
        faster_whisper.transcribe.WhisperModel = _CPUWhisperModel
        sys.modules['faster_whisper'].__dict__['WhisperModel'] = _CPUWhisperModel
        sys.modules['faster_whisper.transcribe'].__dict__['WhisperModel'] = _CPUWhisperModel
        print("DLL fix verified: WhisperModel patched to CPU-only (no CUDA found)")
    else:
        print("DLL fix verified: WhisperModel with CUDA support")
else:
    print(f"DLL fix: ctranslate2={'OK' if _ct2_ok else 'FAIL'}, WhisperModel={'OK' if _fw_ok else 'FAIL'}")
