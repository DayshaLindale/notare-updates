"""AssemblyAI Shim — Provides the assemblyai SDK interface using urllib (stdlib).

Solves: The assemblyai pip package was not bundled in the PyInstaller exe,
causing 'import assemblyai' to fail and all transcription to error out.
This plugin injects a lightweight shim module into sys.modules so that
app.py's 'import assemblyai as aai' succeeds using only stdlib urllib.
"""
import json
import logging
import sys
import time
import types
import urllib.request
import urllib.error

_logger = logging.getLogger("notare")

# Only install the shim if the real SDK is not available
try:
    import assemblyai
    print("AssemblyAI SDK found (shim not needed)")
except ImportError:
    # Build the shim module
    _mod = types.ModuleType("assemblyai")
    _mod.__package__ = "assemblyai"
    _mod.__path__ = []

    _API_BASE = "https://api.assemblyai.com/v2"

    # Retry config
    _MAX_POLL_TIME = 3600       # 60 minutes max poll time
    _POLL_INTERVAL = 3          # seconds between polls
    _UPLOAD_TIMEOUT = 600       # 10 min upload timeout (large files)
    _POLL_TIMEOUT = 30          # 30s timeout per poll request
    _RETRY_ATTEMPTS = 5         # retries on transient network errors
    _RETRY_BACKOFF = 2          # exponential backoff base (2, 4, 8, 16, 32s)

    class _Settings:
        api_key = ""
    _mod.settings = _Settings()

    class TranscriptStatus:
        error = "error"
        completed = "completed"
        queued = "queued"
        processing = "processing"
    _mod.TranscriptStatus = TranscriptStatus

    class TranscriptionConfig:
        def __init__(self, speaker_labels=False, language_code="en",
                     punctuate=True, format_text=True, **kwargs):
            self.speaker_labels = speaker_labels
            self.language_code = language_code
            self.punctuate = punctuate
            self.format_text = format_text
            self.extra = kwargs
    _mod.TranscriptionConfig = TranscriptionConfig

    class _Word:
        def __init__(self, data):
            self.text = data.get("text", "")
            self.start = data.get("start", 0)
            self.end = data.get("end", 0)
            self.confidence = data.get("confidence", 0.0)

    class _Utterance:
        def __init__(self, data):
            self.text = data.get("text", "")
            self.start = data.get("start", 0)
            self.end = data.get("end", 0)
            self.speaker = data.get("speaker", "")
            self.confidence = data.get("confidence", 0.0)
            self.words = [_Word(w) for w in data.get("words", [])]

    class _Transcript:
        def __init__(self, data):
            self.status = data.get("status", "error")
            self.error = data.get("error")
            self.text = data.get("text", "")
            self.audio_duration = data.get("audio_duration")
            raw_utts = data.get("utterances") or []
            raw_words = data.get("words") or []
            self.utterances = [_Utterance(u) for u in raw_utts] if raw_utts else None
            self.words = [_Word(w) for w in raw_words] if raw_words else None

    def _is_transient(exc):
        """Check if an exception is a transient network error worth retrying."""
        if isinstance(exc, urllib.error.HTTPError):
            return exc.code in (429, 500, 502, 503, 504)
        if isinstance(exc, (urllib.error.URLError, TimeoutError, ConnectionError, OSError)):
            return True
        return False

    def _api_call(endpoint, api_key, json_data=None, binary=None, timeout=None):
        """Make a request to AssemblyAI REST API with retry on transient errors."""
        url = f"{_API_BASE}/{endpoint}"
        headers = {"Authorization": api_key}
        if timeout is None:
            timeout = _POLL_TIMEOUT

        if binary is not None:
            headers["Content-Type"] = "application/octet-stream"
            req = urllib.request.Request(url, data=binary, headers=headers, method="POST")
        elif json_data is not None:
            body = json.dumps(json_data).encode()
            headers["Content-Type"] = "application/json"
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        else:
            req = urllib.request.Request(url, headers=headers)

        last_exc = None
        for attempt in range(_RETRY_ATTEMPTS):
            try:
                resp = urllib.request.urlopen(req, timeout=timeout)
                return json.loads(resp.read().decode())
            except Exception as e:
                last_exc = e
                if not _is_transient(e) or attempt == _RETRY_ATTEMPTS - 1:
                    raise
                wait = _RETRY_BACKOFF ** attempt
                _logger.info("AssemblyAI API transient error (attempt %d/%d), retrying in %ds: %s",
                            attempt + 1, _RETRY_ATTEMPTS, wait, e)
                time.sleep(wait)
        raise last_exc

    def _upload_streaming(audio_path, api_key):
        """Upload audio file with streaming to avoid loading entire file into memory."""
        import io
        import os

        file_size = os.path.getsize(audio_path)
        url = f"{_API_BASE}/upload"
        headers = {
            "Authorization": api_key,
            "Content-Type": "application/octet-stream",
            "Content-Length": str(file_size),
            "Transfer-Encoding": "chunked",
        }

        # For files under 100MB, read into memory (simpler, fewer edge cases)
        if file_size < 100 * 1024 * 1024:
            with open(audio_path, "rb") as f:
                return _api_call("upload", api_key, binary=f.read(), timeout=_UPLOAD_TIMEOUT)

        # For larger files, stream in chunks
        CHUNK_SIZE = 5 * 1024 * 1024  # 5MB chunks

        class _ChunkedReader:
            """File-like wrapper that reads in chunks for urllib."""
            def __init__(self, path, size):
                self._fp = open(path, "rb")
                self._size = size
                self._read = 0
            def read(self, n=-1):
                if n == -1:
                    n = CHUNK_SIZE
                data = self._fp.read(min(n, CHUNK_SIZE))
                self._read += len(data)
                return data
            def __len__(self):
                return self._size
            def close(self):
                self._fp.close()

        reader = _ChunkedReader(audio_path, file_size)
        try:
            req = urllib.request.Request(url, data=reader, headers={
                "Authorization": api_key,
                "Content-Type": "application/octet-stream",
                "Content-Length": str(file_size),
            }, method="POST")
            resp = urllib.request.urlopen(req, timeout=_UPLOAD_TIMEOUT)
            return json.loads(resp.read().decode())
        finally:
            reader.close()

    class Transcriber:
        def transcribe(self, audio_path, config=None):
            api_key = _mod.settings.api_key
            if not api_key:
                return _Transcript({"status": "error", "error": "No API key configured"})

            try:
                # Upload audio (streaming for large files)
                upload_resp = _upload_streaming(audio_path, api_key)
                upload_url = upload_resp["upload_url"]

                # Build transcription request
                req_data = {
                    "audio_url": upload_url,
                    "language_code": config.language_code if config else "en",
                    "punctuate": config.punctuate if config else True,
                    "format_text": config.format_text if config else True,
                }
                if config and config.speaker_labels:
                    req_data["speaker_labels"] = True

                # Pass through extra config (word_boost, custom_spelling, etc.)
                if config and config.extra:
                    req_data.update(config.extra)

                # Submit transcription
                tx_resp = _api_call("transcript", api_key, json_data=req_data)
                tx_id = tx_resp.get("id")
                if not tx_id:
                    api_error = tx_resp.get("error", json.dumps(tx_resp)[:200])
                    return _Transcript({"status": "error",
                                        "error": f"AssemblyAI rejected request: {api_error}"})

                # Poll until complete (with timeout and retry)
                poll_start = time.time()
                consecutive_errors = 0
                while True:
                    elapsed = time.time() - poll_start
                    if elapsed > _MAX_POLL_TIME:
                        return _Transcript({
                            "status": "error",
                            "error": f"Transcription timed out after {int(elapsed/60)} minutes. "
                                     f"Transcript ID: {tx_id}"
                        })

                    try:
                        result = _api_call(f"transcript/{tx_id}", api_key)
                        consecutive_errors = 0  # reset on success
                    except Exception as poll_err:
                        consecutive_errors += 1
                        if consecutive_errors >= 10:
                            return _Transcript({
                                "status": "error",
                                "error": f"Lost connection to AssemblyAI after {consecutive_errors} "
                                         f"consecutive failures. Transcript ID: {tx_id} — "
                                         f"last error: {poll_err}"
                            })
                        _logger.warning("AssemblyAI poll error (%d consecutive): %s",
                                       consecutive_errors, poll_err)
                        time.sleep(_POLL_INTERVAL * consecutive_errors)
                        continue

                    status = result.get("status")
                    if status == "completed":
                        return _Transcript(result)
                    if status == "error":
                        return _Transcript(result)
                    # queued or processing — keep polling
                    time.sleep(_POLL_INTERVAL)

            except Exception as e:
                _logger.error("AssemblyAI transcription failed: %s", e)
                return _Transcript({"status": "error", "error": str(e)})

    _mod.Transcriber = Transcriber

    # Install the shim
    sys.modules["assemblyai"] = _mod
    print("Plugin loaded: assemblyai_shim.py — stdlib REST shim active")
