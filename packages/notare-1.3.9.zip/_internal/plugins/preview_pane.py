"""Preview pane plugin — live preview of the transcript using the WORD export engine.

Generates a Word document using the profile's template (.dotm with paragraph
styles), then converts to PDF via Word COM for browser display.
Falls back to depo_pdf or HTML if Word/template unavailable.

Registers:
  GET /api/job/{job_id}/preview       — returns PDF (via Word) or HTML fallback
  GET /api/job/{job_id}/preview/hash  — lightweight content hash for smart refresh
"""
import logging
import sys
import tempfile
import os

logger = logging.getLogger("notare")

_app_mod = sys.modules.get("app")


@app.get("/api/job/{job_id}/preview/hash")
async def preview_hash(job_id: str):
    """Return a lightweight hash so the frontend knows when to reload the preview."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"hash": ""})
    segments = job.get("transcript", {}).get("segments", [])
    _last = segments[-1].get("text", "")[:50] if segments else ""
    _h = f"{len(segments)}:{_last}"
    return JSONResponse({"hash": _h})


def _merge_profile(job):
    """Merge profile into job — only if explicitly selected."""
    profile = job.get("profile", {})
    profile_name = profile.get("name", "") or job.get("jurisdiction_profile", "")
    # Do NOT auto-select a profile. No profile = no template.
    if profile_name and profile_name in PROFILES:
        current_profile = PROFILES[profile_name]
        for k, v in current_profile.items():
            if v and (not profile.get(k) or k in (
                "word_styles", "lines_per_page", "cover_logo",
                "header_image", "footer_image", "watermark_text"
            )):
                profile[k] = v
    job["profile"] = profile
    return profile


def _word_to_pdf(docx_path, pdf_path, keep_line_numbers=False):
    """Convert a Word document to PDF using Word COM automation.
    Returns True on success, False if Word is not available."""
    try:
        import win32com.client
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        word.DisplayAlerts = False
        doc = word.Documents.Open(str(docx_path))
        # Only strip line numbering for non-deposition formats
        if not keep_line_numbers:
            for section in doc.Sections:
                section.PageSetup.LineNumbering.Active = False
        doc.SaveAs(str(pdf_path), FileFormat=17)  # 17 = wdFormatPDF
        doc.Close(False)
        word.Quit()
        return True
    except Exception as e:
        logger.debug("Word COM PDF conversion failed: %s", e)
        return False


@app.get("/api/job/{job_id}/preview")
async def preview_transcript(job_id: str):
    """Generate a preview using the Word template, converted to PDF for display."""
    from fastapi.responses import HTMLResponse

    job = JOBS.get(job_id)
    if not job:
        return HTMLResponse("<p>Job not found</p>", status_code=404)

    transcript = job.get("transcript", {})
    segments = transcript.get("segments", [])
    if not segments:
        return HTMLResponse(
            "<p style='color:#999;padding:40px;text-align:center;font-style:italic;'>"
            "No transcript yet — start recording or upload audio to see a preview.</p>"
        )

    profile = _merge_profile(job)

    # --- Strategy 1: Word template → Word doc → PDF via COM ---
    # Only when a profile with a template is explicitly selected.
    # No profile = clean HTML preview (no template formatting forced).
    _export_word = getattr(_app_mod, '_export_word', None)
    word_styles = profile.get("word_styles", {})
    template_path = word_styles.get("template_path", "")

    if _export_word and template_path and job.get("jurisdiction_profile"):
        try:
            _preview_dir = Path(tempfile.mkdtemp(prefix="notare_wpreview_"))
            # Call the real Word export engine — it returns JSONResponse but
            # also writes the docx to _preview_dir
            result = _export_word(job, _preview_dir, filename="_preview")
            # Find the generated docx/docm
            _docx_files = list(_preview_dir.glob("*.doc*"))
            if not _docx_files:
                # _export_word may have saved to exports/ — check the response
                if hasattr(result, 'body'):
                    try:
                        _rdata = json.loads(result.body)
                        _rpath = _rdata.get("path", "")
                        if _rpath and os.path.exists(_rpath):
                            _docx_files = [Path(_rpath)]
                    except Exception:
                        pass
            if _docx_files:
                _docx_path = _docx_files[0]
                _pdf_path = _preview_dir / "_preview.pdf"
                # Convert to PDF via Word COM
                _is_depo = "depo" in job.get("proceeding_type", "").lower()
                if _word_to_pdf(str(_docx_path.resolve()), str(_pdf_path.resolve()), keep_line_numbers=_is_depo):
                    if _pdf_path.exists():
                        return FileResponse(
                            str(_pdf_path),
                            media_type="application/pdf",
                            headers={"Cache-Control": "no-cache, no-store"}
                        )
        except Exception as e:
            logger.debug("Word template preview failed: %s", e)

    # --- Strategy 2: depo_pdf — ONLY for deposition format ---
    # depo_pdf always generates 25-line numbered pages (deposition standard).
    # Skip for non-deposition jobs — go to clean HTML instead.
    _proceeding = job.get("proceeding_type", "").lower()
    _is_depo = "depo" in _proceeding
    try:
        if not _is_depo:
            raise ImportError("Not a deposition — skip to HTML")
        _depo_pdf_path = BASE_DIR / "_internal" / "depo_pdf.py"
        if not _depo_pdf_path.exists():
            _depo_pdf_path = BASE_DIR / "depo_pdf.py"

        if _depo_pdf_path.exists():
            import importlib.util
            _spec = importlib.util.spec_from_file_location("depo_pdf_live", str(_depo_pdf_path))
            _depo_mod = importlib.util.module_from_spec(_spec)
            _spec.loader.exec_module(_depo_mod)
            generate_deposition_pdf = _depo_mod.generate_deposition_pdf
        else:
            from depo_pdf import generate_deposition_pdf

        _preview_dir = Path(tempfile.mkdtemp(prefix="notare_preview_"))
        _preview_path = generate_deposition_pdf(job, _preview_dir, filename="_preview")
        if _preview_path and Path(_preview_path).exists():
            return FileResponse(
                str(_preview_path),
                media_type="application/pdf",
                headers={"Cache-Control": "no-cache, no-store"}
            )
    except Exception as e:
        logger.debug("PDF preview generation failed (falling back to HTML): %s", e)

    # --- Strategy 3: styled HTML fallback ---
    _fmt_label = getattr(_app_mod, '_format_speaker_label_export', None)

    court_name = job.get("court_name", "")
    case_caption = job.get("case_caption", "")
    case_number = job.get("case_number", "")
    date_str = job.get("date", "")
    proceeding_type = job.get("proceeding_type", "")
    reporter_name = job.get("reporter_name", "")

    lines = []
    lines.append('<!DOCTYPE html><html><head><meta charset="UTF-8"><style>')
    lines.append("@import url('https://fonts.googleapis.com/css2?family=Courier+Prime&display=swap');")
    lines.append('body{font-family:"Courier Prime","Courier New",monospace;font-size:13px;'
                 'line-height:2;margin:0;padding:24px 32px;color:#1a1a2a;background:white}')
    lines.append('.hdr{text-align:center;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid #ccc}')
    lines.append('.hdr .court{font-size:14px;font-weight:bold;text-transform:uppercase;letter-spacing:1px}')
    lines.append('.hdr .cap{font-size:13px;margin:8px 0} .hdr .sub{font-size:12px;color:#666}')
    lines.append('.spk{font-weight:bold;text-transform:uppercase;margin-top:16px;margin-bottom:2px}')
    lines.append('.ln{display:flex;gap:12px} .ln-n{color:#999;min-width:28px;text-align:right;'
                 'user-select:none;flex-shrink:0} .ln-t{flex:1}')
    lines.append('.par{text-indent:40px;font-style:italic;color:#555}')
    lines.append('.ft{text-align:center;margin-top:24px;padding-top:12px;border-top:1px solid #ccc;'
                 'font-size:11px;color:#999}')
    lines.append('</style></head><body>')

    if court_name or case_caption:
        lines.append('<div class="hdr">')
        if court_name:
            lines.append(f'<div class="court">{court_name}</div>')
        if case_caption:
            lines.append(f'<div class="cap">{case_caption}</div>')
        if case_number:
            lines.append(f'<div class="sub">Case No. {case_number}</div>')
        if proceeding_type or date_str:
            parts = [p for p in [proceeding_type, date_str] if p]
            lines.append(f'<div class="sub">{" — ".join(parts)}</div>')
        lines.append('</div>')

    # Show line numbers ONLY for deposition format
    _proceeding = job.get("proceeding_type", "").lower()
    _show_line_nums = "depo" in _proceeding or profile.get("lines_per_page")

    ln = 1
    last_spk = ""
    for seg in segments:
        spk = seg.get("speaker", "").strip()
        txt = seg.get("text", "").strip()
        if not txt:
            continue
        fspk = _fmt_label(spk) if (_fmt_label and spk) else spk.upper()
        if spk and spk != last_spk:
            if _show_line_nums:
                lines.append(f'<div class="ln"><span class="ln-n">{ln}</span>'
                             f'<span class="ln-t spk">{fspk}:</span></div>')
                ln += 1
            else:
                lines.append(f'<div class="spk">{fspk}:</div>')
            last_spk = spk
        is_par = txt.startswith("(") and txt.endswith(")")
        css = ' class="par"' if is_par else ""
        if _show_line_nums:
            words = txt.split()
            cur = ""
            for w in words:
                if len(cur) + len(w) + 1 > 65:
                    lines.append(f'<div class="ln"><span class="ln-n">{ln}</span>'
                                 f'<span class="ln-t{css}">{cur.strip()}</span></div>')
                    ln += 1
                    cur = w + " "
                else:
                    cur += w + " "
            if cur.strip():
                lines.append(f'<div class="ln"><span class="ln-n">{ln}</span>'
                             f'<span class="ln-t{css}">{cur.strip()}</span></div>')
                ln += 1
        else:
            lines.append(f'<div{css}>{txt}</div>')

    if reporter_name:
        lines.append(f'<div class="ft">Reported by: {reporter_name}</div>')
    lines.append('</body></html>')

    return HTMLResponse("\n".join(lines))


print("Plugin loaded: preview_pane.py — live preview endpoint active")
