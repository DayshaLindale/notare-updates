"""ASR Transcribe — Workspace 1.

Audio → rough-draft .docx, via the user's own AssemblyAI key.

Uses a job-queue pattern (not synchronous upload→wait→download) because
transcription takes minutes for a long hearing and a synchronous HTTP
request would hang the UI and break on any network hiccup.

Flow:
    1. POST /api/asr-transcribe/start
        multipart: audio file (required), clerk_log .htm (optional),
                   profile, num_prosecutors, num_defense, has_interpreter,
                   show_timestamps (inherited from settings if absent)
        → returns {job_id, status: "queued"}
    2. Plugin spawns a background thread that:
        - uploads to AssemblyAI
        - submits transcription
        - polls until complete
        - writes the .docx
        - updates job state in a shared dict + persists to index
    3. Frontend polls GET /api/asr-transcribe/status/{job_id} every ~5s
    4. When status == "complete" → GET /api/asr-transcribe/{job_id}/download
       (same history pattern as proofing & cleanup workspaces)

Entitlements mirror the other workspaces: bundled `oregon` profile is
license-gated via _TRANSCRIBE_ENTITLEMENTS. User-uploaded profiles
(unbundled) are always visible.
"""

import sys
import os
import json
import time
import uuid
import shutil
import logging
import tempfile
import threading
import importlib.util
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

from fastapi import UploadFile, File, Form
from fastapi.responses import JSONResponse as _JSONResponse, FileResponse

# ─────────────────────────────────────────────
# Paths + shared state
# ─────────────────────────────────────────────
_ASR_DIR = _app.BASE_DIR / "_internal" / "asr_scripts"
_ASR_DIR.mkdir(parents=True, exist_ok=True)

_HISTORY_ROOT = Path(os.environ.get("APPDATA", str(_app.BASE_DIR))) / "Notare" / "asr_transcribe_history"
_HISTORY_ROOT.mkdir(parents=True, exist_ok=True)
_HISTORY_INDEX = _HISTORY_ROOT / "asr_transcribe_history.json"

# In-memory live job state — keyed by job_id. Persistence to disk happens
# when a job transitions to `complete` or `error`. Queued/uploading/
# transcribing exist only in memory; a process crash loses them (acceptable
# — the user can just re-submit).
_JOB_STATE = {}
_JOB_LOCK = threading.Lock()

# Serialize transcription: one concurrent AssemblyAI job per install is
# plenty. Prevents API key overuse + tmp disk explosion.
_RUN_SEMAPHORE = threading.Semaphore(1)

# ─────────────────────────────────────────────
# Entitlements
# ─────────────────────────────────────────────
_BUNDLED_TRANSCRIBE_KEYS = frozenset({"oregon"})

_TRANSCRIBE_ENTITLEMENTS = {
    "NOTARE-MASTER-ADMIN-0001":          frozenset(_BUNDLED_TRANSCRIBE_KEYS),  # Terry
    "NOTARE-LEGACY-ADMIN-0001":          frozenset(_BUNDLED_TRANSCRIBE_KEYS),  # Elizabeth
    # Lori not entitled to Transcribe
}


def _entitled_transcribe_profiles():
    for lic_path in (_app.BASE_DIR / "license.json",
                     _app.BASE_DIR / "_internal" / "license.json"):
        if not lic_path.exists():
            continue
        try:
            data = json.loads(lic_path.read_text(encoding="utf-8"))
            key = (data.get("key") or "").strip().upper()
            if key in _TRANSCRIBE_ENTITLEMENTS:
                return _TRANSCRIBE_ENTITLEMENTS[key]
        except Exception:
            continue
    return frozenset()


# ─────────────────────────────────────────────
# Profile loading (same pattern as proof/cleanup)
# ─────────────────────────────────────────────
_transcribe_available = {}
_transcribe_load_errors = {}
_transcribe_dir_state = {}

if str(_ASR_DIR) not in sys.path:
    sys.path.insert(0, str(_ASR_DIR))


def _reload_transcribe_profiles():
    _transcribe_available.clear()
    _transcribe_load_errors.clear()
    try:
        _ASR_DIR.mkdir(parents=True, exist_ok=True)
        exists = _ASR_DIR.exists()
        readable = os.access(str(_ASR_DIR), os.R_OK)
    except Exception as e:
        exists = False
        readable = False
        logger.error("ASR Transcribe: dir setup failed: %s", e)

    files = sorted(_ASR_DIR.glob("asr_*.py")) if exists else []
    _transcribe_dir_state["path"] = str(_ASR_DIR)
    _transcribe_dir_state["exists"] = exists
    _transcribe_dir_state["readable"] = readable
    _transcribe_dir_state["file_count"] = len(files)
    _transcribe_dir_state["files"] = [p.name for p in files]

    _orig_exit, _orig_input = sys.exit, __import__("builtins").input
    sys.exit = lambda c=0: None
    __import__("builtins").input = lambda p="": ""
    try:
        for py_file in files:
            try:
                fsize = py_file.stat().st_size
                if fsize < 50:
                    _transcribe_load_errors[py_file.name] = f"file is only {fsize} bytes"
                    continue
                mod_name = py_file.stem
                spec = importlib.util.spec_from_file_location(mod_name, str(py_file))
                if not spec or not spec.loader:
                    _transcribe_load_errors[py_file.name] = "spec_from_file_location returned None"
                    continue
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                label = getattr(mod, "PROFILE_NAME", None)
                if not label or not isinstance(label, str):
                    _transcribe_load_errors[py_file.name] = "missing PROFILE_NAME string"
                    continue
                if not callable(getattr(mod, "process", None)):
                    _transcribe_load_errors[py_file.name] = "missing process() function"
                    continue
                key = mod_name.replace("asr_", "", 1)
                _transcribe_available[key] = {
                    "module": mod,
                    "label": label,
                    "description": f"ASR transcribe profile: {label}",
                    "filename": py_file.name,
                    "size": fsize,
                }
                logger.info("ASR Transcribe: ✓ loaded %s as '%s' (key=%s)", py_file.name, label, key)
            except Exception as e:
                _transcribe_load_errors[py_file.name] = f"{type(e).__name__}: {e}"
                logger.warning("ASR Transcribe: ✗ %s — %s", py_file.name, e)
    finally:
        sys.exit = _orig_exit
        __import__("builtins").input = _orig_input

    logger.info("ASR Transcribe: reload complete — %d loaded, %d errors",
                len(_transcribe_available), len(_transcribe_load_errors))

_reload_transcribe_profiles()


# ─────────────────────────────────────────────
# History
# ─────────────────────────────────────────────
def _load_history():
    if not _HISTORY_INDEX.exists():
        return []
    try:
        data = json.loads(_HISTORY_INDEX.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_history(entries):
    try:
        _HISTORY_INDEX.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    except Exception as e:
        logger.warning("ASR Transcribe history: could not write index: %s", e)


# ─────────────────────────────────────────────
# Filename sanitizer
# ─────────────────────────────────────────────
def _sanitize_filename(raw_name, default_ext=".mp3"):
    import re as _re
    safe = os.path.basename((raw_name or f"upload{default_ext}").replace("\\", "/"))
    safe = _re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", safe).lstrip(".")
    if "." not in safe:
        safe += default_ext
    if len(safe) > 120:
        stem, _, ext = safe.rpartition(".")
        safe = stem[:110] + "." + ext
    return safe


# ─────────────────────────────────────────────
# Background worker
# ─────────────────────────────────────────────
def _update_job(job_id, **fields):
    with _JOB_LOCK:
        if job_id in _JOB_STATE:
            _JOB_STATE[job_id].update(fields)
            _JOB_STATE[job_id]["updated_at"] = time.time()


def _run_transcription(job_id, profile, audio_path, clerk_log_path,
                       output_path, api_key, show_timestamps,
                       num_prosecutors, num_defense, has_interpreter,
                       timeout_minutes, original_filename):
    """Runs in a background thread. Owns the full lifecycle from upload to
    final history entry. Exceptions are captured and surfaced as error
    state — the thread never crashes the plugin."""
    acquired = _RUN_SEMAPHORE.acquire(blocking=True, timeout=600)
    if not acquired:
        _update_job(job_id, status="error",
                    error_message="Another transcription is already running. Try again in a moment.")
        return
    try:
        _update_job(job_id, status="uploading", stage_info={})
        mod = _transcribe_available[profile]["module"]

        def _progress(stage, info):
            _update_job(job_id, status=stage, stage_info=info)

        try:
            mod.process(
                input_path=audio_path,
                output_path=output_path,
                api_key=api_key,
                show_timestamps=show_timestamps,
                num_prosecutors=num_prosecutors,
                num_defense=num_defense,
                has_interpreter=has_interpreter,
                clerk_log_path=clerk_log_path,
                timeout_minutes=timeout_minutes,
                progress_cb=_progress,
            )
        except Exception as e:
            logger.error("ASR Transcribe: job %s failed: %s", job_id, e)
            _update_job(job_id, status="error",
                        error_message=f"{type(e).__name__}: {e}")
            return

        # Preserve output to history dir
        run_dir = _HISTORY_ROOT / f"{int(time.time())}_{job_id}"
        run_dir.mkdir(parents=True, exist_ok=True)
        preserved = run_dir / (os.path.splitext(original_filename)[0] + "_ASR.docx")
        try:
            shutil.copy2(output_path, str(preserved))
        except Exception as e:
            logger.warning("ASR Transcribe: could not preserve output: %s", e)

        # Also copy to user's chosen output folder if configured
        user_output_dir = (_app.SETTINGS.get("proof_output_dir") or "").strip()
        saved_to = ""
        if user_output_dir:
            try:
                td = Path(os.path.expandvars(os.path.expanduser(user_output_dir)))
                if td.exists() and td.is_dir() and os.access(str(td), os.W_OK):
                    stem, ext = os.path.splitext(preserved.name)
                    dest = td / preserved.name
                    counter = 2
                    while dest.exists() and counter < 1000:
                        dest = td / f"{stem}_{counter}{ext}"
                        counter += 1
                    shutil.copy2(str(preserved), str(dest))
                    saved_to = str(dest)
            except Exception as e:
                logger.warning("ASR Transcribe: user-dir copy failed: %s", e)

        entry = {
            "id": job_id,
            "created_at": int(time.time()),
            "original_filename": original_filename,
            "output_filename":   preserved.name,
            "profile_key":       profile,
            "profile_label":     _transcribe_available[profile]["label"],
            "output_path":       str(preserved),
            "saved_to":          saved_to,
        }
        history = _load_history()
        history.insert(0, entry)
        _save_history(history)

        _update_job(job_id, status="complete",
                    output_path=str(preserved),
                    saved_to=saved_to,
                    output_filename=preserved.name)

        logger.info("ASR Transcribe: job %s complete — %s", job_id, preserved.name)
    finally:
        _RUN_SEMAPHORE.release()
        # Clean up staged audio + temp output after short delay so status
        # endpoint can still report paths briefly. Fire in a small timer
        # thread so we don't block the run thread.
        def _cleanup():
            try:
                if audio_path and os.path.exists(audio_path):
                    os.unlink(audio_path)
                if clerk_log_path and os.path.exists(clerk_log_path):
                    os.unlink(clerk_log_path)
                if output_path and os.path.exists(output_path):
                    os.unlink(output_path)
            except Exception:
                pass
        threading.Timer(60.0, _cleanup).start()


# ─────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────

@_app.app.get("/api/asr-transcribe-profiles")
async def list_transcribe_profiles():
    try:
        _reload_transcribe_profiles()
    except Exception:
        pass
    entitled = _entitled_transcribe_profiles()
    profiles = {}
    for key, info in _transcribe_available.items():
        if key in _BUNDLED_TRANSCRIBE_KEYS and key not in entitled:
            continue
        profiles[key] = {
            "label": info["label"],
            "description": info["description"],
            "filename": info.get("filename", ""),
        }
    return _JSONResponse(profiles)


@_app.app.post("/api/asr-transcribe/start")
async def start_transcription(
    file: UploadFile = File(...),
    clerk_log: UploadFile = File(None),
    profile: str = Form("oregon"),
    num_prosecutors: int = Form(1),
    num_defense: int = Form(1),
    has_interpreter: str = Form(""),
):
    """Kick off a background transcription job. Returns immediately with a
    job_id that the client polls."""
    # Profile + entitlement
    if profile not in _transcribe_available:
        return _JSONResponse({
            "error": f"Unknown transcribe profile: {profile}. "
                     f"Available: {', '.join(_transcribe_available.keys()) or 'none loaded'}"
        }, status_code=400)
    if profile in _BUNDLED_TRANSCRIBE_KEYS and profile not in _entitled_transcribe_profiles():
        return _JSONResponse(
            {"error": f"Transcribe profile '{profile}' is not included with your license."},
            status_code=403,
        )

    # API key — user's own, from settings
    api_key = (_app.SETTINGS.get("assemblyai_api_key") or _app.SETTINGS.get("api_key") or "").strip()
    if not api_key:
        return _JSONResponse({
            "error": "No AssemblyAI API key configured. Add one in Settings. "
                     "Your first 185 hours are free with AssemblyAI's signup credit."
        }, status_code=400)

    # Audio file validation
    allowed_audio_ext = (".mp3", ".wav", ".m4a", ".mp4", ".flac", ".ogg")
    if not file.filename or not file.filename.lower().endswith(allowed_audio_ext):
        return _JSONResponse(
            {"error": f"Please upload an audio file ({', '.join(allowed_audio_ext)})."},
            status_code=400,
        )

    # Stage the audio file
    job_id = uuid.uuid4().hex[:16]
    staging = Path(tempfile.gettempdir()) / "notare_asr_transcribe" / job_id
    staging.mkdir(parents=True, exist_ok=True)

    safe_audio = _sanitize_filename(file.filename)
    audio_path = staging / safe_audio
    audio_bytes = await file.read()
    try:
        with open(audio_path, "wb") as f:
            f.write(audio_bytes)
    except Exception as e:
        return _JSONResponse({"error": f"Could not stage audio: {e}"}, status_code=500)

    # Optional clerk log
    clerk_log_path = None
    if clerk_log is not None and clerk_log.filename:
        if not clerk_log.filename.lower().endswith((".htm", ".html")):
            return _JSONResponse(
                {"error": "Clerk log must be a .htm or .html file."},
                status_code=400,
            )
        safe_log = _sanitize_filename(clerk_log.filename, default_ext=".htm")
        clerk_log_path = str(staging / safe_log)
        try:
            log_bytes = await clerk_log.read()
            with open(clerk_log_path, "wb") as f:
                f.write(log_bytes)
        except Exception as e:
            logger.warning("ASR Transcribe: clerk log stage failed: %s", e)
            clerk_log_path = None

    # Case-setup values
    try:
        num_prosecutors = max(0, int(num_prosecutors))
        num_defense = max(0, int(num_defense))
    except Exception:
        num_prosecutors = 1
        num_defense = 1
    has_interpreter_bool = str(has_interpreter).strip().lower() in ("1", "true", "yes", "on")

    # Settings-driven knobs
    show_timestamps = bool(_app.SETTINGS.get("asr_show_timestamps", True))
    try:
        timeout_minutes = int(_app.SETTINGS.get("asr_timeout_minutes", 30))
    except Exception:
        timeout_minutes = 30

    output_path = str(staging / (os.path.splitext(safe_audio)[0] + "_ASR.docx"))

    # Seed job state
    with _JOB_LOCK:
        _JOB_STATE[job_id] = {
            "id": job_id,
            "status": "queued",
            "profile": profile,
            "original_filename": file.filename,
            "has_clerk_log": bool(clerk_log_path),
            "num_prosecutors": num_prosecutors,
            "num_defense": num_defense,
            "has_interpreter": has_interpreter_bool,
            "show_timestamps": show_timestamps,
            "created_at": time.time(),
            "updated_at": time.time(),
            "stage_info": {},
        }

    # Kick off background worker
    t = threading.Thread(
        target=_run_transcription,
        kwargs={
            "job_id": job_id,
            "profile": profile,
            "audio_path": str(audio_path),
            "clerk_log_path": clerk_log_path,
            "output_path": output_path,
            "api_key": api_key,
            "show_timestamps": show_timestamps,
            "num_prosecutors": num_prosecutors,
            "num_defense": num_defense,
            "has_interpreter": has_interpreter_bool,
            "timeout_minutes": timeout_minutes,
            "original_filename": file.filename,
        },
        daemon=True,
        name=f"asr_transcribe_{job_id}",
    )
    t.start()

    return _JSONResponse({
        "ok": True,
        "job_id": job_id,
        "status": "queued",
        "message": "Transcription started. Poll /api/asr-transcribe/status/{job_id} for updates.",
    })


@_app.app.get("/api/asr-transcribe/status/{job_id}")
async def transcribe_status(job_id: str):
    with _JOB_LOCK:
        state = _JOB_STATE.get(job_id)
        if state:
            state = dict(state)  # snapshot
    if not state:
        # Maybe already completed and in history — expose that too
        for e in _load_history():
            if e.get("id") == job_id:
                return _JSONResponse({
                    "id": job_id,
                    "status": "complete",
                    "output_filename": e.get("output_filename"),
                    "created_at": e.get("created_at"),
                    "in_history": True,
                })
        return _JSONResponse({"error": "Job not found."}, status_code=404)
    return _JSONResponse(state)


@_app.app.get("/api/asr-transcribe/{job_id}/download")
async def download_transcribe(job_id: str):
    # First check live state
    with _JOB_LOCK:
        state = dict(_JOB_STATE.get(job_id, {}))
    path = state.get("output_path", "")
    if path and os.path.exists(path):
        return FileResponse(
            path,
            filename=state.get("output_filename") or os.path.basename(path),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
    # Fall through to history
    for e in _load_history():
        if e.get("id") == job_id:
            out = e.get("output_path", "")
            if out and os.path.exists(out):
                return FileResponse(
                    out, filename=os.path.basename(out),
                    media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                )
            return _JSONResponse({"error": "Output file missing from disk."}, status_code=404)
    return _JSONResponse({"error": "Job not found."}, status_code=404)


@_app.app.post("/api/asr-transcribe/{job_id}/open")
async def open_transcribe(job_id: str):
    path = ""
    with _JOB_LOCK:
        state = dict(_JOB_STATE.get(job_id, {}))
    path = state.get("output_path", "")
    if not path or not os.path.exists(path):
        for e in _load_history():
            if e.get("id") == job_id:
                path = e.get("output_path", "")
                break
    if not path or not os.path.exists(path):
        return _JSONResponse({"error": "Output file missing from disk."}, status_code=404)
    try:
        resolved = os.path.realpath(path)
        root = os.path.realpath(str(_HISTORY_ROOT))
        if not resolved.lower().startswith(root.lower()):
            return _JSONResponse({"error": "Refusing to open file outside history root."}, status_code=400)
        if hasattr(os, "startfile"):
            os.startfile(path)
        return _JSONResponse({"ok": True, "opened": os.path.basename(path)})
    except Exception as e:
        return _JSONResponse({"error": f"Could not open: {e}"}, status_code=500)


@_app.app.delete("/api/asr-transcribe/{job_id}")
async def delete_transcribe(job_id: str):
    # Remove from history (if present) + in-memory state
    entries = _load_history()
    remaining = []
    removed = None
    for e in entries:
        if e.get("id") == job_id:
            removed = e
            continue
        remaining.append(e)
    if removed:
        try:
            run_dir = Path(removed.get("output_path", "")).parent
            if run_dir.exists() and run_dir.parent == _HISTORY_ROOT:
                shutil.rmtree(str(run_dir), ignore_errors=True)
        except Exception:
            pass
        _save_history(remaining)
    with _JOB_LOCK:
        _JOB_STATE.pop(job_id, None)
    if not removed and job_id not in _JOB_STATE:
        return _JSONResponse({"error": "Job not found."}, status_code=404)
    return _JSONResponse({"ok": True, "removed": job_id})


@_app.app.get("/api/asr-transcribe-history")
async def get_transcribe_history():
    entries = _load_history()
    stripped = []
    for e in entries:
        stripped.append({
            "id": e.get("id"),
            "created_at": e.get("created_at"),
            "original_filename": e.get("original_filename"),
            "output_filename":   e.get("output_filename"),
            "profile_key":   e.get("profile_key"),
            "profile_label": e.get("profile_label"),
            "has_output": bool(e.get("output_path")) and os.path.exists(e.get("output_path", "")),
        })
    return _JSONResponse({"entries": stripped, "total": len(stripped)})


@_app.app.get("/api/asr-transcribe-profiles/diagnostic")
async def transcribe_diagnostic():
    try:
        _reload_transcribe_profiles()
    except Exception:
        pass
    entitled = _entitled_transcribe_profiles()
    loaded = {}
    for key, info in _transcribe_available.items():
        is_bundled = key in _BUNDLED_TRANSCRIBE_KEYS
        loaded[key] = {
            "label": info["label"],
            "filename": info.get("filename", ""),
            "size_bytes": info.get("size", 0),
            "visible_to_this_install": (not is_bundled) or (key in entitled),
        }
    with _JOB_LOCK:
        live_jobs = list(_JOB_STATE.keys())
    return _JSONResponse({
        "dir_path": _transcribe_dir_state.get("path", ""),
        "dir_exists": _transcribe_dir_state.get("exists", False),
        "dir_readable": _transcribe_dir_state.get("readable", False),
        "file_count": _transcribe_dir_state.get("file_count", 0),
        "files_on_disk": _transcribe_dir_state.get("files", []),
        "loaded_profiles": loaded,
        "load_errors": _transcribe_load_errors,
        "license_entitled_for_bundled": bool(entitled),
        "entitled_profile_keys": sorted(entitled),
        "live_jobs": live_jobs,
    })


@_app.app.post("/api/asr-transcribe-profiles/rebundle")
async def rebundle_transcribe_scripts():
    import urllib.request
    import zipfile as _zf
    try:
        with urllib.request.urlopen("https://notare-updates.onrender.com/api/manifest", timeout=30) as resp:
            manifest = json.loads(resp.read())
        latest = manifest.get("current_version", "")
        if not latest:
            return _JSONResponse({"error": "No current_version in manifest."}, status_code=502)
        zip_url = f"https://notare-updates.onrender.com/api/update/download/{latest}"
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tf:
            zip_path = tf.name
        with urllib.request.urlopen(zip_url, timeout=60) as zresp:
            shutil.copyfileobj(zresp, open(zip_path, "wb"))
        extracted = []
        try:
            with _zf.ZipFile(zip_path) as zf:
                for member in zf.namelist():
                    mn = member.replace("\\", "/")
                    if not mn.startswith("_internal/asr_scripts/"):
                        continue
                    if mn.endswith("/") or not mn.endswith(".py"):
                        continue
                    base = os.path.basename(mn)
                    if ".." in base or "/" in base or "\\" in base:
                        continue
                    dest = _ASR_DIR / base
                    with zf.open(member) as src, open(dest, "wb") as out:
                        shutil.copyfileobj(src, out)
                    extracted.append(base)
        finally:
            try: os.unlink(zip_path)
            except Exception: pass
        _reload_transcribe_profiles()
        return _JSONResponse({
            "ok": True, "version": latest, "extracted": extracted,
            "loaded_profiles": list(_transcribe_available.keys()),
            "load_errors": _transcribe_load_errors,
        })
    except Exception as e:
        logger.error("ASR Transcribe rebundle failed: %s", e)
        return _JSONResponse({"error": f"Rebundle failed: {e}"}, status_code=500)


print("Plugin loaded: asr_transcribe.py — /api/asr-transcribe/* endpoints active")
