"""WASAPI Bootstrap — ensures pyaudiowpatch is available for loopback capture.

Runs at startup. If pyaudiowpatch isn't importable, pip installs it into
the app's Python environment. Small package (~200KB), fast install.

This enables WASAPI loopback capture on every Windows machine without
needing Stereo Mix enabled — the true fix for system audio capture.
"""

import sys
import os
import subprocess
import logging
import threading

logger = logging.getLogger("notare.plugin.wasapi_bootstrap")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

BASE_DIR = getattr(_app, 'BASE_DIR', None)


def _check_and_install():
    """Check for pyaudiowpatch, install if missing."""
    try:
        import pyaudiowpatch
        logger.info("pyaudiowpatch available (v%s)", getattr(pyaudiowpatch, '__version__', '?'))
        return
    except ImportError:
        pass

    # Not available — look for a real Python venv to install into.
    python_exe = None
    if BASE_DIR:
        for env_name in ['_gpu_env', '_cpu_env']:
            env_python = os.path.join(str(BASE_DIR), env_name, 'Scripts', 'python.exe')
            if os.path.exists(env_python):
                python_exe = env_python
                break

    # If there's no real Python, do NOT fall back to sys.executable — in a
    # frozen exe that's Notare.exe itself. Running
    # `subprocess.run([Notare.exe, '-m', 'pip', ...])` doesn't install anything,
    # it just launches another Notare, which loads this plugin, which launches
    # another Notare — a fork bomb. Skip install entirely instead.
    if not python_exe:
        logger.warning(
            "pyaudiowpatch not available and no Python venv found in the app dir — "
            "audio loopback capture will be disabled. Install the CPU or GPU "
            "installer variant, or drop a Python 3.12 venv into _cpu_env/."
        )
        return

    logger.info("pyaudiowpatch not found, installing into %s...", python_exe)

    try:
        result = subprocess.run(
            [python_exe, '-m', 'pip', 'install', 'PyAudioWPatch', '--quiet', '--no-warn-script-location'],
            capture_output=True, text=True, timeout=120,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        if result.returncode == 0:
            logger.info("pyaudiowpatch installed successfully")
            # Try import again to verify
            try:
                import pyaudiowpatch
                logger.info("pyaudiowpatch verified: v%s", getattr(pyaudiowpatch, '__version__', '?'))
            except ImportError:
                logger.warning("pyaudiowpatch installed but still can't import — may need app restart")
        else:
            logger.warning("pip install failed (code %d): %s", result.returncode, result.stderr[:500])

            # Fallback: try installing regular pyaudio (less capable but still works for mic)
            try:
                import pyaudio
                logger.info("Regular pyaudio available as fallback")
            except ImportError:
                logger.info("Attempting pyaudio fallback install...")
                subprocess.run(
                    [python_exe, '-m', 'pip', 'install', 'PyAudio', '--quiet', '--no-warn-script-location'],
                    capture_output=True, timeout=120,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                )
    except Exception as e:
        logger.error("Failed to install pyaudiowpatch: %s", e)


# Run in background so it doesn't block startup
threading.Thread(target=_check_and_install, daemon=True, name="wasapi-bootstrap").start()
logger.info("WASAPI bootstrap started (background)")
