"""Report-only detection — Elizabeth's workflow.

Accepts an uploaded .docx, reads each paragraph's text, runs lint-style
proofing detection against the text (no corrections applied), and returns
a findings-only sidecar .docx.

Hard rule: the uploaded file is copied to imports/ for audit trail only.
It is NEVER parsed into segments, NEVER loaded into the editor, NEVER
re-exported. The customer's file stays bit-identical to what they sent.
The findings report is a separate, new document.

No job is created. No transcript.json is written. Deliberate — Elizabeth
was getting her file rewritten via the existing import-transcript path
because the speaker splitter fires as part of import. This endpoint
bypasses all of that.
"""
import sys
import io
import re
import time
import logging
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

from fastapi import UploadFile, File
from fastapi.responses import FileResponse, JSONResponse

BASE_DIR = _app.BASE_DIR
REPORTS_DIR = BASE_DIR / "reports"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)


# ───────────────────────────────────────────────────────────────────────────
# Detection rules — regex-based, all paragraph-text only. Each rule returns
# a list of (offset, match_text, suggested_text, description).
# Rules mirror proof_engine's fix/flag set but only detect — never apply.
# ───────────────────────────────────────────────────────────────────────────

_RULES = []

def _rule(category: str, description: str):
    def deco(fn):
        _RULES.append((category, description, fn))
        return fn
    return deco


@_rule("informal", "Informal contraction — replace with formal equivalent")
def _contractions(text):
    out = []
    table = {
        "gonna": "going to", "gotta": "got to", "wanna": "want to",
        "kinda": "kind of", "sorta": "sort of", "coulda": "could have",
        "woulda": "would have", "shoulda": "should have", "oughta": "ought to",
        "outta": "out of", "lemme": "let me", "gimme": "give me",
        "dunno": "don't know", "tryna": "trying to", "hafta": "have to",
        "y'all": "you all", "ain't": "is not", "cuz": "because",
        "'cause": "because", "til": "until", "'til": "until",
    }
    for find, replace in table.items():
        for m in re.finditer(r'\b' + re.escape(find) + r'\b', text, re.IGNORECASE):
            out.append((m.start(), m.group(0), replace))
    return out


@_rule("alright", "'Alright' is non-standard — use 'all right'")
def _alright(text):
    return [(m.start(), m.group(0), "all right")
            for m in re.finditer(r'\balright\b', text, re.IGNORECASE)]


@_rule("mrs_miss", "Honorific should be capitalized and punctuated")
def _mrs_miss(text):
    out = []
    for m in re.finditer(r'\bmrs\.?\b', text):
        if m.group(0) != "Mrs.":
            out.append((m.start(), m.group(0), "Mrs."))
    for m in re.finditer(r'\bmiss\b', text):
        if m.group(0)[0].islower():
            out.append((m.start(), m.group(0), "Miss"))
    return out


@_rule("doctor", "'Doctor' as title should be 'Dr.'")
def _doctor(text):
    return [(m.start(), m.group(0), "Dr.")
            for m in re.finditer(r'\bdoctor\b', text, re.IGNORECASE)
            if m.group(0) != "Dr."]


@_rule("percent", "'%' should be spelled 'percent'")
def _percent(text):
    return [(m.start(), "%", " percent") for m in re.finditer(r'%', text)]


@_rule("ellipsis", "Ellipsis '...' → ' --' per standard")
def _ellipsis(text):
    return [(m.start(), "...", " --") for m in re.finditer(r'\.{3}', text)]


@_rule("smart_quotes", "Smart/curly quotes — replace with straight quotes")
def _smart_quotes(text):
    out = []
    for m in re.finditer(r'[‘’]', text):
        out.append((m.start(), m.group(0), "'"))
    for m in re.finditer(r'[“”]', text):
        out.append((m.start(), m.group(0), '"'))
    return out


@_rule("double_space", "Double space — collapse to single")
def _double_space(text):
    # Allow double space after colon (speaker label) — that's standard
    out = []
    for m in re.finditer(r'(?<!:)(?<! )  +', text):
        # Skip the "MR. SMITH:  " speaker label pattern (2 spaces after colon)
        if m.start() >= 1 and text[m.start() - 1] == ':':
            continue
        out.append((m.start(), m.group(0), " "))
    return out


@_rule("space_before_punct", "Space before punctuation — remove")
def _space_before_punct(text):
    return [(m.start(), m.group(0), m.group(0).strip())
            for m in re.finditer(r' [,.;:!?]', text)]


@_rule("missing_space_after_comma", "Missing space after comma")
def _missing_space_after_comma(text):
    return [(m.start(), m.group(0), ", " + m.group(1))
            for m in re.finditer(r',([A-Za-z])', text)]


@_rule("missing_space_after_period", "Missing space after terminal punctuation")
def _missing_space_after_terminal(text):
    return [(m.start(), m.group(0), m.group(1) + " " + m.group(2))
            for m in re.finditer(r'([.?!])([A-Z])', text)]


@_rule("phonetic_ph", "'(ph)' shorthand → '(phonetic)'")
def _ph_phonetic(text):
    return [(m.start(), m.group(0), "(phonetic)")
            for m in re.finditer(r'\(ph\)', text, re.IGNORECASE)]


@_rule("double_dash", "Double dash ' -- ' may need em-dash or single dash review")
def _double_dash_flag(text):
    return [(m.start(), m.group(0), None)  # flag only, no suggestion
            for m in re.finditer(r' -- ', text)]


@_rule("um_uh", "Filler word — usually removed in clean verbatim")
def _um_uh(text):
    return [(m.start(), m.group(0), "")
            for m in re.finditer(r'\b(um|uh|ah|er)\b,?\s*', text, re.IGNORECASE)]


@_rule("inaudible_caps", "[inaudible] / [indiscernible] should be capitalized consistently")
def _inaudible_caps(text):
    out = []
    for m in re.finditer(r'\[\s*(inaudible|indiscernible)\s*\]', text, re.IGNORECASE):
        standard = "[Inaudible]" if "inaud" in m.group(0).lower() else "[Indiscernible]"
        if m.group(0) != standard:
            out.append((m.start(), m.group(0), standard))
    return out


@_rule("exhibit_cap", "'Exhibit' before number/letter should be capitalized")
def _exhibit_cap(text):
    out = []
    for m in re.finditer(r'\bexhibit\s+(?=\d+|[A-Z]\b)', text):
        if m.group(0) != "Exhibit ":
            out.append((m.start(), m.group(0).rstrip(), "Exhibit"))
    return out


@_rule("your_honor", "'Your Honor' should be capitalized")
def _your_honor(text):
    return [(m.start(), m.group(0), "Your Honor")
            for m in re.finditer(r'\byour honor\b', text)
            if m.group(0) != "Your Honor"]


# ───────────────────────────────────────────────────────────────────────────
# Main detection pipeline
# ───────────────────────────────────────────────────────────────────────────

def _scan_paragraph(para_num: int, text: str):
    """Return a list of findings for this paragraph. Each finding is a dict."""
    findings = []
    for category, description, fn in _RULES:
        try:
            hits = fn(text)
        except Exception:
            continue
        for pos, original, suggested in hits:
            ctx_start = max(0, pos - 40)
            ctx_end = min(len(text), pos + len(original) + 40)
            ctx = text[ctx_start:ctx_end].replace("\n", " ")
            findings.append({
                "paragraph": para_num,
                "category": category,
                "description": description,
                "original": original,
                "suggested": suggested,
                "position": pos,
                "context": ctx,
            })
    return findings


def _build_report_docx(findings, source_filename: str, total_paras: int) -> bytes:
    """Generate a findings-only .docx. Returns its bytes."""
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from datetime import datetime

    doc = Document()
    for section in doc.sections:
        section.left_margin = Inches(0.7)
        section.right_margin = Inches(0.7)
        section.top_margin = Inches(0.7)
        section.bottom_margin = Inches(0.7)

    title = doc.add_paragraph()
    r = title.add_run("PROOFING REPORT")
    r.bold = True
    r.font.size = Pt(16)

    meta = doc.add_paragraph()
    def _kv(k, v):
        a = meta.add_run(k); a.bold = True
        meta.add_run(str(v) + "\n")
    _kv("Source file: ", source_filename)
    _kv("Generated: ", datetime.now().strftime("%Y-%m-%d %H:%M"))
    _kv("Paragraphs scanned: ", total_paras)
    _kv("Issues flagged: ", len(findings))

    note = doc.add_paragraph()
    note_run = note.add_run(
        "Your source document was NOT modified. This report lists possible issues "
        "by paragraph number so you can review and correct them in your own file. "
        "Every finding shows the original text and a suggested change — accept or "
        "ignore each on its own merit."
    )
    note_run.italic = True
    doc.add_paragraph()

    if not findings:
        p = doc.add_paragraph()
        ok = p.add_run("No issues detected. ✓")
        ok.bold = True
        ok.font.color.rgb = RGBColor(0x00, 0x80, 0x00)
    else:
        table = doc.add_table(rows=1, cols=5)
        table.alignment = WD_TABLE_ALIGNMENT.LEFT
        try:
            table.style = "Light Grid Accent 1"
        except Exception:
            pass
        hdr = table.rows[0].cells
        hdr[0].text = "Para"
        hdr[1].text = "Issue"
        hdr[2].text = "Original"
        hdr[3].text = "Suggested"
        hdr[4].text = "Context"
        for c in hdr:
            for pp in c.paragraphs:
                for rr in pp.runs:
                    rr.bold = True

        for f in findings:
            row = table.add_row().cells
            row[0].text = str(f["paragraph"])
            row[1].text = f["description"]
            row[2].text = repr(f["original"])
            row[3].text = repr(f["suggested"]) if f["suggested"] is not None else "(flag — review)"
            row[4].text = f["context"]

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ───────────────────────────────────────────────────────────────────────────
# Route: POST /api/report
# ───────────────────────────────────────────────────────────────────────────

@_app.app.post("/api/report")
async def report_only_v2(file: UploadFile = File(...)):
    """Detect issues in an uploaded .docx. Never modifies the source.

    Returns a findings .docx for download. No job is created, no segments
    are parsed, no editor is opened. The source file is stored for audit
    in reports/<timestamp>/source_<name> and the findings live next to it
    as reports/<timestamp>/PROOF_REPORT.docx.
    """
    content = await file.read()
    filename = file.filename or "transcript.docx"
    ext = Path(filename).suffix.lower()

    if ext not in (".docx", ".doc"):
        return JSONResponse(
            {"error": f"Only .docx files are supported in report mode. Got: {ext}"},
            status_code=400,
        )

    # Read paragraphs directly — no segment splitting, no speaker detection,
    # nothing that would imply modification of structure. Just text to scan.
    try:
        from docx import Document as DocxDoc
        doc = DocxDoc(io.BytesIO(content))
        paragraphs = [p.text for p in doc.paragraphs]
    except Exception as e:
        return JSONResponse({"error": f"Could not read .docx: {e}"}, status_code=400)

    # Run detection — iterate paragraphs, apply rules
    all_findings = []
    for idx, text in enumerate(paragraphs, start=1):
        if not text.strip():
            continue
        all_findings.extend(_scan_paragraph(idx, text))

    # Persist source + report to reports/<timestamp>/
    ts = int(time.time())
    safe_stem = re.sub(r'[^A-Za-z0-9._-]', '_', Path(filename).stem)[:60]
    report_dir = REPORTS_DIR / f"{ts}_{safe_stem}"
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / filename).write_bytes(content)  # Audit copy of her source — unchanged

    report_bytes = _build_report_docx(all_findings, filename, total_paras=len(paragraphs))
    report_filename = f"{safe_stem}_PROOF_REPORT.docx"
    report_path = report_dir / report_filename
    report_path.write_bytes(report_bytes)

    logger.info("Report generated: %s paragraphs, %d findings → %s",
                len(paragraphs), len(all_findings), report_path)

    return FileResponse(
        str(report_path),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        filename=report_filename,
    )


print("Plugin loaded: report_only.py — /api/report available (no-modify detection)")
