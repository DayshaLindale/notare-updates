"""Notare embedded LLM inference.

Hosts llama-cpp-python inference inside the Notare process — no Ollama,
no external service. Model file is lazy-downloaded to the user's app data
on first AI use.

State machine:
    NOT_READY      → no model file present, no download in flight
    DOWNLOADING    → model file is being fetched (progress fields populated)
    LOADING        → file present, llama_cpp.Llama is constructing
    READY          → model loaded, generate() will run inference
    ERROR          → terminal failure (download or load); error_msg populated

Public surface:
    get_status()                 → dict for /api/ai/status
    ensure_model_async()         → kick off download if NOT_READY
    generate(messages, ...)      → blocking inference; returns str
    is_ready()                   → bool

Storage layout:
    %APPDATA%/Notare/models/qwen2.5-7b-instruct-q4_k_m.gguf
"""
from __future__ import annotations

import logging
import os
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model catalogue — picked dynamically from hardware tier
# ---------------------------------------------------------------------------

# Update server hosts the GGUF files. Filenames must match TIER_MODEL keys
# in hardware_profile.py.
MODEL_URL_BASE = "https://notare-updates.onrender.com/static/models"

# HuggingFace mirror (fallback if our update server is unreachable).
# Bartowski's repos ship single-file Q4_K_M GGUFs; the official Qwen org
# repos split Q4_K_M across multiple .gguf files which would need stitching.
HF_MIRROR = {
    "Qwen2.5-1.5B-Instruct-Q4_K_M.gguf":
        "https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf?download=true",
    "Qwen2.5-3B-Instruct-Q4_K_M.gguf":
        "https://huggingface.co/bartowski/Qwen2.5-3B-Instruct-GGUF/resolve/main/Qwen2.5-3B-Instruct-Q4_K_M.gguf?download=true",
    "Qwen2.5-7B-Instruct-Q4_K_M.gguf":
        "https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf?download=true",
}


def _selected_model() -> dict | None:
    """Pick the model spec for the current tier. Returns None for api-only."""
    try:
        from hardware_profile import get_profile
        profile = get_profile()
        return profile.get("model")
    except Exception as e:
        logger.warning("hardware_profile unavailable, falling back to 7B: %s", e)
        # Conservative fallback if profile module fails to load
        return {
            "id": "qwen2.5-7b-instruct-q4_k_m",
            "filename": "qwen2.5-7b-instruct-q4_k_m.gguf",
            "size_bytes": 4_683_073_440,
            "context_length": 8192,
            "display_name": "Qwen 2.5 7B Instruct (Q4_K_M)",
            "n_gpu_layers": 0,
        }


def _model_url(filename: str) -> str:
    """Prefer our update server; fall back to HuggingFace if needed."""
    return f"{MODEL_URL_BASE}/{filename}"


# ---------------------------------------------------------------------------
# Runtime bootstrap — wire the smart-installer LLM env onto sys.path so
# `from llama_cpp import Llama` works even though llama-cpp-python isn't
# part of the PyInstaller bundle. The venv is unzipped to {app}/_llm_env
# by installer.iss.
# ---------------------------------------------------------------------------

def _bootstrap_llm_env() -> None:
    if getattr(sys, "frozen", False):
        app_dir = Path(sys.executable).parent
    else:
        app_dir = Path(__file__).resolve().parent
    sp = app_dir / "_llm_env" / "Lib" / "site-packages"
    if sp.exists():
        sp_str = str(sp)
        if sp_str not in sys.path:
            sys.path.insert(0, sp_str)
        # Also surface the venv's DLL dir so llama-cpp-python's native
        # libs resolve cleanly on Windows.
        bin_dir = app_dir / "_llm_env" / "Scripts"
        if bin_dir.exists() and hasattr(os, "add_dll_directory"):
            try:
                os.add_dll_directory(str(bin_dir))
            except Exception:
                pass


_bootstrap_llm_env()


# ---------------------------------------------------------------------------
# Storage paths — user-specific, survives Notare upgrades
# ---------------------------------------------------------------------------

def _models_dir() -> Path:
    """User-app-data dir for cached model files."""
    base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    d = Path(base) / "Notare" / "models"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _model_path() -> Path | None:
    """Path to the currently-selected tier's model file. None if api-only."""
    spec = _selected_model()
    if not spec:
        return None
    return _models_dir() / spec["filename"]


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

class _State:
    NOT_READY = "not_ready"
    DOWNLOADING = "downloading"
    LOADING = "loading"
    READY = "ready"
    ERROR = "error"
    UNAVAILABLE = "unavailable"  # api-only tier — no local model possible


_state = _State.NOT_READY
_state_lock = threading.Lock()
_download_thread: threading.Thread | None = None
_load_thread: threading.Thread | None = None
_progress_bytes = 0
_progress_total = 0
_progress_started_at: float = 0.0
_error_msg = ""
_llm = None  # llama_cpp.Llama instance once loaded
_llm_lock = threading.Lock()  # serializes generate() calls


def _set_state(new_state: str, *, error: str = "") -> None:
    global _state, _error_msg
    with _state_lock:
        _state = new_state
        if error:
            _error_msg = error
        elif new_state != _State.ERROR:
            _error_msg = ""


def get_status() -> dict[str, Any]:
    """Return the current inference-state snapshot for the UI."""
    spec = _selected_model()
    if not spec:
        return {
            "state": _State.UNAVAILABLE,
            "tier": "api-only",
            "model_id": None,
            "display_name": "No local AI on this hardware",
            "model_path": None,
            "file_present": False,
            "progress_pct": 0.0,
            "error": "",
        }

    path = _model_path()
    actual_bytes = path.stat().st_size if (path and path.exists()) else 0
    expected = spec.get("size_bytes", 0)
    pct = 0.0
    if _state == _State.DOWNLOADING and _progress_total > 0:
        pct = min(100.0, (_progress_bytes / _progress_total) * 100.0)
    elif _state == _State.READY:
        pct = 100.0

    eta_sec = None
    if _state == _State.DOWNLOADING and _progress_started_at and _progress_bytes > 0:
        elapsed = max(0.001, time.time() - _progress_started_at)
        rate = _progress_bytes / elapsed
        remaining = max(0, _progress_total - _progress_bytes)
        if rate > 0:
            eta_sec = remaining / rate

    return {
        "state": _state,
        "model_id": spec["id"],
        "display_name": spec["display_name"],
        "context_length": spec["context_length"],
        "filename": spec["filename"],
        "model_path": str(path) if path else None,
        "file_present": path.exists() if path else False,
        "file_size_bytes": actual_bytes,
        "expected_size_bytes": expected,
        "progress_bytes": _progress_bytes,
        "progress_pct": pct,
        "eta_sec": eta_sec,
        "error": _error_msg,
    }


def is_ready() -> bool:
    return _state == _State.READY


# ---------------------------------------------------------------------------
# Download with resume + progress
# ---------------------------------------------------------------------------

def _download_one(url: str, dest: Path, expected_size: int) -> bool:
    """Stream `url` to `dest` (atomic via .part rename). Resumes if dest.part exists."""
    global _progress_bytes, _progress_started_at, _progress_total
    tmp = dest.with_suffix(dest.suffix + ".part")
    already = tmp.stat().st_size if tmp.exists() else 0
    _progress_bytes = already
    _progress_total = expected_size
    _progress_started_at = time.time()

    req = urllib.request.Request(url)
    if already > 0:
        req.add_header("Range", f"bytes={already}-")
    with urllib.request.urlopen(req, timeout=60) as resp:
        content_length = resp.headers.get("Content-Length")
        if content_length:
            try:
                total = int(content_length)
                if resp.status == 206:
                    total += already
                if total > 0:
                    _progress_total = total
            except Exception:
                pass

        mode = "ab" if (resp.status == 206 and already > 0) else "wb"
        if mode == "wb":
            _progress_bytes = 0
            already = 0
        with open(tmp, mode) as f:
            chunk_size = 1024 * 1024  # 1 MiB
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                _progress_bytes += len(chunk)

    # Atomic rename
    if dest.exists():
        dest.unlink()
    tmp.rename(dest)
    return True


def _download_model() -> bool:
    """Download the tier-selected GGUF file. Tries update server first, then HF mirror."""
    spec = _selected_model()
    path = _model_path()
    if not spec or not path:
        _set_state(_State.UNAVAILABLE, error="no model for this hardware tier")
        return False

    expected = spec.get("size_bytes", 0)
    _set_state(_State.DOWNLOADING)

    primary = _model_url(spec["filename"])
    fallback = HF_MIRROR.get(spec["filename"], "")

    last_err = ""
    for url in (primary, fallback):
        if not url:
            continue
        try:
            _download_one(url, path, expected)
            actual = path.stat().st_size
            if expected and abs(actual - expected) / expected > 0.05:
                logger.warning("downloaded model size %d differs from expected %d",
                               actual, expected)
            return True
        except Exception as e:
            last_err = str(e)
            logger.warning("download from %s failed: %s", url, e)
            continue

    _set_state(_State.ERROR, error=f"download failed: {last_err}")
    return False


# ---------------------------------------------------------------------------
# Load + generate
# ---------------------------------------------------------------------------

def _load_model() -> bool:
    """Load the GGUF into a llama_cpp.Llama instance. Returns True on success."""
    global _llm
    spec = _selected_model()
    path = _model_path()
    if not spec or not path:
        _set_state(_State.UNAVAILABLE, error="no model for this hardware tier")
        return False

    _set_state(_State.LOADING)
    try:
        from llama_cpp import Llama
    except ImportError as e:
        _set_state(_State.ERROR, error=f"llama-cpp-python not installed: {e}")
        return False

    if not path.exists():
        _set_state(_State.ERROR, error="model file missing after download")
        return False

    try:
        _llm = Llama(
            model_path=str(path),
            n_ctx=spec["context_length"],
            n_threads=None,
            n_gpu_layers=spec.get("n_gpu_layers", 0),
            verbose=False,
        )
        _set_state(_State.READY)
        logger.info("notare_inference: model loaded (%s)", path.name)
        return True
    except Exception as e:
        logger.exception("model load failed")
        _set_state(_State.ERROR, error=f"load failed: {e}")
        return False


def ensure_model_async(on_done: Callable[[bool], None] | None = None) -> None:
    """Kick off download + load in the background if not already in flight.

    Idempotent: calling repeatedly while download is running is a no-op.
    No-op when the tier is api-only.
    """
    global _download_thread, _load_thread

    if _state in (_State.READY, _State.DOWNLOADING, _State.LOADING, _State.UNAVAILABLE):
        return

    path = _model_path()
    if path is None:
        _set_state(_State.UNAVAILABLE, error="no model for this hardware tier")
        if on_done:
            on_done(False)
        return

    def _worker():
        try:
            if not path.exists():
                ok = _download_model()
                if not ok:
                    if on_done:
                        on_done(False)
                    return
            ok = _load_model()
            if on_done:
                on_done(ok)
        except Exception:
            logger.exception("ensure_model_async worker crashed")
            _set_state(_State.ERROR, error="worker crashed (see log)")
            if on_done:
                on_done(False)

    t = threading.Thread(target=_worker, name="notare-inference-bootstrap", daemon=True)
    _download_thread = t
    t.start()


def _format_messages(messages: list[dict]) -> str:
    """Convert OpenAI-style messages → Qwen ChatML prompt."""
    parts = []
    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if not content:
            continue
        parts.append(f"<|im_start|>{role}\n{content}<|im_end|>")
    parts.append("<|im_start|>assistant\n")
    return "\n".join(parts)


def generate(messages: list[dict], temperature: float = 0.4,
             max_tokens: int = 1500, top_p: float = 0.92) -> str:
    """Run inference. Blocks until complete. Returns the assistant text.

    Returns empty string if the model is not READY — caller should fall
    back to the Anthropic path if so.
    """
    if _state != _State.READY or _llm is None:
        return ""

    prompt = _format_messages(messages)
    with _llm_lock:
        try:
            out = _llm.create_completion(
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                stop=["<|im_end|>", "<|endoftext|>"],
                echo=False,
            )
            choices = out.get("choices") or []
            if choices:
                return (choices[0].get("text") or "").strip()
        except Exception as e:
            logger.warning("notare_inference.generate failed: %s", e)
    return ""


# ---------------------------------------------------------------------------
# Boot hook — eagerly load if model already on disk, otherwise wait for
# the first AI request to trigger ensure_model_async()
# ---------------------------------------------------------------------------

def boot_if_present() -> None:
    """If the GGUF already lives on disk from a prior install, load it now.

    Called at app startup. No download triggered here — that requires a
    user action so they're not surprised by a multi-GB pull.
    """
    path = _model_path()
    if path is None:
        _set_state(_State.UNAVAILABLE)
        return
    if path.exists() and _state == _State.NOT_READY:
        threading.Thread(target=_load_model, name="notare-inference-boot",
                         daemon=True).start()
