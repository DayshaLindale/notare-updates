"""Notare runtime hardware profile + tier classification.

Reads install_manifest.json (written by installer.iss) for the install-time
profile, then does a fresh live detection so we catch post-install hardware
upgrades. Live detection wins when it disagrees with the manifest.

Tier ladder (driven by RAM + VRAM):

    api-only     no local AI; falls back to Anthropic key only
    cpu-1.5b     CPU inference, 1.5B Q4 model     (~1 GB model)
    cpu-3b       CPU inference, 3B Q4 model       (~2 GB model)
    cpu-7b       CPU inference, 7B Q4 model       (~4.5 GB model)
    gpu-3b       CUDA, 3B Q4 fully on GPU
    gpu-7b       CUDA, 7B Q4 fully on GPU

Tier rules:
    VRAM >= 12 GB and RAM >= 16 GB  → gpu-7b
    VRAM >=  6 GB and RAM >=  8 GB  → gpu-3b
    no GPU,         RAM >= 32 GB    → cpu-7b
    no GPU,         RAM >= 16 GB    → cpu-3b
    no GPU,         RAM >=  8 GB    → cpu-1.5b
    otherwise                       → api-only
"""
from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tier definitions
# ---------------------------------------------------------------------------

TIERS = ["api-only", "cpu-1.5b", "cpu-3b", "cpu-7b", "gpu-3b", "gpu-7b"]

# Which model file each tier wants. Filenames match what
# build_scripts/build_llm_*.py publishes to the update server.
TIER_MODEL = {
    "api-only": None,
    "cpu-1.5b": {
        "id": "qwen2.5-1.5b-instruct-q4_k_m",
        "filename": "Qwen2.5-1.5B-Instruct-Q4_K_M.gguf",
        "size_bytes": 986_048_768,
        "context_length": 8192,
        "display_name": "Qwen 2.5 1.5B Instruct (Q4_K_M)",
        "n_gpu_layers": 0,
    },
    "cpu-3b": {
        "id": "qwen2.5-3b-instruct-q4_k_m",
        "filename": "Qwen2.5-3B-Instruct-Q4_K_M.gguf",
        "size_bytes": 1_929_903_264,
        "context_length": 8192,
        "display_name": "Qwen 2.5 3B Instruct (Q4_K_M)",
        "n_gpu_layers": 0,
    },
    "cpu-7b": {
        "id": "qwen2.5-7b-instruct-q4_k_m",
        "filename": "Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        "size_bytes": 4_683_074_240,
        "context_length": 8192,
        "display_name": "Qwen 2.5 7B Instruct (Q4_K_M)",
        "n_gpu_layers": 0,
    },
    "gpu-3b": {
        "id": "qwen2.5-3b-instruct-q4_k_m",
        "filename": "Qwen2.5-3B-Instruct-Q4_K_M.gguf",
        "size_bytes": 1_929_903_264,
        "context_length": 16384,
        "display_name": "Qwen 2.5 3B Instruct (Q4_K_M, GPU)",
        "n_gpu_layers": -1,  # all layers on GPU
    },
    "gpu-7b": {
        "id": "qwen2.5-7b-instruct-q4_k_m",
        "filename": "Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        "size_bytes": 4_683_074_240,
        "context_length": 16384,
        "display_name": "Qwen 2.5 7B Instruct (Q4_K_M, GPU)",
        "n_gpu_layers": -1,
    },
}


def tier_rank(tier: str) -> int:
    """Position in the ladder; -1 if unknown. Higher = more capable."""
    try:
        return TIERS.index(tier)
    except ValueError:
        return -1


def tier_at_least(have: str, need: str) -> bool:
    """True if `have` is at or above `need` in the ladder.

    GPU tiers always satisfy CPU-tier requirements at the same model size.
    """
    return tier_rank(have) >= tier_rank(need)


# ---------------------------------------------------------------------------
# Manifest read (install-time profile)
# ---------------------------------------------------------------------------

def _app_dir() -> Path:
    """Directory containing install_manifest.json. Sibling to the .exe."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent


def read_manifest() -> dict[str, Any]:
    p = _app_dir() / "install_manifest.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("install_manifest.json unreadable: %s", e)
        return {}


def write_manifest(updates: dict[str, Any]) -> None:
    """Merge updates into install_manifest.json. Used to record the LLM
    tier the user picked or upgraded to."""
    p = _app_dir() / "install_manifest.json"
    current = read_manifest()
    current.update(updates)
    try:
        p.write_text(json.dumps(current, indent=2), encoding="utf-8")
    except Exception as e:
        logger.warning("could not write install_manifest.json: %s", e)


# ---------------------------------------------------------------------------
# Live hardware detection
# ---------------------------------------------------------------------------

def _ram_gb_live() -> int:
    try:
        import psutil
        return int(psutil.virtual_memory().total // (1024 ** 3))
    except Exception:
        # Fallback: WMI via PowerShell
        if platform.system() == "Windows":
            try:
                out = subprocess.check_output(
                    ["powershell", "-NoProfile", "-Command",
                     "[math]::Floor((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)"],
                    timeout=8, text=True,
                ).strip()
                return int(out)
            except Exception:
                pass
        return 0


def _gpu_info_live() -> dict[str, Any]:
    """Returns {has_nvidia, vram_gb, name, cuda_version}."""
    info = {"has_nvidia": False, "vram_gb": 0, "name": "", "cuda_version": ""}

    nvsmi = shutil.which("nvidia-smi")
    if nvsmi:
        try:
            out = subprocess.check_output(
                [nvsmi, "--query-gpu=name,memory.total,driver_version",
                 "--format=csv,noheader,nounits"],
                timeout=5, text=True,
            ).strip().splitlines()
            if out:
                first = out[0].split(",")
                if len(first) >= 2:
                    info["has_nvidia"] = True
                    info["name"] = first[0].strip()
                    try:
                        # memory.total in MiB
                        mib = int(first[1].strip())
                        info["vram_gb"] = mib // 1024
                    except Exception:
                        pass
            # CUDA runtime version
            try:
                out2 = subprocess.check_output(
                    [nvsmi, "--query"], timeout=5, text=True,
                )
                for line in out2.splitlines():
                    if "CUDA Version" in line:
                        info["cuda_version"] = line.split(":", 1)[1].strip()
                        break
            except Exception:
                pass
            return info
        except Exception as e:
            logger.debug("nvidia-smi failed: %s", e)

    # Fallback: Win32_VideoController via WMI
    if platform.system() == "Windows":
        try:
            out = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command",
                 "$g = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -like '*NVIDIA*' } | Select-Object -First 1; "
                 "if ($g) { Write-Output ($g.Name + '|' + [math]::Floor($g.AdapterRAM / 1GB)) }"],
                timeout=8, text=True,
            ).strip()
            if "|" in out:
                name, vram = out.split("|", 1)
                info["has_nvidia"] = True
                info["name"] = name.strip()
                try:
                    info["vram_gb"] = int(vram)
                except Exception:
                    pass
        except Exception:
            pass

    return info


def _classify(ram_gb: int, vram_gb: int, has_nvidia: bool) -> str:
    # 7B Q4_K_M needs ~5GB weights + ~2GB KV cache at 16K ctx + ~1GB overhead.
    # Cards marketed as 12 GB report ~11 GB usable; 10 GB threshold catches them.
    if has_nvidia and vram_gb >= 10 and ram_gb >= 16:
        return "gpu-7b"
    if has_nvidia and vram_gb >= 6 and ram_gb >= 8:
        return "gpu-3b"
    if ram_gb >= 32:
        return "cpu-7b"
    if ram_gb >= 16:
        return "cpu-3b"
    if ram_gb >= 8:
        return "cpu-1.5b"
    return "api-only"


# ---------------------------------------------------------------------------
# Public profile API
# ---------------------------------------------------------------------------

_cache: dict[str, Any] | None = None


def get_profile(force_redetect: bool = False) -> dict[str, Any]:
    """Returns the runtime hardware profile.

    Combines install_manifest.json with live re-detection. Live wins for
    the *current* tier (catches a GPU added post-install); manifest is
    kept as `installed_tier` for reference.

    Cached after first call. Pass force_redetect=True to refresh.
    """
    global _cache
    if _cache is not None and not force_redetect:
        return _cache

    manifest = read_manifest()
    ram_gb = _ram_gb_live() or manifest.get("ram_gb", 0)
    gpu = _gpu_info_live()
    vram_gb = gpu["vram_gb"] or manifest.get("vram_gb", 0)
    has_nvidia = gpu["has_nvidia"] or vram_gb > 0

    tier = _classify(ram_gb, vram_gb, has_nvidia)

    profile = {
        "tier": tier,
        "installed_tier": manifest.get("llm_tier") or manifest.get("tier"),
        "ram_gb": ram_gb,
        "vram_gb": vram_gb,
        "has_nvidia": has_nvidia,
        "gpu_name": gpu["name"],
        "cuda_version": gpu["cuda_version"],
        "model": TIER_MODEL.get(tier),
        "platform": platform.system(),
        "manifest_present": bool(manifest),
    }
    _cache = profile
    return profile


def explain_tier(tier: str) -> str:
    """Human-readable description of a tier — used in alerts."""
    descriptions = {
        "api-only": "no local AI; uses Anthropic API if a key is configured",
        "cpu-1.5b": "CPU inference with the 1.5B model (basic AI features)",
        "cpu-3b": "CPU inference with the 3B model (most AI features, slower)",
        "cpu-7b": "CPU inference with the 7B model (full AI features, slow)",
        "gpu-3b": "GPU inference with the 3B model (most AI features, fast)",
        "gpu-7b": "GPU inference with the 7B model (full AI features, fast)",
    }
    return descriptions.get(tier, tier)


def hardware_summary() -> str:
    """One-line description of detected hardware for UI display."""
    p = get_profile()
    parts = [f"{p['ram_gb']} GB RAM"]
    if p["has_nvidia"]:
        parts.append(f"NVIDIA {p['gpu_name']} ({p['vram_gb']} GB VRAM)")
    else:
        parts.append("CPU only")
    return ", ".join(parts)
