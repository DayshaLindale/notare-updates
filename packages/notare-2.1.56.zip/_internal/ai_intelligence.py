"""Notare AI Intelligence Layer — Phase 3.

Provides:
  3.1 AI page-line summary
  3.2 AI narrative summary
  3.3 AI Chat against transcript (RAG)
  3.4 Contradiction detection
  3.5 Bluebook citation linking

LLM access:
  - Default: embedded Notare inference (notare_inference.py) — llama-cpp
    runs the model in-process. Model file is lazy-downloaded to user app
    data on first AI use. No external service, no data egress.
  - Optional: Anthropic Claude (set ANTHROPIC_API_KEY in settings/env)
    used as fallback if the local model isn't ready or fails.

Embeddings:
  - sentence-transformers/all-MiniLM-L6-v2 (CPU-friendly, ~80MB, no GPU).
  - Embeddings cached per job at job_dir/embeddings.npz.

Citation lookups:
  - CourtListener public API for case lookups (free, no auth needed for
    basic citation queries).
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# LLM client — embedded Notare inference by default, Anthropic fallback
# ---------------------------------------------------------------------------

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-4-6"


def llm_chat(messages: list[dict], settings: dict | None = None,
             temperature: float = 0.4, max_tokens: int = 1500) -> str:
    """Send a chat completion request. Returns the assistant message text.

    Tries the embedded local model first (notare_inference). If it isn't
    ready, kicks off the lazy download/load and falls back to Anthropic
    for this single call so the user isn't blocked. Returns empty string
    on total failure (caller handles).
    """
    settings = settings or {}
    prefer_local = settings.get("ai_prefer_local", True)

    # 1) Embedded local model
    if prefer_local:
        try:
            import notare_inference
            if notare_inference.is_ready():
                text = notare_inference.generate(
                    messages, temperature=temperature, max_tokens=max_tokens,
                )
                if text:
                    return text
            else:
                # First time the user pressed an AI button without the model
                # loaded — kick off the download in the background. This call
                # falls through to Anthropic so the user still gets an answer.
                notare_inference.ensure_model_async()
        except Exception as e:
            logger.debug("notare_inference call failed: %s", e)

    # 2) Anthropic fallback
    api_key = settings.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if api_key:
        try:
            import requests
            model = settings.get("ai_remote_model") or DEFAULT_ANTHROPIC_MODEL
            # Convert OpenAI-style messages to Anthropic format
            system_parts = [m["content"] for m in messages if m.get("role") == "system"]
            user_assistant = [m for m in messages if m.get("role") in ("user", "assistant")]
            r = requests.post(ANTHROPIC_URL, json={
                "model": model,
                "max_tokens": max_tokens,
                "system": "\n\n".join(system_parts) or None,
                "messages": user_assistant,
                "temperature": temperature,
            }, headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }, timeout=180)
            if r.status_code == 200:
                data = r.json()
                content = data.get("content") or []
                for blk in content:
                    if blk.get("type") == "text":
                        return blk.get("text", "").strip()
        except Exception as e:
            logger.warning("anthropic call failed: %s", e)

    return ""


def llm_available(settings: dict | None = None) -> dict:
    """Quick health check — returns which providers are reachable."""
    settings = settings or {}
    out: dict[str, Any] = {"local": False, "anthropic": False}
    try:
        import notare_inference
        status = notare_inference.get_status()
        out["local"] = status["state"] == "ready"
        out["local_status"] = status
    except Exception as e:
        logger.debug("notare_inference status failed: %s", e)
    if settings.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", ""):
        out["anthropic"] = True
    return out


# ---------------------------------------------------------------------------
# 3.1 — page-line summary
# ---------------------------------------------------------------------------

def chunk_transcript_by_page(segments: list[dict], lines_per_page: int = 25,
                             chars_per_line: int = 63) -> list[dict]:
    """Approximate NCRA pagination — returns [{page, start_idx, end_idx, lines}]."""
    pages = []
    current = {"page": 1, "start_idx": 0, "end_idx": 0, "lines": []}
    line_count = 0
    for i, seg in enumerate(segments):
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        # Roughly count lines this segment spans
        seg_lines = max(1, len(text) // chars_per_line + (1 if len(text) % chars_per_line else 0))
        if seg.get("speaker"):
            seg_lines += 1  # speaker label adds a line
        if line_count + seg_lines > lines_per_page and current["lines"]:
            current["end_idx"] = i - 1
            pages.append(current)
            current = {"page": current["page"] + 1, "start_idx": i, "end_idx": i, "lines": []}
            line_count = 0
        current["lines"].append({
            "line": line_count + 1,
            "speaker": seg.get("speaker", ""),
            "text": text,
            "seg_idx": i,
        })
        line_count += seg_lines
        current["end_idx"] = i
    if current["lines"]:
        pages.append(current)
    return pages


def generate_page_line_summary(segments: list[dict], settings: dict | None = None,
                              progress_cb=None) -> list[dict]:
    """3.1: per-page summary. Returns [{page, summary, key_lines: [int,...]}]."""
    pages = chunk_transcript_by_page(segments)
    out = []
    for i, page in enumerate(pages):
        page_text = "\n".join(
            f"L{L['line']:>2}: {L['speaker']+': ' if L['speaker'] else ''}{L['text']}"
            for L in page["lines"]
        )
        prompt = (
            "You are summarizing one page of a deposition transcript for a "
            "lawyer reviewing the proceeding.\n\n"
            f"Page {page['page']}:\n{page_text}\n\n"
            "Write a 1-2 sentence summary capturing the substantive testimony "
            "on this page. Cite specific line numbers like (L3, L7) when a "
            "fact comes from a specific line. Skip pleasantries. Output the "
            "summary only — no preamble."
        )
        text = llm_chat([
            {"role": "system", "content": "You are a deposition page summarizer for legal professionals."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.2, max_tokens=300)
        # Pull out cited lines
        cited = sorted(set(int(m.group(1)) for m in re.finditer(r'L\s*(\d+)', text)))
        out.append({
            "page": page["page"],
            "start_idx": page["start_idx"],
            "end_idx": page["end_idx"],
            "summary": text or "(summary unavailable — LLM unreachable)",
            "key_lines": cited,
        })
        if progress_cb:
            progress_cb(i + 1, len(pages))
    return out


# ---------------------------------------------------------------------------
# 3.2 — narrative summary
# ---------------------------------------------------------------------------

def generate_narrative_summary(segments: list[dict], settings: dict | None = None,
                               case_info: dict | None = None) -> str:
    """3.2: single 400-600 word narrative summary covering the whole depo."""
    # Compress segments — sample evenly if very long
    LIMIT_CHARS = 25000
    blocks = []
    total = 0
    for seg in segments:
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        spk = seg.get("speaker") or ""
        line = (f"{spk}: " if spk else "") + text
        if total + len(line) > LIMIT_CHARS:
            break
        blocks.append(line)
        total += len(line) + 1
    body = "\n".join(blocks)
    case_line = ""
    if case_info:
        c = case_info
        parts = [c.get("case_caption"), c.get("case_number"), c.get("court_name")]
        case_line = " | ".join([p for p in parts if p])
    prompt = (
        "Write a 400-600 word narrative summary of this deposition. Organize "
        "by topic (not chronologically). Capture: who the witness is, what "
        "the substantive disputes are, key admissions, areas of "
        "uncertainty, and any contradictions or impeachment moments. Use "
        "active voice. No bullet points; flowing prose.\n\n"
        + (f"Case: {case_line}\n\n" if case_line else "")
        + f"Transcript (excerpt):\n{body}"
    )
    return llm_chat([
        {"role": "system", "content": "You are a deposition summarizer for trial lawyers. Write clear, concise narrative summaries."},
        {"role": "user", "content": prompt},
    ], settings=settings, temperature=0.3, max_tokens=2000) or "(summary unavailable — LLM unreachable)"


# ---------------------------------------------------------------------------
# 3.3 — RAG chat against transcript
# ---------------------------------------------------------------------------

_EMBED_MODEL = None


def _get_embed_model():
    """Lazy-load sentence-transformers all-MiniLM-L6-v2."""
    global _EMBED_MODEL
    if _EMBED_MODEL is None:
        try:
            from sentence_transformers import SentenceTransformer
            _EMBED_MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        except Exception as e:
            logger.warning("sentence-transformers not available: %s", e)
            return None
    return _EMBED_MODEL


def _chunk_for_embedding(segments: list[dict], chunk_tokens: int = 200,
                         overlap: int = 30) -> list[dict]:
    """Window the transcript into ~200-token chunks with 30-token overlap."""
    chunks = []
    buf_text = ""
    buf_segs = []
    buf_tokens = 0
    for i, seg in enumerate(segments):
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        spk = seg.get("speaker") or ""
        line = (f"{spk}: " if spk else "") + text
        # Rough token count: chars/4
        line_toks = max(1, len(line) // 4)
        if buf_tokens + line_toks > chunk_tokens and buf_segs:
            chunks.append({
                "text": buf_text.strip(),
                "first_idx": buf_segs[0],
                "last_idx": buf_segs[-1],
            })
            # Overlap window
            keep = max(1, len(buf_segs) // 5)
            buf_segs = buf_segs[-keep:]
            buf_text = " ... ".join(
                ((segments[j].get("speaker") + ": ") if segments[j].get("speaker") else "")
                + (segments[j].get("text") or "") for j in buf_segs
            ) + "\n"
            buf_tokens = sum(max(1, len(segments[j].get("text") or "") // 4) for j in buf_segs)
        buf_text += line + "\n"
        buf_segs.append(i)
        buf_tokens += line_toks
    if buf_segs:
        chunks.append({
            "text": buf_text.strip(),
            "first_idx": buf_segs[0],
            "last_idx": buf_segs[-1],
        })
    return chunks


def build_embedding_index(job_dir: Path, segments: list[dict],
                          force: bool = False) -> dict | None:
    """Build (or load) per-job embedding index. Returns {chunks, embeddings}.

    Cached at job_dir/embeddings.npz (numpy format) + chunks at
    job_dir/embeddings_chunks.json.
    """
    import numpy as np
    cache_npz = job_dir / "embeddings.npz"
    cache_json = job_dir / "embeddings_chunks.json"
    if not force and cache_npz.exists() and cache_json.exists():
        try:
            arr = np.load(cache_npz)
            chunks = json.loads(cache_json.read_text(encoding="utf-8"))
            return {"chunks": chunks, "embeddings": arr["embeddings"]}
        except Exception:
            pass

    model = _get_embed_model()
    if model is None:
        return None

    chunks = _chunk_for_embedding(segments)
    if not chunks:
        return None
    texts = [c["text"] for c in chunks]
    embs = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    np.savez_compressed(cache_npz, embeddings=embs)
    cache_json.write_text(json.dumps(chunks), encoding="utf-8")
    return {"chunks": chunks, "embeddings": embs}


def retrieve_top_k(index: dict, query: str, k: int = 6) -> list[dict]:
    import numpy as np
    model = _get_embed_model()
    if model is None or not index:
        return []
    qe = model.encode([query], normalize_embeddings=True)[0]
    sims = index["embeddings"] @ qe
    top = np.argsort(-sims)[:k]
    return [{**index["chunks"][int(i)], "score": float(sims[int(i)])} for i in top]


def chat_with_transcript(job_dir: Path, segments: list[dict], question: str,
                        history: list[dict] | None = None,
                        settings: dict | None = None) -> dict:
    """3.3: answer a question using RAG. Returns {answer, citations: [seg_idx,...]}."""
    index = build_embedding_index(job_dir, segments)
    if not index:
        # Fallback — pass the whole transcript (truncated) without retrieval
        body = "\n".join(
            (s.get("speaker", "") + ": " if s.get("speaker") else "") + (s.get("text") or "")
            for s in segments[:300]
        )
        prompt = (
            f"Question: {question}\n\nTranscript:\n{body}\n\n"
            "Answer the question using only the transcript. Cite segment "
            "numbers like [seg N] for every claim."
        )
        text = llm_chat([
            {"role": "system", "content": "You are a deposition Q&A assistant. Cite segments for every claim."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.2, max_tokens=1500)
        return {"answer": text or "(unable to answer — LLM unreachable)", "citations": []}

    hits = retrieve_top_k(index, question, k=6)
    context = "\n\n".join(
        f"[chunk @ segments {h['first_idx']}-{h['last_idx']}] {h['text']}"
        for h in hits
    )
    msgs = [
        {"role": "system", "content": (
            "You are answering questions about a specific deposition transcript. "
            "Use only the supplied excerpts. Every factual claim MUST be "
            "followed by a citation in the form [seg N] where N is the "
            "segment index. If the answer is not in the excerpts, say so."
        )},
    ]
    if history:
        msgs.extend(history)
    msgs.append({"role": "user", "content": f"Question: {question}\n\nRelevant excerpts:\n{context}"})

    answer = llm_chat(msgs, settings=settings, temperature=0.2, max_tokens=1500)
    citations = sorted(set(int(m.group(1)) for m in re.finditer(r'\[seg\s+(\d+)\]', answer or "")))
    return {"answer": answer or "(unable to answer — LLM unreachable)", "citations": citations}


# ---------------------------------------------------------------------------
# 3.4 — contradiction detection
# ---------------------------------------------------------------------------

def detect_contradictions(job_dir: Path, segments: list[dict],
                         settings: dict | None = None,
                         threshold: float = 0.62) -> list[dict]:
    """3.4: find within-deposition contradictions. Returns
    [{idx_a, idx_b, type, confidence, explanation}].
    """
    import numpy as np
    index = build_embedding_index(job_dir, segments)
    if not index:
        return []
    embs = index["embeddings"]
    chunks = index["chunks"]
    candidates = []
    # Pairs above similarity threshold but with surface-form contradiction signals
    sim_matrix = embs @ embs.T
    for i in range(len(chunks)):
        for j in range(i + 1, len(chunks)):
            sim = float(sim_matrix[i, j])
            if sim < threshold:
                continue
            # Quick filter: the two chunks shouldn't be adjacent
            if abs(chunks[i]["first_idx"] - chunks[j]["first_idx"]) < 5:
                continue
            ti = chunks[i]["text"]
            tj = chunks[j]["text"]
            # Surface-form signal: negation flip
            negs_i = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t|can'?t|isn'?t|haven'?t|wouldn'?t)\b", ti, re.I))
            negs_j = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t|can'?t|isn'?t|haven'?t|wouldn'?t)\b", tj, re.I))
            if negs_i != negs_j:
                candidates.append({"i": i, "j": j, "sim": sim, "signal": "negation_flip"})
            # Number/date mismatch signal
            nums_i = set(re.findall(r"\b\d+\b", ti))
            nums_j = set(re.findall(r"\b\d+\b", tj))
            if nums_i and nums_j and nums_i.isdisjoint(nums_j) and (nums_i ^ nums_j):
                candidates.append({"i": i, "j": j, "sim": sim, "signal": "number_mismatch"})
    # Dedup pairs
    seen = set()
    unique = []
    for c in candidates:
        key = (c["i"], c["j"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(c)
    # LLM-validate top candidates (cap at 12 to control cost)
    out = []
    for c in unique[:12]:
        ti = chunks[c["i"]]["text"]
        tj = chunks[c["j"]]["text"]
        prompt = (
            "Are these two excerpts from the same deposition contradictory or "
            "inconsistent? Answer in JSON: "
            '{"contradiction": true|false, "type": "negation"|"number"|"date"|"semantic"|"none", '
            '"explanation": "..."}\n\n'
            f"A (segments {chunks[c['i']]['first_idx']}-{chunks[c['i']]['last_idx']}):\n{ti}\n\n"
            f"B (segments {chunks[c['j']]['first_idx']}-{chunks[c['j']]['last_idx']}):\n{tj}"
        )
        resp = llm_chat([
            {"role": "system", "content": "Output ONLY the JSON object, nothing else."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.1, max_tokens=400)
        try:
            m = re.search(r'\{.*?\}', resp or "", re.S)
            j_obj = json.loads(m.group()) if m else None
        except Exception:
            j_obj = None
        if j_obj and j_obj.get("contradiction"):
            out.append({
                "idx_a": chunks[c["i"]]["first_idx"],
                "idx_b": chunks[c["j"]]["first_idx"],
                "range_a": [chunks[c["i"]]["first_idx"], chunks[c["i"]]["last_idx"]],
                "range_b": [chunks[c["j"]]["first_idx"], chunks[c["j"]]["last_idx"]],
                "type": j_obj.get("type", c["signal"]),
                "confidence": float(c["sim"]),
                "explanation": j_obj.get("explanation", ""),
            })
    out.sort(key=lambda x: -x["confidence"])
    return out


# ---------------------------------------------------------------------------
# 3.5 — Bluebook citation linking
# ---------------------------------------------------------------------------

# Common citation formats (Bluebook 21st ed.)
CITATION_PATTERNS = [
    # 410 U.S. 113
    (r'\b(\d{1,4})\s+(U\.S\.|U\.\s*S\.)\s+(\d+)\b', "us"),
    # 123 F.3d 456
    (r'\b(\d{1,4})\s+F\.\s*(\d?d?)\s+(\d+)\b', "f"),
    # 123 F. Supp. 2d 456
    (r'\b(\d{1,4})\s+F\.\s*Supp\.?\s*(\d?d?)\s+(\d+)\b', "fsupp"),
    # 123 S. Ct. 456
    (r'\b(\d{1,4})\s+S\.\s*Ct\.\s+(\d+)\b', "sct"),
    # 123 L. Ed. 2d 456
    (r'\b(\d{1,4})\s+L\.\s*Ed\.\s*(\d?d?)\s+(\d+)\b', "led"),
    # State reporters: 123 P.3d 456 / 123 N.E.2d 456 / 123 Cal. 4th 456 / etc.
    (r'\b(\d{1,4})\s+([A-Z]\.[A-Za-z\.]*\d*\w*)\s+(\d+)\b', "state"),
]


def detect_citations(text: str) -> list[dict]:
    """Return [{citation, span: [start, end], type, key}] for all detected citations."""
    out = []
    for pat, kind in CITATION_PATTERNS:
        for m in re.finditer(pat, text):
            out.append({
                "citation": m.group(0),
                "start": m.start(),
                "end": m.end(),
                "type": kind,
            })
    # Dedup overlapping
    out.sort(key=lambda x: (x["start"], -x["end"]))
    deduped = []
    for c in out:
        if deduped and c["start"] < deduped[-1]["end"]:
            continue
        deduped.append(c)
    return deduped


def lookup_citation_courtlistener(citation: str, timeout: float = 5.0) -> dict | None:
    """Look up a citation via the CourtListener public API. Returns {url, name} or None."""
    try:
        import requests
        # Use the citation lookup endpoint
        r = requests.get(
            "https://www.courtlistener.com/api/rest/v3/search/",
            params={"q": citation, "type": "o"},
            timeout=timeout,
        )
        if r.status_code == 200:
            results = (r.json() or {}).get("results") or []
            if results:
                first = results[0]
                return {
                    "case_name": first.get("caseName") or first.get("caseNameShort"),
                    "url": "https://www.courtlistener.com" + (first.get("absolute_url") or ""),
                    "court": first.get("court", ""),
                    "date_filed": first.get("dateFiled", ""),
                }
    except Exception as e:
        logger.debug("courtlistener lookup failed for %s: %s", citation, e)
    return None


def link_citations_in_transcript(segments: list[dict],
                                 lookup: bool = False) -> list[dict]:
    """3.5: detect Bluebook citations in transcript text. Returns
    [{seg_idx, citation, start, end, type, case_name?, url?}].
    """
    out = []
    for i, seg in enumerate(segments):
        text = seg.get("text") or ""
        if not text:
            continue
        for cit in detect_citations(text):
            entry = {"seg_idx": i, **cit}
            if lookup:
                meta = lookup_citation_courtlistener(cit["citation"])
                if meta:
                    entry.update(meta)
            out.append(entry)
    return out


# ---------------------------------------------------------------------------
# Phase 4.1 — exhibit direct-to-page sync
# ---------------------------------------------------------------------------

# Match patterns like:
#   "Exhibit 3, page 14"        "page 14 of Exhibit 3"
#   "Exhibit A page 7"          "Exhibit A, p. 7"
#   "turn to page 14 of Exhibit B"
EXHIBIT_PAGE_PATTERNS = [
    re.compile(r'\b[Ee]xhibit\s+([A-Za-z0-9]+)[\s,]*(?:page|p\.?)\s*(\d+)\b'),
    re.compile(r'\b(?:page|p\.?)\s*(\d+)[\s,]+(?:of\s+)?[Ee]xhibit\s+([A-Za-z0-9]+)\b'),
    re.compile(r'\b[Ee]xhibit\s+([A-Za-z0-9]+)\s+(\d+)\b'),  # "Exhibit 3 14" — ambiguous, low-conf
]


def detect_exhibit_page_references(segments: list[dict]) -> list[dict]:
    """Phase 4.1: scan segments for 'Exhibit X page Y' references.

    Returns [{seg_idx, exhibit_id, page, span: [start,end], confidence}].
    """
    refs = []
    for i, seg in enumerate(segments):
        text = seg.get("text") or ""
        if not text:
            continue
        for pat_idx, pat in enumerate(EXHIBIT_PAGE_PATTERNS):
            for m in pat.finditer(text):
                # Normalize group order — first pattern: (exhibit, page)
                # second: (page, exhibit). Third: (exhibit, page) low-conf.
                if pat_idx == 1:
                    page, exhibit_id = m.group(1), m.group(2)
                else:
                    exhibit_id, page = m.group(1), m.group(2)
                refs.append({
                    "seg_idx": i,
                    "exhibit_id": exhibit_id,
                    "page": int(page),
                    "span": [m.start(), m.end()],
                    "match_text": m.group(0),
                    "confidence": 0.9 if pat_idx < 2 else 0.5,
                })
    # Dedup by (seg_idx, span_start)
    seen = set()
    deduped = []
    for r in refs:
        key = (r["seg_idx"], r["span"][0])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    return deduped


# ---------------------------------------------------------------------------
# Phase 4.2 — cross-deposition intelligence (case-level analysis)
# ---------------------------------------------------------------------------

def cross_deposition_search(jobs: list[dict], query: str,
                            settings: dict | None = None,
                            top_k_per_depo: int = 3) -> list[dict]:
    """Phase 4.2: semantic search across all depositions in a case.

    Returns ranked matches across jobs:
      [{job_id, witness_name, seg_idx, text, score}, ...]
    """
    import numpy as np
    model = _get_embed_model()
    if model is None:
        return []
    qe = model.encode([query], normalize_embeddings=True)[0]
    out = []
    for job in jobs:
        if not job.get("transcript"):
            continue
        segs = job["transcript"].get("segments", [])
        if not segs:
            continue
        index = build_embedding_index(Path(job["dir"]), segs)
        if not index:
            continue
        sims = index["embeddings"] @ qe
        top = np.argsort(-sims)[:top_k_per_depo]
        for i in top:
            i = int(i)
            chunk = index["chunks"][i]
            out.append({
                "job_id": job.get("id") or job.get("job_id"),
                "witness_name": job.get("witness_name") or job.get("title", ""),
                "case_caption": job.get("case_caption", ""),
                "seg_idx": chunk["first_idx"],
                "range": [chunk["first_idx"], chunk["last_idx"]],
                "text": chunk["text"],
                "score": float(sims[i]),
            })
    out.sort(key=lambda x: -x["score"])
    return out


def cross_deposition_contradictions(jobs: list[dict],
                                    settings: dict | None = None,
                                    threshold: float = 0.65) -> list[dict]:
    """Phase 4.2: find contradictions BETWEEN depositions in the same case.

    Useful for impeaching a witness whose later testimony contradicts an
    earlier deposition, or contrasting two witnesses' accounts of the same
    event.
    """
    import numpy as np
    model = _get_embed_model()
    if model is None or len(jobs) < 2:
        return []

    indices = []
    for job in jobs:
        if not job.get("transcript"):
            continue
        segs = job["transcript"].get("segments", [])
        if not segs:
            continue
        idx = build_embedding_index(Path(job["dir"]), segs)
        if not idx:
            continue
        indices.append({"job": job, "index": idx})

    if len(indices) < 2:
        return []

    candidates = []
    for a_i in range(len(indices)):
        for b_i in range(a_i + 1, len(indices)):
            A = indices[a_i]
            B = indices[b_i]
            sim_matrix = A["index"]["embeddings"] @ B["index"]["embeddings"].T
            for i in range(sim_matrix.shape[0]):
                for j in range(sim_matrix.shape[1]):
                    sim = float(sim_matrix[i, j])
                    if sim < threshold:
                        continue
                    ti = A["index"]["chunks"][i]["text"]
                    tj = B["index"]["chunks"][j]["text"]
                    negs_i = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t)\b", ti, re.I))
                    negs_j = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t)\b", tj, re.I))
                    nums_i = set(re.findall(r"\b\d+\b", ti))
                    nums_j = set(re.findall(r"\b\d+\b", tj))
                    has_signal = (negs_i != negs_j) or (
                        nums_i and nums_j and nums_i.isdisjoint(nums_j)
                    )
                    if has_signal:
                        candidates.append({
                            "job_a": A["job"].get("id") or A["job"].get("job_id"),
                            "witness_a": A["job"].get("witness_name") or A["job"].get("title", ""),
                            "range_a": [A["index"]["chunks"][i]["first_idx"], A["index"]["chunks"][i]["last_idx"]],
                            "text_a": ti,
                            "job_b": B["job"].get("id") or B["job"].get("job_id"),
                            "witness_b": B["job"].get("witness_name") or B["job"].get("title", ""),
                            "range_b": [B["index"]["chunks"][j]["first_idx"], B["index"]["chunks"][j]["last_idx"]],
                            "text_b": tj,
                            "confidence": sim,
                        })

    # LLM-validate top candidates
    candidates.sort(key=lambda c: -c["confidence"])
    out = []
    for c in candidates[:10]:
        prompt = (
            "Are these two excerpts from different depositions in the same "
            "case substantively contradictory or inconsistent? Reply JSON: "
            '{"contradiction": true|false, "type": "...", "explanation": "..."}\n\n'
            f"From {c['witness_a']}:\n{c['text_a']}\n\n"
            f"From {c['witness_b']}:\n{c['text_b']}"
        )
        resp = llm_chat([
            {"role": "system", "content": "Output ONLY JSON."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.1, max_tokens=400)
        try:
            m = re.search(r'\{.*?\}', resp or "", re.S)
            j_obj = json.loads(m.group()) if m else None
        except Exception:
            j_obj = None
        if j_obj and j_obj.get("contradiction"):
            out.append({**c, "type": j_obj.get("type", "semantic"), "explanation": j_obj.get("explanation", "")})
    return out


# ---------------------------------------------------------------------------
# Phase 4.3 — real-time follow-up question suggestion (attorney aid)
# ---------------------------------------------------------------------------

def suggest_follow_up_questions(recent_segments: list[dict],
                                case_topics: list[str] | None = None,
                                covered_topics: list[str] | None = None,
                                settings: dict | None = None) -> dict:
    """Phase 4.3: surface attorney suggestions based on recent testimony.

    Inputs:
      recent_segments: last ~15 segments (live tail)
      case_topics: topics the attorney wants to cover (optional)
      covered_topics: topics already addressed (optional)

    Returns:
      {
        "suggestions": [{"question": str, "rationale": str, "topic": str}, ...],
        "missed_topics": [str, ...]
      }
    """
    if not recent_segments:
        return {"suggestions": [], "missed_topics": []}
    tail = "\n".join(
        ((s.get("speaker") or "") + ": " if s.get("speaker") else "")
        + (s.get("text") or "")
        for s in recent_segments
    )
    topics_hint = ""
    if case_topics:
        topics_hint += "\nTopics to cover: " + ", ".join(case_topics)
    if covered_topics:
        topics_hint += "\nAlready covered: " + ", ".join(covered_topics)

    prompt = (
        "You are assisting an attorney conducting a deposition. Based on "
        "the witness's last few answers, suggest up to 3 follow-up "
        "questions that would be worth asking — questions that probe "
        "inconsistency, request specifics, anchor a fact for trial, or "
        "fill a gap. Output JSON:\n"
        '{"suggestions": [{"question": "...", "rationale": "...", "topic": "..."}], '
        '"missed_topics": ["..."]}\n\n'
        f"Recent testimony:\n{tail}{topics_hint}"
    )
    resp = llm_chat([
        {"role": "system", "content": "You are a deposition strategy assistant. Output ONLY valid JSON."},
        {"role": "user", "content": prompt},
    ], settings=settings, temperature=0.5, max_tokens=900)
    try:
        m = re.search(r'\{.*\}', resp or "", re.S)
        if not m:
            return {"suggestions": [], "missed_topics": []}
        return json.loads(m.group())
    except Exception:
        return {"suggestions": [], "missed_topics": [], "raw": resp}


# ---------------------------------------------------------------------------
# Phase 2 — Qwen speaker labeler (SPEAKER_NN → human name)
# ---------------------------------------------------------------------------
# Notare's ECAPA streaming clustering groups voices into SPEAKER_01,
# SPEAKER_02, … by acoustic identity. Qwen reads the transcript text + the
# matter intake (attorneys, witness, reporter from new_job.html / WS4 form)
# and proposes a human-name mapping for each cluster. The reporter has
# final edit authority — Qwen suggests, reporter accepts/rejects/edits.

def suggest_speaker_labels(job: dict, segments: list[dict],
                           settings: dict | None = None) -> dict:
    """Map SPEAKER_NN cluster IDs to human names using transcript + matter context.

    Returns:
        {
          "mapping": {"SPEAKER_01": "MR. JOHNSON", "SPEAKER_02": "THE WITNESS", ...},
          "confidence": {"SPEAKER_01": 0.92, "SPEAKER_02": 0.55, ...},
          "rationale": {"SPEAKER_01": "Self-identifies as 'Counsel for plaintiff'...", ...},
          "unmapped": ["SPEAKER_03"]   # clusters Qwen wouldn't guess
        }

    Conservative: returns the SPEAKER_NN unchanged when context is ambiguous.
    Closed vocabulary — only proposes names that appear in the matter intake.
    """
    if not segments:
        return {"mapping": {}, "confidence": {}, "rationale": {}, "unmapped": []}

    # Collect unique speaker-label "clusters" + a sample of utterances per
    # cluster. Includes ALL labels — SPEAKER_NN (acoustic clusters from
    # ECAPA), "Reporter" / "Remote (Zoom)" (fixed channel labels), and any
    # human names already manually entered. Qwen looks at the utterance
    # samples and suggests renames where evidence supports it (e.g. self-
    # introductions: "This is Mr. Taylor" → reassign that cluster to
    # MR. TAYLOR). Leaves clusters unchanged when context is ambiguous.
    cluster_samples: dict[str, list[str]] = {}
    for seg in segments:
        spk = (seg.get("speaker") or "").strip()
        if not spk:
            continue
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        cluster_samples.setdefault(spk, []).append(text)

    if not cluster_samples:
        return {"mapping": {}, "confidence": {}, "rationale": {}, "unmapped": []}

    # Cap samples per cluster to keep the prompt bounded
    max_samples = 8
    for spk in list(cluster_samples.keys()):
        utterances = cluster_samples[spk]
        if len(utterances) > max_samples:
            # Take first 3 + last 3 + 2 from middle — captures opening / closing / mid-arc patterns
            mid_start = len(utterances) // 2 - 1
            picks = utterances[:3] + utterances[mid_start:mid_start + 2] + utterances[-3:]
            cluster_samples[spk] = picks

    # Matter context — from the job's intake fields (set in WS1 / WS4 / WS5 forms)
    case_caption = (job.get("case_caption") or "").strip()
    case_number  = (job.get("case_number") or "").strip()
    court_name   = (job.get("court_name") or "").strip()
    witness      = (job.get("witness") or "").strip()
    reporter     = (job.get("reporter_name") or "").strip()

    # Attorneys list lives under different keys depending on which intake
    # form created the job (WS4 uses 'speakers' list; WS1 uses 'attorneys').
    attorneys = job.get("attorneys") or job.get("speakers") or []
    if not isinstance(attorneys, list):
        attorneys = []

    # Build a closed-vocabulary string of expected human names — Qwen
    # picks from this list rather than inventing names.
    expected_names: list[str] = []
    if witness:
        expected_names.append(f"THE WITNESS  ({witness})")
    if reporter:
        expected_names.append(f"COURT REPORTER  ({reporter})")
    expected_names.append("THE COURT")  # always plausible in legal proceedings
    expected_names.append("THE INTERPRETER")
    for a in attorneys:
        if not isinstance(a, dict):
            continue
        name = (a.get("name") or "").strip()
        firm = (a.get("firm") or "").strip()
        rep  = (a.get("representing") or a.get("rep") or "").strip()
        if not name:
            continue
        # Format like a court reporter would: "MR. JONES" / "MS. SMITH"
        prefix = "MR." if name.upper().startswith(("MR ", "MR.")) else (
            "MS." if name.upper().startswith(("MS ", "MS.", "MRS ", "MRS.")) else ""
        )
        formatted = name.upper() if prefix else name
        suffix_parts = []
        if firm: suffix_parts.append(firm)
        if rep:  suffix_parts.append(f"for {rep}")
        suffix = f"  ({', '.join(suffix_parts)})" if suffix_parts else ""
        expected_names.append(f"{formatted}{suffix}")

    expected_block = "\n".join(f"  - {n}" for n in expected_names) if expected_names else "  (no matter intake provided — use generic role names if obvious from context)"

    # Build the prompt
    cluster_block_parts = []
    for spk, utterances in cluster_samples.items():
        sample_text = "\n    ".join(f"- \"{u}\"" for u in utterances[:8])
        cluster_block_parts.append(f"  {spk}:\n    {sample_text}")
    cluster_block = "\n".join(cluster_block_parts)

    matter_lines = []
    if case_caption: matter_lines.append(f"Case caption: {case_caption}")
    if case_number:  matter_lines.append(f"Case number:  {case_number}")
    if court_name:   matter_lines.append(f"Court:        {court_name}")
    matter_block = "\n".join(matter_lines) if matter_lines else "(no case info provided)"

    prompt = (
        "You are assisting a court reporter. Each speaker cluster below is "
        "either an anonymous acoustic cluster (SPEAKER_01, SPEAKER_02, …), a "
        "fixed channel label (Reporter, Remote (Zoom)), or a name already "
        "set. Your job is to read the sample utterances and propose a "
        "rename when the text gives clear evidence — e.g. self-introductions "
        "(\"this is Mr. Taylor\"), being addressed (\"Mr. Smith, please state…\"), "
        "or role-shaped speech (Q/A patterns, judge-style commentary). Pick "
        "the new name from the closed vocabulary below. Be conservative — "
        "if the evidence is weak or ambiguous, leave the cluster alone.\n\n"
        f"MATTER:\n{matter_block}\n\n"
        f"EXPECTED SPEAKERS (closed vocabulary — pick from this list ONLY):\n{expected_block}\n\n"
        f"CLUSTERS WITH SAMPLE UTTERANCES:\n{cluster_block}\n\n"
        "Output JSON ONLY in this exact shape:\n"
        '{\n'
        '  "mapping":   {"SPEAKER_01": "MR. JONES", "Reporter": "MR. TAYLOR", …},\n'
        '  "confidence": {"SPEAKER_01": 0.92, "Reporter": 0.78, …},  // 0.0–1.0\n'
        '  "rationale":  {"SPEAKER_01": "Says \'I represent the plaintiff\' at L3.", …}\n'
        '}\n\n'
        "Rules:\n"
        " - Use the formatted name from the EXPECTED SPEAKERS list (e.g. 'MR. JONES'), not free-form.\n"
        " - If a cluster doesn't have clear evidence of a rename, OMIT it from 'mapping' (leaves the existing label alone).\n"
        " - Confidence < 0.65 means you're guessing — leave it OUT of the mapping.\n"
        " - One cluster = one name. Don't propose multiple names per cluster.\n"
        " - Self-introductions are strong evidence (\"this is X\", \"my name is X\").\n"
        " - Don't propose renaming a cluster to its own current label — that's a no-op.\n"
    )

    resp = llm_chat([
        {"role": "system", "content": "You are a court-reporter speaker-labeling assistant. Output only valid JSON."},
        {"role": "user", "content": prompt},
    ], settings=settings, temperature=0.15, max_tokens=900)

    try:
        m = re.search(r'\{.*\}', resp or "", re.S)
        if not m:
            return {"mapping": {}, "confidence": {}, "rationale": {},
                    "unmapped": list(cluster_samples.keys()), "raw": resp}
        parsed = json.loads(m.group())
    except Exception:
        return {"mapping": {}, "confidence": {}, "rationale": {},
                "unmapped": list(cluster_samples.keys()), "raw": resp}

    mapping    = parsed.get("mapping") or {}
    confidence = parsed.get("confidence") or {}
    rationale  = parsed.get("rationale") or {}

    # Anything in cluster_samples but NOT in mapping is unmapped (Qwen left it as SPEAKER_NN)
    unmapped = [c for c in cluster_samples.keys() if c not in mapping]

    return {
        "mapping":    mapping,
        "confidence": confidence,
        "rationale":  rationale,
        "unmapped":   unmapped,
    }


# ---------------------------------------------------------------------------
# Phase 3+4 — Qwen "Polish" pass: punctuation, capitalization, homophones,
# witness-name correction. Reporter-approval pattern (Option 2): Qwen
# proposes corrections per segment, reporter reviews each in a modal,
# accepts/rejects/edits before any rewrite.
# ---------------------------------------------------------------------------

_HOMOPHONE_HINTS = (
    "your/you're, there/their/they're, its/it's, then/than, hear/here, "
    "principal/principle, accept/except, affect/effect, to/too/two, "
    "lose/loose, who's/whose, lead/led, cite/site/sight, "
    "for/four, where/were/we're, peace/piece, knew/new, no/know, "
    "complement/compliment, council/counsel, capital/capitol"
)


def suggest_polish(job: dict, segments: list[dict],
                   settings: dict | None = None,
                   limit: int = 200) -> dict:
    """Per-segment Qwen review: punctuation, capitalization (legal terms),
    homophones, witness-name mishearings against matter context. Returns
    proposed corrections; reporter reviews in modal before any rewrite.

    Returns:
        {
          "suggestions": [
            {
              "index": int,
              "original": str,
              "suggested": str,
              "changes": ["punctuation", "capitalization", "homophone", "name"],
              "rationale": "Capitalized 'the Court'; 'their' → 'they're'..."
            }, ...
          ]
        }

    Conservative — segment with no clear improvement is omitted entirely.
    """
    if not segments:
        return {"suggestions": []}

    # Matter context for witness/name correction
    case_caption = (job.get("case_caption") or "").strip()
    witness      = (job.get("witness") or "").strip()
    reporter     = (job.get("reporter_name") or "").strip()
    attorneys    = job.get("attorneys") or job.get("speakers") or []
    expected_names = []
    if witness:  expected_names.append(witness)
    if reporter: expected_names.append(reporter)
    for a in attorneys if isinstance(attorneys, list) else []:
        if isinstance(a, dict) and a.get("name"):
            expected_names.append(a["name"].strip())
    expected_block = (
        ("Names from this proceeding: " + ", ".join(expected_names) + ".")
        if expected_names else ""
    )

    # Cap at `limit` segments per call to keep prompt size bounded.
    # Caller can paginate by passing slices of segments[].
    capped = segments[:limit]

    seg_block = "\n".join(
        f"[{seg.get('index', i)}] " + (seg.get("text") or "").replace("\n", " ").strip()
        for i, seg in enumerate(capped)
    )

    prompt = (
        "You are reviewing a court-reporter transcript segment-by-segment for "
        "FOUR specific kinds of error. Each segment is on its own line with "
        "its index in [brackets]. For each segment, propose a correction "
        "ONLY when the original is clearly wrong on one of these axes:\n\n"
        " 1. PUNCTUATION — missing periods, wrong commas, missing question marks.\n"
        " 2. CAPITALIZATION — proper-noun and legal-term capitalization "
        "    (the Court, Defendant, Plaintiff, the Witness when these refer "
        "    to specific roles in the proceeding).\n"
        f" 3. HOMOPHONES — wrong sound-alike: {_HOMOPHONE_HINTS}\n"
        " 4. WITNESS / ATTORNEY NAME mishearing — the segment contains a "
        "    name-shaped word that matches a name from the matter context "
        "    when corrected.\n\n"
        "Be CONSERVATIVE. Court reporters need verbatim accuracy. Do NOT:\n"
        " - 'Improve' grammar that's grammatically OK as-spoken (verbatim rule).\n"
        " - Remove filler words (\"um\", \"uh\") — those are intentional.\n"
        " - Rephrase for style.\n"
        " - Insert words you're guessing at.\n\n"
        "Output JSON ONLY in this exact shape:\n"
        '{\n'
        '  "suggestions": [\n'
        '    {\n'
        '      "index": 5,\n'
        '      "suggested": "the Court asked her if she\'d been there before.",\n'
        '      "changes": ["capitalization", "homophone"],\n'
        '      "rationale": "Capitalized \'Court\'; their → there."\n'
        '    },\n'
        '    ...\n'
        '  ]\n'
        '}\n\n'
        f"{expected_block}\n\n"
        "SEGMENTS TO REVIEW:\n" + seg_block + "\n"
    )

    resp = llm_chat([
        {"role": "system", "content": "You are a court-transcript polish assistant. Output only valid JSON. Be conservative — verbatim wins over grammatical."},
        {"role": "user", "content": prompt},
    ], settings=settings, temperature=0.1, max_tokens=3000)

    try:
        m = re.search(r'\{.*\}', resp or "", re.S)
        if not m:
            return {"suggestions": [], "raw": resp}
        parsed = json.loads(m.group())
    except Exception:
        return {"suggestions": [], "raw": resp}

    out = parsed.get("suggestions") or []
    # Attach the original text to each suggestion for the modal UI
    by_idx = {seg.get("index", i): seg for i, seg in enumerate(capped)}
    enriched = []
    for s in out:
        if not isinstance(s, dict):
            continue
        idx = s.get("index")
        if idx not in by_idx:
            continue
        orig = (by_idx[idx].get("text") or "").strip()
        suggested = (s.get("suggested") or "").strip()
        if not suggested or suggested == orig:
            continue  # no-op, drop
        enriched.append({
            "index": idx,
            "original": orig,
            "suggested": suggested,
            "changes": s.get("changes") or [],
            "rationale": s.get("rationale") or "",
        })

    return {"suggestions": enriched}


def apply_polish(job: dict, accepted: list[dict]) -> dict:
    """Reporter accepts a list of polish suggestions — apply each to the
    matching segment. Original text preserved on each segment as
    `polish_original` so revert is one click. Returns counts.
    """
    if not accepted:
        return {"updated_count": 0}
    transcript = job.get("transcript") or {}
    segments = transcript.get("segments", [])
    updated = 0
    for sugg in accepted:
        if not isinstance(sugg, dict):
            continue
        idx = sugg.get("index")
        new_text = (sugg.get("suggested") or "").strip()
        if idx is None or not new_text:
            continue
        if 0 <= idx < len(segments):
            seg = segments[idx]
            if "polish_original" not in seg:
                seg["polish_original"] = seg.get("text", "")
            seg["text"] = new_text
            seg["polish_qwen_applied"] = True
            updated += 1
    return {"updated_count": updated}


def revert_polish(job: dict, indices: list[int] | None = None) -> dict:
    """Reporter undoes Qwen polish on specified segments (or all if None).
    Restores the original text from `polish_original`.
    """
    transcript = job.get("transcript") or {}
    segments = transcript.get("segments", [])
    reverted = 0
    for i, seg in enumerate(segments):
        if not seg.get("polish_qwen_applied"):
            continue
        if indices is not None and i not in indices:
            continue
        original = seg.get("polish_original")
        if original is None:
            continue
        seg["text"] = original
        seg.pop("polish_qwen_applied", None)
        seg.pop("polish_original", None)
        reverted += 1
    return {"reverted_count": reverted}


def apply_speaker_labels(job: dict, mapping: dict[str, str]) -> dict:
    """Rewrite SPEAKER_NN labels on every segment using the cluster→name mapping.

    Reporter-final-authority pattern: this is called when the reporter
    accepts a Qwen suggestion. The original cluster ID is preserved on
    each segment as `speaker_cluster` so the reporter can revert with one
    click ('show original SPEAKER_NN').

    Returns:
        {"updated_count": int, "clusters_renamed": [str, ...]}
    """
    if not mapping:
        return {"updated_count": 0, "clusters_renamed": []}
    transcript = job.get("transcript") or {}
    segments = transcript.get("segments", [])
    updated = 0
    renamed = set()
    for seg in segments:
        spk = (seg.get("speaker") or "").strip()
        if spk in mapping:
            # Preserve the cluster ID for revert capability
            if "speaker_cluster" not in seg:
                seg["speaker_cluster"] = spk
            seg["speaker"] = mapping[spk]
            seg["speaker_qwen_labeled"] = True
            updated += 1
            renamed.add(spk)
    if updated:
        # Persist the mapping on the job so future segments from the same
        # cluster auto-inherit the human name.
        job["speaker_label_mapping"] = {**(job.get("speaker_label_mapping") or {}), **mapping}
    return {"updated_count": updated, "clusters_renamed": sorted(renamed)}
