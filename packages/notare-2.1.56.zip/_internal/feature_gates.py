"""Notare feature gates — which AI features each hardware tier supports.

When the UI is about to invoke an AI feature, it calls check_gate(feature).
If the user's tier doesn't satisfy the gate, the response carries a
structured reason — what's required, what's missing, what the user can do
about it. The UI renders that reason in a small alert.

Gating principles:
  - Don't lock users out — surface the constraint, suggest alternatives.
  - Anthropic-API fallback always available (if user has set a key) and
    is named explicitly as a route around any local-tier limit.
  - Latency-sensitive features (live assist, real-time corrections) are
    gated on GPU tiers. Non-latency-sensitive features (summary, chat,
    contradictions) are gated on capability tiers — even cpu-1.5b can run
    them, just slowly.

Feature → required tier mapping:

    page_line_summary        api-only   (works everywhere; remote via API)
    narrative_summary        api-only   (works everywhere)
    chat_with_transcript     cpu-1.5b   (needs decent context window)
    citation_lookup          api-only   (regex + CourtListener; no LLM math)
    contradiction_detection  cpu-3b     (needs reasoning quality)
    cross_depo_search        cpu-1.5b   (semantic search via embeddings)
    cross_depo_contradictions cpu-3b
    follow_up_suggestions    cpu-3b     (attorney aid; quality matters)
    live_assist_corrections  gpu-3b     (warm path, must feel close to live)
    realtime_voice_assist    gpu-7b     (long-context, hot path)
    exhibit_page_sync        api-only   (regex + UI)
"""
from __future__ import annotations

import os
from typing import Any

from hardware_profile import (
    TIERS, get_profile, tier_at_least, tier_rank, explain_tier,
)


# ---------------------------------------------------------------------------
# Feature requirements
# ---------------------------------------------------------------------------

FEATURE_REQUIREMENTS: dict[str, dict[str, Any]] = {
    # Phase 3 — already exist
    "page_line_summary": {
        "required_tier": "api-only",
        "needs_local_or_api": True,
        "label": "Page-Line Summary",
        "description": "Per-page summary of the deposition.",
    },
    "narrative_summary": {
        "required_tier": "api-only",
        "needs_local_or_api": True,
        "label": "Narrative Summary",
        "description": "400-600 word topical summary of the entire deposition.",
    },
    "chat_with_transcript": {
        "required_tier": "cpu-1.5b",
        "needs_local_or_api": True,
        "label": "Chat with Transcript",
        "description": "Ask questions, get answers cited to segments.",
    },
    "citation_lookup": {
        "required_tier": "api-only",
        "needs_local_or_api": False,
        "label": "Bluebook Citation Lookup",
        "description": "Detect citations and link to CourtListener.",
    },
    "contradiction_detection": {
        "required_tier": "cpu-3b",
        "needs_local_or_api": True,
        "label": "Contradiction Detection",
        "description": "Find contradictions within the deposition.",
        "rationale": "Requires reliable reasoning over long passages — the 1.5B model is too small for this.",
    },
    "cross_depo_search": {
        "required_tier": "cpu-1.5b",
        "needs_local_or_api": False,
        "label": "Cross-Deposition Search",
        "description": "Search across all depositions in a case.",
    },
    "cross_depo_contradictions": {
        "required_tier": "cpu-3b",
        "needs_local_or_api": True,
        "label": "Cross-Deposition Contradictions",
        "description": "Find contradictions between witnesses in the same case.",
        "rationale": "Same reasoning constraint as in-deposition contradictions.",
    },
    "follow_up_suggestions": {
        "required_tier": "cpu-3b",
        "needs_local_or_api": True,
        "label": "Live Follow-up Question Suggestions",
        "description": "Real-time suggestions for the attorney's next question.",
        "rationale": "Quality of suggestions matters — small models produce generic questions.",
    },
    "live_assist_corrections": {
        "required_tier": "gpu-3b",
        "needs_local_or_api": False,
        "label": "Live Assist Corrections",
        "description": "Qwen suggests corrections to live ASR segments as they commit.",
        "rationale": "Must respond within ~1 second to feel live. CPU inference at any size lags behind the conversation.",
        "no_api_fallback": True,  # remote API is too slow for this loop
    },
    "realtime_voice_assist": {
        "required_tier": "gpu-7b",
        "needs_local_or_api": False,
        "label": "Real-time Voice Assistant",
        "description": "Higher-tier real-time analysis with voice + context.",
        "rationale": "Long-context, low-latency — needs GPU 7B fully resident.",
        "no_api_fallback": True,
    },
    "exhibit_page_sync": {
        "required_tier": "api-only",
        "needs_local_or_api": False,
        "label": "Exhibit Page Sync",
        "description": "Auto-navigate exhibits referenced in transcript.",
    },
}


# ---------------------------------------------------------------------------
# Gate check
# ---------------------------------------------------------------------------

def has_anthropic_key(settings: dict | None = None) -> bool:
    settings = settings or {}
    return bool(settings.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", ""))


def check_gate(feature: str, settings: dict | None = None) -> dict[str, Any]:
    """Evaluate whether `feature` is available to the user.

    Returns:
        {
          "allowed": bool,
          "feature": str,
          "label": str,
          "current_tier": str,
          "required_tier": str,
          "use_local": bool,        # if True, the local model handles it
          "use_api": bool,          # if True, Anthropic API handles it
          "reasons": [str, ...],    # why blocked, if blocked
          "suggestions": [str, ...] # what the user can do
        }
    """
    feat = FEATURE_REQUIREMENTS.get(feature)
    if not feat:
        return {
            "allowed": False,
            "feature": feature,
            "reasons": [f"Unknown feature: {feature}"],
            "suggestions": [],
        }

    profile = get_profile()
    current = profile["tier"]
    required = feat["required_tier"]

    # Path 1 — local model satisfies the tier requirement
    local_ok = tier_at_least(current, required)
    # Path 2 — Anthropic API can satisfy if the feature allows it
    api_ok = (
        feat.get("needs_local_or_api", False)
        and not feat.get("no_api_fallback", False)
        and has_anthropic_key(settings)
    )
    # Some features don't need an LLM at all (regex/embeddings/UI logic)
    no_llm_needed = not feat.get("needs_local_or_api", False) and required == "api-only"

    out = {
        "allowed": local_ok or api_ok or no_llm_needed,
        "feature": feature,
        "label": feat.get("label", feature),
        "description": feat.get("description", ""),
        "current_tier": current,
        "required_tier": required,
        "use_local": local_ok,
        "use_api": (not local_ok) and api_ok,
        "reasons": [],
        "suggestions": [],
    }

    if out["allowed"]:
        return out

    # Build the reason — why this feature can't run on this hardware
    rationale = feat.get("rationale", "")
    out["reasons"].append(
        f"This feature needs at least {explain_tier(required)}. "
        f"Your machine is detected as {explain_tier(current)} "
        f"({profile['ram_gb']} GB RAM"
        + (f", {profile['gpu_name']} {profile['vram_gb']} GB VRAM" if profile["has_nvidia"] else ", no NVIDIA GPU")
        + ")."
    )
    if rationale:
        out["reasons"].append(rationale)

    # Build suggestions — what the user can do
    if feat.get("needs_local_or_api") and not feat.get("no_api_fallback") and not has_anthropic_key(settings):
        out["suggestions"].append(
            "Add an Anthropic API key in Settings to run this feature in the cloud."
        )
    if feat.get("no_api_fallback"):
        out["suggestions"].append(
            "This feature can't run remotely — it needs local hardware fast enough for live response."
        )

    # Hardware path — name the specific upgrade
    if required.startswith("gpu-"):
        out["suggestions"].append(
            "Install an NVIDIA GPU with at least "
            + ("12 GB VRAM" if required == "gpu-7b" else "6 GB VRAM")
            + " to enable this feature."
        )
    elif required == "cpu-7b":
        out["suggestions"].append("Upgrade to 32 GB system RAM to enable this feature on CPU.")
    elif required == "cpu-3b":
        out["suggestions"].append("Upgrade to 16 GB system RAM to enable this feature on CPU.")
    elif required == "cpu-1.5b":
        out["suggestions"].append("Upgrade to 8 GB system RAM to enable this feature on CPU.")

    return out


def feature_catalog(settings: dict | None = None) -> list[dict[str, Any]]:
    """Return every feature with its current gate status — for the UI to
    render the full feature matrix on the settings page.
    """
    return [check_gate(f, settings=settings) for f in FEATURE_REQUIREMENTS]
