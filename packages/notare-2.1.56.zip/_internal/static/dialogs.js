// Notare styled dialog helpers — replaces native confirm/alert/prompt with
// modal popups that match the app's color palette and respect dark mode.
// Returns Promises so callers `await` them. Behavior mirrors natives:
//   notareConfirm(msg, title?) -> Promise<boolean>
//   notareAlert(msg, title?)   -> Promise<void>     (returns when dismissed)
//   notarePrompt(msg, default?, title?) -> Promise<string|null>  (null = cancel)
//
// Styling lives in style.css under .notare-modal-* classes so dark mode
// (body.dark) automatically themes via existing CSS rules.
(function () {
    if (typeof window.notareConfirm === "function") return; // idempotent

    function _esc(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function _dialog({ title, message, type, defaultValue, confirmLabel, cancelLabel }) {
        return new Promise((resolve) => {
            const overlay = document.createElement("div");
            overlay.className = "notare-modal-overlay";
            const modal = document.createElement("div");
            modal.className = "notare-modal";

            const titleHtml = title
                ? `<h3 class="notare-modal-title">${_esc(title)}</h3>`
                : "";
            const messageHtml = `<p class="notare-modal-message">${_esc(message)}</p>`;
            const inputHtml =
                type === "prompt"
                    ? `<input class="notare-modal-input" id="_notareDlgInput" type="text" value="${_esc(defaultValue || "")}" />`
                    : "";
            const cancelHtml =
                type === "alert"
                    ? ""
                    : `<button class="notare-modal-btn notare-modal-cancel">${_esc(cancelLabel || "Cancel")}</button>`;
            const confirmText = type === "alert" ? "OK" : (confirmLabel || "Confirm");
            modal.innerHTML = `
                ${titleHtml}
                ${messageHtml}
                ${inputHtml}
                <div class="notare-modal-actions">
                    ${cancelHtml}
                    <button class="notare-modal-btn notare-modal-confirm">${_esc(confirmText)}</button>
                </div>
            `;
            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            const close = (val) => {
                overlay.remove();
                document.removeEventListener("keydown", onKey);
                resolve(val);
            };
            const confirmBtn = modal.querySelector(".notare-modal-confirm");
            const cancelBtn = modal.querySelector(".notare-modal-cancel");
            const input = modal.querySelector("#_notareDlgInput");

            if (input) {
                setTimeout(() => { input.focus(); input.select(); }, 0);
            } else {
                setTimeout(() => confirmBtn.focus(), 0);
            }

            confirmBtn.onclick = () =>
                close(type === "prompt" ? input.value : true);
            if (cancelBtn) cancelBtn.onclick = () => close(type === "prompt" ? null : false);

            // Backdrop click cancels (except for alert which can only be OK'd)
            overlay.addEventListener("click", (e) => {
                if (e.target === overlay && cancelBtn) cancelBtn.click();
            });

            function onKey(e) {
                if (e.key === "Enter") { e.preventDefault(); confirmBtn.click(); }
                else if (e.key === "Escape" && cancelBtn) { e.preventDefault(); cancelBtn.click(); }
            }
            document.addEventListener("keydown", onKey);
        });
    }

    window.notareConfirm = (message, title = "Confirm") =>
        _dialog({ title, message, type: "confirm" });
    window.notareAlert = (message, title = "Notice") =>
        _dialog({ title, message, type: "alert" });
    window.notarePrompt = (message, defaultValue = "", title = "Enter value") =>
        _dialog({ title, message, type: "prompt", defaultValue });
})();
