/* Notare workspace-switcher tabs.
 *
 * Drop-in script for any standalone page (proof.html, cases.html, voices.html,
 * profiles.html, compare.html, etc.) that needs the agency-suite navigation.
 *
 * Usage in the host page:
 *   <div id="workspaceTabs"></div>
 *   <script src="/static/workspace_tabs.js"></script>
 *
 * Behavior:
 *   - Fetches /api/mode to learn the user's entitled workspaces and current mode
 *   - Renders a horizontal tab strip with one tab per entitled workspace
 *   - Active tab = current mode
 *   - Click a tab → POST /api/mode to switch, then route to /static/index.html
 *     which renders that workspace's UI
 *   - "Switch workspace" tab routes to dashboard with the picker forced open
 */
(function () {
    const WORKSPACE_LABELS = {
        reporting: 'Reporting',
        proofing: 'Proofing',
        asr_cleanup: 'ASR Cleanup',
        asr: 'Transcribe',
        realtime: 'Realtime',
    };

    async function setMode(mode) {
        try {
            await fetch('/api/mode', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode: mode }),
            });
        } catch (e) { /* fall through to redirect anyway */ }
        window.location.href = '/static/index.html';
    }

    function showPicker() {
        // Index.html shows the picker if mode is null. Clear it server-side.
        fetch('/api/mode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mode: null }),
        }).finally(() => {
            window.location.href = '/static/index.html';
        });
    }

    async function render() {
        const target = document.getElementById('workspaceTabs');
        if (!target) return;

        let entitled = [];
        let currentMode = null;
        try {
            const r = await fetch('/api/mode');
            const d = await r.json();
            entitled = d.entitled_workspaces || [];
            currentMode = d.mode || null;
        } catch (e) {
            console.warn('workspace_tabs: /api/mode unavailable', e);
            return;
        }

        if (!entitled.length) return;

        target.style.cssText = (target.style.cssText || '') +
            ';display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:8px 0;font-size:13px;';

        const label = document.createElement('span');
        label.style.cssText = 'color:var(--text-muted, #888);font-size:12px;margin-right:4px;';
        label.textContent = 'Workspace:';
        target.appendChild(label);

        entitled.forEach((id) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            const isActive = id === currentMode;
            btn.textContent = WORKSPACE_LABELS[id] || id;
            btn.style.cssText =
                'padding:5px 12px;border-radius:14px;font-size:12px;cursor:pointer;' +
                (isActive
                    ? 'background:var(--accent, #4a90e2);color:#fff;border:1px solid var(--accent, #4a90e2);font-weight:600;'
                    : 'background:transparent;color:var(--text, #333);border:1px solid var(--border, #ccc);');
            btn.onclick = () => setMode(id);
            target.appendChild(btn);
        });

        // Always include a "Switch workspace" anchor that routes to the picker
        const switcher = document.createElement('button');
        switcher.type = 'button';
        switcher.textContent = 'Switch workspace';
        switcher.style.cssText =
            'padding:5px 12px;border-radius:14px;font-size:12px;cursor:pointer;' +
            'background:transparent;color:var(--text-muted, #888);border:1px dashed var(--border, #ccc);' +
            'margin-left:8px;';
        switcher.title = 'Return to the workspace picker';
        switcher.onclick = showPicker;
        target.appendChild(switcher);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', render);
    } else {
        render();
    }
})();
