/* Notare nav-active highlighter.
 *
 * Drop-in script for any page that uses the standard <nav> block. Matches
 * the current page path against the nav anchors and applies an "active"
 * style to the one that matches. Single source of truth so we don't have
 * to hardcode active states in every page.
 *
 * Usage: include `<script src="/static/nav_active.js"></script>` after the
 * <nav> block (or anywhere before </body>).
 */
(function () {
    function highlight() {
        const path = window.location.pathname.toLowerCase();
        const anchors = document.querySelectorAll('.header nav > a, header nav > a, nav > a');
        anchors.forEach((a) => {
            try {
                const href = (a.getAttribute('href') || '').toLowerCase();
                // Strip query/hash and any trailing slash for the comparison
                const linkPath = href.split('?')[0].split('#')[0];
                if (!linkPath) return;
                // Resolve relative paths
                const resolved = new URL(href, window.location.origin).pathname.toLowerCase();
                if (resolved === path) {
                    a.style.fontWeight = '600';
                    a.style.color = 'var(--gold, #c8a55c)';
                    a.classList.add('nav-active');
                }
            } catch (e) { /* ignore parse errors */ }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', highlight);
    } else {
        highlight();
    }
})();
