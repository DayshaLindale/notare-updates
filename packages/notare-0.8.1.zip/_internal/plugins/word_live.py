"""Word Live Plugin — Real-time transcription directly into Microsoft Word.

Opens the reporter's Word template and feeds transcript segments into it
as they arrive. The reporter edits in Word with their macros, styles, and
familiar tools while Notare handles the transcription.

Requires: Microsoft Word installed, pywin32 (win32com)

Architecture:
  1. On job start with a template, open the template in Word via COM
  2. As segments arrive, merge same-speaker consecutive segments
  3. Insert text at the end of the document using template styles
  4. Reporter can edit earlier text while new text appears at the bottom
"""
import logging
import threading
import time
import json
from pathlib import Path

logger = logging.getLogger("notare.word_live")

# Try to import COM automation
_COM_AVAILABLE = False
try:
    import win32com.client
    import pythoncom
    _COM_AVAILABLE = True
except ImportError:
    logger.info("win32com not available — Word Live disabled")


class WordLiveSession:
    """Manages a live connection to a Word document."""

    def __init__(self, template_path: str, job: dict, styles: dict = None):
        self.template_path = template_path
        self.job = job
        self.styles = styles or {}
        self._word = None
        self._doc = None
        self._lock = threading.Lock()
        self._last_speaker = ""
        self._segment_buffer = []
        self._buffer_timer = None
        self._running = False
        self._initialized = False

    def start(self):
        """Open the template in Word."""
        if not _COM_AVAILABLE:
            logger.warning("Word Live: COM not available")
            return False

        try:
            # COM must be initialized in the thread that uses it
            pythoncom.CoInitialize()

            self._word = win32com.client.Dispatch("Word.Application")
            self._word.Visible = True  # Reporter sees Word

            # Open the template as a NEW document (not editing the template itself)
            template = Path(self.template_path)
            if template.exists():
                self._doc = self._word.Documents.Add(str(template))
                logger.info("Word Live: opened template %s", template.name)
            else:
                self._doc = self._word.Documents.Add()
                logger.warning("Word Live: template not found, using blank document")

            self._running = True
            self._initialized = True

            # Move cursor to end of document
            self._move_to_end()

            return True

        except Exception as e:
            logger.error("Word Live: failed to start — %s", e)
            self._cleanup()
            return False

    def add_segment(self, speaker: str, text: str, timestamp_ms: int = 0):
        """Add a transcript segment to the Word document.

        Same-speaker segments are merged into the current paragraph.
        New speakers start a new paragraph with a designation.
        """
        if not self._running or not self._doc:
            return

        with self._lock:
            try:
                sel = self._word.Selection

                if speaker != self._last_speaker:
                    # New speaker — insert designation
                    if self._last_speaker:
                        # End the previous paragraph
                        sel.TypeParagraph()

                    # Apply speaker designation style if available
                    designation_style = self.styles.get("speaker_designation", "")
                    if designation_style:
                        try:
                            sel.Style = designation_style
                        except Exception:
                            pass

                    # Insert speaker name
                    sel.TypeText(f"{speaker}:")
                    sel.TypeParagraph()

                    # Switch to body text style
                    body_style = self.styles.get("body_text", self.styles.get("colloquy", ""))
                    if body_style:
                        try:
                            sel.Style = body_style
                        except Exception:
                            pass

                    self._last_speaker = speaker

                # Append text (same speaker continues)
                if text.strip():
                    # Add space before if not start of paragraph
                    current_text = sel.Range.Text if sel.Range else ""
                    if current_text and not current_text.endswith("\r"):
                        sel.TypeText(" ")
                    sel.TypeText(text.strip())

            except Exception as e:
                logger.warning("Word Live: insert failed — %s", e)

    def add_segments_batch(self, segments: list):
        """Add multiple segments at once — merges same-speaker runs."""
        merged = []
        current = None

        for seg in segments:
            speaker = seg.get("speaker", "")
            text = seg.get("text", "").strip()
            if not text:
                continue

            if current and current["speaker"] == speaker:
                current["text"] += " " + text
            else:
                if current:
                    merged.append(current)
                current = {"speaker": speaker, "text": text}

        if current:
            merged.append(current)

        for m in merged:
            self.add_segment(m["speaker"], m["text"])

    def save(self, path: str = None):
        """Save the Word document."""
        if not self._doc:
            return
        try:
            if path:
                self._doc.SaveAs2(str(Path(path).resolve()))
            else:
                self._doc.Save()
            logger.info("Word Live: document saved")
        except Exception as e:
            logger.warning("Word Live: save failed — %s", e)

    def stop(self):
        """Close the session (don't close Word — reporter may still be editing)."""
        self._running = False
        logger.info("Word Live: session stopped (Word remains open for editing)")

    def _move_to_end(self):
        """Move the cursor to the end of the document."""
        try:
            self._word.Selection.EndKey(Unit=6)  # wdStory = 6
        except Exception:
            pass

    def _cleanup(self):
        """Clean up COM references."""
        self._running = False
        try:
            if self._doc:
                self._doc = None
            if self._word:
                self._word = None
            pythoncom.CoUninitialize()
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
# API integration — called from app.py during live transcription
# ═══════════════════════════════════════════════════════════

_active_sessions = {}  # job_id -> WordLiveSession


def start_word_live(job_id: str, template_path: str, job: dict, styles: dict = None):
    """Start a Word Live session for a job."""
    if not _COM_AVAILABLE:
        return {"ok": False, "error": "Microsoft Word integration requires pywin32"}

    session = WordLiveSession(template_path, job, styles)

    # Start in a separate thread (COM needs its own thread)
    def _start():
        if session.start():
            _active_sessions[job_id] = session
            logger.info("Word Live: session active for job %s", job_id)
        else:
            logger.warning("Word Live: failed to start for job %s", job_id)

    threading.Thread(target=_start, daemon=True, name=f"word-live-{job_id}").start()
    time.sleep(2)  # Give Word time to open

    return {"ok": True, "message": "Word document opening..."}


def feed_word_live(job_id: str, segments: list):
    """Feed new segments to the Word Live session."""
    session = _active_sessions.get(job_id)
    if not session:
        return

    # Run in the COM thread
    def _feed():
        pythoncom.CoInitialize()
        try:
            session.add_segments_batch(segments)
        finally:
            pythoncom.CoUninitialize()

    threading.Thread(target=_feed, daemon=True).start()


def stop_word_live(job_id: str):
    """Stop a Word Live session."""
    session = _active_sessions.pop(job_id, None)
    if session:
        session.stop()
        return {"ok": True}
    return {"ok": False, "error": "No active session"}


def get_word_live_status(job_id: str):
    """Check if Word Live is active for a job."""
    session = _active_sessions.get(job_id)
    if session and session._running:
        return {"active": True, "speaker": session._last_speaker}
    return {"active": False}


logger.info("Word Live plugin loaded — COM available: %s", _COM_AVAILABLE)
