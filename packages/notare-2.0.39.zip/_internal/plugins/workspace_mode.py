"""Workspace mode — which dashboard the user sees.

Notare ships with two distinct workspaces:
  - "reporting" — live transcription, editor, stem splitting, full power-user
                  surface. What a court reporter does to CREATE a transcript.
  - "proofing"  — upload a .docx, get back the same document with auto-fixes
                  applied and flags as Word comments. Minimal surface. What
                  someone does to PROOF an existing transcript.

The choice is persisted in settings.json. On first launch after install the
setting is absent, and the frontend shows the mode-picker splash. After
either card is clicked the choice is saved, and subsequent launches skip the
splash and go straight to that workspace.

Users can switch modes anytime from the Settings page — the toggle writes
through this same endpoint.
"""
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

from fastapi import Request
from fastapi.responses import JSONResponse

VALID_MODES = {"reporting", "proofing", "asr_cleanup", "asr", "realtime"}
ALL_WORKSPACES = frozenset({"reporting", "proofing", "asr_cleanup", "asr", "realtime"})

# Hardcoded fallback for known internal keys — only consulted if the
# license.json on disk has no entitlements field (e.g. older license or
# offline validation). Server-driven entitlements (written by the license
# validator into license.json["entitlements"]["workspaces"]) take precedence.
_WORKSPACE_FALLBACK = {
    "NOTARE-MASTER-ADMIN-0001":           ALL_WORKSPACES,   # Terry
    "NOTARE-LEGACY-ADMIN-0001":           ALL_WORKSPACES,   # Elizabeth
    "NOTARE-ALLY-BETA-0001":              ALL_WORKSPACES,   # Allyson
    "NOTARE-GRACE-BETA-0001":             ALL_WORKSPACES,   # Grace
    "NOTARE-D7A2F47A-AB18929C-759A1584":  ALL_WORKSPACES,   # Alyssa
    "NOTARE-9C1AD6DF-F13DE4F0-2988B865":  ALL_WORKSPACES,   # Lori (Alyssa's mother)
}


def _entitled_workspaces():
    """Return the set of workspace IDs the active license can open.

    Resolution rules:
      1. If license.json has an `entitlements` object with a valid
         `workspaces` list (even an empty list), use it verbatim. Server is
         authoritative — admins can explicitly deny by setting [].
      2. Else (no entitlements object, or malformed): hardcoded fallback
         for known internal keys. Safety net for offline + pre-migration.
      3. Else: empty.
    """
    import json as _lj
    for lic_path in (_app.BASE_DIR / "license.json",
                     _app.BASE_DIR / "_internal" / "license.json"):
        if not lic_path.exists():
            continue
        try:
            data = _lj.loads(lic_path.read_text(encoding="utf-8"))
            key = (data.get("key") or "").strip().upper()
            ent_obj = data.get("entitlements")
            if isinstance(ent_obj, dict):
                ws = ent_obj.get("workspaces")
                if isinstance(ws, list):
                    return frozenset(str(x) for x in ws)  # empty = deny
                # ws key missing or wrong type → fall through to fallback
            if key in _WORKSPACE_FALLBACK:
                return _WORKSPACE_FALLBACK[key]
        except Exception:
            continue
    return frozenset()


@_app.app.get("/api/mode")
async def get_mode():
    """Return the current workspace mode (or null if unset — triggers splash),
    along with which workspaces this install is entitled to open."""
    mode = _app.SETTINGS.get("mode")
    if mode not in VALID_MODES:
        mode = None
    last_profile = _app.SETTINGS.get("last_proof_profile", "depo_direct")
    entitled = sorted(_entitled_workspaces())
    return JSONResponse({
        "mode": mode,
        "last_proof_profile": last_profile,
        "entitled_workspaces": entitled,
    })


@_app.app.post("/api/mode")
async def set_mode(request: Request):
    """Persist the chosen workspace mode. Body: {mode: "reporting"|"editing"}."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    mode = body.get("mode")
    if mode not in VALID_MODES:
        return JSONResponse(
            {"error": f"mode must be one of {sorted(VALID_MODES)}"},
            status_code=400,
        )

    _app.SETTINGS["mode"] = mode
    try:
        _app._save_settings()
    except Exception as e:
        logger.warning("workspace_mode: save_settings failed: %s", e)

    logger.info("workspace_mode: set to %s", mode)
    return JSONResponse({"ok": True, "mode": mode})


@_app.app.post("/api/mode/last-profile")
async def set_last_profile(request: Request):
    """Remember the last proofing profile the user chose, so the modal
    defaults to it on next open. Body: {profile: "depo_direct"}.
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    profile = body.get("profile", "")
    if not isinstance(profile, str) or not profile:
        return JSONResponse({"error": "profile must be a non-empty string"}, status_code=400)

    _app.SETTINGS["last_proof_profile"] = profile
    try:
        _app._save_settings()
    except Exception as e:
        logger.warning("workspace_mode: save_settings failed: %s", e)
    return JSONResponse({"ok": True})


print("Plugin loaded: workspace_mode.py — /api/mode and /api/mode/last-profile active")
