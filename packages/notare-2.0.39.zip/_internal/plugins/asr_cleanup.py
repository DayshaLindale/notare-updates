"""ASR Cleanup Upload — Workspace 2.

Takes a raw AssemblyAI-style .docx and applies general cleanup so the
human transcriber has a readable starting point. Two-phase API because
the user needs to map speaker labels (SPEAKER_A → MS. SMITH) before
cleanup runs.

Endpoints:
  GET  /api/asr-cleanup-profiles                  — list profiles (license-filtered)
  POST /api/asr-cleanup/scan                      — upload file, return labels + run_token
  POST /api/asr-cleanup/apply                     — run_token + speaker_map → _CLEANED.docx
  GET  /api/asr-cleanup-history                   — past runs (newest first)
  GET  /api/asr-cleanup-history/{id}/download     — re-download a past output
  POST /api/asr-cleanup-history/{id}/open         — launch in Word
  DELETE /api/asr-cleanup-history/{id}            — remove from history
  POST /api/asr-cleanup-profiles/rebundle         — re-pull bundled scripts from OTA
  GET  /api/asr-cleanup-profiles/diagnostic       — full troubleshooting snapshot
"""

import sys
import os
import json
import time
import uuid
import shutil
import logging
import tempfile
import importlib.util
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

from fastapi import UploadFile, File, Form, Request
from fastapi.responses import JSONResponse as _JSONResponse, FileResponse

# ─────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────
_ASR_DIR = _app.BASE_DIR / "_internal" / "asr_cleanup_scripts"
_ASR_DIR.mkdir(parents=True, exist_ok=True)

_HISTORY_ROOT = Path(os.environ.get("APPDATA", str(_app.BASE_DIR))) / "Notare" / "asr_cleanup_history"
_HISTORY_ROOT.mkdir(parents=True, exist_ok=True)
_HISTORY_INDEX = _HISTORY_ROOT / "asr_cleanup_history.json"

# Scan-phase uploads held briefly in a temp area, keyed by run_token
_SCAN_STAGING = Path(tempfile.gettempdir()) / "notare_asr_scan"
_SCAN_STAGING.mkdir(parents=True, exist_ok=True)
_SCAN_TTL_SEC = 1800  # a scan can sit for up to 30 min before apply is called

# ─────────────────────────────────────────────
# Entitlements — per-workspace, per-profile
# ─────────────────────────────────────────────
_BUNDLED_ASR_KEYS = frozenset({"default"})

# Hardcoded fallback for known internal keys when server-issued
# entitlements aren't present on the license. ASR Cleanup entitlement is
# implied by the asr_cleanup workspace being in the user's workspace set —
# we key off workspace entitlement (license.json["entitlements"]["workspaces"])
# first, then fall back to this hardcoded list by license key.
_ASR_FALLBACK = {
    "NOTARE-MASTER-ADMIN-0001":           frozenset(_BUNDLED_ASR_KEYS),  # Terry
    "NOTARE-LEGACY-ADMIN-0001":           frozenset(_BUNDLED_ASR_KEYS),  # Elizabeth
    "NOTARE-ALLY-BETA-0001":              frozenset(_BUNDLED_ASR_KEYS),  # Allyson
    "NOTARE-GRACE-BETA-0001":             frozenset(_BUNDLED_ASR_KEYS),  # Grace
    "NOTARE-D7A2F47A-AB18929C-759A1584":  frozenset(_BUNDLED_ASR_KEYS),  # Alyssa
    "NOTARE-9C1AD6DF-F13DE4F0-2988B865":  frozenset(_BUNDLED_ASR_KEYS),  # Lori (Alyssa's mother)
}


def _entitled_asr_profiles():
    """Server-authoritative: if entitlements.workspaces is present (list),
    grant the bundled ASR profile iff 'asr_cleanup' is in it (empty list =
    deny). Fallback to hardcoded allowlist only when no entitlements object."""
    for lic_path in (_app.BASE_DIR / "license.json",
                     _app.BASE_DIR / "_internal" / "license.json"):
        if not lic_path.exists():
            continue
        try:
            data = json.loads(lic_path.read_text(encoding="utf-8"))
            key = (data.get("key") or "").strip().upper()
            ent_obj = data.get("entitlements")
            if isinstance(ent_obj, dict):
                ws_ent = ent_obj.get("workspaces")
                if isinstance(ws_ent, list):
                    return frozenset(_BUNDLED_ASR_KEYS) if "asr_cleanup" in ws_ent else frozenset()
            if key in _ASR_FALLBACK:
                return _ASR_FALLBACK[key]
        except Exception:
            continue
    return frozenset()


# ─────────────────────────────────────────────
# Profile loading
# ─────────────────────────────────────────────
_asr_available = {}
_asr_load_errors = {}
_asr_dir_state = {}

if str(_ASR_DIR) not in sys.path:
    sys.path.insert(0, str(_ASR_DIR))


def _reload_asr_profiles():
    _asr_available.clear()
    _asr_load_errors.clear()
    try:
        _ASR_DIR.mkdir(parents=True, exist_ok=True)
        exists = _ASR_DIR.exists()
        readable = os.access(str(_ASR_DIR), os.R_OK)
    except Exception as e:
        exists = False
        readable = False
        logger.error("ASR Cleanup: dir setup failed: %s", e)

    files = sorted(_ASR_DIR.glob("asr_*.py")) if exists else []
    _asr_dir_state["path"] = str(_ASR_DIR)
    _asr_dir_state["exists"] = exists
    _asr_dir_state["readable"] = readable
    _asr_dir_state["file_count"] = len(files)
    _asr_dir_state["files"] = [p.name for p in files]

    if not files:
        logger.warning("ASR Cleanup: no asr_*.py files in %s", _ASR_DIR)

    _orig_exit, _orig_input = sys.exit, __import__("builtins").input
    sys.exit = lambda c=0: None
    __import__("builtins").input = lambda p="": ""
    try:
        for py_file in files:
            try:
                fsize = py_file.stat().st_size
            except Exception as e:
                _asr_load_errors[py_file.name] = f"stat failed: {e}"
                continue
            if fsize < 50:
                _asr_load_errors[py_file.name] = f"file is only {fsize} bytes"
                logger.warning("ASR Cleanup: ✗ %s — too small", py_file.name)
                continue
            try:
                mod_name = py_file.stem
                spec = importlib.util.spec_from_file_location(mod_name, str(py_file))
                if not spec or not spec.loader:
                    _asr_load_errors[py_file.name] = "spec_from_file_location returned None"
                    continue
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                label = getattr(mod, "PROFILE_NAME", None)
                if not label or not isinstance(label, str):
                    _asr_load_errors[py_file.name] = "missing PROFILE_NAME string"
                    logger.warning("ASR Cleanup: ✗ %s — no PROFILE_NAME", py_file.name)
                    continue
                if not callable(getattr(mod, "process", None)):
                    _asr_load_errors[py_file.name] = "missing process() function"
                    logger.warning("ASR Cleanup: ✗ %s — no process()", py_file.name)
                    continue
                if not callable(getattr(mod, "scan_labels", None)):
                    _asr_load_errors[py_file.name] = "missing scan_labels() function"
                    logger.warning("ASR Cleanup: ✗ %s — no scan_labels()", py_file.name)
                    continue
                key = mod_name.replace("asr_", "", 1)
                _asr_available[key] = {
                    "module": mod,
                    "label": label,
                    "description": f"ASR cleanup profile: {label}",
                    "filename": py_file.name,
                    "size": fsize,
                }
                logger.info("ASR Cleanup: ✓ loaded %s as '%s' (key=%s)", py_file.name, label, key)
            except Exception as e:
                _asr_load_errors[py_file.name] = f"{type(e).__name__}: {e}"
                logger.warning("ASR Cleanup: ✗ %s — %s: %s", py_file.name, type(e).__name__, e)
    finally:
        sys.exit = _orig_exit
        __import__("builtins").input = _orig_input

    logger.info("ASR Cleanup: reload complete — %d loaded, %d errors",
                len(_asr_available), len(_asr_load_errors))

_reload_asr_profiles()


# ─────────────────────────────────────────────
# History helpers
# ─────────────────────────────────────────────
def _load_history():
    if not _HISTORY_INDEX.exists():
        return []
    try:
        data = json.loads(_HISTORY_INDEX.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_history(entries):
    try:
        _HISTORY_INDEX.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    except Exception as e:
        logger.warning("ASR Cleanup history: could not write index: %s", e)


# ─────────────────────────────────────────────
# Scan-staging cleanup — drop any file older than TTL on each scan POST
# ─────────────────────────────────────────────
def _cleanup_stale_scans():
    cutoff = time.time() - _SCAN_TTL_SEC
    for p in _SCAN_STAGING.glob("*"):
        try:
            if p.is_file() and p.stat().st_mtime < cutoff:
                p.unlink()
        except Exception:
            pass


# ─────────────────────────────────────────────
# Filename sanitization (mirror of proof_upload)
# ─────────────────────────────────────────────
def _sanitize_filename(raw_name):
    import re as _re
    safe = os.path.basename((raw_name or "upload.docx").replace("\\", "/"))
    safe = _re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", safe).lstrip(".")
    if not safe.lower().endswith(".docx"):
        safe = (safe or "upload") + ".docx"
    if len(safe) > 120:
        safe = safe[:115] + ".docx"
    return safe


# ─────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────

@_app.app.get("/api/asr-cleanup-profiles")
async def list_asr_profiles():
    """List available ASR cleanup profiles, filtered by license entitlement."""
    try:
        _reload_asr_profiles()
    except Exception:
        pass
    entitled = _entitled_asr_profiles()
    profiles = {}
    for key, info in _asr_available.items():
        if key in _BUNDLED_ASR_KEYS and key not in entitled:
            continue
        profiles[key] = {
            "label": info["label"],
            "description": info["description"],
            "filename": info.get("filename", ""),
        }
    return _JSONResponse(profiles)


@_app.app.post("/api/asr-cleanup/scan")
async def scan_asr_file(file: UploadFile = File(...), profile: str = Form("default")):
    """Phase 1: accept the uploaded .docx, return the speaker labels found so
    the UI can show a substitution form. File is held in a temp location
    keyed by run_token until the /apply call."""
    _cleanup_stale_scans()

    if not file.filename or not file.filename.lower().endswith(".docx"):
        return _JSONResponse({"error": "Please upload a .docx file"}, status_code=400)

    if profile not in _asr_available:
        return _JSONResponse({
            "error": f"Unknown ASR cleanup profile: {profile}. "
                     f"Available: {', '.join(_asr_available.keys()) or 'none loaded'}"
        }, status_code=400)

    if profile in _BUNDLED_ASR_KEYS and profile not in _entitled_asr_profiles():
        return _JSONResponse(
            {"error": f"ASR cleanup profile '{profile}' is not included with your license."},
            status_code=403,
        )

    safe_name = _sanitize_filename(file.filename)
    display_name = file.filename or safe_name

    # Ensure staging dir exists — Windows temp cleanup can blow it away
    # between the module-load creation and the first actual scan call.
    try:
        _SCAN_STAGING.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return _JSONResponse({"error": f"Could not prepare staging dir: {e}"}, status_code=500)

    run_token = uuid.uuid4().hex[:24]
    staged_path = _SCAN_STAGING / f"{run_token}_{safe_name}"
    content = await file.read()
    try:
        with open(staged_path, "wb") as f:
            f.write(content)
    except Exception as e:
        return _JSONResponse({"error": f"Could not stage upload: {e}"}, status_code=500)

    # Validate it's a real .docx
    import zipfile as _zf
    try:
        with _zf.ZipFile(staged_path) as z:
            if "word/document.xml" not in z.namelist():
                staged_path.unlink(missing_ok=True)
                return _JSONResponse(
                    {"error": "File is not a valid .docx (missing word/document.xml)."},
                    status_code=400,
                )
    except _zf.BadZipFile:
        staged_path.unlink(missing_ok=True)
        return _JSONResponse({"error": "File is not a valid .docx (not a zip)."}, status_code=400)

    # Extract labels via the profile
    mod = _asr_available[profile]["module"]
    try:
        labels = mod.scan_labels(str(staged_path))
    except Exception as e:
        staged_path.unlink(missing_ok=True)
        return _JSONResponse({"error": f"Scan failed: {e}"}, status_code=500)

    return _JSONResponse({
        "ok": True,
        "run_token": run_token,
        "profile": profile,
        "labels": list(labels),
        "original_filename": display_name,
        "expires_in_sec": _SCAN_TTL_SEC,
    })


@_app.app.post("/api/asr-cleanup/apply")
async def apply_asr_cleanup(request: Request):
    """Phase 2: apply the user's speaker_map to the staged file, return the
    cleaned .docx. Cleans up the staged file after success."""
    try:
        body = await request.json()
    except Exception:
        return _JSONResponse({"error": "Invalid JSON"}, status_code=400)

    run_token = (body.get("run_token") or "").strip()
    profile = (body.get("profile") or "default").strip()
    speaker_map = body.get("speaker_map") or {}

    if not run_token or not all(c.isalnum() for c in run_token):
        return _JSONResponse({"error": "Invalid run_token"}, status_code=400)
    if profile not in _asr_available:
        return _JSONResponse({"error": f"Unknown profile: {profile}"}, status_code=400)
    if profile in _BUNDLED_ASR_KEYS and profile not in _entitled_asr_profiles():
        return _JSONResponse(
            {"error": f"ASR cleanup profile '{profile}' is not included with your license."},
            status_code=403,
        )
    if not isinstance(speaker_map, dict):
        return _JSONResponse({"error": "speaker_map must be an object"}, status_code=400)
    # Sanitize: string keys and values only
    speaker_map = {str(k): str(v or "") for k, v in speaker_map.items()}

    # Find the staged file
    matches = list(_SCAN_STAGING.glob(f"{run_token}_*"))
    if not matches:
        return _JSONResponse(
            {"error": "Upload session expired or not found. Re-upload the file."},
            status_code=404,
        )
    staged_path = matches[0]

    # Derive the original filename from the staged name
    original_filename = staged_path.name[len(run_token) + 1:]
    cleaned_filename = os.path.splitext(original_filename)[0] + "_CLEANED.docx"

    # Run the profile
    mod = _asr_available[profile]["module"]
    try:
        import asyncio as _ai
        out_path = _SCAN_STAGING / f"{run_token}_CLEANED.docx"
        await _ai.wait_for(
            _ai.get_running_loop().run_in_executor(
                None,
                lambda: mod.process(str(staged_path), speaker_map=speaker_map, output_path=str(out_path)),
            ),
            timeout=120,
        )
    except _ai.TimeoutError:
        return _JSONResponse(
            {"error": "ASR cleanup took longer than 120 seconds. Try a smaller file."},
            status_code=504,
        )
    except Exception as e:
        return _JSONResponse({"error": f"Cleanup failed: {e}"}, status_code=500)

    # Persist to history
    run_id = uuid.uuid4().hex[:12]
    ts = int(time.time())
    run_dir = _HISTORY_ROOT / f"{ts}_{run_id}"
    run_dir.mkdir(parents=True, exist_ok=True)
    preserved_output = run_dir / cleaned_filename
    try:
        shutil.copy2(str(out_path), str(preserved_output))
    except Exception as e:
        logger.warning("ASR Cleanup history: could not preserve output: %s", e)

    # Optional: copy to user's chosen output dir (same setting proof uses)
    user_output_dir = (_app.SETTINGS.get("proof_output_dir") or "").strip()
    saved_to = ""
    save_error = ""
    if user_output_dir:
        try:
            target_dir = Path(os.path.expandvars(os.path.expanduser(user_output_dir)))
            if target_dir.exists() and target_dir.is_dir() and os.access(str(target_dir), os.W_OK):
                stem, ext = os.path.splitext(cleaned_filename)
                dest = target_dir / cleaned_filename
                counter = 2
                while dest.exists() and counter < 1000:
                    dest = target_dir / f"{stem}_{counter}{ext}"
                    counter += 1
                shutil.copy2(str(preserved_output), str(dest))
                saved_to = str(dest)
            else:
                save_error = "output folder invalid/unwritable"
        except Exception as e:
            save_error = f"{type(e).__name__}: {e}"

    # Log history entry
    entry = {
        "id": run_id,
        "created_at": ts,
        "original_filename": original_filename,
        "cleaned_filename":  cleaned_filename,
        "profile_key": profile,
        "profile_label": _asr_available[profile]["label"],
        "speaker_count": len(speaker_map),
        "output_path": str(preserved_output),
        "saved_to": saved_to,
    }
    history = _load_history()
    history.insert(0, entry)
    _save_history(history)

    # Cleanup scan staging
    try:
        staged_path.unlink(missing_ok=True)
        out_path.unlink(missing_ok=True)
    except Exception:
        pass

    logger.info("ASR Cleanup: run %s complete for %s via %s", run_id, original_filename, profile)

    return FileResponse(
        str(preserved_output),
        filename=cleaned_filename,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "X-Notare-Run-Id": run_id,
            "X-Notare-Saved-To": saved_to,
            "X-Notare-Save-Error": save_error,
        },
    )


@_app.app.get("/api/asr-cleanup-history")
async def get_asr_history():
    entries = _load_history()
    stripped = []
    for e in entries:
        stripped.append({
            "id": e.get("id"),
            "created_at": e.get("created_at"),
            "original_filename": e.get("original_filename"),
            "cleaned_filename":  e.get("cleaned_filename"),
            "profile_key": e.get("profile_key"),
            "profile_label": e.get("profile_label"),
            "speaker_count": e.get("speaker_count", 0),
            "has_output": bool(e.get("output_path")) and os.path.exists(e.get("output_path", "")),
        })
    return _JSONResponse({"entries": stripped, "total": len(stripped)})


@_app.app.get("/api/asr-cleanup-history/{run_id}/download")
async def download_asr_history(run_id: str):
    for e in _load_history():
        if e.get("id") == run_id:
            path = e.get("output_path", "")
            if path and os.path.exists(path):
                return FileResponse(
                    path, filename=os.path.basename(path),
                    media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                )
            return _JSONResponse({"error": "Output file missing from disk."}, status_code=404)
    return _JSONResponse({"error": "Run id not found."}, status_code=404)


@_app.app.post("/api/asr-cleanup-history/{run_id}/open")
async def open_asr_history(run_id: str):
    for e in _load_history():
        if e.get("id") == run_id:
            path = e.get("output_path", "")
            if not path or not os.path.exists(path):
                return _JSONResponse({"error": "Output file missing from disk."}, status_code=404)
            try:
                resolved = os.path.realpath(path)
                root = os.path.realpath(str(_HISTORY_ROOT))
                if not resolved.lower().startswith(root.lower()):
                    return _JSONResponse({"error": "Refusing to open file outside history root."}, status_code=400)
            except Exception:
                return _JSONResponse({"error": "Could not resolve file path."}, status_code=500)
            try:
                if hasattr(os, "startfile"):
                    os.startfile(path)
                logger.info("ASR Cleanup: opened %s in default handler", path)
                return _JSONResponse({"ok": True, "opened": os.path.basename(path)})
            except Exception as ex:
                return _JSONResponse({"error": f"Could not open: {ex}"}, status_code=500)
    return _JSONResponse({"error": "Run id not found."}, status_code=404)


@_app.app.delete("/api/asr-cleanup-history/{run_id}")
async def delete_asr_history(run_id: str):
    entries = _load_history()
    remaining = []
    removed = None
    for e in entries:
        if e.get("id") == run_id:
            removed = e
            continue
        remaining.append(e)
    if removed is None:
        return _JSONResponse({"error": "Run id not found."}, status_code=404)
    try:
        out = removed.get("output_path", "")
        if out:
            run_dir = Path(out).parent
            if run_dir.exists() and run_dir.parent == _HISTORY_ROOT:
                shutil.rmtree(str(run_dir), ignore_errors=True)
    except Exception:
        pass
    _save_history(remaining)
    return _JSONResponse({"ok": True, "removed": run_id, "remaining": len(remaining)})


@_app.app.get("/api/asr-cleanup-profiles/diagnostic")
async def asr_profiles_diagnostic():
    try:
        _reload_asr_profiles()
    except Exception:
        pass
    entitled = _entitled_asr_profiles()
    loaded = {}
    for key, info in _asr_available.items():
        is_bundled = key in _BUNDLED_ASR_KEYS
        loaded[key] = {
            "label": info["label"],
            "filename": info.get("filename", ""),
            "size_bytes": info.get("size", 0),
            "visible_to_this_install": (not is_bundled) or (key in entitled),
        }
    return _JSONResponse({
        "dir_path": _asr_dir_state.get("path", ""),
        "dir_exists": _asr_dir_state.get("exists", False),
        "dir_readable": _asr_dir_state.get("readable", False),
        "file_count": _asr_dir_state.get("file_count", 0),
        "files_on_disk": _asr_dir_state.get("files", []),
        "loaded_profiles": loaded,
        "load_errors": _asr_load_errors,
        "license_entitled_for_bundled": bool(entitled),
        "entitled_profile_keys": sorted(entitled),
    })


@_app.app.post("/api/asr-cleanup-profiles/upload")
async def upload_asr_cleanup_profile(file: UploadFile = File(...)):
    """Upload a new ASR cleanup profile (.py) — so the user can iterate on
    her own rules without waiting for a Notare OTA. Applies the same
    sanitization + blocklist as the proof upload endpoint: basename-only,
    illegal-char strip, path-traversal resolution check, notare_shared
    blocklist (that file is the shared helper, not a profile, and replacing
    it could break proof scripts that import from it).
    """
    if not file.filename or not file.filename.lower().endswith(".py"):
        return _JSONResponse({"error": "Please upload a .py ASR cleanup script"}, status_code=400)

    content = await file.read()
    if len(content) < 50:
        return _JSONResponse(
            {"error": f"File is only {len(content)} bytes — probably truncated or empty."},
            status_code=400,
        )

    # Sanitize filename — strip path components, normalize spaces, force asr_ prefix
    import re as _re_fn
    stripped = os.path.basename(file.filename.replace("\\", "/"))
    safe_name = stripped.replace(" ", "_")
    safe_name = _re_fn.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", safe_name).lstrip(".")
    if not safe_name.startswith("asr_"):
        safe_name = "asr_" + safe_name
    if len(safe_name) > 120:
        return _JSONResponse({"error": "Filename too long (max 120 chars)."}, status_code=400)

    # Block uploads that would overwrite shared helpers or collide with
    # proof-script naming. notare_shared is imported by her proof scripts —
    # replacing it in the asr folder can't break proof directly (different
    # folder) but is confusing and worth flagging.
    blocked = {"asr_notare_shared.py", "notare_shared.py",
               "asr_proof_depo_direct.py", "asr_proof_legacy_oregon.py", "asr_proof_legacy_texas.py"}
    if safe_name in blocked or stripped.lower() in blocked:
        return _JSONResponse(
            {"error": f"Reserved filename '{safe_name}'. Use a different name."},
            status_code=400,
        )

    # Resolve + confirm the target is under _ASR_DIR (defense in depth vs. traversal)
    dest = _ASR_DIR / safe_name
    try:
        resolved = dest.resolve()
        asr_root = _ASR_DIR.resolve()
    except Exception:
        return _JSONResponse({"error": "Invalid filename."}, status_code=400)
    if not str(resolved).lower().startswith(str(asr_root).lower()):
        return _JSONResponse(
            {"error": "Invalid filename — path escape detected."},
            status_code=400,
        )

    # Syntax-check the .py BEFORE saving — catch indent/paren errors early
    # so a broken upload doesn't break subsequent reloads. This does NOT
    # run the code, just compiles it.
    try:
        compile(content, safe_name, "exec")
    except SyntaxError as e:
        return _JSONResponse(
            {"error": f"Script has a Python syntax error on line {e.lineno}: {e.msg}"},
            status_code=400,
        )

    dest.write_bytes(content)
    logger.info("ASR Cleanup: new script uploaded: %s (%d bytes)", safe_name, len(content))

    # Reload + check this specific file loaded cleanly
    _reload_asr_profiles()
    if safe_name in _asr_load_errors:
        err = _asr_load_errors[safe_name]
        # Don't delete — leave it on disk for the user to see + fix. Just
        # surface the error so the UI can show it.
        return _JSONResponse({
            "ok": False,
            "filename": safe_name,
            "saved": True,
            "load_error": err,
            "hint": "The file was saved but failed to load. Check it defines PROFILE_NAME (str), process(input_path, speaker_map, output_path), and scan_labels(input_path).",
        }, status_code=200)

    # Success path
    derived_key = safe_name[:-3].replace("asr_", "", 1)
    return _JSONResponse({
        "ok": True,
        "filename": safe_name,
        "profile_key": derived_key,
        "profile_label": _asr_available.get(derived_key, {}).get("label", derived_key),
        "profiles": len(_asr_available),
    })


@_app.app.delete("/api/asr-cleanup-profiles/{profile_key}")
async def delete_asr_cleanup_profile(profile_key: str):
    """Delete an ASR cleanup profile by key. Symmetrical with the proof
    profile delete: removes the file, reloads."""
    if profile_key not in _asr_available:
        return _JSONResponse({"error": "Profile not found"}, status_code=404)

    filename = _asr_available[profile_key].get("filename", "")
    if filename:
        target = _ASR_DIR / filename
        # Resolve again to defend against key shenanigans — profile_key
        # came from URL path
        try:
            resolved = target.resolve()
            asr_root = _ASR_DIR.resolve()
            if not str(resolved).lower().startswith(str(asr_root).lower()):
                return _JSONResponse({"error": "Invalid profile path."}, status_code=400)
        except Exception:
            return _JSONResponse({"error": "Invalid profile path."}, status_code=400)
        if target.exists():
            target.unlink()
            logger.info("ASR Cleanup: deleted %s", filename)

    _reload_asr_profiles()
    return _JSONResponse({"ok": True, "remaining": len(_asr_available)})


@_app.app.post("/api/asr-cleanup-profiles/rebundle")
async def rebundle_asr_scripts():
    import urllib.request
    import zipfile as _zf
    try:
        with urllib.request.urlopen("https://notare-updates.onrender.com/api/manifest", timeout=30) as resp:
            manifest = json.loads(resp.read())
        latest = manifest.get("current_version", "")
        if not latest:
            return _JSONResponse({"error": "No current_version in manifest."}, status_code=502)
        zip_url = f"https://notare-updates.onrender.com/api/update/download/{latest}"
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tf:
            zip_path = tf.name
        with urllib.request.urlopen(zip_url, timeout=60) as zresp:
            shutil.copyfileobj(zresp, open(zip_path, "wb"))
        extracted = []
        try:
            with _zf.ZipFile(zip_path) as zf:
                for member in zf.namelist():
                    mn = member.replace("\\", "/")
                    if not mn.startswith("_internal/asr_cleanup_scripts/"):
                        continue
                    if mn.endswith("/") or not mn.endswith(".py"):
                        continue
                    base = os.path.basename(mn)
                    if ".." in base or "/" in base or "\\" in base:
                        continue
                    dest = _ASR_DIR / base
                    with zf.open(member) as src, open(dest, "wb") as out:
                        shutil.copyfileobj(src, out)
                    extracted.append(base)
        finally:
            try: os.unlink(zip_path)
            except Exception: pass
        _reload_asr_profiles()
        return _JSONResponse({
            "ok": True, "version": latest, "extracted": extracted,
            "loaded_profiles": list(_asr_available.keys()),
            "load_errors": _asr_load_errors,
        })
    except Exception as e:
        logger.error("ASR Cleanup rebundle failed: %s", e)
        return _JSONResponse({"error": f"Rebundle failed: {e}"}, status_code=500)


print("Plugin loaded: asr_cleanup.py — /api/asr-cleanup/* endpoints active")
