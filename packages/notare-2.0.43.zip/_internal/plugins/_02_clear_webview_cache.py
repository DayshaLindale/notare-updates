"""One-time WebView2 cache wipe — rescues installs whose exe predates the
notare.py startup cache-clearer (added Apr 9 2026). Underscore prefix +
numeric ordering makes this run BEFORE other plugins, and importantly before
WebView2 opens the window (plugins load during app.py import, which happens
before notare.py creates the WebView2 window).

Why:
  An OTA can replace static/index.html on disk, but if WebView2's HTTP cache
  has the old payload (older builds never wiped it), the user keeps seeing
  the stale UI even after restart. notare.py:577-581 fixed this for new
  builds, but installs from before Apr 9 2026 don't have that fix and the
  exe can't be re-patched via OTA. This plugin lands the same wipe via the
  one path that DOES patch in: a plugin file in _internal/plugins/.

Idempotent:
  Wipe-once-per-version is enforced by a marker. We re-wipe on each new
  version so future stale-cache symptoms are fixed by the act of updating.
"""
import os
import sys
import logging
import shutil
from pathlib import Path

logger = logging.getLogger("notare")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

BASE_DIR = _app.BASE_DIR

try:
    _stamp = (BASE_DIR / "_internal" / "_notare_version.txt").read_text(encoding="utf-8").strip()
except Exception:
    _stamp = "unknown"

_marker = BASE_DIR / "_internal" / f".cache_wiped_{_stamp}"

if not _marker.exists():
    try:
        _cache_dir = os.path.join(os.environ.get("APPDATA", ""), "pywebview", "EBWebView", "Default", "Cache")
        if os.path.isdir(_cache_dir):
            shutil.rmtree(_cache_dir, ignore_errors=True)
            logger.info("clear_webview_cache: wiped %s for v%s", _cache_dir, _stamp)
            print(f"WebView2 cache cleared (v{_stamp})")
        else:
            logger.info("clear_webview_cache: no cache dir to wipe (clean state)")
        try:
            _marker.parent.mkdir(parents=True, exist_ok=True)
            _marker.write_text(_stamp, encoding="utf-8")
        except Exception:
            pass
    except Exception as e:
        logger.warning("clear_webview_cache: wipe failed (non-fatal): %s", e)

print("Plugin loaded: _02_clear_webview_cache.py")
