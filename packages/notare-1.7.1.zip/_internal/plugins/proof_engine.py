"""Proof Engine — Secure proofing with encrypted rule configs.

Architecture:
  - All fix/flag FUNCTIONS are compiled into this plugin (bytecode in the exe)
  - Rule CONFIGS are encrypted JSON that say WHICH functions to run
  - Configs are tied to license keys via the admin panel
  - Users never see the rules — they see the results

Config format (before encryption):
{
    "name": "DepoDirect — Full Verbatim",
    "key": "depo_direct",
    "fixes": ["mrs", "miss", "alright", "okay", "percent", "ellipsis", "title_space",
              "colon_space", "um_uh_ah", "stutter", "smart_quotes", "council", "no_abbrev"],
    "flags": ["underline", "doctor", "semicolon", "phonetic_wrong", "ph", "sic",
              "indiscernible", "exclamation", "smart_quotes_remaining", "double_dash",
              "date_ordinal", "section_symbol", "exhibit_cap", "manual_indent"],
    "grammar": true,
    "strip_formatting": false,
    "body_start": null,
    "body_end": null,
    "process_styles": ["Colloquy", "Q&A", "Parenthetical", "Quoted", "Normal"],
    "verbatim": "full"
}

Encrypted configs stored in: _internal/proof_configs/
"""
import hashlib
import json
import logging
import os
import re
import sys
import base64
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

_CONFIG_DIR = _app.BASE_DIR / "_internal" / "proof_configs"
_CONFIG_DIR.mkdir(parents=True, exist_ok=True)


# ═══════════════════════════════════════════════
# ENCRYPTION — simple but effective
# Uses license key as the encryption seed
# ═══════════════════════════════════════════════

def _derive_key(license_key):
    """Derive a 32-byte encryption key from a license key."""
    return hashlib.sha256(f"notare-proof-{license_key}-v1".encode()).digest()


def _xor_crypt(data_bytes, key_bytes):
    """XOR encrypt/decrypt bytes with a repeating key."""
    key_len = len(key_bytes)
    return bytes(b ^ key_bytes[i % key_len] for i, b in enumerate(data_bytes))


def encrypt_config(config_dict, license_key):
    """Encrypt a config dict to bytes."""
    plaintext = json.dumps(config_dict, indent=2).encode("utf-8")
    key = _derive_key(license_key)
    encrypted = _xor_crypt(plaintext, key)
    return base64.b64encode(encrypted)


def decrypt_config(encrypted_bytes, license_key):
    """Decrypt bytes back to a config dict."""
    key = _derive_key(license_key)
    encrypted = base64.b64decode(encrypted_bytes)
    plaintext = _xor_crypt(encrypted, key)
    return json.loads(plaintext.decode("utf-8"))


def save_config(config_dict, license_key, config_key=None):
    """Save an encrypted config to disk."""
    config_key = config_key or config_dict.get("key", "unnamed")
    encrypted = encrypt_config(config_dict, license_key)
    filepath = _CONFIG_DIR / f"{config_key}.npc"  # Notare Proof Config
    filepath.write_bytes(encrypted)
    logger.info("Proof Engine: saved encrypted config '%s'", config_key)
    return filepath


def load_config(config_key, license_key):
    """Load and decrypt a config from disk."""
    filepath = _CONFIG_DIR / f"{config_key}.npc"
    if not filepath.exists():
        return None
    try:
        encrypted = filepath.read_bytes()
        return decrypt_config(encrypted, license_key)
    except Exception as e:
        logger.warning("Proof Engine: could not decrypt config '%s': %s", config_key, e)
        return None


def list_configs():
    """List available config files (without decrypting)."""
    configs = []
    for f in sorted(_CONFIG_DIR.glob("*.npc")):
        configs.append(f.stem)
    return configs


# ═══════════════════════════════════════════════
# THE RULE ENGINE — all functions live here
# These ship as compiled bytecode in the exe.
# The configs just reference them by name.
# ═══════════════════════════════════════════════

# --- Auto-fix functions ---
# Each returns (new_text, [list of change descriptions])

def _fix_mrs(t):
    n = re.sub(r'\bMrs\.', 'Ms.', t)
    return n, (["Auto-fixed: Mrs. → Ms."] if n != t else [])

def _fix_miss(t):
    n = re.sub(r'\bMiss\b', 'Ms.', t)
    return n, (["Auto-fixed: Miss → Ms."] if n != t else [])

def _fix_alright(t):
    def rep(m): return "All right" if m.group(0)[0].isupper() else "all right"
    n = re.sub(r'\b[Aa]lright\b', rep, t)
    return n, (["Auto-fixed: alright → all right"] if n != t else [])

def _fix_okay(t):
    def rep(m): return "Okay" if m.group(0)[0].isupper() else "okay"
    n = re.sub(r'\b[Oo]k\b', rep, t)
    return n, (["Auto-fixed: ok → okay"] if n != t else [])

def _fix_percent(t):
    n = re.sub(r'(\d)\s*%', r'\1 percent', t)
    return n, (["Auto-fixed: % → percent"] if n != t else [])

def _fix_ellipsis(t):
    n = t.replace('...', '--')
    return n, (["Auto-fixed: ellipsis (...) → (--)"] if n != t else [])

def _fix_title_space(t):
    n = re.sub(r'\b(Mr|Ms|Dr|St)\.  +', r'\1. ', t)
    return n, (["Auto-fixed: double space after title → single space"] if n != t else [])

def _fix_colon_space(t):
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s+)', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
        fixed_rest = re.sub(r':(?!\s{2})\s(?=\S)', ':  ', rest)
        n = prefix + fixed_rest
    else:
        n = re.sub(r':(?!\s{2})\s(?=\S)', ':  ', t)
    return n, (["Auto-fixed: single space after colon → two spaces"] if n != t else [])

def _fix_um_uh_ah(t):
    original = t
    t = re.sub(r',\s*(um|uh|ah)\s*,', ',', t, flags=re.IGNORECASE)
    t = re.sub(r'^(Um|Uh|Ah),\s+', '', t, flags=re.IGNORECASE)
    t = re.sub(r'\s+\b(um|uh|ah)\b\s*\.', '.', t, flags=re.IGNORECASE)
    t = re.sub(r'(?<= )\b(um|uh|ah)\b(?= )', '', t, flags=re.IGNORECASE)
    return t, (["Auto-fixed: removed um/uh/ah"] if t != original else [])

def _fix_stutter(t):
    original = t
    def cap(m):
        parts = re.split(r'\s+--\s+', m.group(0))
        return ' -- '.join(parts[:3]) if len(parts) > 3 else m.group(0)
    t = re.sub(r'\b(\w+)(?:\s+--\s+\1){3,}', cap, t)
    return t, (["Auto-fixed: stutter capped at 3 repetitions"] if t != original else [])

def _fix_smart_quotes(t):
    original = t
    t = t.replace('\u201c', '"').replace('\u201d', '"')
    t = t.replace('\u2018', "'").replace('\u2019', "'")
    return t, (["Auto-fixed: smart/curly quotes → straight quotes"] if t != original else [])

def _fix_council(t):
    def rep(m): return "Counsel" if m.group(0)[0].isupper() else "counsel"
    n = re.sub(r'\b[Cc]ouncil\b', rep, t)
    return n, (["Auto-fixed: Council → Counsel"] if n != t else [])

def _fix_no_abbrev(t):
    n = re.sub(r'\bNo\.\s+(\d)', r'Number \1', t)
    return n, (["Auto-fixed: 'No.' → 'Number'"] if n != t else [])

def _fix_inaudible(t):
    n = re.sub(r'\binaudible\b', '(Indiscernible)', t, flags=re.IGNORECASE)
    return n, (["Auto-fixed: 'inaudible' → '(Indiscernible)'"] if n != t else [])

def _fix_ph_to_phonetic(t):
    n = re.sub(r'\(ph\)', '(phonetic)', t, flags=re.IGNORECASE)
    return n, (["Auto-fixed: (ph) → (phonetic)"] if n != t else [])

def _fix_extra_spaces_mid(t):
    """Fix 2+ spaces between words mid-sentence.
    Skips byline prefix (e.g. 'MR. JONES:  ') and after terminal punctuation."""
    original = t
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s{2})', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
    else:
        prefix = ''
        rest = t
    fixed = re.sub(r'(?<![.?!:,])\s{2,}(?=\S)', ' ', rest)
    n = prefix + fixed
    return n, (["Auto-fixed: extra space(s) between words removed"] if n != original else [])

def _fix_terminal_spacing(t):
    """Normalize spaces after terminal punctuation (.?!) to exactly 2."""
    original = t
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s{2})', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
    else:
        prefix = ''
        rest = t
    fixed = re.sub(r'([.?!])\s{3,}(?=\S)', r'\1  ', rest)
    n = prefix + fixed
    return n, (["Auto-fixed: excess spaces after terminal punctuation → 2 spaces"] if n != original else [])


# Registry of all available fixes
FIX_REGISTRY = {
    "mrs": _fix_mrs,
    "miss": _fix_miss,
    "alright": _fix_alright,
    "okay": _fix_okay,
    "percent": _fix_percent,
    "ellipsis": _fix_ellipsis,
    "title_space": _fix_title_space,
    "colon_space": _fix_colon_space,
    "um_uh_ah": _fix_um_uh_ah,
    "stutter": _fix_stutter,
    "smart_quotes": _fix_smart_quotes,
    "council": _fix_council,
    "no_abbrev": _fix_no_abbrev,
    "inaudible": _fix_inaudible,
    "ph_to_phonetic": _fix_ph_to_phonetic,
    "extra_spaces_mid": _fix_extra_spaces_mid,
    "terminal_spacing": _fix_terminal_spacing,
}


# --- Flag functions ---
# Each returns a list of flag strings (empty if no issue)

def _flag_underline(para):
    for r in para.runs:
        if r.underline:
            return ["FLAG — Underlined text: verify appropriate per style guide."]
    return []

def _flag_doctor(t):
    if re.search(r'\bDoctor\s+[A-Z]', t):
        return ["FLAG — 'Doctor' before a name: use 'Dr.' as title abbreviation."]
    return []

def _flag_semicolon(t):
    if re.search(r'\bcertify\b|\bnotary\b|\bdisinterested\b|\bsubscribed\b', t, re.IGNORECASE):
        return []
    if ';' in t:
        return ["FLAG — Semicolon: verify appropriate use per style guide."]
    return []

def _flag_phonetic_wrong(t):
    if re.search(r'\(phonetic\)', t, re.IGNORECASE):
        return ["FLAG — '(phonetic)' found: verify correct notation per style guide."]
    return []

def _flag_ph(t):
    if re.search(r'\(ph\)', t, re.IGNORECASE):
        return ["FLAG — (ph) unresolved: research and confirm correct spelling."]
    return []

def _flag_sic(t):
    if re.search(r'\(sic\)', t, re.IGNORECASE):
        return ["FLAG — (sic): verify speaker actually misspoke."]
    return []

def _flag_indiscernible(t):
    if re.search(r'\b(indiscernible|unintelligible|inaudible)\b', t, re.IGNORECASE):
        return ["FLAG — Indiscernible/inaudible: confirm correct term and timestamp."]
    return []

def _flag_exclamation(t):
    if '!' in t:
        return ["FLAG — Exclamation point: not used in standard transcripts."]
    return []

def _flag_smart_quotes_remaining(t):
    if any(c in t for c in ['\u201c', '\u201d', '\u2018', '\u2019']):
        return ["FLAG — Smart/curly quotes remain: disable in Word AutoCorrect."]
    return []

def _flag_double_dash(t):
    if re.search(r'\S--\S|\S-- | --\S', t):
        return ["FLAG — Double dash (--): verify space on both sides."]
    return []

def _flag_date_ordinal(t):
    if re.search(r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(st|nd|rd|th),\s+\d{4}', t):
        return ["FLAG — Date ordinal with year: omit ordinal ending."]
    return []

def _flag_section_symbol(t):
    if re.search(r'\b[Ss]ection\s+\d|\b[Ss]tatute\b', t):
        return ["FLAG — 'Section'/'Statute': verify § symbol is used for code sections."]
    return []

def _flag_exhibit_cap(t):
    if re.search(r'\bexhibit\s+\d', t):
        return ["FLAG — 'exhibit' lowercase before number: should be 'Exhibit'."]
    return []

def _flag_manual_indent(para):
    pf = para.paragraph_format
    if pf.left_indent is not None or pf.first_line_indent is not None:
        return ["FLAG — Manual indent override: may cause wrapped lines to indent incorrectly."]
    return []

def _flag_double_slash(t):
    if '//' in t:
        return ["FLAG — '//' notation: confirm header/BY line follows at top of next page."]
    return []

def _flag_witness_cap(t):
    if re.search(r'\bthe Witness\b', t):
        return ["FLAG — 'the Witness': lowercase unless used as name substitute."]
    return []

def _flag_victim_cap(t):
    if re.search(r'\bthe Victim\b', t):
        return ["FLAG — 'the Victim': lowercase unless used as name substitute."]
    return []

def _flag_fraction(t):
    if re.search(r'\bhalf an hour\b|\btwo and a half\b|\bone and a half\b', t, re.IGNORECASE):
        return ["FLAG — Fraction: may need hyphens per style guide."]
    return []

def _flag_filler(t):
    if re.search(r'\b(you know|I mean|like,)\b', t, re.IGNORECASE):
        return ["FLAG (Clean Verbatim) — Filler word: omit per clean verbatim standard."]
    return []

def _flag_active_listening(t):
    if re.match(r'^\s*(Right|Okay|Sure|Uh-huh|Mm-hmm|All right|Got it|I see)\s*[.?]?\s*$', t, re.IGNORECASE):
        return ["FLAG (Clean Verbatim) — Possible active listening response: omit per clean verbatim."]
    return []

def _flag_false_start(t):
    if re.search(r'\b(\w+(?:\s+\w+){0,2})\s+--\s+', t):
        return ["FLAG (Clean Verbatim) — Possible false start before '--': omit unless substantive."]
    return []

def _flag_terminal_comma(t):
    """Flag paragraph ending with a comma (with or without closing quote)."""
    stripped = t.rstrip()
    if re.search(r',[\u201d"\u2019]?$', stripped):
        return ["FLAG — Paragraph ends with a comma: should this be a period or question mark?"]
    return []

def _flag_comma_before_closing_quote(t):
    """Flag comma immediately before a closing quote — verify sentence continues after."""
    if re.search(r',[\u201d"\u2019]', t):
        return ["FLAG — Comma before closing quote: verify sentence continues after the quote. "
                "If the quoted passage ends the sentence, comma should be a period."]
    return []


# Text-based flags (take text string)
FLAG_TEXT_REGISTRY = {
    "doctor": _flag_doctor,
    "semicolon": _flag_semicolon,
    "phonetic_wrong": _flag_phonetic_wrong,
    "ph": _flag_ph,
    "sic": _flag_sic,
    "indiscernible": _flag_indiscernible,
    "exclamation": _flag_exclamation,
    "smart_quotes_remaining": _flag_smart_quotes_remaining,
    "double_dash": _flag_double_dash,
    "date_ordinal": _flag_date_ordinal,
    "section_symbol": _flag_section_symbol,
    "exhibit_cap": _flag_exhibit_cap,
    "double_slash": _flag_double_slash,
    "witness_cap": _flag_witness_cap,
    "victim_cap": _flag_victim_cap,
    "fraction": _flag_fraction,
    "filler": _flag_filler,
    "active_listening": _flag_active_listening,
    "false_start": _flag_false_start,
    "terminal_comma": _flag_terminal_comma,
    "comma_before_closing_quote": _flag_comma_before_closing_quote,
}

# Paragraph-based flags (take paragraph object)
FLAG_PARA_REGISTRY = {
    "underline": _flag_underline,
    "manual_indent": _flag_manual_indent,
}


# --- Grammar flags (built-in versions of grammar_flags.py) ---

_CONFUSABLES = [
    (r'\bthere\s+(house|home|car|truck|office|kids|children|family)', "FLAG — Possible 'there' vs 'their': verify possessive."),
    (r'\b(go|went|over|sit|stood|standing)\s+their\b', "FLAG — Possible 'their' vs 'there': verify location."),
    (r"\byour\s+(going|saying|telling|asking|trying|doing)", "FLAG — Possible 'your' vs 'you're': verify contraction."),
    (r"\bits\s+(a|an|the|not|been|very|clear)", "FLAG — Possible 'its' vs 'it's': verify contraction."),
    (r'\b(could|would|should|must|might)\s+of\b', "FLAG — 'of' after modal verb: likely 'have'."),
    (r'\b(more|less|better|worse|rather)\s+then\b', "FLAG — 'then' in comparison: likely 'than'."),
]

_LEGAL_HOMOPHONES = [
    ("statue", "statute"), ("fiscal", "physical"), ("disposed", "deposed"),
    ("capitol", "capital"), ("principal", "principle"), ("plaintiff", "plaintive"),
    ("precedent", "president"), ("tort", "torte"),
]

def _run_grammar(t):
    flags = []
    for pattern, msg in _CONFUSABLES:
        if re.search(pattern, t, re.IGNORECASE):
            flags.append(msg)
    for word, confused in _LEGAL_HOMOPHONES:
        if re.search(r'\b' + re.escape(word) + r'\b', t, re.IGNORECASE):
            flags.append(f"FLAG — Possible homophone: '{word}' may be '{confused}'. Verify.")
    # Missing terminal punctuation
    stripped = t.strip()
    if stripped and len(stripped.split()) > 2 and not stripped[-1] in '.?!-)':
        flags.append("FLAG — Possible missing terminal punctuation.")
    return flags


# ═══════════════════════════════════════════════
# COMMENT ENGINE (built-in, no external dependency)
# ═══════════════════════════════════════════════

from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.opc.part import Part
from docx.opc.packuri import PackURI
import lxml.etree as etree
from datetime import datetime, timezone


class _CommentEngine:
    def __init__(self, doc):
        self._comments = []
        self._doc = doc
        rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
        try:
            existing = doc.part.part_related_by(rel_type)
            ids = [int(c.get(qn("w:id"))) for c in existing._element.findall(qn("w:comment"))]
            self._id_offset = max(ids) + 1 if ids else 0
            self._use_existing = True
            self._existing_part = existing
        except Exception:
            self._id_offset = 0
            self._use_existing = False
            self._existing_part = None
        self._next_id = 0

    def add(self, paragraph, text):
        cid = self._next_id + self._id_offset
        self._next_id += 1
        self._comments.append({"id": cid, "text": text})
        # Stamp paragraph
        p = paragraph._p
        sid = str(cid)
        crs = OxmlElement("w:commentRangeStart"); crs.set(qn("w:id"), sid)
        cre = OxmlElement("w:commentRangeEnd"); cre.set(qn("w:id"), sid)
        ref_run = OxmlElement("w:r")
        rpr = OxmlElement("w:rPr"); rst = OxmlElement("w:rStyle"); rst.set(qn("w:val"), "CommentReference")
        rpr.append(rst); ref_run.append(rpr)
        cref = OxmlElement("w:commentReference"); cref.set(qn("w:id"), sid)
        ref_run.append(cref)
        runs = p.findall(qn("w:r"))
        if runs:
            runs[0].addprevious(crs); runs[-1].addnext(cre); cre.addnext(ref_run)
        else:
            p.append(crs); p.append(cre); p.append(ref_run)

    def write(self):
        if not self._comments:
            return
        rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        root = self._existing_part._element if self._use_existing else OxmlElement("w:comments")
        for c in self._comments:
            comment = OxmlElement("w:comment")
            comment.set(qn("w:id"), str(c["id"]))
            comment.set(qn("w:author"), "Notare Proofer")
            comment.set(qn("w:date"), date_str)
            comment.set(qn("w:initials"), "NP")
            cp = OxmlElement("w:p")
            cr = OxmlElement("w:r")
            ct = OxmlElement("w:t"); ct.text = c["text"]
            ct.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            cr.append(ct); cp.append(cr); comment.append(cp); root.append(comment)
        xml_bytes = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        if self._use_existing:
            self._existing_part._blob = xml_bytes
        else:
            part = Part(PackURI("/word/comments.xml"),
                       "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml",
                       xml_bytes, self._doc.part.package)
            self._doc.part.relate_to(part, rel_type)


# ═══════════════════════════════════════════════
# PROCESS ENGINE — runs a config against a document
# ═══════════════════════════════════════════════

def process_document(input_path, config, output_path=None):
    """Run proofing against a document using an encrypted config.

    Args:
        input_path: Path to the .docx
        config: Decrypted config dict
        output_path: Where to save (default: input_PROOFED.docx)

    Returns:
        dict with stats
    """
    from docx import Document

    doc = Document(str(input_path))
    engine = _CommentEngine(doc)

    # Get config settings
    fix_keys = config.get("fixes", [])
    flag_keys = config.get("flags", [])
    use_grammar = config.get("grammar", False)
    strip_fmt = config.get("strip_formatting", False)
    process_styles = set(config.get("process_styles", ["Colloquy", "Q&A", "Parenthetical", "Quoted", "Normal"]))
    body_start = config.get("body_start")
    body_end = config.get("body_end")

    # Build function lists from config
    fixes = [FIX_REGISTRY[k] for k in fix_keys if k in FIX_REGISTRY]
    text_flags = [FLAG_TEXT_REGISTRY[k] for k in flag_keys if k in FLAG_TEXT_REGISTRY]
    para_flags = [FLAG_PARA_REGISTRY[k] for k in flag_keys if k in FLAG_PARA_REGISTRY]

    # Strip production formatting if requested
    format_count = 0
    if strip_fmt:
        from docx.shared import RGBColor
        for para in doc.paragraphs:
            for run in para.runs:
                changed = False
                if run.bold:
                    run.bold = False; changed = True
                if run.font.color and run.font.color.type is not None:
                    run.font.color.rgb = RGBColor(0x00, 0x00, 0x00); changed = True
                if changed:
                    format_count += 1

    # Find body range if anchors specified
    start_idx, end_idx = 0, len(doc.paragraphs) - 1
    if body_start:
        for i, p in enumerate(doc.paragraphs):
            if body_start in "".join(r.text for r in p.runs):
                start_idx = i; break
    if body_end:
        for i, p in enumerate(doc.paragraphs):
            if i >= start_idx and body_end in "".join(r.text for r in p.runs):
                end_idx = i; break

    fix_count = flag_count = touched = skipped = 0

    for i, para in enumerate(doc.paragraphs):
        if i < start_idx or i > end_idx:
            skipped += 1
            continue

        # Check style
        try:
            style_name = para.style.name.strip()
        except Exception:
            style_name = ""
        if process_styles and style_name not in process_styles:
            skipped += 1
            continue

        text = "".join(r.text for r in para.runs)
        if not text.strip():
            continue

        # Run fixes
        changes = []
        for fix_fn in fixes:
            text, c = fix_fn(text)
            changes.extend(c)

        if changes:
            # Write fixed text back
            if para.runs:
                para.runs[0].text = text
                for r in para.runs[1:]:
                    has_fmt = r.bold or r.underline or (r.font.color and r.font.color.type is not None)
                    if not has_fmt:
                        r.text = ""
            fix_count += len(changes)

        # Run flags
        flags = []
        for flag_fn in text_flags:
            flags.extend(flag_fn(text))
        for flag_fn in para_flags:
            flags.extend(flag_fn(para))
        if use_grammar:
            flags.extend(_run_grammar(text))

        flag_count += len(flags)

        # Insert comment if anything found
        all_notes = changes + flags
        if all_notes:
            engine.add(para, "\n\n".join(all_notes))
            touched += 1

    engine.write()

    # Save
    if not output_path:
        base, ext = os.path.splitext(str(input_path))
        output_path = base + "_PROOFED" + ext
    doc.save(str(output_path))

    return {
        "fixes": fix_count,
        "flags": flag_count,
        "touched": touched,
        "skipped": skipped,
        "format_stripped": format_count,
        "output": str(output_path),
    }


# ═══════════════════════════════════════════════
# ADMIN API — assign configs to keys
# ═══════════════════════════════════════════════

from fastapi import Request, UploadFile, File, Form
from fastapi.responses import JSONResponse as _JSONResponse, FileResponse
import tempfile


# Master key check
def _is_master_key():
    """Check if the current install has the master/admin key."""
    admin_path = _app.BASE_DIR / "admin_data.json"
    if not admin_path.exists():
        return False
    try:
        data = json.loads(admin_path.read_text(encoding="utf-8"))
        current_key = _app.SETTINGS.get("license_key", "")
        for lic in data.get("licenses", []):
            if lic.get("key", "").upper() == current_key.upper():
                return lic.get("tier", "").lower() in ("enterprise", "admin", "master")
    except Exception:
        pass
    return False


@_app.app.post("/api/admin/proof-config/create")
async def create_proof_config(request: Request):
    """Create and encrypt a proofing config, optionally tied to a license key.

    Body: {
        "config": { ... config dict ... },
        "license_key": "TARGET_KEY",  // key this config is for
        "master_key": "ADMIN_KEY"     // your admin key for authorization
    }
    """
    data = await request.json()
    config = data.get("config", {})
    target_key = data.get("license_key", "")
    master_key = data.get("master_key", "")

    if not config or not config.get("key"):
        return _JSONResponse({"error": "Config must have a 'key' field"}, status_code=400)
    if not target_key:
        return _JSONResponse({"error": "license_key required — who is this config for?"}, status_code=400)

    # Use the target key for encryption so only that install can decrypt
    save_config(config, target_key, config["key"])

    return _JSONResponse({
        "ok": True,
        "config_key": config["key"],
        "name": config.get("name", ""),
        "encrypted_for": target_key[:4] + "..." + target_key[-4:] if len(target_key) > 8 else "***",
    })


@_app.app.get("/api/proof-engine/profiles")
async def list_engine_profiles():
    """List available encrypted proofing configs for this install."""
    license_key = _app.SETTINGS.get("license_key", "")
    if not license_key:
        return _JSONResponse({"profiles": {}, "message": "No license key configured"})

    profiles = {}
    for config_key in list_configs():
        config = load_config(config_key, license_key)
        if config:
            profiles[config_key] = {
                "name": config.get("name", config_key),
                "verbatim": config.get("verbatim", ""),
                "fixes": len(config.get("fixes", [])),
                "flags": len(config.get("flags", [])),
                "grammar": config.get("grammar", False),
            }
    return _JSONResponse({"profiles": profiles})


@_app.app.post("/api/proof-engine/run")
async def run_proof_engine(file: UploadFile = File(...), profile: str = Form("")):
    """Upload a .docx, run proofing with the encrypted config, return flagged document."""
    if not file.filename or not file.filename.lower().endswith(".docx"):
        return _JSONResponse({"error": "Please upload a .docx file"}, status_code=400)

    license_key = _app.SETTINGS.get("license_key", "")
    if not license_key:
        return _JSONResponse({"error": "No license key configured"}, status_code=400)

    config = load_config(profile, license_key)
    if not config:
        return _JSONResponse({"error": f"Proofing profile '{profile}' not available or cannot be decrypted"}, status_code=400)

    tmp_dir = tempfile.mkdtemp(prefix="notare_proof_")
    try:
        input_path = os.path.join(tmp_dir, file.filename)
        content = await file.read()
        with open(input_path, "wb") as f:
            f.write(content)

        stats = process_document(input_path, config)
        output_name = os.path.splitext(file.filename)[0] + "_PROOFED.docx"

        return FileResponse(
            stats["output"],
            filename=output_name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
    except Exception as e:
        logger.error("Proof Engine: error: %s", e)
        return _JSONResponse({"error": f"Proofing failed: {str(e)}"}, status_code=500)


# ═══════════════════════════════════════════════
# PRE-BUILT CONFIGS (created on admin machines only)
# ═══════════════════════════════════════════════

DEPO_DIRECT_CONFIG = {
    "key": "depo_direct",
    "name": "DepoDirect — Full Verbatim",
    "verbatim": "full",
    "fixes": ["mrs", "miss", "alright", "okay", "percent", "ellipsis", "title_space",
              "colon_space", "extra_spaces_mid", "terminal_spacing",
              "um_uh_ah", "stutter", "smart_quotes", "council", "no_abbrev"],
    "flags": ["underline", "doctor", "semicolon", "phonetic_wrong", "ph", "sic",
              "indiscernible", "exclamation", "smart_quotes_remaining", "double_dash",
              "date_ordinal", "section_symbol", "exhibit_cap", "manual_indent",
              "terminal_comma", "comma_before_closing_quote"],
    "grammar": True,
    "strip_formatting": False,
    "body_start": None,
    "body_end": None,
    "process_styles": ["Colloquy", "Q&A", "Parenthetical", "Quoted", "Normal"],
}

LEGACY_OREGON_CONFIG = {
    "key": "legacy_oregon",
    "name": "Legacy Oregon — Modified Full Verbatim",
    "verbatim": "modified_full",
    "fixes": ["mrs", "miss", "alright", "okay", "percent", "ph_to_phonetic", "ellipsis",
              "title_space", "colon_space", "extra_spaces_mid", "terminal_spacing",
              "um_uh_ah", "stutter", "smart_quotes", "council", "inaudible", "no_abbrev"],
    "flags": ["underline", "doctor", "semicolon", "double_slash", "phonetic_wrong", "sic",
              "indiscernible", "exclamation", "smart_quotes_remaining", "witness_cap",
              "victim_cap", "double_dash", "date_ordinal", "fraction", "manual_indent",
              "terminal_comma", "comma_before_closing_quote"],
    "grammar": True,
    "strip_formatting": True,
    "body_start": "(Proceedings convened at",
    "body_end": "(Proceedings concluded at",
    "process_styles": [],
}

LEGACY_TEXAS_CONFIG = {
    "key": "legacy_texas",
    "name": "Legacy Texas/Florida — Clean Verbatim",
    "verbatim": "clean",
    "fixes": ["mrs", "miss", "alright", "okay", "percent", "ph_to_phonetic", "ellipsis",
              "title_space", "colon_space", "extra_spaces_mid", "terminal_spacing",
              "um_uh_ah", "stutter", "smart_quotes", "council", "inaudible", "no_abbrev"],
    "flags": ["underline", "doctor", "semicolon", "double_slash", "phonetic_wrong", "sic",
              "indiscernible", "exclamation", "smart_quotes_remaining", "witness_cap",
              "victim_cap", "double_dash", "date_ordinal", "fraction",
              "filler", "active_listening", "false_start",
              "terminal_comma", "comma_before_closing_quote"],
    "grammar": False,
    "strip_formatting": False,
    "body_start": "(Proceedings convened at",
    "body_end": "(Proceedings concluded at",
    "process_styles": [],
}


# ═══════════════════════════════════════════════
# AUTO-PULL — on startup, check server for assigned configs
# ═══════════════════════════════════════════════

_UPDATE_SERVER = "https://notare-updates.onrender.com"

def _pull_configs_from_server():
    """Pull any proof configs assigned to this install's license key."""
    license_key = _app.SETTINGS.get("license_key", "")
    if not license_key:
        return 0

    try:
        import urllib.request as _ur
        url = f"{_UPDATE_SERVER}/api/proof-configs/pull?key={license_key}"
        with _ur.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())

        configs = data.get("configs", [])
        pulled = 0
        for c in configs:
            config_key = c.get("config_key", "")
            encrypted_data = c.get("encrypted_data", "")
            if config_key and encrypted_data:
                filepath = _CONFIG_DIR / f"{config_key}.npc"
                # Only write if we don't have it or it's different
                existing = filepath.read_text(encoding="utf-8") if filepath.exists() else ""
                if encrypted_data != existing:
                    filepath.write_text(encrypted_data, encoding="utf-8")
                    pulled += 1
                    logger.info("Proof Engine: pulled config '%s' from server", config_key)

        return pulled
    except Exception as e:
        logger.debug("Proof Engine: config pull failed (non-critical): %s", e)
        return 0


# Run on plugin load — non-fatal
try:
    _pulled = _pull_configs_from_server()
    if _pulled:
        logger.info("Proof Engine: pulled %d config(s) from server", _pulled)
except Exception:
    pass


logger.info("Proof Engine: %d fixes, %d text flags, %d para flags registered, %d configs on disk",
            len(FIX_REGISTRY), len(FLAG_TEXT_REGISTRY), len(FLAG_PARA_REGISTRY), len(list_configs()))
print("Plugin loaded: proof_engine.py — secure encrypted proofing engine active")
