"""License Key Settings — adds endpoints for viewing and changing the license key
from the Settings page.

Endpoints:
  GET  /api/validate-key?key=...  — validate a license key (local + remote)
  POST /api/license/change        — change the active license key (writes license.json)

Also patches GET /api/settings to include a masked license_key field.
"""
import json
import sys
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

app = _app.app
BASE_DIR = _app.BASE_DIR
logger = _app.logger

# --- Helper: validate a key (same logic as notare.py) ---

def _validate_key(key):
    """Validate license key — checks local database first, then remote server."""
    from datetime import datetime

    if not key or not key.strip():
        return {"valid": False, "reason": "empty_key"}

    key = key.strip()

    # Check local admin databases
    admin_files = [
        BASE_DIR / "admin_data.json",
        BASE_DIR / "_internal" / "admin_data.json",
    ]
    for admin_file in admin_files:
        if not admin_file.exists():
            continue
        try:
            admin_data = json.loads(admin_file.read_text(encoding="utf-8"))
            for l in admin_data.get("licenses", []):
                if l.get("key", "").upper() == key.upper() and l.get("status") == "active":
                    exp = l.get("expires", "")
                    if exp and exp != "" and exp < datetime.now().strftime("%Y-%m-%d"):
                        return {"valid": False, "reason": "expired"}
                    return {
                        "valid": True,
                        "tier": l.get("tier", "solo"),
                        "expires": l.get("expires", ""),
                        "customer": l.get("customer_name", ""),
                    }
        except Exception:
            pass

    # Remote validation
    try:
        import urllib.request
        payload = json.dumps({"key": key}).encode()
        req = urllib.request.Request(
            "https://notare-updates.onrender.com/api/validate-license",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
            if result.get("valid"):
                return result
    except Exception:
        pass

    return {"valid": False, "reason": "invalid_key"}


# --- GET /api/validate-key ---

from starlette.requests import Request
from starlette.responses import JSONResponse

@app.get("/api/validate-key")
async def validate_key_endpoint(request: Request):
    key = request.query_params.get("key", "")
    result = _validate_key(key)
    return JSONResponse(result)


# --- POST /api/license/change ---

@app.post("/api/license/change")
async def change_license_key(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "Invalid request"}, status_code=400)

    key = data.get("key", "").strip()
    if not key:
        return JSONResponse({"ok": False, "error": "No key provided"})

    # Validate the key first
    validation = _validate_key(key)
    if not validation.get("valid"):
        return JSONResponse({
            "ok": False,
            "error": validation.get("reason", "invalid_key"),
            "validation": validation,
        })

    # Write to license.json (what the launcher reads)
    license_file = BASE_DIR / "license.json"
    license_data = {"key": key, **validation}
    license_file.write_text(json.dumps(license_data, indent=2), encoding="utf-8")

    # Also store in settings.json for the settings page display
    _app.SETTINGS["license_key"] = key
    _app._save_settings()

    logger.info("License key changed to %s...%s (%s tier)",
                key[:8], key[-4:], validation.get("tier", "unknown"))

    return JSONResponse({"ok": True, "validation": validation})


# --- Patch GET /api/settings to include masked license key ---

_original_get_settings = None

# Find and wrap the existing get_settings endpoint
for route in app.routes:
    if hasattr(route, 'path') and route.path == "/api/settings" and hasattr(route, 'methods'):
        if "GET" in (route.methods or set()):
            _original_get_settings = route.endpoint
            break

if _original_get_settings:
    async def _patched_get_settings(*args, **kwargs):
        response = await _original_get_settings(*args, **kwargs)
        # Parse the response body to inject license_key
        body = json.loads(response.body)

        # Read license key from license.json
        license_file = BASE_DIR / "license.json"
        if license_file.exists():
            try:
                lic = json.loads(license_file.read_text(encoding="utf-8"))
                body["license_key"] = lic.get("key", "")
            except Exception:
                body["license_key"] = ""
        else:
            body["license_key"] = ""

        return JSONResponse(body)

    # Replace the endpoint
    for route in app.routes:
        if hasattr(route, 'path') and route.path == "/api/settings" and hasattr(route, 'methods'):
            if "GET" in (route.methods or set()):
                route.endpoint = _patched_get_settings
                break

print("Plugin loaded: license_key_settings.py — /api/validate-key + /api/license/change")
