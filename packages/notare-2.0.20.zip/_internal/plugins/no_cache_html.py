"""Force WebView2 (and any browser) to never cache HTML responses.

Older Notare.exe builds don't have the startup cache-clearing code that lives
in notare.py — they were built before that existed. If those users get an OTA
that updates the dashboard HTML on disk, WebView2 still renders the cached
OLD HTML indefinitely. The only ways out are (a) manually delete
%APPDATA%/pywebview/EBWebView/Default/Cache or (b) never let the response be
cached in the first place.

This plugin takes path (b): it adds middleware that sets
  Cache-Control: no-store, no-cache, must-revalidate
on every .html response and on any static file whose Content-Type is
text/html. Bandwidth impact is tiny (these files are small) and the app is
served from localhost so latency doesn't matter.
"""
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

from starlette.middleware.base import BaseHTTPMiddleware


class _NoCacheHTMLMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        try:
            ctype = response.headers.get("content-type", "").lower()
            path = request.url.path.lower()
            if "text/html" in ctype or path.endswith((".html", "/")):
                response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
        except Exception:
            pass
        return response


try:
    _app.app.add_middleware(_NoCacheHTMLMiddleware)
    logger.info("no_cache_html: Cache-Control: no-store active on all HTML responses")
except Exception as e:
    logger.warning("no_cache_html: could not attach middleware: %s", e)

print("Plugin loaded: no_cache_html.py — HTML is never cached")
