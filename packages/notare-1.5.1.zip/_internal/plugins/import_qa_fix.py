"""Import Q&A Fix — Better segment splitting for imported transcripts.

Patches the import parser to handle:
  1. Q./A. format (with period): "Q.  Did you see the defendant?"
  2. Q:/A: format (with colon): "Q:  Did you see the defendant?"
  3. Q/A with just spaces: "Q   Did you see the defendant?"
  4. Mid-line Q/A: "...end of answer. Q. Next question?" → split into two segments
  5. Colloquy labels mid-paragraph: "...text THE COURT: ruling text"

Also improves:
  - Line number stripping for imported court transcripts
  - Page header/footer removal
  - Empty line handling
"""
import re
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

_original_import = getattr(_app, "import_completed_transcript", None)

if _original_import:
    from fastapi import UploadFile, File, Form
    from fastapi.responses import JSONResponse as _JSONResponse
    from pathlib import Path as _Path
    import json as _json
    import io as _io

    # Speaker label pattern — same as app.py but compiled once
    _SPEAKER_RE = re.compile(
        r'^((?:MR\.|MS\.|MRS\.|DR\.|THE COURT|THE WITNESS|THE REPORTER|THE CLERK|THE BAILIFF|'
        r'THE DEFENDANT|THE PLAINTIFF|THE INTERPRETER|PROSECUTOR|DEFENSE|BY )[A-Z\s.\'-]*?):\s*(.*)',
        re.IGNORECASE
    )

    # Q&A patterns — broader than the original
    _QA_RE = re.compile(
        r'^\s*([QA])\s*[.:]\s{0,4}(.*)',  # Q. text / Q: text / Q  text
    )

    # Mid-line Q&A split — finds Q./A. starting mid-paragraph
    _MIDLINE_QA_RE = re.compile(
        r'(?<=[.?!])\s+([QA])\s*[.:]\s{1,4}(?=[A-Z])',
    )

    # Mid-line speaker label — finds "THE COURT:" etc. mid-paragraph
    _MIDLINE_SPEAKER_RE = re.compile(
        r'(?<=[.?!])\s+((?:MR\.|MS\.|MRS\.|DR\.|THE COURT|THE WITNESS|THE CLERK|'
        r'PROSECUTOR|DEFENSE)[A-Z\s.\'-]*?):\s+',
        re.IGNORECASE
    )

    # Line number pattern (1-25 at start of line, common in court transcripts)
    _LINE_NUM_RE = re.compile(r'^\s{0,4}\d{1,2}\s{2,}')

    # Page header/footer patterns
    _PAGE_HEADER_RE = re.compile(
        r'^\s*(?:Page \d+|^\d+$|\f|PROCEEDINGS|DIRECT EXAMINATION|CROSS.EXAMINATION|'
        r'REDIRECT EXAMINATION|RECROSS.EXAMINATION|EXAMINATION BY)',
        re.IGNORECASE
    )

    def _split_midline(line):
        """Split a line that contains mid-line Q/A or speaker changes.

        "...end of answer. Q. Next question?" → ["...end of answer.", "Q. Next question?"]
        """
        parts = []

        # Try mid-line Q/A split first
        splits = list(_MIDLINE_QA_RE.finditer(line))
        if not splits:
            # Try mid-line speaker split
            splits = list(_MIDLINE_SPEAKER_RE.finditer(line))

        if not splits:
            return [line]

        prev_end = 0
        for m in splits:
            before = line[prev_end:m.start()].strip()
            if before:
                parts.append(before)
            prev_end = m.start() + 1  # Keep the space before Q/A/speaker
            # The rest starting from the Q/A/speaker label
        remainder = line[prev_end:].strip()
        if remainder:
            # Re-attach the matched label
            parts.append(line[splits[-1].start():].strip())
        elif not parts:
            parts.append(line)

        return parts if parts else [line]

    def _parse_lines_to_segments(text_lines):
        """Enhanced line parser with mid-line splitting and broader Q/A detection."""
        segments = []
        current_speaker = ""
        current_text = []

        def flush():
            nonlocal current_text
            if current_text:
                text = " ".join(current_text).strip()
                if text:
                    segments.append({
                        "text": text,
                        "speaker": current_speaker,
                        "start": len(segments) * 1000,
                        "end": (len(segments) + 1) * 1000,
                        "confidence": 1.0,
                    })
                current_text = []

        for raw_line in text_lines:
            line = raw_line.strip()
            if not line:
                continue

            # Strip line numbers
            line = _LINE_NUM_RE.sub('', line).strip()
            if not line:
                continue

            # Skip page headers/footers
            if _PAGE_HEADER_RE.match(line):
                # But keep examination headers as section markers
                exam_match = re.match(r'^\s*((?:DIRECT|CROSS|REDIRECT|RECROSS)\s+EXAMINATION.*)', line, re.IGNORECASE)
                if exam_match:
                    flush()
                    current_speaker = ""
                    current_text = [f"({exam_match.group(1).strip()})"]
                    flush()
                continue

            # Split mid-line Q/A and speaker changes
            sub_lines = _split_midline(line)

            for sub in sub_lines:
                sub = sub.strip()
                if not sub:
                    continue

                # Check for speaker label
                speaker_match = _SPEAKER_RE.match(sub)
                if speaker_match:
                    flush()
                    current_speaker = speaker_match.group(1).strip()
                    remaining = speaker_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Check for Q/A
                qa_match = _QA_RE.match(sub)
                if qa_match:
                    flush()
                    current_speaker = "Q" if qa_match.group(1) == "Q" else "A"
                    remaining = qa_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Continuation of current speaker
                current_text.append(sub)

        flush()
        return segments

    async def _patched_import_transcript(job_id: str, file: UploadFile = File(...),
                                          run_proofing: bool = Form(True)):
        """Enhanced transcript import with better Q/A splitting."""
        job = _app.JOBS.get(job_id)
        if not job:
            return _JSONResponse({"error": "Job not found"}, status_code=404)

        content = await file.read()
        ext = _Path(file.filename).suffix.lower()
        job_dir = _Path(job["dir"])

        # Save original
        imports_dir = job_dir / "imports"
        imports_dir.mkdir(exist_ok=True)
        (imports_dir / file.filename).write_bytes(content)

        # Parse text
        text_lines = []

        if ext == ".txt":
            text_lines = content.decode("utf-8", errors="replace").split("\n")

        elif ext in (".docx", ".doc"):
            try:
                from docx import Document as DocxDoc
                doc = DocxDoc(_io.BytesIO(content))
                text_lines = [p.text for p in doc.paragraphs if p.text.strip()]
            except Exception as e:
                return _JSONResponse({"error": f"Could not read .docx: {e}"}, status_code=400)

        elif ext == ".pdf":
            try:
                import pdfplumber
                with pdfplumber.open(_io.BytesIO(content)) as pdf:
                    for page in pdf.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text_lines.extend(page_text.split("\n"))
            except Exception as e:
                return _JSONResponse({"error": f"Could not read .pdf: {e}"}, status_code=400)
        else:
            return _JSONResponse({"error": f"Unsupported format: {ext}. Use .docx, .txt, or .pdf"}, status_code=400)

        if not text_lines:
            return _JSONResponse({"error": "No text found in the uploaded file"}, status_code=400)

        # Parse with enhanced splitter
        segments = _parse_lines_to_segments(text_lines)

        if not segments:
            return _JSONResponse({"error": "Could not parse any segments from the file"}, status_code=400)

        # Store as transcript
        job["transcript"] = {"segments": segments}
        job["status"] = "complete"
        try:
            _app._feed_word_live_on_complete(job)
        except Exception:
            pass
        job["progress"] = 100
        job["imported_from"] = file.filename

        # Run proofing
        if run_proofing:
            try:
                _app._auto_detect_styles(job)
                _app._apply_proofing_rules(job)
            except Exception as e:
                logger.warning("Proofing on imported transcript failed: %s", e)

        # Save
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            _json.dump(job["transcript"], f, indent=2)
        _app._save_job(job)

        logger.info("Import (enhanced): %s -> %d segments (proofing=%s)",
                    file.filename, len(segments), run_proofing)
        return _JSONResponse({
            "ok": True,
            "segments": len(segments),
            "imported_from": file.filename,
            "proofing_applied": run_proofing,
        })

    # Patch the route
    for route in _app.app.routes:
        if hasattr(route, "path") and route.path == "/api/job/{job_id}/import-transcript":
            route.endpoint = _patched_import_transcript
            logger.info("Import Q&A: Patched /api/job/{job_id}/import-transcript with enhanced parser")
            break
    else:
        logger.warning("Import Q&A: Could not find import-transcript route to patch")


print("Plugin loaded: import_qa_fix.py — enhanced Q&A import parsing active")
