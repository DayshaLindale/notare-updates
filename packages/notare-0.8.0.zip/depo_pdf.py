"""Standard Deposition PDF Generator — Court-standard transcript format.

Generates a SINGLE PDF document containing all sections of a complete
deposition transcript in the format expected by law firms and courts.

Sections (in order):
  1. Cover page (with optional logo, stamps, watermark)
  2. Caption page (court, parties, case number, deponent, reporter)
  3. Appearances page (attorneys with firm info)
  4. Index page (examination index + exhibit list with page refs)
  5-N. Transcript body (25 lines/page, line-numbered, Q&A + colloquy)
  N+1. Certificate of Reporter (with optional signature)
  N+2. Certificate of Transcriber (with optional signature)
  N+3. Errata Sheet (blank or auto-populated from comparison)
  N+4. Word Index (hyperlinked to page:line references)
  N+5+. Exhibit pages (embedded with bidirectional hyperlinks)

Features:
  - Branded cover pages (logo, stamps, watermarks)
  - Header/footer graphics (BMP/JPEG/PNG images)
  - Signature management (scanned image or stylized text)
  - Auto-optimized line/character spacing
  - Bidirectional exhibit hyperlinks (transcript ↔ exhibit)
  - Errata comparison (auto-populated from diff)
  - Digital PDF signing (via pyHanko post-processing)
  - Disc label generation
  - Cover letter template generation
  - Multi-volume master index (CRC 8.144)
  - Multi-volume consolidation
"""

import difflib
import io
import math
import os
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import inch
    from reportlab.pdfgen import canvas as pdf_canvas
    from reportlab.lib.colors import black, white, Color
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
except ImportError:
    raise ImportError("reportlab is required: pip install reportlab")


PAGE_W, PAGE_H = letter
FONT = "Courier"
FONT_BOLD = "Courier-Bold"
FONT_SIZE = 12
LINE_HEIGHT = 19.2  # Standard court transcript line spacing
LINES_PER_PAGE = 25
CHARS_PER_LINE = 68

# Margins
L_MARGIN = 1.0 * inch
R_MARGIN = 0.75 * inch
T_MARGIN = 0.75 * inch
B_MARGIN = 0.75 * inch

# Line number position
LN_X = L_MARGIN - 0.3 * inch
# Text start
TEXT_X = L_MARGIN + 0.05 * inch

# Stop words for word index
_STOP_WORDS = {
    "a", "an", "the", "and", "or", "but", "is", "are", "was", "were", "be",
    "been", "being", "have", "has", "had", "do", "does", "did", "will", "would",
    "shall", "should", "may", "might", "must", "can", "could", "of", "to", "in",
    "for", "on", "with", "at", "by", "from", "as", "into", "through", "during",
    "before", "after", "above", "below", "between", "out", "off", "over", "under",
    "again", "further", "then", "once", "here", "there", "when", "where", "why",
    "how", "all", "each", "every", "both", "few", "more", "most", "other", "some",
    "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very",
    "just", "because", "if", "while", "about", "up", "down", "it", "its", "i", "me",
    "my", "we", "our", "you", "your", "he", "him", "his", "she", "her", "they",
    "them", "their", "what", "which", "who", "whom", "this", "that", "these",
    "those", "am", "well", "um", "uh", "okay", "yeah", "yes", "right", "going",
    "get", "got", "let", "know", "think", "said", "say", "like", "go", "come",
    "take", "make", "see", "give", "tell",
}

# Exhibit reference patterns
_EXHIBIT_PATTERNS = [
    re.compile(r"(Exhibit\s+[A-Z0-9]+)", re.IGNORECASE),
    re.compile(r"(Plaintiff'?s?\s+(?:Exhibit\s+)?(?:No\.?\s*)?[A-Z0-9]+)", re.IGNORECASE),
    re.compile(r"(Defendant'?s?\s+(?:Exhibit\s+)?(?:No\.?\s*)?[A-Z0-9]+)", re.IGNORECASE),
    re.compile(r"(Ex\.?\s+[A-Z0-9]+)", re.IGNORECASE),
]


# ═══════════════════════════════════════════════════════════════════
# DepositionPDFBuilder — Main class
# ═══════════════════════════════════════════════════════════════════

class DepositionPDFBuilder:
    """Builds a court-standard deposition transcript PDF with all features."""

    def __init__(self, job, job_dir, profile=None):
        self.job = job
        self.job_dir = Path(job_dir)
        self.segments = job.get("transcript", {}).get("segments", [])
        self.speakers = job.get("speakers", [])
        self.profile = profile or job.get("profile", {})
        self.exhibits = job.get("exhibits", [])

        # Auto-load exhibits from exhibits.json if not on the job
        if not self.exhibits:
            try:
                _exhibits_file = Path(job_dir).parent.parent / "exhibits.json"
                if not _exhibits_file.exists():
                    _exhibits_file = Path(job_dir).parent / "exhibits.json"
                if _exhibits_file.exists():
                    import json as _json
                    _all_exhibits = _json.loads(_exhibits_file.read_text(encoding="utf-8"))
                    self.exhibits = _all_exhibits.get(job.get("id", ""), [])
            except Exception:
                pass

        # Job metadata
        self.case_num = job.get("case_number", "")
        self.case_caption = job.get("case_caption", "")
        self.court_name = job.get("court_name", "")
        self.proceeding_type = job.get("proceeding_type", "Deposition")
        self.date_str = job.get("date", "")
        self.location = job.get("location", "")
        self.reporter = job.get("reporter_name", "")
        self.reporter_cred = job.get("reporter_credential", "")
        self.job_number = job.get("job_number", "")
        self.time_in = job.get("time_in", "")
        self.volume_number = job.get("volume_number", "")

        # Layout settings
        self.lines_per_page = self.profile.get("lines_per_page") or LINES_PER_PAGE
        self.font_size = FONT_SIZE
        self.line_height = LINE_HEIGHT
        self.chars_per_line = CHARS_PER_LINE

        # Branding / graphics from profile
        self.cover_logo = self.profile.get("cover_logo", "")
        self.cover_logo_position = self.profile.get("cover_logo_position", "top-center")
        self.cover_logo_width = self.profile.get("cover_logo_width", 2.0)
        self.cover_stamps = self.profile.get("cover_stamps", [])
        self.watermark_text = self.profile.get("watermark_text", "")
        self.watermark_image = self.profile.get("watermark_image", "")
        self.watermark_opacity = self.profile.get("watermark_opacity", 0.06)
        self.watermark_scope = self.profile.get("watermark_scope", "all")
        self.header_image = self.profile.get("header_image", "")
        self.header_height = self.profile.get("header_height", 0.5)
        self.footer_image = self.profile.get("footer_image", "")
        self.footer_height = self.profile.get("footer_height", 0.4)
        self.signature_image = self.profile.get("signature_image", "")
        self.signature_name = self.profile.get("signature_name", "")
        self.signature_width = self.profile.get("signature_width", 2.0)
        self.digital_cert_path = self.profile.get("digital_certificate_path", "")
        self.digital_cert_password = self.profile.get("digital_certificate_password", "")

        # Auto-optimize spacing
        self.auto_optimize = self.profile.get("auto_optimize_spacing", False)

        # Find deponent
        self.deponent = self._find_deponent()

        # State during build
        self.c = None
        self.page_num = 0
        self.body_lines = []
        self.body_start_page = 0
        self.exam_entries = []
        self.exam_pages = []
        self.exhibit_refs = {}  # {exhibit_id: [(page, line), ...]}
        self.exhibit_pages = {}  # {exhibit_id: start_page_in_pdf}
        self.t_margin = T_MARGIN
        self.b_margin = B_MARGIN
        self.errata_entries = []  # populated by compare_errata()

    # ── Metadata helpers ──────────────────────────────────────────

    def _find_deponent(self):
        for spk in self.speakers:
            role = (spk.get("role") or spk.get("representing") or "").lower()
            if "witness" in role or "deponent" in role:
                return spk.get("name", "")
        title = self.job.get("title", "")
        if "deposition of" in title.lower():
            return title.lower().split("deposition of")[-1].strip().title()
        return ""

    # ── Drawing helpers ───────────────────────────────────────────

    def _new_page(self):
        if self.page_num > 0:
            self.c.showPage()
        self.page_num += 1
        # Draw watermark on every page (or cover only)
        if self.watermark_text or self.watermark_image:
            if self.watermark_scope == "all" or (self.watermark_scope == "cover" and self.page_num == 1):
                self._draw_watermark()
        # Draw header/footer graphics
        self._draw_header_graphic()

    def _page_footer(self):
        self._draw_footer_graphic()
        self.c.setFont(FONT, 10)
        self.c.setFillColor(black)
        footer_y = self.b_margin - 0.3 * inch
        if self.footer_image and self._image_exists(self.footer_image):
            footer_y -= self.footer_height * inch
        self.c.drawCentredString(PAGE_W / 2, footer_y, str(self.page_num))

    def _line_y(self, line_num):
        return PAGE_H - self.t_margin - (line_num - 1) * self.line_height

    def _draw_ln(self, num, y_pos):
        self.c.setFont(FONT, self.font_size - 1)
        self.c.setFillColor(Color(0.5, 0.5, 0.5))
        self.c.drawRightString(LN_X + 0.15 * inch, y_pos, str(num))
        self.c.setFillColor(black)
        self.c.setFont(FONT, self.font_size)

    def _draw_text(self, text, y_pos, x=None):
        if x is None:
            x = TEXT_X
        self.c.setFont(FONT, self.font_size)
        self.c.drawString(x, y_pos, text[:85])

    def _draw_bold(self, text, y_pos, x=None):
        if x is None:
            x = TEXT_X
        self.c.setFont(FONT_BOLD, self.font_size)
        self.c.drawString(x, y_pos, text[:85])
        self.c.setFont(FONT, self.font_size)

    def _centered(self, text, y_pos, size=None, bold=False):
        if size is None:
            size = self.font_size
        self.c.setFont(FONT_BOLD if bold else FONT, size)
        self.c.drawCentredString(PAGE_W / 2, y_pos, text)

    def _write_page(self, lines, show_line_nums=True):
        for i, text in enumerate(lines):
            ln = i + 1
            y = self._line_y(ln)
            if show_line_nums:
                self._draw_ln(ln, y)
            self._draw_text(text, y)
        self._page_footer()

    def _word_wrap(self, text, max_chars=None):
        if max_chars is None:
            max_chars = self.chars_per_line
        result = []
        words = text.split()
        current = ""
        for w in words:
            if len(current) + len(w) + 1 > max_chars:
                result.append(current)
                current = w
            else:
                current = (current + " " + w).strip()
        if current:
            result.append(current)
        return result or [""]

    def _pad_lines(self, lines, count=None):
        if count is None:
            count = self.lines_per_page
        while len(lines) < count:
            lines.append("")
        return lines

    def _image_exists(self, path):
        if not path:
            return False
        p = Path(path)
        if not p.is_absolute():
            p = self.job_dir / path
        return p.exists()

    def _resolve_image(self, path):
        if not path:
            return None
        p = Path(path)
        if not p.is_absolute():
            p = self.job_dir / path
        if p.exists():
            return str(p)
        return None

    # ── Graphics features ─────────────────────────────────────────

    def _draw_watermark(self):
        """Draw diagonal watermark text or image across the page."""
        self.c.saveState()
        if self.watermark_text:
            self.c.setFillAlpha(self.watermark_opacity)
            self.c.setFillColor(Color(0.5, 0.5, 0.5))
            self.c.translate(PAGE_W / 2, PAGE_H / 2)
            self.c.rotate(45)
            self.c.setFont(FONT_BOLD, 60)
            self.c.drawCentredString(0, 0, self.watermark_text)
        elif self.watermark_image:
            img = self._resolve_image(self.watermark_image)
            if img:
                self.c.setFillAlpha(self.watermark_opacity)
                w = PAGE_W * 0.6
                h = PAGE_H * 0.6
                self.c.drawImage(img, (PAGE_W - w) / 2, (PAGE_H - h) / 2,
                                 width=w, height=h, preserveAspectRatio=True, mask='auto')
        self.c.restoreState()

    def _draw_header_graphic(self):
        """Draw header image if configured."""
        img = self._resolve_image(self.header_image)
        if not img:
            return
        h = self.header_height * inch
        # Draw at top of page, full width with aspect ratio preserved
        self.c.drawImage(img, L_MARGIN, PAGE_H - h - 0.2 * inch,
                         width=PAGE_W - L_MARGIN - R_MARGIN, height=h,
                         preserveAspectRatio=True, anchor='c', mask='auto')
        # Adjust top margin so text doesn't overlap
        self.t_margin = T_MARGIN + h + 0.1 * inch

    def _draw_footer_graphic(self):
        """Draw footer image if configured."""
        img = self._resolve_image(self.footer_image)
        if not img:
            return
        h = self.footer_height * inch
        self.c.drawImage(img, L_MARGIN, 0.2 * inch,
                         width=PAGE_W - L_MARGIN - R_MARGIN, height=h,
                         preserveAspectRatio=True, anchor='c', mask='auto')

    def _draw_signature(self, y_pos):
        """Draw scanned signature or stylized name at the given y position."""
        img = self._resolve_image(self.signature_image)
        if img:
            w = self.signature_width * inch
            h = w * 0.4  # typical signature aspect ratio
            x = TEXT_X + 0.5 * inch
            self.c.drawImage(img, x, y_pos - h + 5, width=w, height=h,
                             preserveAspectRatio=True, mask='auto')
            return True
        elif self.signature_name:
            # Stylized signature using italic courier (available everywhere)
            self.c.saveState()
            self.c.setFont("Courier-Oblique", self.font_size + 4)
            self.c.setFillColor(Color(0.15, 0.15, 0.4))
            self.c.drawString(TEXT_X + 0.5 * inch, y_pos, self.signature_name)
            self.c.restoreState()
            return True
        return False

    def _draw_stamps(self):
        """Draw configurable stamps on the cover page."""
        for stamp in self.cover_stamps:
            text = stamp.get("text", "")
            if not text:
                continue
            x = stamp.get("x", PAGE_W / 2)
            y = stamp.get("y", PAGE_H * 0.25)
            size = stamp.get("font_size", 14)
            rotation = stamp.get("rotation", 0)
            color = stamp.get("color", [0.7, 0.1, 0.1])

            self.c.saveState()
            self.c.setFillColor(Color(*color))
            self.c.setFont(FONT_BOLD, size)
            if rotation:
                self.c.translate(x, y)
                self.c.rotate(rotation)
                self.c.drawCentredString(0, 0, text.upper())
            else:
                self.c.drawCentredString(x, y, text.upper())
            self.c.restoreState()

    # ── Auto-optimize spacing ─────────────────────────────────────

    def _optimize_spacing(self):
        """Adjust lines_per_page and line_height to minimize blank lines on final page."""
        if not self.auto_optimize or not self.body_lines:
            return
        total = len(self.body_lines)
        best_lpp = self.lines_per_page
        best_waste = self.lines_per_page  # worst case
        # Try lines_per_page from 23 to 28 (court-acceptable range)
        for lpp in range(23, 29):
            remainder = total % lpp
            waste = (lpp - remainder) if remainder > 0 else 0
            if waste < best_waste:
                best_waste = waste
                best_lpp = lpp
        if best_lpp != self.lines_per_page:
            self.lines_per_page = best_lpp
            # Recalculate line height to fit within the available space
            available = PAGE_H - self.t_margin - self.b_margin
            self.line_height = available / self.lines_per_page
            # Keep within court-acceptable range (17-22 points)
            self.line_height = max(17.0, min(22.0, self.line_height))

    # ── Build transcript body ─────────────────────────────────────

    def _build_body(self):
        """Build body_lines and exam_entries from segments."""
        self.body_lines = []
        self.exam_entries = []
        current_speaker = ""

        for seg in self.segments:
            speaker = seg.get("speaker", "")
            text = seg.get("text", "").strip()
            style = seg.get("style", "colloquy")
            qa_role = seg.get("qa_role", "")
            if not text:
                continue

            if speaker and speaker != current_speaker:
                current_speaker = speaker
                label = _format_label(speaker, self.speakers)

                for spk in self.speakers:
                    if spk.get("name") == speaker:
                        role = (spk.get("role") or spk.get("representing") or "").lower()
                        if any(r in role for r in ("plaintiff", "defendant", "attorney", "counsel")):
                            if not any(e[0] == label for e in self.exam_entries):
                                self.exam_entries.append((label, len(self.body_lines)))
                        break

                self.body_lines.append(f"          {label}:")

            # Format based on style
            if style == "qa" and qa_role == "Q":
                prefix = "     Q    "
                cont_prefix = "          "
            elif style == "qa" and qa_role == "A":
                prefix = "     A    "
                cont_prefix = "          "
            elif style == "parenthetical":
                prefix = "          "
                cont_prefix = "          "
                if not text.startswith("("):
                    text = f"({text})"
            else:
                prefix = "     "
                cont_prefix = "     "

            wrapped = self._word_wrap(text, self.chars_per_line - len(prefix))
            for i, line in enumerate(wrapped):
                self.body_lines.append(f"{prefix if i == 0 else cont_prefix}{line}")

    # ── Section renderers ─────────────────────────────────────────

    def draw_cover(self):
        """Page 1: Cover page with optional logo, stamps, and watermark."""
        self._new_page()

        # Logo
        img = self._resolve_image(self.cover_logo)
        if img:
            w = self.cover_logo_width * inch
            h = w * 0.5  # estimate
            pos = self.cover_logo_position
            if "top" in pos:
                y = PAGE_H * 0.78
            elif "bottom" in pos:
                y = PAGE_H * 0.15
            else:
                y = PAGE_H * 0.65
            if "left" in pos:
                x = L_MARGIN
            elif "right" in pos:
                x = PAGE_W - R_MARGIN - w
            else:
                x = (PAGE_W - w) / 2
            self.c.drawImage(img, x, y, width=w, height=h,
                             preserveAspectRatio=True, mask='auto')

        # Title text
        self._centered(f"AUDIOVISUAL {self.proceeding_type.upper()}", PAGE_H * 0.55, size=14, bold=True)
        if self.deponent:
            self._centered(f"OF {self.deponent.upper()}", PAGE_H * 0.51, size=13, bold=True)
        self._centered(self.case_caption, PAGE_H * 0.44, size=11)
        self._centered(f"Case No. {self.case_num}", PAGE_H * 0.40, size=11)
        self._centered(self.date_str, PAGE_H * 0.36, size=11)
        if self.volume_number:
            self._centered(f"Volume {self.volume_number}", PAGE_H * 0.32, size=11)

        # Stamps
        self._draw_stamps()

        self._page_footer()

    def draw_caption(self):
        """Page 2: Caption page with case style."""
        self._new_page()
        lines = []
        lines.append(f"     IN {self.court_name.upper()}" if self.court_name else "")
        lines.append("")
        lines.append(" " + "_" * 40)

        for sep in [" v. ", " vs. ", " vs ", " V. "]:
            if sep in self.case_caption:
                parts = self.case_caption.split(sep, 1)
                break
        else:
            parts = [self.case_caption, ""]

        plaintiff = parts[0].strip() if parts[0] else ""
        defendant = parts[1].strip() if len(parts) > 1 else ""

        lines.append(f" {plaintiff},")
        lines.append("              Plaintiff,")
        lines.append(f"   v.                                    Case No.")
        lines.append(f" {defendant:<33s}  {self.case_num}")
        lines.append("              Defendant.")
        lines.append(" " + "_" * 40)
        lines.append("")
        lines.append(f"     {self.proceeding_type.upper()} OF {self.deponent.upper()}" if self.deponent
                     else f"     {self.proceeding_type.upper()}")
        lines.append(f" DATE:         {self.date_str}")
        lines.append(f" TIME:         {self.time_in}" if self.time_in else "")
        lines.append(f" LOCATION:     {self.location}" if self.location else "")
        lines.append(f" REPORTED BY:  {self.reporter}, {self.reporter_cred}" if self.reporter else "")
        lines.append(f" JOB No.:      {self.job_number}" if self.job_number else "")

        self._write_page(self._pad_lines(lines))

    def draw_appearances(self):
        """Page 3: Appearances."""
        self._new_page()
        lines = []
        lines.append("              A P P E A R A N C E S")
        lines.append("")

        plt_attys = [s for s in self.speakers if "plaintiff" in (s.get("role") or s.get("representing") or "").lower()]
        def_attys = [s for s in self.speakers if any(r in (s.get("role") or s.get("representing") or "").lower() for r in ("defendant", "defense"))]

        for party_label, attys in [("PLAINTIFF", plt_attys), ("DEFENDANT", def_attys)]:
            if not attys:
                continue
            suffix = "S" if len(attys) > 1 and party_label == "DEFENDANT" else ""
            lines.append(f" ON BEHALF OF {party_label}{suffix}:")
            for a in attys:
                lines.append(f"      {a.get('name', '').upper()}, ESQ.")
                if a.get("firm"):
                    lines.append(f"      {a['firm']}")
                if a.get("address"):
                    for addr_line in a["address"].split("\n"):
                        lines.append(f"      {addr_line.strip()}")
                if a.get("email"):
                    lines.append(f"      {a['email']}")
                if a.get("phone"):
                    lines.append(f"      {a['phone']}")
            lines.append("")

        self._write_page(self._pad_lines(lines))

    def draw_index(self):
        """Page 4: Examination and exhibit index."""
        self._new_page()
        lines = []
        lines.append("                     I N D E X")
        lines.append(f" EXAMINATION:                                      PAGE")
        for label, pg in self.exam_pages:
            lines.append(f"      BY {label:<45s}{pg}")
        lines.append("")
        lines.append("                    E X H I B I T S")
        lines.append(f" NO.       DESCRIPTION                              PAGE")

        if self.exhibits:
            for idx, ex in enumerate(self.exhibits):
                eid = ex.get('id', '') or ex.get('exhibit_id', '')
                desc = ex.get('description', '')
                # Find page reference from exhibit_refs if available
                page_ref = ex.get('page', '')
                if not page_ref and eid:
                    # Try to find in scanned exhibit references
                    clean_id = re.sub(r'(?i)exhibit\s*', '', eid).strip()
                    refs = self.exhibit_refs.get(clean_id, [])
                    if refs:
                        page_ref = str(refs[0][0])
                # Format: number the exhibits sequentially if ID is verbose
                display_num = str(idx + 1)
                if eid and not eid[0].isdigit():
                    display_id = f"{display_num}. {eid}"
                else:
                    display_id = eid or str(idx + 1)
                lines.append(f" {display_id:<15s}{desc:<35s}{page_ref}")
            lines.append("")
            lines.append("          (*Exhibits attached.)")
        else:
            lines.append("")

        self._write_page(self._pad_lines(lines))

    def draw_body(self):
        """Pages 5-N: Line-numbered transcript body with bookmarks and exhibit links."""
        self.body_start_page = self.page_num + 1

        # Scan body for exhibit references
        self._scan_exhibit_refs()

        for pg_idx in range(0, len(self.body_lines), self.lines_per_page):
            self._new_page()
            pg_lines = self.body_lines[pg_idx:pg_idx + self.lines_per_page]
            for i, text in enumerate(pg_lines):
                ln = i + 1
                y = self._line_y(ln)
                self._draw_ln(ln, y)
                self._draw_text(text, y)
                # Bookmark for word index and exhibit backlinks
                bookmark_name = f"p{self.page_num}l{ln}"
                self.c.bookmarkHorizontal(bookmark_name, TEXT_X, y)

                # Draw exhibit hyperlink if this line references one
                global_line = pg_idx + i
                self._draw_exhibit_link(text, y, self.page_num, ln)

            self._page_footer()

    def _scan_exhibit_refs(self):
        """Find exhibit references in body text for bidirectional linking."""
        self.exhibit_refs = defaultdict(list)
        for line_idx, text in enumerate(self.body_lines):
            page = (self.page_num + 1) + (line_idx // self.lines_per_page)
            line_on_page = (line_idx % self.lines_per_page) + 1
            for pattern in _EXHIBIT_PATTERNS:
                for match in pattern.finditer(text):
                    ref_text = match.group(1).strip()
                    # Normalize to exhibit id
                    ex_id = re.sub(r'(?:Exhibit|Ex\.?)\s*(?:No\.?\s*)?', '', ref_text, flags=re.IGNORECASE).strip()
                    self.exhibit_refs[ex_id].append((page, line_on_page))

    def _draw_exhibit_link(self, text, y, page, line):
        """If text contains an exhibit reference, make it a clickable link to the exhibit page."""
        for pattern in _EXHIBIT_PATTERNS:
            match = pattern.search(text)
            if match:
                ex_id = re.sub(r'(?:Exhibit|Ex\.?)\s*(?:No\.?\s*)?', '', match.group(1), flags=re.IGNORECASE).strip()
                bookmark = f"exhibit_{ex_id}"
                # Find position of match in text
                start_col = match.start()
                ref_text = match.group(1)
                x = TEXT_X + self.c.stringWidth(text[:start_col], FONT, self.font_size)
                w = self.c.stringWidth(ref_text, FONT, self.font_size)
                try:
                    self.c.linkAbsolute(ref_text, bookmark,
                                       (x, y - 2, x + w, y + self.font_size - 2))
                except Exception:
                    pass
                break

    def draw_cert_reporter(self):
        """Certificate of Reporter with optional signature."""
        self._new_page()
        cert = self.profile.get("certificate_template", "")
        if not cert:
            cert = (
                f"          CERTIFICATE OF REPORTER\n"
                f"     I, {self.reporter or '[REPORTER NAME]'}, "
                f"{'a ' + self.reporter_cred + ', ' if self.reporter_cred else ''}"
                f"duly authorized to administer\n"
                f"oaths, do hereby certify:\n"
                f"     That I am a disinterested person herein;\n"
                f"that the witness, {self.deponent.upper() or '[WITNESS]'}, named in the\n"
                f"foregoing deposition, was by me duly sworn to testify\n"
                f"the truth, the whole truth, and nothing but the truth;\n"
                f"that the deposition was reported by me, {self.reporter or '[REPORTER]'},\n"
                f"and is a true and correct record of the testimony so\n"
                f"given.\n"
                f"     IN WITNESS WHEREOF, I hereby certify under\n"
                f"penalty of perjury that the foregoing is true and\n"
                f"correct.\n"
                f"\n"
                f"     Dated this _____ day of __________, ____.\n"
            )

        cert_lines = [f" {line}" for line in cert.split("\n")]

        # Add signature space
        if self.signature_image or self.signature_name:
            cert_lines.append("")
            cert_lines.append("")  # space for signature
        else:
            cert_lines.append("")
            cert_lines.append("     _________________________________")

        cert_lines.append(f"     {self.reporter or '[REPORTER NAME]'}")
        cert_lines.append(f"     {self.reporter_cred or '[CREDENTIAL]'}")

        self._write_page(self._pad_lines(cert_lines))

        # Overlay signature image on the blank space
        if self.signature_image or self.signature_name:
            sig_line = len(cert.split("\n")) + 1  # line after cert text
            sig_y = self._line_y(sig_line)
            self._draw_signature(sig_y)

    def draw_cert_transcriber(self):
        """Certificate of Transcriber with optional signature."""
        self._new_page()
        trans_lines = [
            "          CERTIFICATE OF TRANSCRIBER",
            f"     I, __________________, do hereby certify that this",
            f"transcript was prepared from the digital audio",
            f"recording of the foregoing proceeding, that said",
            f"transcript is a true and accurate record of the",
            f"proceedings to the best of my knowledge, skills, and",
            f"ability; that I am neither counsel for, related to,",
            f"nor employed by any of the parties to the action in",
            f"which this was taken; and, further, that I am not a",
            f"relative or employee of any counsel or attorney",
            f"employed by the parties hereto, nor financially",
            f"interested in the action.",
            f"",
            f"",
            f"     _________________________________",
            f"     Transcriber",
            f"     Date: ______________",
        ]
        self._write_page(self._pad_lines(trans_lines))

    def draw_errata(self):
        """Errata sheet — blank or auto-populated from comparison."""
        self._new_page()
        errata_lines = [
            " Errata Sheet",
            "",
            f" NAME OF CASE: {self.case_caption} {self.case_num}",
            f" DATE OF DEPOSITION: {self.date_str}",
            f" NAME OF WITNESS: {self.deponent or '_______________'}",
            " Reason Codes:",
            "      1. To clarify the record.",
            "      2. To conform to the facts.",
            "      3. To correct transcription errors.",
        ]

        if self.errata_entries:
            # Auto-populated errata from comparison
            errata_lines.append("")
            for entry in self.errata_entries[:10]:
                pg = entry.get("page", "___")
                ln = entry.get("line", "___")
                reason = entry.get("reason", "3")
                errata_lines.append(f" Page {pg:<5s} Line {ln:<6s} Reason {reason}")
                errata_lines.append(f" From: {entry.get('original', '')[:45]}")
                errata_lines.append(f" To:   {entry.get('corrected', '')[:45]}")
                errata_lines.append("")
        else:
            # Blank errata
            for _ in range(5):
                errata_lines.append(" Page _____ Line ______ Reason ______")
                errata_lines.append(" From ____________________ to ____________________")

        self._write_page(self._pad_lines(errata_lines))

    def draw_word_index(self):
        """Word index with hyperlinked page:line references."""
        word_refs = defaultdict(list)
        for line_idx, text in enumerate(self.body_lines):
            page = self.body_start_page + (line_idx // self.lines_per_page)
            line_on_page = (line_idx % self.lines_per_page) + 1
            words = re.findall(r"[a-zA-Z'-]+", text)
            for w in words:
                wl = w.lower().strip("'-")
                if len(wl) < 3 or wl in _STOP_WORDS:
                    continue
                ref = f"{page}:{line_on_page}"
                if not word_refs[wl] or word_refs[wl][-1] != ref:
                    word_refs[wl].append(ref)

        sorted_words = sorted(word_refs.items())

        self._new_page()
        wi_ln = 0

        def wi_new_line():
            nonlocal wi_ln
            wi_ln += 1
            if wi_ln > self.lines_per_page:
                self._page_footer()
                self._new_page()
                wi_ln = 1
            return self._line_y(wi_ln)

        def wi_draw_ln():
            self._draw_ln(wi_ln, self._line_y(wi_ln))

        # Title
        y = wi_new_line()
        wi_draw_ln()
        self.c.setFont(FONT_BOLD, self.font_size)
        self.c.drawCentredString(PAGE_W / 2, y, "W O R D   I N D E X")
        self.c.setFont(FONT, self.font_size)
        wi_new_line()

        current_letter = ""
        for wl, refs in sorted_words:
            first = wl[0].upper()
            if first != current_letter:
                current_letter = first
                wi_new_line()
                y = wi_new_line()
                wi_draw_ln()
                self.c.setFont(FONT_BOLD, self.font_size)
                self.c.drawCentredString(PAGE_W / 2, y, first)
                self.c.setFont(FONT, self.font_size)
                wi_new_line()

            y = wi_new_line()
            wi_draw_ln()

            self.c.setFont(FONT, self.font_size)
            self.c.drawString(TEXT_X, y, wl[:20])

            ref_x = TEXT_X + 1.5 * inch
            self.c.setFont(FONT, self.font_size - 2)
            display_refs = refs[:15]
            for ri, ref in enumerate(display_refs):
                ref_text = ref
                if ri < len(display_refs) - 1:
                    ref_text += ","
                parts = ref.split(":")
                pg = parts[0]
                ln_ref = parts[1] if len(parts) > 1 else "1"
                bookmark = f"p{pg}l{ln_ref}"

                self.c.setFillColor(Color(0.02, 0.38, 0.76))
                text_width = self.c.stringWidth(ref_text, FONT, self.font_size - 2)

                if ref_x + text_width > PAGE_W - R_MARGIN:
                    y = wi_new_line()
                    wi_draw_ln()
                    ref_x = TEXT_X + 1.5 * inch

                self.c.drawString(ref_x, y, ref_text)
                try:
                    self.c.linkAbsolute(ref_text, bookmark,
                                       (ref_x, y - 2, ref_x + text_width, y + self.font_size - 2))
                except Exception:
                    pass
                ref_x += text_width + 4

            if len(refs) > 15:
                self.c.setFillColor(Color(0.5, 0.5, 0.5))
                self.c.drawString(ref_x, y, f" +{len(refs) - 15} more")

            self.c.setFillColor(black)
            self.c.setFont(FONT, self.font_size)

        self._page_footer()

    def draw_exhibits(self):
        """Embed exhibit files as pages with bidirectional hyperlinks."""
        if not self.exhibits:
            return

        try:
            from pypdf import PdfReader, PdfWriter
        except ImportError:
            return  # pypdf not available, skip exhibit embedding

        for ex in self.exhibits:
            ex_id = ex.get("id", "") or ex.get("exhibit_id", "")
            file_ref = ex.get("file_path", "") or ex.get("file_reference", "")
            if not file_ref:
                continue

            # Resolve file path
            file_path = Path(file_ref)
            if not file_path.is_absolute():
                file_path = self.job_dir / "exhibits" / file_ref
            if not file_path.exists():
                continue

            # Draw exhibit header page
            self._new_page()
            self.exhibit_pages[ex_id] = self.page_num
            bookmark = f"exhibit_{ex_id}"
            self.c.bookmarkHorizontal(bookmark, TEXT_X, PAGE_H * 0.7)

            self._centered(f"E X H I B I T   {ex_id}", PAGE_H * 0.65, size=16, bold=True)
            self._centered(ex.get("description", ""), PAGE_H * 0.58, size=12)
            self._centered(f"({file_path.name})", PAGE_H * 0.53, size=10)

            # Backlinks to transcript references
            refs = self.exhibit_refs.get(ex_id, [])
            if refs:
                self.c.setFont(FONT, 10)
                self.c.setFillColor(Color(0.02, 0.38, 0.76))
                y_ref = PAGE_H * 0.45
                self.c.drawString(TEXT_X, y_ref, "Referenced at:")
                y_ref -= 16
                for pg, ln in refs[:10]:
                    ref_text = f"Page {pg}, Line {ln}"
                    bm = f"p{pg}l{ln}"
                    tw = self.c.stringWidth(ref_text, FONT, 10)
                    self.c.drawString(TEXT_X + 0.3 * inch, y_ref, ref_text)
                    try:
                        self.c.linkAbsolute(ref_text, bm,
                                           (TEXT_X + 0.3 * inch, y_ref - 2,
                                            TEXT_X + 0.3 * inch + tw, y_ref + 10))
                    except Exception:
                        pass
                    y_ref -= 14

            self.c.setFillColor(black)
            self._page_footer()

            # If the exhibit is a PDF, we note the page count
            # (actual PDF merging happens in post-processing with pypdf)
            if file_path.suffix.lower() == '.pdf':
                try:
                    reader = PdfReader(str(file_path))
                    pg_count = len(reader.pages)
                    self.c.setFont(FONT, 10)
                    self.c.drawString(TEXT_X, PAGE_H * 0.25,
                                     f"[Exhibit document: {pg_count} page(s) — see attached]")
                except Exception:
                    pass

    # ── Errata comparison ─────────────────────────────────────────

    def compare_errata(self, original_segments, edited_segments):
        """Compare original and edited transcript, populate errata_entries.

        Call this before generate() to auto-populate the errata sheet.
        """
        self.errata_entries = []

        # Build line-level comparison
        orig_lines = []
        edit_lines = []
        for seg in original_segments:
            text = seg.get("text", "").strip()
            if text:
                orig_lines.append(text)
        for seg in edited_segments:
            text = seg.get("text", "").strip()
            if text:
                edit_lines.append(text)

        matcher = difflib.SequenceMatcher(None, orig_lines, edit_lines)
        line_num = 0
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                line_num += (i2 - i1)
                continue
            if tag in ('replace', 'delete', 'insert'):
                for k in range(i1, i2):
                    line_num += 1
                    page = 5 + (line_num // self.lines_per_page)
                    line_on_page = (line_num % self.lines_per_page) + 1
                    original = orig_lines[k] if k < len(orig_lines) else ""
                    corrected = edit_lines[j1 + (k - i1)] if (j1 + (k - i1)) < len(edit_lines) else "[deleted]"
                    self.errata_entries.append({
                        "page": str(page),
                        "line": str(line_on_page),
                        "original": original,
                        "corrected": corrected,
                        "reason": "3",  # default: transcription error
                    })

    # ── Digital signing (post-process) ────────────────────────────

    def _apply_digital_signature(self, pdf_path):
        """Apply cryptographic PDF signature using pyHanko."""
        if not self.digital_cert_path:
            return pdf_path

        cert_file = Path(self.digital_cert_path)
        if not cert_file.exists():
            return pdf_path

        try:
            from pyhanko.sign import signers, fields
            from pyhanko.sign.general import load_cert_list
            from pyhanko import stamp
            from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter

            signer = signers.SimpleSigner.load_pkcs12(
                pfx_file=str(cert_file),
                passphrase=self.digital_cert_password.encode() if self.digital_cert_password else None,
            )

            with open(pdf_path, 'rb') as f:
                w = IncrementalPdfFileWriter(f)
                fields.append_signature_field(w, sig_field_spec=fields.SigFieldSpec(
                    sig_field_name='ReporterSignature',
                    on_page=0,
                    box=(L_MARGIN, B_MARGIN, PAGE_W - R_MARGIN, B_MARGIN + 0.5 * inch),
                ))
                out = signers.sign_pdf(
                    w, signers.PdfSignatureMetadata(
                        field_name='ReporterSignature',
                        reason=self.profile.get("signing_reason", "Court Reporter Certification"),
                        location=self.profile.get("signing_location", ""),
                        contact_info=self.profile.get("signing_contact", ""),
                    ),
                    signer=signer,
                )
                signed_path = pdf_path.replace('.pdf', '_signed.pdf')
                with open(signed_path, 'wb') as sf:
                    sf.write(out.getvalue())
                # Replace original with signed
                os.replace(signed_path, pdf_path)
        except ImportError:
            pass  # pyHanko not installed
        except Exception:
            pass  # signing failed, return unsigned

        return pdf_path

    # ── Main generate ─────────────────────────────────────────────

    def generate(self, filename=""):
        """Generate the complete deposition PDF. Returns the output path."""
        output_path = self.job_dir / (filename or f"notare_{self.job['id']}_deposition.pdf")
        self.c = pdf_canvas.Canvas(str(output_path), pagesize=letter)
        self.page_num = 0
        self.t_margin = T_MARGIN
        self.b_margin = B_MARGIN

        # Build body and optimize spacing
        self._build_body()
        self._optimize_spacing()

        # Calculate exam page numbers (body starts on page 5)
        self.exam_pages = []
        for label, line_idx in self.exam_entries:
            page = 5 + (line_idx // self.lines_per_page)
            self.exam_pages.append((label, page))

        # Render all sections
        self.draw_cover()
        self.draw_caption()
        self.draw_appearances()
        self.draw_index()
        self.draw_body()
        self.draw_cert_reporter()
        self.draw_cert_transcriber()
        self.draw_errata()
        self.draw_word_index()
        self.draw_exhibits()

        self.c.save()

        # Post-process: digital signature
        if self.digital_cert_path:
            self._apply_digital_signature(str(output_path))

        return output_path


# ═══════════════════════════════════════════════════════════════════
# Disc Label Generator
# ═══════════════════════════════════════════════════════════════════

def generate_disc_label(job, job_dir, filename=""):
    """Generate a printable disc label PDF (standard CD/DVD 4.65" diameter)."""
    output_path = Path(job_dir) / (filename or f"notare_{job['id']}_disc_label.pdf")
    c = pdf_canvas.Canvas(str(output_path), pagesize=letter)

    case_caption = job.get("case_caption", "")
    case_num = job.get("case_number", "")
    date_str = job.get("date", "")
    deponent = ""
    for spk in job.get("speakers", []):
        role = (spk.get("role") or spk.get("representing") or "").lower()
        if "witness" in role or "deponent" in role:
            deponent = spk.get("name", "")
            break
    reporter = job.get("reporter_name", "")
    volume = job.get("volume_number", "")

    # Disc dimensions
    disc_diameter = 4.65 * inch
    hub_diameter = 1.6 * inch
    cx, cy = PAGE_W / 2, PAGE_H / 2

    # Outer circle
    c.setStrokeColor(Color(0.7, 0.7, 0.7))
    c.setLineWidth(0.5)
    c.circle(cx, cy, disc_diameter / 2, stroke=1, fill=0)
    # Hub circle
    c.circle(cx, cy, hub_diameter / 2, stroke=1, fill=0)

    # Text on disc
    c.setFont(FONT_BOLD, 10)
    c.drawCentredString(cx, cy + 1.2 * inch, "DEPOSITION TRANSCRIPT")
    c.setFont(FONT, 9)
    if case_caption:
        # Truncate for disc
        cap = case_caption[:40]
        c.drawCentredString(cx, cy + 0.95 * inch, cap)
    if case_num:
        c.drawCentredString(cx, cy + 0.75 * inch, f"Case No. {case_num}")
    if deponent:
        c.setFont(FONT_BOLD, 9)
        c.drawCentredString(cx, cy + 0.5 * inch, deponent.upper())
    c.setFont(FONT, 8)
    if date_str:
        c.drawCentredString(cx, cy - 0.6 * inch, date_str)
    if volume:
        c.drawCentredString(cx, cy - 0.8 * inch, f"Volume {volume}")
    if reporter:
        c.drawCentredString(cx, cy - 1.0 * inch, f"Reported by: {reporter}")

    # Trim marks at corners
    c.setStrokeColor(Color(0.8, 0.8, 0.8))
    c.setLineWidth(0.25)
    for dx in [-1, 1]:
        for dy in [-1, 1]:
            mx = cx + dx * (disc_diameter / 2 + 0.15 * inch)
            my = cy + dy * (disc_diameter / 2 + 0.15 * inch)
            c.line(mx - 0.1 * inch, my, mx + 0.1 * inch, my)
            c.line(mx, my - 0.1 * inch, mx, my + 0.1 * inch)

    c.save()
    return output_path


# ═══════════════════════════════════════════════════════════════════
# Cover Letter Generator
# ═══════════════════════════════════════════════════════════════════

def generate_cover_letter(job, job_dir, profile=None, template_path=None, filename=""):
    """Generate a cover letter from a Word template with replacement fields.

    Template fields: {case_caption}, {case_number}, {date}, {deponent},
    {reporter_name}, {reporter_credential}, {court_name}, {location},
    {volume_number}, {job_number}, {today}, {recipient}, {firm}.
    """
    try:
        from docx import Document
    except ImportError:
        return None

    profile = profile or job.get("profile", {})
    tpl_path = template_path or profile.get("cover_letter_template", "")
    if not tpl_path:
        # Generate a basic cover letter without template
        return _generate_default_cover_letter(job, job_dir, profile, filename)

    tpl = Path(tpl_path)
    if not tpl.exists():
        return _generate_default_cover_letter(job, job_dir, profile, filename)

    doc = Document(str(tpl))

    # Build replacement map
    deponent = ""
    for spk in job.get("speakers", []):
        role = (spk.get("role") or spk.get("representing") or "").lower()
        if "witness" in role or "deponent" in role:
            deponent = spk.get("name", "")
            break

    replacements = {
        "{case_caption}": job.get("case_caption", ""),
        "{case_number}": job.get("case_number", ""),
        "{date}": job.get("date", ""),
        "{deponent}": deponent,
        "{reporter_name}": job.get("reporter_name", ""),
        "{reporter_credential}": job.get("reporter_credential", ""),
        "{court_name}": job.get("court_name", ""),
        "{location}": job.get("location", ""),
        "{volume_number}": job.get("volume_number", ""),
        "{job_number}": job.get("job_number", ""),
        "{today}": datetime.now().strftime("%B %d, %Y"),
        "{recipient}": job.get("recipient", ""),
        "{firm}": job.get("firm", ""),
    }

    # Replace in paragraphs
    for para in doc.paragraphs:
        for key, val in replacements.items():
            if key in para.text:
                for run in para.runs:
                    if key in run.text:
                        run.text = run.text.replace(key, val)

    # Replace in tables
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for key, val in replacements.items():
                        if key in para.text:
                            for run in para.runs:
                                if key in run.text:
                                    run.text = run.text.replace(key, val)

    output_path = Path(job_dir) / (filename or f"notare_{job['id']}_cover_letter.docx")
    doc.save(str(output_path))
    return output_path


def _generate_default_cover_letter(job, job_dir, profile, filename):
    """Generate a basic cover letter without a template."""
    try:
        from docx import Document
        from docx.shared import Pt, Inches
    except ImportError:
        return None

    doc = Document()

    # Header
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(12)

    reporter = job.get("reporter_name", "")
    reporter_cred = job.get("reporter_credential", "")

    doc.add_paragraph(datetime.now().strftime("%B %d, %Y"))
    doc.add_paragraph("")

    # Body
    deponent = ""
    for spk in job.get("speakers", []):
        role = (spk.get("role") or spk.get("representing") or "").lower()
        if "witness" in role or "deponent" in role:
            deponent = spk.get("name", "")
            break

    doc.add_paragraph("RE: " + (job.get("case_caption", "") or "Transcript Delivery"))
    if job.get("case_number"):
        doc.add_paragraph(f"Case No. {job['case_number']}")
    doc.add_paragraph("")
    doc.add_paragraph("Dear Counsel:")
    doc.add_paragraph("")

    body = (
        f"Enclosed please find the transcript of the "
        f"{job.get('proceeding_type', 'deposition').lower()} of "
        f"{deponent or 'the witness'}, taken on {job.get('date', '[DATE]')}."
    )
    doc.add_paragraph(body)
    doc.add_paragraph("")
    doc.add_paragraph("This package includes:")
    doc.add_paragraph("    • Full-size transcript (PDF)", style='List Bullet')
    doc.add_paragraph("    • Condensed transcript (4-on-1 PDF)", style='List Bullet')
    doc.add_paragraph("    • ASCII text file", style='List Bullet')
    doc.add_paragraph("    • Word index with hyperlinks", style='List Bullet')
    doc.add_paragraph("")
    doc.add_paragraph(
        "Please review the transcript and submit any corrections on the "
        "enclosed errata sheet within thirty (30) days."
    )
    doc.add_paragraph("")
    doc.add_paragraph("Respectfully,")
    doc.add_paragraph("")
    doc.add_paragraph("")
    if reporter:
        doc.add_paragraph(f"{reporter}{', ' + reporter_cred if reporter_cred else ''}")

    output_path = Path(job_dir) / (filename or f"notare_{job['id']}_cover_letter.docx")
    doc.save(str(output_path))
    return output_path


# ═══════════════════════════════════════════════════════════════════
# Multi-Volume Master Index (CRC 8.144)
# ═══════════════════════════════════════════════════════════════════

def generate_master_index(jobs, output_dir, filename="master_index.pdf"):
    """Generate a CRC 8.144-compliant master index across multiple volumes.

    Args:
        jobs: list of job dicts, each with volume_number, transcript, speakers, etc.
        output_dir: where to write the master index PDF
        filename: output filename
    """
    output_path = Path(output_dir) / filename
    c = pdf_canvas.Canvas(str(output_path), pagesize=letter)

    # Sort by volume number
    sorted_jobs = sorted(jobs, key=lambda j: j.get("volume_number", "0"))

    case_caption = sorted_jobs[0].get("case_caption", "") if sorted_jobs else ""
    case_num = sorted_jobs[0].get("case_number", "") if sorted_jobs else ""

    page_num = [0]

    def new_page():
        if page_num[0] > 0:
            c.showPage()
        page_num[0] += 1

    def footer():
        c.setFont(FONT, 10)
        c.drawCentredString(PAGE_W / 2, B_MARGIN - 0.3 * inch, str(page_num[0]))

    # Cover
    new_page()
    c.setFont(FONT_BOLD, 14)
    c.drawCentredString(PAGE_W / 2, PAGE_H * 0.65, "MASTER INDEX")
    c.setFont(FONT, 12)
    c.drawCentredString(PAGE_W / 2, PAGE_H * 0.58, case_caption)
    c.drawCentredString(PAGE_W / 2, PAGE_H * 0.54, f"Case No. {case_num}")
    c.setFont(FONT, 11)
    c.drawCentredString(PAGE_W / 2, PAGE_H * 0.48, f"{len(sorted_jobs)} Volume(s)")
    footer()

    # Volume listing
    new_page()
    y = PAGE_H - T_MARGIN
    c.setFont(FONT_BOLD, 12)
    c.drawString(TEXT_X, y, "VOLUME INDEX")
    y -= LINE_HEIGHT * 2

    c.setFont(FONT, 11)
    for job in sorted_jobs:
        vol = job.get("volume_number", "?")
        date = job.get("date", "")
        deponent = ""
        for spk in job.get("speakers", []):
            role = (spk.get("role") or spk.get("representing") or "").lower()
            if "witness" in role or "deponent" in role:
                deponent = spk.get("name", "")
                break
        c.drawString(TEXT_X, y, f"Volume {vol}:")
        c.drawString(TEXT_X + 1.5 * inch, y, f"{deponent or 'Unknown'} — {date}")
        segs = job.get("transcript", {}).get("segments", [])
        c.drawString(TEXT_X + 5.0 * inch, y, f"{len(segs)} segments")
        y -= LINE_HEIGHT
        if y < B_MARGIN + inch:
            footer()
            new_page()
            y = PAGE_H - T_MARGIN

    # Master witness index
    y -= LINE_HEIGHT
    c.setFont(FONT_BOLD, 12)
    c.drawString(TEXT_X, y, "WITNESS INDEX")
    y -= LINE_HEIGHT * 2
    c.setFont(FONT, 11)

    all_witnesses = {}
    for job in sorted_jobs:
        vol = job.get("volume_number", "?")
        for spk in job.get("speakers", []):
            role = (spk.get("role") or spk.get("representing") or "").lower()
            if "witness" in role or "deponent" in role:
                name = spk.get("name", "")
                if name not in all_witnesses:
                    all_witnesses[name] = []
                all_witnesses[name].append(vol)

    for name, vols in sorted(all_witnesses.items()):
        c.drawString(TEXT_X, y, f"{name}")
        c.drawString(TEXT_X + 3.0 * inch, y, f"Volume(s): {', '.join(str(v) for v in vols)}")
        y -= LINE_HEIGHT
        if y < B_MARGIN + inch:
            footer()
            new_page()
            y = PAGE_H - T_MARGIN

    # Master exhibit index
    y -= LINE_HEIGHT
    c.setFont(FONT_BOLD, 12)
    c.drawString(TEXT_X, y, "EXHIBIT INDEX")
    y -= LINE_HEIGHT * 2
    c.setFont(FONT, 11)

    all_exhibits = []
    for job in sorted_jobs:
        vol = job.get("volume_number", "?")
        for ex in job.get("exhibits", []):
            all_exhibits.append({
                "id": ex.get("id", ""),
                "description": ex.get("description", ""),
                "volume": vol,
            })

    for ex in all_exhibits:
        c.drawString(TEXT_X, y, f"Exhibit {ex['id']}")
        c.drawString(TEXT_X + 1.5 * inch, y, ex['description'][:40])
        c.drawString(TEXT_X + 5.0 * inch, y, f"Vol. {ex['volume']}")
        y -= LINE_HEIGHT
        if y < B_MARGIN + inch:
            footer()
            new_page()
            y = PAGE_H - T_MARGIN

    footer()
    c.save()
    return output_path


# ═══════════════════════════════════════════════════════════════════
# Multi-Volume Consolidation
# ═══════════════════════════════════════════════════════════════════

def consolidate_volumes(jobs, output_dir, filename="consolidated_transcript.pdf"):
    """Combine multiple volume PDFs into a single document with continuous numbering.

    Args:
        jobs: list of (job_dict, pdf_path) tuples, ordered by volume
        output_dir: where to write the consolidated PDF
        filename: output filename

    Returns:
        Path to consolidated PDF, or None on failure.
    """
    try:
        from pypdf import PdfReader, PdfWriter, PageObject
        from pypdf.annotations import FreeText
    except ImportError:
        return None

    output_path = Path(output_dir) / filename
    writer = PdfWriter()
    continuous_page = 0

    for job, pdf_path in jobs:
        pdf_file = Path(pdf_path)
        if not pdf_file.exists():
            continue

        reader = PdfReader(str(pdf_file))
        for page in reader.pages:
            writer.add_page(page)
            continuous_page += 1

    # Generate master index and prepend it
    job_dicts = [j for j, _ in jobs]
    master_idx_path = generate_master_index(job_dicts, str(output_dir), "temp_master_index.pdf")

    if master_idx_path and Path(master_idx_path).exists():
        # Create new writer with master index first
        final_writer = PdfWriter()
        master_reader = PdfReader(str(master_idx_path))
        for page in master_reader.pages:
            final_writer.add_page(page)
        # Then all volume pages
        for page in writer.pages:
            final_writer.add_page(page)
        final_writer.write(str(output_path))
        # Cleanup temp
        try:
            Path(master_idx_path).unlink()
        except Exception:
            pass
    else:
        writer.write(str(output_path))

    return output_path


# ═══════════════════════════════════════════════════════════════════
# Backward-compatible wrapper
# ═══════════════════════════════════════════════════════════════════

def generate_deposition_pdf(job, job_dir, filename=""):
    """Generate a complete single-file deposition transcript PDF.

    Backward-compatible wrapper around DepositionPDFBuilder.
    """
    builder = DepositionPDFBuilder(job, job_dir)
    return builder.generate(filename)


# ═══════════════════════════════════════════════════════════════════
# Speaker label formatting
# ═══════════════════════════════════════════════════════════════════

def _format_label(speaker, speakers=None):
    """Format speaker name for deposition transcript body."""
    if not speaker:
        return speaker
    name = speaker.rstrip(":")
    lower = name.lower()

    if any(r in lower for r in ["the court", "the witness", "the clerk",
           "the reporter", "the defendant", "the plaintiff", "the bailiff"]):
        return name.upper()
    if "judge" in lower:
        return "THE COURT"

    if name.upper().startswith(("MR.", "MS.", "MRS.", "DR.")):
        return name.upper()

    parts = name.split()
    if not parts:
        return name

    last = parts[-1].upper()
    first = parts[0].lower()

    _fem = {'elizabeth', 'stephanie', 'jessica', 'jennifer', 'sarah', 'amanda',
            'ashley', 'emily', 'hannah', 'mary', 'patricia', 'linda', 'barbara',
            'susan', 'margaret', 'lisa', 'nancy', 'karen', 'betty', 'sandra',
            'donna', 'carol', 'ruth', 'sharon', 'michelle', 'laura', 'kim',
            'kimberly', 'deborah', 'diane', 'rebecca', 'rachel', 'katherine',
            'catherine', 'christine', 'ann', 'anne', 'grace', 'allyson', 'megan',
            'heather', 'amber', 'nicole', 'crystal', 'robin', 'meghan', 'edwina'}

    title = "MS." if first in _fem else "MR."
    return f"{title} {last}"
