"""Proof Upload — Upload a .docx, run proofing, download flagged document.

Bundles the standalone proofing scripts into Notare:
  - proof_depo_direct (DepoDirect — Full Verbatim)
  - proof_legacy_oregon (Legacy Oregon — Modified Full Verbatim)
  - proof_legacy_texas (Legacy Texas/Florida — Clean Verbatim)

Endpoint: POST /api/proof-document
  - Upload a .docx file + select a proofing profile
  - Returns the _PROOFED.docx with Word comments inserted

No job creation, no editor — just upload, process, download.
"""
import sys
import os
import logging
import tempfile
import shutil
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

import importlib.util

# Proofing profiles loaded only from user-uploaded scripts
_proof_available = {}


# ─────────────────────────────────────────────
# API Endpoints
# ─────────────────────────────────────────────

from fastapi import UploadFile, File, Form
from fastapi.responses import JSONResponse as _JSONResponse, FileResponse

_PROOF_DIR = _app.BASE_DIR / "_internal" / "proof_scripts"
_PROOF_DIR.mkdir(parents=True, exist_ok=True)

# Add proof_scripts dir to path so uploaded scripts can find each other
if str(_PROOF_DIR) not in sys.path:
    sys.path.insert(0, str(_PROOF_DIR))


def _reload_proof_profiles():
    """Scan proof_scripts dir for available proofing profiles."""
    _proof_available.clear()
    for py_file in sorted(_PROOF_DIR.glob("proof_*.py")):
        try:
            mod_name = py_file.stem
            spec = importlib.util.spec_from_file_location(mod_name, str(py_file))
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                key = mod_name.replace("proof_", "")
                label = getattr(mod, "PROFILE_NAME", mod_name)
                _proof_available[key] = {
                    "module": mod,
                    "label": label,
                    "description": f"Proofing profile: {label}",
                    "filename": py_file.name,
                }
        except Exception as e:
            logger.warning("Proof Upload: could not load %s: %s", py_file.name, e)

_reload_proof_profiles()


@_app.app.get("/api/proof-profiles")
async def list_proof_profiles():
    """List available proofing profiles."""
    profiles = {}
    for key, info in _proof_available.items():
        profiles[key] = {
            "label": info["label"],
            "description": info["description"],
            "filename": info.get("filename", ""),
        }
    return _JSONResponse(profiles)


@_app.app.post("/api/proof-profiles/upload")
async def upload_proof_profile(file: UploadFile = File(...)):
    """Upload a new proofing script (.py)."""
    if not file.filename or not file.filename.lower().endswith(".py"):
        return _JSONResponse({"error": "Please upload a .py proofing script"}, status_code=400)

    content = await file.read()
    # Sanitize filename
    safe_name = file.filename.replace(" ", "_")
    if not safe_name.startswith("proof_"):
        safe_name = "proof_" + safe_name

    dest = _PROOF_DIR / safe_name
    dest.write_bytes(content)
    logger.info("Proof Upload: new script uploaded: %s (%d bytes)", safe_name, len(content))

    # Reload profiles
    _reload_proof_profiles()

    return _JSONResponse({"ok": True, "filename": safe_name, "profiles": len(_proof_available)})


@_app.app.delete("/api/proof-profiles/{profile_key}")
async def delete_proof_profile(profile_key: str):
    """Delete a proofing profile."""
    if profile_key not in _proof_available:
        return _JSONResponse({"error": "Profile not found"}, status_code=404)

    filename = _proof_available[profile_key].get("filename", "")
    if filename:
        target = _PROOF_DIR / filename
        if target.exists():
            target.unlink()
            logger.info("Proof Upload: deleted %s", filename)

    _reload_proof_profiles()
    return _JSONResponse({"ok": True, "remaining": len(_proof_available)})


@_app.app.post("/api/proof-document")
async def proof_document(file: UploadFile = File(...), profile: str = Form("depo_direct")):
    """Upload a .docx, run proofing, return the flagged document.

    Args:
        file: The .docx transcript to proof
        profile: Proofing profile key (depo_direct, legacy_oregon, legacy_texas)

    Returns:
        The proofed .docx file with Word comments
    """
    if not file.filename or not file.filename.lower().endswith(".docx"):
        return _JSONResponse({"error": "Please upload a .docx file"}, status_code=400)

    if profile not in _proof_available:
        available = ", ".join(_proof_available.keys()) if _proof_available else "none loaded"
        return _JSONResponse({
            "error": f"Unknown proofing profile: {profile}. Available: {available}"
        }, status_code=400)

    # Save uploaded file to temp location
    tmp_dir = tempfile.mkdtemp(prefix="notare_proof_")
    try:
        input_path = os.path.join(tmp_dir, file.filename)
        content = await file.read()
        with open(input_path, "wb") as f:
            f.write(content)

        # Run the proofing script
        proof_module = _proof_available[profile]["module"]
        proof_module.process(input_path)

        # Find the output file (_PROOFED.docx)
        base, ext = os.path.splitext(input_path)
        output_path = base + "_PROOFED" + ext

        if not os.path.exists(output_path):
            return _JSONResponse({"error": "Proofing completed but output file not found"}, status_code=500)

        # Return the proofed file
        output_name = os.path.splitext(file.filename)[0] + "_PROOFED.docx"
        return FileResponse(
            output_path,
            filename=output_name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            background=None,  # Don't delete until response is sent
        )

    except Exception as e:
        logger.error("Proof Upload: error processing %s: %s", file.filename, e)
        return _JSONResponse({"error": f"Proofing failed: {str(e)}"}, status_code=500)


# ─────────────────────────────────────────────
# Proof Upload UI Page
# ─────────────────────────────────────────────

_PROOF_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notare — Proof Document</title>
    <link rel="icon" href="/static/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="header">
        <a href="https://notarelegal.com" target="_blank" style="text-decoration:none;"><h1 style="margin:0;display:flex;align-items:center;gap:6px;"><img src="/static/quill_icon_only.png" style="height:24px;" alt=""><span style="font-family:Palatino,Georgia,serif;letter-spacing:1px;font-style:italic;color:var(--gold,#c8a55c);">Notare</span></h1></a>
        <nav>
            <a href="/static/index.html">Dashboard</a>
            <a href="/static/new_job.html">New Job</a>
            <a href="/static/batch.html">Batch</a>
            <a href="/static/proof.html">Proof</a>
            <a href="/static/cases.html">Cases</a>
            <a href="/static/compare.html">Compare</a>
            <a href="/static/voices.html">Voices</a>
            <a href="/static/profiles.html">Profiles</a>
            <a href="/static/settings.html">Settings</a>
            <a href="/static/help.html">Help</a>
        </nav>
    </div>

    <div class="container">
        <h2 class="page-title">Proof Document</h2>
        <p style="color:var(--text-muted); margin-bottom:24px;">Upload a transcript (.docx), select a proofing profile, and download the flagged document with Word comments showing auto-fixes and issues to review.</p>

        <div class="card" id="uploadCard">
            <h3>Upload Transcript</h3>

            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600;">Proofing Profile</label>
                <select id="profileSelect" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:6px; font-size:14px; background:var(--bg-secondary); color:var(--text-body);">
                </select>
                <small id="profileDesc" style="color:var(--text-muted); display:block; margin-top:4px;"></small>
            </div>

            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600;">Transcript File (.docx)</label>
                <input type="file" id="fileInput" accept=".docx"
                       style="width:100%; padding:10px; border:1px solid var(--border); border-radius:6px; font-size:14px; background:var(--bg-secondary); color:var(--text-body);">
            </div>

            <button onclick="runProof()" class="btn btn-primary" id="proofBtn" style="padding:12px 32px; font-size:16px;">Run Proofing</button>
        </div>

        <div class="card" style="margin-top:20px;">
            <h3>Manage Proofing Profiles</h3>
            <div id="profileList" style="margin-bottom:16px;"></div>
            <div style="display:flex; gap:8px; align-items:center;">
                <input type="file" id="uploadProfileInput" accept=".py" style="font-size:13px;">
                <button onclick="uploadProfile()" class="btn btn-secondary" style="font-size:13px;">Upload New Profile</button>
            </div>
            <small style="color:var(--text-muted); display:block; margin-top:6px;">Upload a .py proofing script. Must follow the Notare proofing format with a process() function.</small>
        </div>

        <div class="card" id="resultCard" style="display:none;">
            <h3 id="resultTitle">Processing...</h3>
            <p id="resultMessage" style="color:var(--text-muted);"></p>
            <a id="downloadLink" href="#" class="btn btn-primary" style="display:none; padding:12px 32px; font-size:16px; text-decoration:none; margin-top:12px;">Download Proofed Document</a>
            <button onclick="resetForm()" class="btn btn-secondary" style="margin-top:12px; margin-left:8px;">Proof Another</button>
        </div>
    </div>

    <script>
    let profileData = {};

    // Load profiles
    fetch('/api/proof-profiles').then(r => r.json()).then(profiles => {
        profileData = profiles;
        const sel = document.getElementById('profileSelect');
        for (const [key, info] of Object.entries(profiles)) {
            const opt = document.createElement('option');
            opt.value = key;
            opt.textContent = info.label;
            sel.appendChild(opt);
        }
        updateDesc();
    });

    document.getElementById('profileSelect').addEventListener('change', updateDesc);

    function updateDesc() {
        const key = document.getElementById('profileSelect').value;
        const desc = profileData[key]?.description || '';
        document.getElementById('profileDesc').textContent = desc;
    }

    async function runProof() {
        const fileInput = document.getElementById('fileInput');
        const profile = document.getElementById('profileSelect').value;

        if (!fileInput.files.length) {
            alert('Please select a .docx file.');
            return;
        }

        const file = fileInput.files[0];
        if (!file.name.toLowerCase().endsWith('.docx')) {
            alert('Please select a .docx file.');
            return;
        }

        const btn = document.getElementById('proofBtn');
        btn.disabled = true;
        btn.textContent = 'Processing...';

        document.getElementById('uploadCard').style.display = 'none';
        document.getElementById('resultCard').style.display = '';
        document.getElementById('resultTitle').textContent = 'Processing...';
        document.getElementById('resultMessage').textContent = 'Running proofing rules against ' + file.name + '. This may take a moment for large documents.';

        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('profile', profile);

            const resp = await fetch('/api/proof-document', {
                method: 'POST',
                body: formData,
            });

            if (resp.ok) {
                const blob = await resp.blob();
                const url = URL.createObjectURL(blob);
                const outputName = file.name.replace('.docx', '_PROOFED.docx');

                document.getElementById('resultTitle').textContent = 'Proofing Complete';
                document.getElementById('resultMessage').textContent = 'Your document has been proofed. Open the downloaded file in Word and review the comments in the Review tab.';
                const link = document.getElementById('downloadLink');
                link.href = url;
                link.download = outputName;
                link.style.display = 'inline-block';
                link.textContent = 'Download ' + outputName;

                // Auto-trigger download
                link.click();
            } else {
                const data = await resp.json();
                document.getElementById('resultTitle').textContent = 'Error';
                document.getElementById('resultMessage').textContent = data.error || 'Proofing failed. Please try again.';
            }
        } catch (e) {
            document.getElementById('resultTitle').textContent = 'Error';
            document.getElementById('resultMessage').textContent = 'Connection error: ' + e.message;
        }

        btn.disabled = false;
        btn.textContent = 'Run Proofing';
    }

    function resetForm() {
        document.getElementById('uploadCard').style.display = '';
        document.getElementById('resultCard').style.display = 'none';
        document.getElementById('downloadLink').style.display = 'none';
        document.getElementById('fileInput').value = '';
    }

    function renderProfiles() {
        const container = document.getElementById('profileList');
        if (!Object.keys(profileData).length) {
            container.innerHTML = '<p style="color:var(--text-muted); font-size:13px;">No proofing profiles loaded.</p>';
            return;
        }
        container.innerHTML = Object.entries(profileData).map(([key, info]) =>
            '<div style="display:flex; justify-content:space-between; align-items:center; padding:8px 12px; border:1px solid var(--border); border-radius:6px; margin-bottom:6px;">' +
                '<div>' +
                    '<strong style="font-size:14px;">' + info.label + '</strong>' +
                    '<div style="font-size:12px; color:var(--text-muted);">' + (info.filename || '') + '</div>' +
                '</div>' +
                '<button onclick="deleteProfile(\\'' + key + '\\')" class="btn btn-sm" style="font-size:12px; color:#e74c3c; border:1px solid #e74c3c; background:none; cursor:pointer;">Delete</button>' +
            '</div>'
        ).join('');
    }

    async function deleteProfile(key) {
        if (!confirm('Delete proofing profile "' + (profileData[key]?.label || key) + '"?')) return;
        const resp = await fetch('/api/proof-profiles/' + key, {method: 'DELETE'});
        const data = await resp.json();
        if (data.ok) {
            delete profileData[key];
            // Refresh profiles
            const r = await fetch('/api/proof-profiles');
            profileData = await r.json();
            renderProfiles();
            // Rebuild dropdown
            const sel = document.getElementById('profileSelect');
            sel.innerHTML = '';
            for (const [k, info] of Object.entries(profileData)) {
                const opt = document.createElement('option');
                opt.value = k;
                opt.textContent = info.label;
                sel.appendChild(opt);
            }
            updateDesc();
        }
    }

    async function uploadProfile() {
        const input = document.getElementById('uploadProfileInput');
        if (!input.files.length) { alert('Select a .py file first.'); return; }
        const formData = new FormData();
        formData.append('file', input.files[0]);
        const resp = await fetch('/api/proof-profiles/upload', {method: 'POST', body: formData});
        const data = await resp.json();
        if (data.ok) {
            input.value = '';
            // Refresh everything
            const r = await fetch('/api/proof-profiles');
            profileData = await r.json();
            renderProfiles();
            const sel = document.getElementById('profileSelect');
            sel.innerHTML = '';
            for (const [k, info] of Object.entries(profileData)) {
                const opt = document.createElement('option');
                opt.value = k;
                opt.textContent = info.label;
                sel.appendChild(opt);
            }
            updateDesc();
            alert('Profile uploaded successfully.');
        } else {
            alert(data.error || 'Upload failed.');
        }
    }

    // Initial render of profile list
    fetch('/api/proof-profiles').then(r => r.json()).then(p => { profileData = p; renderProfiles(); });
    </script>
<script src="/static/theme.js"></script>
<script src="/static/support_widget.js"></script>
</body>
</html>"""

# Write the static HTML file
_static_dir = _app.BASE_DIR / "_internal" / "static"
_static_dir_exe = _app.BASE_DIR / "static"
for d in [_static_dir, _static_dir_exe]:
    try:
        (d / "proof.html").write_text(_PROOF_HTML, encoding="utf-8")
    except Exception:
        pass

logger.info("Proof Upload: endpoint active at /api/proof-document, page at /static/proof.html")
print("Plugin loaded: proof_upload.py — document proofing with Word comments active")
