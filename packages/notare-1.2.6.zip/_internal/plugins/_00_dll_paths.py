"""DLL + Import Fix — preloads ctranslate2 DLL and ensures WhisperModel is importable.

MUST load before any plugin that imports faster_whisper or ctranslate2.
Named _00_ to sort first alphabetically in the plugin loader.

Solves: In frozen PyInstaller exe, ctranslate2's .pyd can't find
ctranslate2.dll, AND faster_whisper's PYZ-compiled __init__.py
can't chain-import from its submodules correctly.
"""
import os
import sys
import ctypes

# Find the _internal directory
if getattr(sys, 'frozen', False):
    _internal = os.path.join(os.path.dirname(sys.executable), '_internal')
else:
    _internal = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(_internal) == 'plugins':
        _internal = os.path.dirname(_internal)

_ct2_dir = os.path.join(_internal, 'ctranslate2')
_ct2_dll = os.path.join(_ct2_dir, 'ctranslate2.dll')
_iomp_dll = os.path.join(_ct2_dir, 'libiomp5md.dll')

# Step 1: Add DLL directories
if os.path.isdir(_ct2_dir):
    try:
        os.add_dll_directory(_ct2_dir)
        os.add_dll_directory(_internal)
    except (OSError, AttributeError):
        os.environ['PATH'] = _ct2_dir + os.pathsep + _internal + os.pathsep + os.environ.get('PATH', '')

# Step 2: Preload DLLs with ctypes (most reliable method)
_loaded = []
for dll_path in [_iomp_dll, _ct2_dll]:
    if os.path.exists(dll_path):
        try:
            ctypes.CDLL(dll_path)
            _loaded.append(os.path.basename(dll_path))
        except OSError as e:
            print(f"DLL preload failed for {os.path.basename(dll_path)}: {e}")

if _loaded:
    print(f"DLL preloaded: {', '.join(_loaded)}")

# Step 3: Try importing ctranslate2 first (before faster_whisper)
_ct2_ok = False
try:
    import ctranslate2
    _ct2_ok = True
except ImportError as e:
    print(f"ctranslate2 import failed: {e}")
except Exception as e:
    print(f"ctranslate2 error: {e}")

# Step 4: Try importing WhisperModel
_fw_ok = False
if _ct2_ok:
    try:
        from faster_whisper import WhisperModel
        _fw_ok = True
    except ImportError:
        # PYZ might have broken the chain — try direct submodule import
        try:
            from faster_whisper.transcribe import WhisperModel
            import faster_whisper
            faster_whisper.WhisperModel = WhisperModel
            _fw_ok = True
            print("WhisperModel imported via direct submodule path")
        except ImportError as e2:
            print(f"WhisperModel import failed (both paths): {e2}")
    except Exception as e:
        print(f"WhisperModel error: {e}")

if _fw_ok:
    print("DLL fix verified: ctranslate2 + WhisperModel importable")
else:
    print(f"DLL fix: ctranslate2={'OK' if _ct2_ok else 'FAIL'}, WhisperModel={'OK' if _fw_ok else 'FAIL'}")
