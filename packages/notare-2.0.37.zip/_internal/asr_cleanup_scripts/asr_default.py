"""ASR Cleanup — Default profile.

Adapted from Elizabeth Knittle's Oregon ASR_Edit script (Apr 2026).

What it does:
  Takes a raw AssemblyAI-style .docx transcript and applies general cleanup
  so the human transcriber has an easier starting point. Does NOT produce a
  finished transcript — just makes the raw output readable.

  Specifically:
    - Normalizes speaker labels via a caller-supplied speaker_map
    - Strips [Speaker:XYZ] tags left by AssemblyAI
    - Collapses whitespace, em-dashes → "--", drops fillers (um/ah/uh)
    - Capitalizes legal terms: the Court, the State, Defendant, Defense,
      Your Honor, Judge
    - Un-capitalizes compound words: courtroom, courthouse, statement
    - Exhibit/Count only capitalize before numbers/letters
    - Juror + spelled-out numbers → digits
    - % → percent, gonna → going to, etc.
    - Two spaces after terminal punctuation (except after Mr./Mrs./Ms./Dr.)

Contract:
  PROFILE_NAME         : str  — shown in the UI dropdown
  scan_labels(path)    : returns sorted list of unique speaker labels in the
                         doc, so the UI can prompt the user for name mapping
                         before running cleanup
  process(path,
          speaker_map, : dict mapping "SPEAKER_A" → "MS. GENTRY"
          output_path) : writes cleaned copy here; defaults to sibling
                         <stem>_CLEANED.docx
"""

import re
from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn

PROFILE_NAME = "ASR Cleanup — Default"


# ─────────────────────────────────────────────
# LABEL EXTRACTION — now timestamp-aware.
# Handles all of:
#   "the Court - 1:  body text"
#   "THE COURT: body text"
#   "[00:14:32] MS. GENTRY: body text"  (WS1 output with timestamps on)
#   "SPEAKER_A: body text"              (legacy prefix)
# ─────────────────────────────────────────────
LABEL_RE     = re.compile(r'^([A-Za-z][A-Za-z0-9_ ]*(?:\s*-\s*\d+)?):\s+')
TIMESTAMP_RE = re.compile(r'^\[(\d{2}:\d{2}:\d{2})\]\s+')


def _extract_label(text):
    """Returns (UPPERCASED_ROLE, body_text, timestamp_prefix) if a label is
    found, else (None, text, ''). Handles lines with or without a leading
    [HH:MM:SS] timestamp. Caller must preserve the timestamp_prefix when
    reassembling so timestamped output round-trips correctly through cleanup.
    """
    # Check for optional timestamp prefix and strip it temporarily
    ts_match = TIMESTAMP_RE.match(text)
    timestamp_prefix = f"[{ts_match.group(1)}] " if ts_match else ''
    working = text[ts_match.end():] if ts_match else text

    # Strip SPEAKER_ prefix if present (legacy AssemblyAI format)
    working = re.sub(r'^SPEAKER_', '', working, flags=re.IGNORECASE)

    m = LABEL_RE.match(working)
    if m:
        role = m.group(1).strip()
        role = re.sub(r'\s*-\s*\d+$', '', role)  # strip " - 1" etc.
        body = working[m.end():]
        return role.upper(), body, timestamp_prefix
    return None, text, ''


# ─────────────────────────────────────────────
# BODY TEXT CLEANUP — runs only on text AFTER the speaker label
# ─────────────────────────────────────────────
def _clean_body(text):
    # Strip [Speaker:WHATEVER] tags left by AssemblyAI
    text = re.sub(r'\[Speaker:[^\]]*\]', '', text)

    # Clean up double spaces left behind after tag removal
    text = re.sub(r'  +', ' ', text)

    # Em dash to double dash with spaces
    text = re.sub(r'—', '--', text)
    text = re.sub(r'\s*--\s*', ' -- ', text)

    # Remove filler words. Preserves: uh-huh, uh-uh, mm-hmm. Removes: um, ah,
    # standalone uh.
    text = re.sub(r'\b(um|ah)\b,?\s*', '', text, flags=re.IGNORECASE)
    text = re.sub(r'\buh\b(?!-),?\s*', '', text, flags=re.IGNORECASE)

    # Clean up double spaces from filler removal
    text = re.sub(r'  +', ' ', text)
    text = text.strip()

    # Fix okay, -> okay. and all right, -> all right.
    text = re.sub(r'\bokay,', 'okay.', text, flags=re.IGNORECASE)
    text = re.sub(r'\ball right,', 'all right.', text, flags=re.IGNORECASE)

    # Fix double periods
    text = re.sub(r'\bokay\.\.+', 'okay.', text, flags=re.IGNORECASE)
    text = re.sub(r'\ball right\.\.+', 'all right.', text, flags=re.IGNORECASE)

    # Capitalization fixes — body text only
    text = re.sub(r'\bthe court\b', 'the Court', text, flags=re.IGNORECASE)
    text = re.sub(r'\bthe state\b', 'the State', text, flags=re.IGNORECASE)

    # Undo over-capitalization of compound words
    text = re.sub(r'\bCourtroom\b', 'courtroom', text)
    text = re.sub(r'\bCourthouse\b', 'courthouse', text)
    text = re.sub(r'\bStatement\b', 'statement', text)

    # Defense / Defendant
    text = re.sub(r'\bdefense\b', 'Defense', text)
    text = re.sub(r'\bdefendant\b', 'Defendant', text)

    # Your Honor / Judge
    text = re.sub(r'\byour honor\b', 'Your Honor', text, flags=re.IGNORECASE)
    text = re.sub(r'\byou,\s+honor\b', 'Your Honor', text, flags=re.IGNORECASE)
    text = re.sub(r'\bjudge\b', 'Judge', text, flags=re.IGNORECASE)

    # Exhibit capitalized only when followed by a number or letter identifier
    text = re.sub(r'\bexhibit\s+(?=\d+|[A-Z]\b)', 'Exhibit ', text, flags=re.IGNORECASE)

    # Count capitalized only when followed by a number
    text = re.sub(r'\bcount\s+(?=\d+)', 'Count ', text, flags=re.IGNORECASE)

    # Juror — capitalize and convert spelled-out numbers to numerals
    number_words = {
        'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
        'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10',
        'eleven': '11', 'twelve': '12', 'thirteen': '13', 'fourteen': '14',
        'fifteen': '15', 'sixteen': '16', 'seventeen': '17', 'eighteen': '18',
        'nineteen': '19', 'twenty': '20'
    }

    def replace_juror(m):
        num = m.group(1).lower()
        return f"Juror number {number_words.get(num, num)}"

    text = re.sub(
        r'\bjuror\s+number\s+(' + '|'.join(number_words.keys()) + r')\b',
        replace_juror, text, flags=re.IGNORECASE
    )
    text = re.sub(r'\bjuror\b', 'Juror', text, flags=re.IGNORECASE)

    def replace_count_number(m):
        num = m.group(1).lower()
        return f"Count {number_words.get(num, num)}"

    text = re.sub(
        r'\bCount\s+(' + '|'.join(number_words.keys()) + r')\b',
        replace_count_number, text, flags=re.IGNORECASE
    )

    # Replace % with " percent"
    text = re.sub(r'%', ' percent', text)

    # Informal word replacements
    text = re.sub(r'\bwanna\b', 'want to', text, flags=re.IGNORECASE)
    text = re.sub(r'\bgonna\b', 'going to', text, flags=re.IGNORECASE)
    text = re.sub(r'\bgotta\b', 'got to', text, flags=re.IGNORECASE)
    text = re.sub(r'\bgotcha\b', 'got you', text, flags=re.IGNORECASE)
    text = re.sub(r'\bkinda\b', 'kind of', text, flags=re.IGNORECASE)
    text = re.sub(r'\bsorta\b', 'sort of', text, flags=re.IGNORECASE)

    # Two spaces after all periods and question marks
    text = re.sub(r'([.?]) ', r'\1  ', text)

    # Fix back abbreviations that should only have one space after period
    text = re.sub(r'\bMrs\.  ', 'Mrs. ', text)
    text = re.sub(r'\bMr\.  ', 'Mr. ', text)
    text = re.sub(r'\bMs\.  ', 'Ms. ', text)
    text = re.sub(r'\bDr\.  ', 'Dr. ', text)

    return text


# ─────────────────────────────────────────────
# PUBLIC API — contract Notare's asr_cleanup plugin calls
# ─────────────────────────────────────────────

def scan_labels(input_path):
    """Return a sorted list of unique speaker labels found in the doc.

    Called before process() so the UI can prompt the user to map each label
    (SPEAKER_A → MS. GENTRY). The special label "UNIDENTIFIED" is still
    returned for transparency; the plugin may auto-map it.
    """
    doc = Document(str(input_path))
    found = set()
    for para in doc.paragraphs:
        # _extract_label handles timestamp + SPEAKER_ stripping internally now
        label, _, _ = _extract_label(para.text.strip())
        if label:
            found.add(label)
    return sorted(found)


def process(input_path, speaker_map=None, output_path=None):
    """Apply speaker substitutions + cleanup rules, save a cleaned copy.

    Args:
        input_path:   path to a .docx file (raw ASR output).
        speaker_map:  dict mapping found labels → replacement labels.
                      Labels not in the map are left as-is.
        output_path:  where to write the cleaned copy. Defaults to a sibling
                      file named "<stem>_CLEANED.docx".

    Returns:
        Path to the written cleaned file.
    """
    input_path = Path(input_path)
    if output_path is None:
        output_path = input_path.with_name(input_path.stem + "_CLEANED.docx")
    else:
        output_path = Path(output_path)

    speaker_map = dict(speaker_map or {})
    # Always normalize "UNIDENTIFIED" → "UNIDENTIFIED SPEAKER" unless the
    # caller explicitly set something else for it.
    speaker_map.setdefault("UNIDENTIFIED", "UNIDENTIFIED SPEAKER")

    doc = Document(str(input_path))

    for para in doc.paragraphs:
        original = para.text

        # Remove legacy "Transcription" heading
        if original.strip() == 'Transcription':
            _replace_paragraph_text(para, "")
            continue

        # Strip legacy "Speaker A:" prefix — _extract_label handles SPEAKER_ internally
        text = re.sub(r'^Speaker\s+[A-Z]:\s*', '', original)

        # Split into timestamp, label, body — all three may be empty strings
        label, body, timestamp_prefix = _extract_label(text)

        # Apply substitution to label if mapped
        if label and label in speaker_map:
            label = speaker_map[label].upper() if speaker_map[label] else label

        # Clean body text only
        body = _clean_body(body)

        # Reassemble, preserving the timestamp prefix so timestamped output
        # round-trips correctly through cleanup
        if label:
            cleaned = f"{timestamp_prefix}{label}:  {body}"
        else:
            cleaned = body

        # Fully rewrite the paragraph (see _replace_paragraph_text below)
        _replace_paragraph_text(para, cleaned)

    doc.save(str(output_path))
    return str(output_path)


# ─────────────────────────────────────────────
# Paragraph text rewriter — bulletproof version
#
# The previous pattern was:
#     para.runs[0].text = cleaned
#     for run in para.runs[1:]:
#         run.text = ''
#
# That has several failure modes depending on the source Word file's XML:
#   1. Paragraph has text inside hyperlinks or field codes (not <w:r> direct
#      children). python-docx's `para.runs` skips those, so the original
#      text survives inside the hyperlink.
#   2. Paragraph has no runs at all (empty p with a direct <w:t>). The code
#      does nothing → original content persists.
#   3. Paragraph has a <w:r> with no <w:t> inside. Setting `.text` on it
#      doesn't add a <w:t>; the text stays elsewhere.
#   4. Multi-run paragraphs where runs[0] has styling we want but the actual
#      text is split across runs[1:]. Blanking runs[1:]'s .text works in
#      most python-docx versions, but a few edge-case <w:t xml:space> tags
#      survive untouched, leaving invisible trailing content.
#
# This function removes all text-carrying children from the paragraph's XML
# (runs, hyperlinks, smart tags) while keeping <w:pPr> (paragraph properties
# — style, alignment, indent). Then it adds a single new run with the
# cleaned text, inheriting the paragraph's pPr-defined style. Bulletproof.
# ─────────────────────────────────────────────
def _replace_paragraph_text(para, new_text):
    """Replace ALL text in the paragraph with new_text, preserving only the
    paragraph's pPr (style/formatting properties). Works regardless of how
    the original paragraph's runs/hyperlinks/etc. were structured."""
    p = para._p
    # Remove every child except pPr. This kills runs, hyperlinks, smart
    # tags, ins/del revisions, bookmarks, everything text-carrying.
    for child in list(p):
        if child.tag == qn('w:pPr'):
            continue
        p.remove(child)
    # Add a new run with the replacement text. add_run handles the w:r +
    # w:t XML for us, and xml:space="preserve" is applied so leading/
    # trailing whitespace survives the save.
    if new_text:
        run = para.add_run(new_text)
        # If text has leading/trailing space, force xml:space preserve
        # (python-docx usually does this but belt-and-suspenders).
        for t in run._r.findall(qn('w:t')):
            if t.text and (t.text.startswith(' ') or t.text.endswith(' ')):
                t.set(qn('xml:space'), 'preserve')
