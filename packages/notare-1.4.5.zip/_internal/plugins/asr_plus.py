"""Enhanced ASR Upgrade — Speaker identification + legal formatting enhancements.

Adds two capabilities that ship in Enhanced standalone Oregon ASR scripts:

1. AssemblyAI speech_understanding API with role-based speaker identification
   and the universal-3-pro model. This sends structured speaker roles with
   descriptions to AssemblyAI, producing dramatically cleaner speaker labels.

2. Enhanced legal formatting rules in the proofing pass:
   - Em dash to double-dash (legal standard)
   - Two spaces after periods/question marks (legal standard)
   - Abbreviation exceptions (Mr. Mrs. Dr. Ms. get single space)
   - "the Court" / "the State" / "Defense" / "Defendant" / "Judge" capitalization
   - Filler word removal (um, ah, standalone uh) preserving uh-huh/mm-hmm

Loads after assemblyai_shim.py and engine_failover.py (alphabetical: 'b').
Monkey-patches _transcribe_single_aai and _apply_proofing_rules.
"""
import re
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")


# ─────────────────────────────────────────────
# PART 1: Patch AssemblyAI transcription to use speech_understanding
# ─────────────────────────────────────────────

_original_transcribe_single_aai = getattr(_app, "_transcribe_single_aai", None)

if _original_transcribe_single_aai:

    def _build_speaker_roles(job):
        """Convert Notare's job speakers into AssemblyAI speech_understanding format.

        Notare speakers look like:
            {"name": "The Court (Judge Smith)", "representing": "", ...}
            {"name": "Jane Doe", "representing": "Plaintiff/State", ...}
            {"name": "John Smith", "representing": "Defense", ...}

        We convert these into AssemblyAI's speaker_identification format with
        descriptive role hints.
        """
        speakers = job.get("speakers", [])
        if not speakers:
            return None

        role_list = []
        has_judge = False

        for spk in speakers:
            name = spk.get("name", "").strip()
            rep = spk.get("representing", "").strip().lower()

            if not name:
                continue

            # Detect role from name or representing field
            name_lower = name.lower()

            if "court" in name_lower or "judge" in name_lower or "hon." in name_lower:
                role_list.append({
                    "name": "THE COURT",
                    "description": "Judge presiding. Rules on objections, addresses parties, controls the courtroom."
                })
                has_judge = True

            elif rep in ("plaintiff/state", "plaintiff", "state", "prosecution", "prosecutor"):
                # Use actual name for the label
                display = name.upper()
                if len(speakers) > 4:
                    # Multiple attorneys — use name to distinguish
                    role_list.append({
                        "name": display,
                        "description": "Prosecutor or plaintiff's counsel. Asks questions on direct, objects, makes argument."
                    })
                else:
                    role_list.append({
                        "name": "PROSECUTOR",
                        "description": f"Prosecutor or plaintiff's counsel ({name}). Asks questions on direct, objects, makes argument."
                    })

            elif rep in ("defense", "defendant", "appellant"):
                display = name.upper()
                if len(speakers) > 4:
                    role_list.append({
                        "name": display,
                        "description": "Defense counsel. Asks questions on cross, objects, makes argument."
                    })
                else:
                    role_list.append({
                        "name": "DEFENSE",
                        "description": f"Defense counsel ({name}). Asks questions on cross, objects, makes argument."
                    })

            elif "witness" in name_lower:
                role_list.append({
                    "name": name.upper(),
                    "description": "Witness under oath. Answers questions from attorneys."
                })

            elif "clerk" in name_lower:
                role_list.append({
                    "name": "THE CLERK",
                    "description": "Court clerk. Administers oaths and manages exhibits."
                })

            elif "interpreter" in name_lower:
                role_list.append({
                    "name": "THE INTERPRETER",
                    "description": "Interpreter translating for a party or witness."
                })

            elif "defendant" in name_lower:
                role_list.append({
                    "name": "THE DEFENDANT",
                    "description": "Defendant speaking in colloquy, not under oath as a witness."
                })

            else:
                # Generic — could be a witness or other participant
                role_list.append({
                    "name": name.upper(),
                    "description": f"Participant in the proceeding: {name}."
                })

        # Always include an unidentified catch-all
        role_list.append({
            "name": "UNIDENTIFIED",
            "description": "Any speaker whose role cannot be determined from context."
        })

        return role_list if role_list else None

    def _patched_transcribe_single_aai(job, audio_path, aai):
        """Enhanced AssemblyAI transcription with speech_understanding speaker ID."""
        from pathlib import Path

        job["progress"] = 15
        job["progress_message"] = "Uploading to AssemblyAI..."

        # Build word boost and custom spelling from profile
        profile = job.get("profile", {})
        word_boost = profile.get("word_boost", [])
        custom_spelling = profile.get("custom_spelling", {})

        # Default legal term boost
        _default_boost = [
            "objection", "sustained", "overruled", "voir dire",
            "motion in limine", "Daubert", "Miranda", "Strickland",
            "appellant", "appellee", "amicus",
            "Multnomah", "Clackamas", "ORS", "ORCP",
        ]
        boost_set = set(w.lower() for w in _default_boost)
        combined_boost = list(_default_boost)
        for w in word_boost:
            if w.lower() not in boost_set:
                combined_boost.append(w)
                boost_set.add(w.lower())

        config_kwargs = {
            "speaker_labels": True,
            "language_code": "en",
            "punctuate": True,
            "format_text": True,
        }
        if combined_boost:
            config_kwargs["word_boost"] = combined_boost
        if custom_spelling:
            config_kwargs["custom_spelling"] = custom_spelling

        # --- Enhanced enhancements ---

        # 1. Use universal-3-pro model
        config_kwargs["speech_models"] = ["universal-3-pro", "universal-2"]

        # 2. Add legal context prompt
        legal_prompt = profile.get("asr_prompt", "")
        if not legal_prompt:
            legal_prompt = (
                "Context: Legal court proceeding. "
                "Modified full verbatim transcription — include false starts, repetitions, "
                "incomplete sentences, and corrections. Do not remove filler words. "
                "Preserve exact spoken words. "
                "Spelling: "
                "'ORS' not 'ors', 'ORCP' not 'orcp', "
                "'Daubert' not 'daubert', 'Miranda' not 'miranda', "
                "'Defense' not 'defense', 'Defendant' not 'defendant'. "
                "Multiple speakers are present. Label each speaker consistently throughout."
            )
        config_kwargs["prompt"] = legal_prompt

        # 3. Build speech_understanding speaker identification
        speaker_roles = _build_speaker_roles(job)
        if speaker_roles:
            config_kwargs["speech_understanding"] = {
                "request": {
                    "speaker_identification": {
                        "speaker_type": "name",
                        "speakers": speaker_roles
                    }
                }
            }
            logger.info("ASR+: speech_understanding enabled with %d speaker roles", len(speaker_roles))

        config = aai.TranscriptionConfig(**config_kwargs)
        transcriber = aai.Transcriber()

        job["progress"] = 30
        job["progress_message"] = "Transcribing with AssemblyAI (enhanced)..."

        transcript = transcriber.transcribe(str(audio_path), config=config)

        if transcript.status == aai.TranscriptStatus.error:
            raise RuntimeError(f"AssemblyAI error: {transcript.error}")

        job["progress"] = 85
        job["progress_message"] = "Processing results..."

        # Extract speech_understanding speaker labels if available
        speaker_label_map = {}
        raw_data = getattr(transcript, "_raw", None)
        if raw_data and isinstance(raw_data, dict):
            try:
                identified = (
                    raw_data
                    .get("speech_understanding", {})
                    .get("results", {})
                    .get("speaker_identification", {})
                    .get("utterances", [])
                )
                speaker_label_map = {utt["start"]: utt["speaker"] for utt in identified}
                if speaker_label_map:
                    logger.info("ASR+: %d speaker identifications from speech_understanding",
                               len(speaker_label_map))
            except Exception as e:
                logger.warning("ASR+: Could not parse speech_understanding results: %s", e)

        # Build segments from utterances
        segments = []
        if transcript.utterances:
            for utt in transcript.utterances:
                # Use speech_understanding label if available, fall back to default
                identified_name = speaker_label_map.get(utt.start)
                if identified_name:
                    speaker = identified_name.upper()
                else:
                    speaker = utt.speaker or ""

                seg = {
                    "start": utt.start,
                    "end": utt.end,
                    "text": utt.text.strip(),
                    "speaker": speaker,
                    "confidence": round(utt.confidence, 3) if utt.confidence else 0.0,
                }
                if utt.words:
                    seg["words"] = [
                        {"word": w.text, "start": w.start, "end": w.end,
                         "confidence": round(w.confidence, 3) if w.confidence else 0.0}
                        for w in utt.words
                    ]
                segments.append(seg)
        elif transcript.words:
            current_seg = {"start": 0, "end": 0, "text": "", "speaker": "", "words": []}
            for w in transcript.words:
                current_seg["words"].append(
                    {"word": w.text, "start": w.start, "end": w.end,
                     "confidence": round(w.confidence, 3) if w.confidence else 0.0})
                current_seg["text"] += " " + w.text
                current_seg["end"] = w.end
                if w.text.rstrip().endswith(('.', '!', '?')):
                    current_seg["text"] = current_seg["text"].strip()
                    current_seg["confidence"] = round(
                        sum(wd["confidence"] for wd in current_seg["words"]) / len(current_seg["words"]), 3
                    ) if current_seg["words"] else 0.0
                    segments.append(current_seg)
                    current_seg = {"start": w.end, "end": w.end, "text": "", "speaker": "", "words": []}
            if current_seg["text"].strip():
                current_seg["text"] = current_seg["text"].strip()
                segments.append(current_seg)

        job["transcript"] = {
            "segments": segments,
            "full_text": transcript.text or "",
            "duration": segments[-1]["end"] if segments else 0,
            "engine": "assemblyai",
            "audio_duration": transcript.audio_duration,
        }
        job["audio_file"] = audio_path.name
        job["progress"] = 95
        job["progress_message"] = "Finalizing..."

    # Install the patched function
    _app._transcribe_single_aai = _patched_transcribe_single_aai
    logger.info("ASR+: Patched _transcribe_single_aai with speech_understanding + universal-3-pro")


# ─────────────────────────────────────────────
# PART 2: Enhance proofing rules
# ─────────────────────────────────────────────

_original_apply_proofing = getattr(_app, "_apply_proofing_rules", None)

if _original_apply_proofing:

    # Abbreviations that should NOT get double-spaced after the period
    _ABBREV_SINGLE_SPACE = re.compile(
        r'\b(?:Mr|Mrs|Ms|Dr|Sgt|Det|Ofc|No|vs|Esq|St|Ave|Blvd|Jr|Sr|Prof|Rev|Gen|Col|Capt|Lt|Cpl|Hon)\.  ',
        re.IGNORECASE
    )

    def _enhanced_proofing_pass(job):
        """Enhanced legal formatting — runs AFTER the base proofing rules.

        Adds rules that don't exist in the base pass:
        - Em/en dash → double dash with spaces (legal standard)
        - Filler word removal (um, ah, standalone uh — preserves uh-huh/mm-hmm)
        - Legal body text capitalization (the Court, the State, Defense, Defendant, Judge)
        - Two spaces after sentence-ending periods and question marks (legal standard)
        - Abbreviation exceptions (Mr. Mrs. Dr. etc. keep single space)
        - Strip leaked ASR speaker tags
        """
        if not job.get("transcript"):
            return

        for seg in job["transcript"].get("segments", []):
            text = seg.get("text", "")

            # --- Dash normalization ---
            text = re.sub(r'[\u2014\u2013]', '--', text)  # em/en dash → --
            text = re.sub(r'\s*--\s*', ' -- ', text)

            # --- Filler word removal ---
            text = re.sub(r'\b(um|ah)\b,?\s*', '', text, flags=re.IGNORECASE)
            text = re.sub(r'\buh\b(?!-),?\s*', '', text, flags=re.IGNORECASE)
            text = re.sub(r'  +', ' ', text)

            # --- Legal body text capitalization ---
            text = re.sub(r'\bthe court\b', 'the Court', text, flags=re.IGNORECASE)
            text = re.sub(r'\bthe state\b', 'the State', text, flags=re.IGNORECASE)
            text = re.sub(r'\bdefense\b', 'Defense', text)
            text = re.sub(r'\bdefendant\b', 'Defendant', text)
            text = re.sub(r'\bjudge\b', 'Judge', text, flags=re.IGNORECASE)

            # --- Two spaces after sentence-ending . and ? (legal standard) ---
            # The base pass normalizes to single space; we upgrade to double.
            text = re.sub(r'([.?])\s+', r'\1 ', text)   # normalize first
            text = re.sub(r'([.?]) ', r'\1  ', text)     # then double
            # Undo for abbreviations (single regex covers all)
            text = _ABBREV_SINGLE_SPACE.sub(lambda m: m.group(0).replace('  ', ' '), text)

            # --- Clean up ASR artifacts ---
            text = re.sub(r'\[Speaker:[^\]]*\]', '', text)
            text = text.strip()

            seg["text"] = text

    def _patched_apply_proofing_rules(job):
        """Run original proofing, then enhanced legal formatting."""
        _original_apply_proofing(job)
        _enhanced_proofing_pass(job)

    _app._apply_proofing_rules = _patched_apply_proofing_rules
    logger.info("ASR+: Patched _apply_proofing_rules with enhanced legal formatting")


# ─────────────────────────────────────────────
# PART 3: Clerk log HTM table parser for speaker extraction
# ─────────────────────────────────────────────
# Enhanced v2 script parses Multnomah-style clerk log HTML tables to
# auto-extract prosecutor/defense names. This patches extract-case-info
# to run the structured HTML parser BEFORE the plaintext strip, giving
# much better speaker extraction from docket logs.

_NAME_SUFFIXES = {'jr', 'sr', 'ii', 'iii', 'iv', 'esq'}


def _clean_attorney_name(name):
    """Strip bar numbers, suffixes, hearing types from a raw attorney name."""
    name = re.sub(r'\s*OSB[#:\s]+[\d]+', '', name)
    name = re.sub(r'\s*\([\d]+\)', '', name)
    name = re.sub(r'\s+\d+$', '', name)  # Bare bar numbers at end
    name = re.sub(r'\s+(Plea|Sent|Trial|Hearing|Further|Arraignment).*$', '', name, flags=re.IGNORECASE)
    return name.strip(' .;,')


def _last_name(full_name):
    """Extract last name, skipping suffixes like Jr, Sr, Esq."""
    parts = full_name.strip().split()
    while parts and parts[-1].lower().rstrip('.') in _NAME_SUFFIXES:
        parts.pop()
    return parts[-1] if parts else full_name


def _parse_clerk_log_html(html_content, case_keywords=None):
    """Parse a Multnomah-style clerk log HTML for attorney names.

    Returns dict with 'method' and parsed names:
      - {'prosecutors': [...], 'defense': [...], 'method': 'called_entry'}
      - {'speakers': [...], 'method': 'speaker_scan'}
      - {'method': 'none'}
    """
    # Extract table rows from HTML
    rows_raw = re.findall(r'<tr.*?</tr>', html_content, re.DOTALL | re.IGNORECASE)
    rows = []
    for row in rows_raw:
        cells = re.findall(r'<td.*?>(.*?)</td>', row, re.DOTALL | re.IGNORECASE)
        cells = [re.sub(r'<[^>]+>', '', c).replace('&nbsp;', ' ').strip() for c in cells]
        if len(cells) == 3:
            rows.append(tuple(cells))

    if not rows:
        return {'method': 'none'}

    prosecutors = []
    defense = []

    # Method 1: "Called" entry with District/Defense Attorney fields
    for time_val, speaker, note in rows:
        if speaker.lower().rstrip(':') != 'called':
            continue
        if case_keywords and not any(kw.lower() in note.lower() for kw in case_keywords):
            continue

        da_match = re.search(
            r'District Attorney:\s*(.+?)(?=\s*Defense Attorney|$)',
            note, re.IGNORECASE
        )
        def_match = re.search(
            r'Defense Attorney:\s*(.+?)(?=\s*;?\s*Defendant|\s*Attorney for|$)',
            note, re.IGNORECASE
        )

        if da_match:
            for name in da_match.group(1).split(','):
                name = _clean_attorney_name(name)
                if name:
                    prosecutors.append(name)

        if def_match:
            for name in def_match.group(1).split(','):
                name = _clean_attorney_name(name)
                if name:
                    defense.append(name)

        if prosecutors or defense:
            return {'prosecutors': prosecutors, 'defense': defense, 'method': 'called_entry'}

    # Method 2: Speaker column scan — collect unique names from relevant case section
    SKIP = {
        'judge', 'called', 'called:', 'recess', 'return', 'lunch',
        'end', 'break', 'clerk', 'bailiff', 'interpreter', 'witness',
        'jury', 'sidebar', '', ' '
    }

    # Find case section boundaries
    case_start_idx = None
    case_end_idx = len(rows)
    for idx, (time_val, speaker, note) in enumerate(rows):
        if case_keywords and any(kw.lower() in note.lower() for kw in case_keywords):
            if speaker.lower().rstrip(':') == 'called':
                case_start_idx = idx
                break

    if case_start_idx is not None:
        for idx in range(case_start_idx + 1, len(rows)):
            time_val, speaker, note = rows[idx]
            if speaker.lower().rstrip(':') == 'called':
                if not case_keywords or not any(kw.lower() in note.lower() for kw in case_keywords):
                    case_end_idx = idx
                    break
        scan_rows = rows[case_start_idx:case_end_idx]
    else:
        scan_rows = rows

    seen = set()
    speakers_found = []
    for time_val, speaker, note in scan_rows:
        s = speaker.strip().rstrip(':').lower()
        if not s or s in SKIP:
            continue
        if 'audio' in s or 'cleanup' in s or 'intro' in s:
            continue
        if s not in seen:
            seen.add(s)
            speakers_found.append(speaker.strip().rstrip(':'))

    if speakers_found:
        return {'speakers': speakers_found, 'method': 'speaker_scan'}

    return {'method': 'none'}


def _name_to_speaker(name, representing=""):
    """Convert a raw attorney name to a Notare speaker dict."""
    clean = _clean_attorney_name(name)
    ln = _last_name(clean).upper()
    first = clean.split()[0].lower() if clean.split() else ""
    prefix = "MS." if first.endswith(('a', 'ie', 'ey', 'ah', 'na', 'ne', 'ia', 'ly', 'yn')) else "MR."
    return {
        "name": f"{prefix} {ln}",
        "firm": "",
        "representing": representing,
        "hotkey": "",
        "_full_name": clean,
    }


def _clerk_log_to_notare_speakers(log_result):
    """Convert clerk log parse result into Notare speaker format."""
    speakers = []
    if log_result['method'] == 'called_entry':
        speakers += [_name_to_speaker(n, "Plaintiff/State") for n in log_result.get('prosecutors', [])]
        speakers += [_name_to_speaker(n, "Defense") for n in log_result.get('defense', [])]
    elif log_result['method'] == 'speaker_scan':
        speakers += [_name_to_speaker(n) for n in log_result.get('speakers', [])]
    return speakers


# Patch extract-case-info to run clerk log parser on raw HTML
_original_extract_case_info = getattr(_app, "extract_case_info", None)

if _original_extract_case_info:
    from fastapi import UploadFile, File
    from fastapi.responses import JSONResponse as _JSONResponse
    from pathlib import Path as _Path

    async def _patched_extract_case_info(files: list[UploadFile] = File(...)):
        """Enhanced extract-case-info that runs Enhanced clerk log parser on HTM files."""

        # First, read raw HTML from any HTM files BEFORE the original strips them
        htm_raw_contents = {}
        case_keywords = []

        for file in files:
            fname = file.filename or ""
            ext = _Path(fname).suffix.lower()
            if ext in (".htm", ".html"):
                content_bytes = await file.read()
                await file.seek(0)  # Reset for the original handler
                try:
                    raw_html = content_bytes.decode("utf-8", errors="replace")
                    htm_raw_contents[fname] = raw_html
                except Exception:
                    pass

        # Run the original extraction
        result = await _original_extract_case_info(files=files)

        # If we got HTM files, try Enhanced structured parser
        if htm_raw_contents:
            # Extract case keywords from the result for scoping
            case_num = ""
            defendant_name = ""
            try:
                import json as _json
                result_body = result.body
                if isinstance(result_body, bytes):
                    result_data = _json.loads(result_body)
                else:
                    result_data = result_body
                case_num = result_data.get("case_number", "")
                defendant_name = result_data.get("defendant_name", "")
                existing_speakers = result_data.get("speakers", [])
            except Exception:
                result_data = {}
                existing_speakers = []

            # Build case keywords from defendant name and case number
            if defendant_name:
                case_keywords = re.findall(r'\b([A-Z][a-z]+)\b', defendant_name)
            if case_num:
                case_keywords.append(case_num)

            # Run Enhanced parser on each HTM file
            clerk_speakers = []
            for fname, raw_html in htm_raw_contents.items():
                log_result = _parse_clerk_log_html(raw_html, case_keywords if case_keywords else None)
                if log_result['method'] != 'none':
                    clerk_speakers = _clerk_log_to_notare_speakers(log_result)
                    logger.info("ASR+ clerk log: %s parsed via '%s' — %d speakers found",
                                fname, log_result['method'], len(clerk_speakers))
                    break  # Use the first successful parse

            # Merge clerk log speakers with any existing speakers
            if clerk_speakers and result_data:
                # Clerk log speakers supplement existing extraction
                existing_names = {s.get("name", "").lower() for s in existing_speakers}
                for cs in clerk_speakers:
                    if cs["name"].lower() not in existing_names:
                        existing_speakers.append(cs)
                        existing_names.add(cs["name"].lower())

                if existing_speakers:
                    result_data["speakers"] = existing_speakers
                    result_data["_clerk_log_used"] = True

                # Return updated result
                return _JSONResponse(result_data)

        return result

    # Replace the route handler
    # FastAPI routes need special handling — find and replace the route
    for route in _app.app.routes:
        if hasattr(route, "path") and route.path == "/api/extract-case-info":
            route.endpoint = _patched_extract_case_info
            # Also update the dependant to match new signature
            try:
                from fastapi.routing import APIRoute
                if isinstance(route, APIRoute):
                    route.dependant = route.dependant  # Force re-resolution
            except Exception:
                pass
            logger.info("ASR+: Patched /api/extract-case-info with clerk log parser")
            break
    else:
        logger.warning("ASR+: Could not find /api/extract-case-info route to patch")


print("Plugin loaded: asr_plus.py — speech_understanding + legal formatting + clerk log parser active")
