"""Import Q&A Fix — Better segment splitting for imported transcripts.

Patches the import parser to handle:
  1. Q./A. format (with period): "Q.  Did you see the defendant?"
  2. Q:/A: format (with colon): "Q:  Did you see the defendant?"
  3. Q/A with just spaces: "Q   Did you see the defendant?"
  4. Mid-line Q/A: "...end of answer. Q. Next question?" → split into two segments
  5. Colloquy labels mid-paragraph: "...text THE COURT: ruling text"

Also improves:
  - Line number stripping for imported court transcripts
  - Page header/footer removal
  - Empty line handling
"""
import re
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

_original_import = getattr(_app, "import_completed_transcript", None)

if _original_import:
    from fastapi import UploadFile, File, Form
    from fastapi.responses import JSONResponse as _JSONResponse
    from pathlib import Path as _Path
    import json as _json
    import io as _io

    # Speaker label pattern — same as app.py but compiled once
    _SPEAKER_RE = re.compile(
        r'^((?:MR\.|MS\.|MRS\.|DR\.|THE COURT|THE WITNESS|THE REPORTER|THE CLERK|THE BAILIFF|'
        r'THE DEFENDANT|THE PLAINTIFF|THE INTERPRETER|PROSECUTOR|DEFENSE|BY )[A-Z\s.\'-]*?):\s*(.*)',
        re.IGNORECASE
    )

    # Q&A patterns — broader than the original
    _QA_RE = re.compile(
        r'^\s*([QA])\s*[.:]\s{0,4}(.*)',  # Q. text / Q: text / Q  text
    )

    # Mid-line Q&A split — finds Q./A. starting mid-paragraph
    _MIDLINE_QA_RE = re.compile(
        r'(?<=[.?!])\s+([QA])\s*[.:]\s{1,4}(?=[A-Z])',
    )

    # Mid-line speaker label — finds "THE COURT:" etc. mid-paragraph
    _MIDLINE_SPEAKER_RE = re.compile(
        r'(?<=[.?!])\s+((?:MR\.|MS\.|MRS\.|DR\.|THE COURT|THE WITNESS|THE CLERK|'
        r'PROSECUTOR|DEFENSE)[A-Z\s.\'-]*?):\s+',
        re.IGNORECASE
    )

    # Line number pattern (1-25 at start of line, common in court transcripts)
    _LINE_NUM_RE = re.compile(r'^\s{0,4}\d{1,2}\s{2,}')

    # Page header/footer patterns
    _PAGE_HEADER_RE = re.compile(
        r'^\s*(?:Page \d+|^\d+$|\f|PROCEEDINGS|DIRECT EXAMINATION|CROSS.EXAMINATION|'
        r'REDIRECT EXAMINATION|RECROSS.EXAMINATION|EXAMINATION BY)',
        re.IGNORECASE
    )

    def _split_midline(line):
        """Split a line that contains mid-line Q/A or speaker changes.

        "...end of answer. Q. Next question?" → ["...end of answer.", "Q. Next question?"]
        """
        parts = []

        # Try mid-line Q/A split first
        splits = list(_MIDLINE_QA_RE.finditer(line))
        if not splits:
            # Try mid-line speaker split
            splits = list(_MIDLINE_SPEAKER_RE.finditer(line))

        if not splits:
            return [line]

        prev_end = 0
        for m in splits:
            before = line[prev_end:m.start()].strip()
            if before:
                parts.append(before)
            prev_end = m.start() + 1  # Keep the space before Q/A/speaker
            # The rest starting from the Q/A/speaker label
        remainder = line[prev_end:].strip()
        if remainder:
            # Re-attach the matched label
            parts.append(line[splits[-1].start():].strip())
        elif not parts:
            parts.append(line)

        return parts if parts else [line]

    # Word paragraph style → Notare style mapping
    _WORD_STYLE_MAP = {
        # Common court reporter Word styles
        "colloquy": "colloquy", "ccColloquy": "colloquy", "Colloquy": "colloquy",
        "qa": "qa", "ccQandA": "qa", "Q&A": "qa", "QandA": "qa",
        "question": "qa", "answer": "qa",
        "parenthetical": "parenthetical", "ccParenthetical": "parenthetical",
        "Paren": "parenthetical", "Stage Direction": "parenthetical",
        "speaker": "speaker_id", "Speaker ID": "speaker_id",
        "Attorney Name": "speaker_id", "ccSpeaker": "speaker_id",
        "exam header": "exam_header", "Examination": "exam_header",
        "Direct Examination": "exam_header", "Cross Examination": "exam_header",
        "Redirect Examination": "exam_header", "Recross Examination": "exam_header",
        "Normal": None,  # Skip — use content detection
    }

    def _parse_docx_with_styles(content_bytes):
        """Parse a .docx reading both text AND paragraph styles.

        Returns list of dicts: {"text": ..., "word_style": ..., "is_bold": ...}
        """
        from docx import Document as DocxDoc
        doc = DocxDoc(_io.BytesIO(content_bytes))
        paragraphs = []
        for p in doc.paragraphs:
            text = p.text.strip()
            if not text:
                continue
            style_name = p.style.name if p.style else ""
            is_bold = any(run.bold for run in p.runs if run.bold is not None) if p.runs else False
            paragraphs.append({
                "text": text,
                "word_style": style_name,
                "is_bold": is_bold,
            })
        return paragraphs

    def _parse_lines_to_segments(text_lines, word_styles=None):
        """Enhanced line parser with mid-line splitting, Q/A detection, and style awareness.

        Args:
            text_lines: List of text strings
            word_styles: Optional list of dicts with "word_style" per line (from .docx)
        """
        segments = []
        current_speaker = ""
        current_text = []
        current_style = None
        current_qa_role = None

        def flush():
            nonlocal current_text, current_style, current_qa_role
            if current_text:
                text = " ".join(current_text).strip()
                if text:
                    seg = {
                        "text": text,
                        "speaker": current_speaker,
                        "start": len(segments) * 1000,
                        "end": (len(segments) + 1) * 1000,
                        "confidence": 1.0,
                    }
                    # Apply style if detected
                    if current_style:
                        seg["style"] = current_style
                    if current_qa_role:
                        seg["qa_role"] = current_qa_role
                        seg["style"] = "qa"
                    # Parenthetical detection
                    if text.startswith("(") and text.endswith(")"):
                        seg["style"] = "parenthetical"
                    segments.append(seg)
                current_text = []
                current_style = None
                current_qa_role = None

        # Skip the transcript's preamble/caption (title page text before
        # proceedings actually start). Body begins at either "(Proceedings
        # convened at …)" or the first speaker designation. Everything before
        # that (Case No., APPEARANCES, I N D E X, court headers, etc.) isn't
        # dialog — it's metadata that Notare either already stores separately
        # or decorates via the caption block on export. Keeping it out of
        # segments gives Elizabeth's workflow a clean body-only transcript.
        body_started = False  # UNIQUE-MARKER-1776809714
        _body_start_patterns = (
            re.compile(r'^\s*\(?\s*Proceedings\s+(?:convened|began|commenced)', re.IGNORECASE),
            re.compile(r'^\s*\(?\s*(?:THE\s+CLERK|THE\s+COURT|THE\s+BAILIFF)\b', re.IGNORECASE),
        )
        logger.info("Import Q&A: preamble-skip engaged (body_started=False; %d input lines)", len(text_lines))

        for idx, raw_line in enumerate(text_lines):
            line = raw_line.strip() if isinstance(raw_line, str) else raw_line
            if not line:
                continue

            # Get Word style for this line if available
            line_word_style = None
            if word_styles and idx < len(word_styles):
                ws = word_styles[idx].get("word_style", "")
                line_word_style = _WORD_STYLE_MAP.get(ws)

            # Strip line numbers
            line = _LINE_NUM_RE.sub('', line).strip()
            if not line:
                continue

            # Preamble skip — wait for the first real body marker before we
            # start collecting content.
            if not body_started:
                starts_with_speaker = _SPEAKER_RE.match(line) is not None
                matches_body = any(p.match(line) for p in _body_start_patterns)
                if starts_with_speaker or matches_body:
                    body_started = True
                    # fall through so the speaker/proceedings line is processed below
                else:
                    continue

            # Skip page headers/footers
            if _PAGE_HEADER_RE.match(line):
                exam_match = re.match(r'^\s*((?:DIRECT|CROSS|REDIRECT|RECROSS)\s+EXAMINATION.*)', line, re.IGNORECASE)
                if exam_match:
                    flush()
                    current_speaker = ""
                    current_style = "parenthetical"
                    current_text = [f"({exam_match.group(1).strip()})"]
                    flush()
                continue

            # Split mid-line Q/A and speaker changes
            sub_lines = _split_midline(line)

            for sub in sub_lines:
                sub = sub.strip()
                if not sub:
                    continue

                # Check for speaker label
                speaker_match = _SPEAKER_RE.match(sub)
                if speaker_match:
                    flush()
                    current_speaker = speaker_match.group(1).strip()
                    current_style = line_word_style or "colloquy"
                    remaining = speaker_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Check for Q/A
                qa_match = _QA_RE.match(sub)
                if qa_match:
                    flush()
                    qa_letter = qa_match.group(1).upper()
                    current_speaker = qa_letter
                    current_qa_role = qa_letter
                    current_style = "qa"
                    remaining = qa_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Check for "BY MR. SMITH:" introducing examination
                by_match = re.match(r'^BY\s+((?:MR\.|MS\.|MRS\.|DR\.)\s+[A-Z\s.\'-]+?):\s*(.*)', sub, re.IGNORECASE)
                if by_match:
                    flush()
                    current_speaker = f"BY {by_match.group(1).strip()}"
                    current_style = "exam_header"
                    remaining = by_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Apply Word style if detected and no speaker change
                if line_word_style and not current_style:
                    current_style = line_word_style

                # Continuation of current speaker
                current_text.append(sub)

        flush()

        # Post-parse: assign styles to segments that don't have one
        # Use the style detection from app.py's _auto_detect_styles for consistency
        for seg in segments:
            if not seg.get("style"):
                # Quick heuristic — will be refined by _auto_detect_styles later
                speaker = seg.get("speaker", "").upper()
                if speaker in ("Q", "A"):
                    seg["style"] = "qa"
                    seg["qa_role"] = speaker

        return segments

    async def _patched_import_transcript(job_id: str, file: UploadFile = File(...),
                                          run_proofing: bool = Form(True)):
        """Enhanced transcript import with better Q/A splitting."""
        job = _app.JOBS.get(job_id)
        if not job:
            return _JSONResponse({"error": "Job not found"}, status_code=404)

        content = await file.read()
        ext = _Path(file.filename).suffix.lower()
        job_dir = _Path(job["dir"])

        # Save original
        imports_dir = job_dir / "imports"
        imports_dir.mkdir(exist_ok=True)
        (imports_dir / file.filename).write_bytes(content)

        # Parse text
        text_lines = []
        word_styles = None

        if ext == ".txt":
            text_lines = content.decode("utf-8", errors="replace").split("\n")

        elif ext in (".docx", ".doc"):
            try:
                word_data = _parse_docx_with_styles(content)
                text_lines = [p["text"] for p in word_data]
                word_styles = word_data  # Pass to parser for style-aware segmentation
            except Exception as e:
                return _JSONResponse({"error": f"Could not read .docx: {e}"}, status_code=400)

        elif ext == ".pdf":
            try:
                import pdfplumber
                with pdfplumber.open(_io.BytesIO(content)) as pdf:
                    for page in pdf.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text_lines.extend(page_text.split("\n"))
            except Exception as e:
                return _JSONResponse({"error": f"Could not read .pdf: {e}"}, status_code=400)
        else:
            return _JSONResponse({"error": f"Unsupported format: {ext}. Use .docx, .txt, or .pdf"}, status_code=400)

        if not text_lines:
            return _JSONResponse({"error": "No text found in the uploaded file"}, status_code=400)

        # Parse with enhanced splitter (style-aware for .docx)
        segments = _parse_lines_to_segments(text_lines, word_styles=word_styles)

        if not segments:
            return _JSONResponse({"error": "Could not parse any segments from the file"}, status_code=400)

        # Store as transcript
        job["transcript"] = {"segments": segments}
        job["status"] = "complete"
        try:
            _app._feed_word_live_on_complete(job)
        except Exception:
            pass
        job["progress"] = 100
        job["imported_from"] = file.filename

        # Run proofing
        if run_proofing:
            try:
                _app._auto_detect_styles(job)
                _app._apply_proofing_rules(job)
            except Exception as e:
                logger.warning("Proofing on imported transcript failed: %s", e)

        # Save
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            _json.dump(job["transcript"], f, indent=2)
        _app._save_job(job)

        logger.info("Import (enhanced): %s -> %d segments (proofing=%s)",
                    file.filename, len(segments), run_proofing)
        return _JSONResponse({
            "ok": True,
            "segments": len(segments),
            "imported_from": file.filename,
            "proofing_applied": run_proofing,
        })

    # Patch the route
    for route in _app.app.routes:
        if hasattr(route, "path") and route.path == "/api/job/{job_id}/import-transcript":
            route.endpoint = _patched_import_transcript
            logger.info("Import Q&A: Patched /api/job/{job_id}/import-transcript with enhanced parser")
            break
    else:
        logger.warning("Import Q&A: Could not find import-transcript route to patch")


print("Plugin loaded: import_qa_fix.py — enhanced Q&A import parsing active")
