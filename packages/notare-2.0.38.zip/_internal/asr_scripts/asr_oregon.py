"""
ASR_Primary_Notare.py
Notare WS1 — ASR Transcription (Oregon)

Notare contract:
    PROFILE_NAME  — displayed in the workspace picker
    process(input_path, output_path, show_timestamps=True)
        input_path   : string path to uploaded audio file (.mp3/.wav/.m4a)
        output_path  : string path where the finished .docx should be written
        show_timestamps : bool — if True, prepend [HH:MM:SS] to each utterance
        returns output_path on success, raises on failure

Notare calls process() after saving the upload to a temp path.
This script never deals with uploads, browsers, or HTTP.
"""

import time
import os
import re
import json as _json
import urllib.request
import urllib.error
from pathlib import Path
from docx import Document

PROFILE_NAME = "ASR — Oregon"

BASE_URL = "https://api.assemblyai.com"


# ─────────────────────────────────────────────
# HTTP SHIM — stdlib-only so we work inside the frozen Notare exe without
# depending on the third-party `requests` package being bundled.
# ─────────────────────────────────────────────
class _Resp:
    """Minimal shim mimicking the subset of requests.Response used below."""
    def __init__(self, status, body_bytes):
        self.status_code = status
        self._body = body_bytes
    def json(self):
        return _json.loads(self._body.decode("utf-8"))
    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}: {self._body[:500]!r}")


def _http_post(url, headers=None, data=None, json_body=None, timeout=60):
    headers = dict(headers or {})
    if json_body is not None:
        body = _json.dumps(json_body).encode("utf-8")
        headers.setdefault("content-type", "application/json")
    else:
        body = data
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _Resp(resp.status, resp.read())
    except urllib.error.HTTPError as e:
        return _Resp(e.code, e.read() if e.fp else b"")


def _http_get(url, headers=None, timeout=60):
    req = urllib.request.Request(url, headers=dict(headers or {}), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _Resp(resp.status, resp.read())
    except urllib.error.HTTPError as e:
        return _Resp(e.code, e.read() if e.fp else b"")

# ─────────────────────────────────────────────
# LEGAL PROMPT
# ─────────────────────────────────────────────
LEGAL_PROMPT = """Context: Oregon circuit court legal proceeding. \
Modified full verbatim transcription — include false starts, repetitions, \
incomplete sentences, and corrections. Do not remove filler words. \
Preserve exact spoken words.

Spelling: \
'Multnomah' not 'multnomah', \
'Clackamas' not 'clackamas', \
'ORS' not 'ors', \
'ORCP' not 'orcp', \
'Miranda' not 'miranda', \
'Defense' not 'defense', \
'Defendant' not 'defendant', \
'appellant' not 'Appellant', \
'appellee' not 'Appellee', \
'amicus' not 'Amicus', \
'voir dire' not 'Voir Dire', \
'motion in limine' not 'Motion In Limine'.

Multiple speakers are present. Label each speaker consistently throughout."""


# ─────────────────────────────────────────────
# CLERK LOG PARSING
# ─────────────────────────────────────────────
from html.parser import HTMLParser

NAME_SUFFIXES = {'jr', 'sr', 'ii', 'iii', 'iv', 'esq'}

def clean_name(name):
    name = re.sub(r'\s*OSB[#:\s]+[\d]+', '', name)
    name = re.sub(r'\s*\([\d]+\)', '', name)
    name = re.sub(r'\s+\d+$', '', name)
    name = re.sub(r'\s+(Plea|Sent|Trial|Hearing|Further|Arraignment).*$', '', name, flags=re.IGNORECASE)
    return name.strip(' .;,')

def last_name(full_name):
    parts = full_name.strip().split()
    while parts and parts[-1].lower().rstrip('.') in NAME_SUFFIXES:
        parts.pop()
    return parts[-1] if parts else full_name

def to_label(name):
    ln = last_name(clean_name(name)).upper()
    return f"MR. {ln}"

def parse_htm_log(filepath, case_keywords=None):
    class LogParser(HTMLParser):
        def __init__(self):
            super().__init__()
            self.rows = []
            self._in_td = False
            self._current_row = []
            self._current_cell = []

        def handle_starttag(self, tag, attrs):
            if tag == 'tr':
                self._current_row = []
            elif tag == 'td':
                self._in_td = True
                self._current_cell = []

        def handle_endtag(self, tag):
            if tag == 'td':
                self._in_td = False
                self._current_row.append(''.join(self._current_cell).strip())
            elif tag == 'tr':
                if len(self._current_row) == 3:
                    self.rows.append(tuple(self._current_row))

        def handle_data(self, data):
            if self._in_td:
                self._current_cell.append(data)

        def handle_entityref(self, name):
            if self._in_td and name == 'nbsp':
                self._current_cell.append(' ')

    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    parser = LogParser()
    parser.feed(content)
    rows = parser.rows

    prosecutors = []
    defense = []

    for time_val, speaker, note in rows:
        if speaker.lower().rstrip(':') != 'called':
            continue
        if case_keywords and not any(kw.lower() in note.lower() for kw in case_keywords):
            continue

        da_match = re.search(
            r'District Attorney:\s*(.+?)(?=\s*Defense Attorney|$)',
            note, re.IGNORECASE
        )
        def_match = re.search(
            r'Defense Attorney:\s*(.+?)(?=\s*;?\s*Defendant|\s*Attorney for|$)',
            note, re.IGNORECASE
        )

        if da_match:
            for name in da_match.group(1).split(','):
                name = clean_name(name)
                if name:
                    prosecutors.append(name)

        if def_match:
            for name in def_match.group(1).split(','):
                name = clean_name(name)
                if name:
                    defense.append(name)

        if prosecutors or defense:
            return {'prosecutors': prosecutors, 'defense': defense, 'method': 'called_entry'}

    SKIP = {
        'judge', 'called', 'called:', 'recess', 'recess:', 'return', 'return:',
        'lunch', 'end', 'break', 'clerk', 'bailiff', 'interpreter', 'witness',
        'jury', 'sidebar', 'resume', 'resumed', 'reconvene', 'reconvened', '', ' '
    }

    PROCEDURAL_KEYWORDS = {
        'docket', 'assignment', 'assignments', 'conference', 'case', 'parte',
        'motion', 'hearing', 'trial', 'arraignment', 'sentencing', 'plea',
        'pretrial', 'pre-trial', 'calendar', 'call', 'session', 'proceeding',
        'order', 'judgment', 'verdict', 'status', 'scheduling', 'chambers',
        'audio', 'cleanup', 'intro', 'recess', 'lunch', 'break', 'end',
    }

    def looks_like_name(raw):
        s = raw.strip().rstrip(':').lower()
        if not s or s in SKIP:
            return False
        words = re.split(r'[\s/]+', s)
        if any(w in PROCEDURAL_KEYWORDS for w in words):
            return False
        return True

    case_start_idx = None
    case_end_idx = len(rows)
    for idx, (time_val, speaker, note) in enumerate(rows):
        if case_keywords and any(kw.lower() in note.lower() for kw in case_keywords):
            if speaker.lower().rstrip(':') == 'called':
                case_start_idx = idx
                break

    if case_start_idx is not None:
        for idx in range(case_start_idx + 1, len(rows)):
            time_val, speaker, note = rows[idx]
            if speaker.lower().rstrip(':') == 'called':
                if not case_keywords or not any(kw.lower() in note.lower() for kw in case_keywords):
                    case_end_idx = idx
                    break
        scan_rows = rows[case_start_idx:case_end_idx]
    else:
        scan_rows = rows

    seen = set()
    speakers = []
    for time_val, speaker, note in scan_rows:
        if not looks_like_name(speaker):
            continue
        s = speaker.strip().rstrip(':').lower()
        if s not in seen:
            seen.add(s)
            speakers.append(speaker.strip().rstrip(':'))

    if speakers:
        return {'speakers': speakers, 'method': 'speaker_scan'}

    return {'method': 'none'}


def find_clerk_log(documentation_folder, audio_filename):
    date_match = re.match(r'(\d{4})[._](\d{2})[._](\d{2})', os.path.basename(audio_filename))
    if not date_match:
        return None
    yyyy, mm, dd = date_match.groups()
    log_name = f"{yyyy}.{mm}.{dd}.htm"
    log_path = os.path.join(documentation_folder, log_name)
    return log_path if os.path.exists(log_path) else None


def build_speakers_from_log(log_result, case_name_parts):
    speakers = [
        {"name": "THE COURT",
         "description": "Judge presiding. Rules on objections, addresses parties, controls the courtroom."}
    ]
    summary_lines = ["  THE COURT (Judge)"]

    if log_result['method'] == 'called_entry':
        for name in log_result['prosecutors']:
            label = to_label(name)
            speakers.append({
                "name": label,
                "description": "Prosecutor. Asks questions on direct, objects, makes argument."
            })
            summary_lines.append(f"  {label} (Prosecutor — from '{name}')")

        for name in log_result['defense']:
            label = to_label(name)
            speakers.append({
                "name": label,
                "description": "Defense counsel. Asks questions on cross, objects, makes argument."
            })
            summary_lines.append(f"  {label} (Defense — from '{name}')")

    elif log_result['method'] == 'speaker_scan':
        for name in log_result['speakers']:
            label = to_label(name)
            speakers.append({
                "name": label,
                "description": f"Attorney or participant identified as {name} in clerk's log."
            })
            summary_lines.append(f"  {label} (from speaker log)")

    speakers.extend([
        {"name": "THE WITNESS",
         "description": "Witness currently testifying under oath. Answers questions from attorneys."},
        {"name": "THE DEFENDANT",
         "description": "Defendant speaking in colloquy, not under oath as a witness."},
        {"name": "THE CLERK",
         "description": "Court clerk. Administers oaths and manages exhibits."},
        {"name": "UNIDENTIFIED",
         "description": "Any speaker whose role cannot be determined from context."},
    ])
    summary_lines.extend([
        "  THE WITNESS",
        "  THE DEFENDANT",
        "  THE CLERK",
        "  UNIDENTIFIED"
    ])

    TRIM_ORDER = ["UNIDENTIFIED", "THE DEFENDANT", "THE CLERK"]
    for trim_name in TRIM_ORDER:
        if len(speakers) <= 10:
            break
        speakers = [s for s in speakers if s["name"] != trim_name]
        summary_lines = [l for l in summary_lines if trim_name not in l]
    if len(speakers) > 10:
        speakers = speakers[:10]
        summary_lines = summary_lines[:10]

    return speakers, summary_lines


def build_speakers_from_defaults(num_prosecutors, num_defense, has_interpreter):
    speakers = [
        {"name": "THE COURT",
         "description": "Judge presiding. Rules on objections, addresses parties, controls the courtroom."}
    ]

    for i in range(1, num_prosecutors + 1):
        label = "PROSECUTOR" if num_prosecutors == 1 else f"PROSECUTOR {i}"
        speakers.append({"name": label,
                         "description": "Prosecutor. Asks questions on direct, objects, makes argument."})

    for i in range(1, num_defense + 1):
        label = "DEFENSE" if num_defense == 1 else f"DEFENSE {i}"
        speakers.append({"name": label,
                         "description": "Defense counsel. Asks questions on cross, objects, makes argument."})

    speakers.extend([
        {"name": "THE WITNESS",
         "description": "Witness under oath. Answers questions from attorneys."},
        {"name": "THE DEFENDANT",
         "description": "Defendant speaking in colloquy, not under oath as a witness."},
        {"name": "THE CLERK",
         "description": "Court clerk. Administers oaths and manages exhibits."},
    ])

    if has_interpreter:
        speakers.append({"name": "THE INTERPRETER",
                         "description": "Interpreter translating for a party or witness."})

    speakers.append({"name": "UNIDENTIFIED",
                     "description": "Any speaker whose role cannot be determined from context."})

    return speakers


# ─────────────────────────────────────────────
# ASSEMBLYAI HELPERS
# ─────────────────────────────────────────────
def upload_file(filepath, api_key):
    # AssemblyAI accepts raw bytes on the upload endpoint. We stream via
    # Request.data — for a very large audio file this loads it into memory
    # (Notare callers should have already validated size before invoking).
    with open(filepath, "rb") as f:
        body = f.read()
    response = _http_post(
        f"{BASE_URL}/v2/upload",
        headers={"authorization": api_key},
        data=body,
        timeout=600,  # allow up to 10 min for a large upload
    )
    response.raise_for_status()
    return response.json()["upload_url"]


def submit_transcription(audio_url, speakers_list, api_key):
    data = {
        "audio_url": audio_url,
        "speech_models": ["universal-3-pro", "universal-2"],
        "speaker_labels": True,
        "language_code": "en",
        "language_detection": False,
        "prompt": LEGAL_PROMPT,
        "speech_understanding": {
            "request": {
                "speaker_identification": {
                    "speaker_type": "name",
                    "speakers": speakers_list
                }
            }
        }
    }
    response = _http_post(
        f"{BASE_URL}/v2/transcript",
        headers={"authorization": api_key},
        json_body=data,
        timeout=60,
    )
    response.raise_for_status()
    return response.json()["id"]


def poll_transcript(transcript_id, api_key, timeout_minutes=30, progress_cb=None):
    """Poll AssemblyAI every 5s until the job is done or we time out.

    progress_cb: optional callable invoked on every poll with the current
                 AssemblyAI status dict. Notare uses this to surface progress
                 to the browser.
    """
    headers = {"authorization": api_key}
    url = f"{BASE_URL}/v2/transcript/{transcript_id}"
    max_attempts = (timeout_minutes * 60) // 5
    for attempt in range(max_attempts):
        resp = _http_get(url, headers=headers, timeout=30)
        if resp.status_code != 200:
            time.sleep(5)
            continue
        result = resp.json()
        status = result.get("status")
        if progress_cb:
            try:
                progress_cb(result)
            except Exception:
                pass
        if status == "completed":
            return result
        elif status == "error":
            raise RuntimeError(f"Transcription error: {result.get('error')}")
        else:
            time.sleep(5)
    raise RuntimeError(f"Transcription timed out after {timeout_minutes} minutes (job {transcript_id})")


def get_speaker_labels(transcript_result):
    try:
        identified = (
            transcript_result
            .get("speech_understanding", {})
            .get("results", {})
            .get("speaker_identification", {})
            .get("utterances", [])
        )
        return {utt["start"]: utt["speaker"] for utt in identified}
    except Exception:
        return {}


# ─────────────────────────────────────────────
# WHISPER ENGINE — local transcription + pyannote diarization.
#
# Runs via subprocess in Notare's _cpu_env / _gpu_env (installed by the
# smart installer alongside the exe). We generate a self-contained Python
# script, run it in the venv, and parse its JSON output. The venv has
# faster-whisper, pyannote-audio, and torch installed.
#
# Return shape matches AssemblyAI's: a result dict with `utterances` each
# containing `start` (ms), `end` (ms), `speaker` (str), `text` (str). The
# rest of the pipeline (get_speaker_labels, save_transcript_to_word) works
# unchanged because it reads from the same shape.
#
# Limitation: Whisper+pyannote produces generic labels (SPEAKER_00 etc.) —
# real names come later via the WS2 ASR Cleanup workspace.
# ─────────────────────────────────────────────
def _discover_venv_python(base_dir):
    """Find the bundled Python env the smart installer dropped."""
    base = Path(base_dir)
    candidates = [
        base / "_gpu_env" / "Scripts" / "python.exe",
        base / "_cpu_env" / "Scripts" / "python.exe",
        base / "_pyannote_env" / "Scripts" / "python.exe",  # legacy
    ]
    # Prefer GPU if present
    for p in candidates:
        if p.exists():
            return p
    return None


_WHISPER_RUNNER_SRC = r"""
import sys, json, os, traceback
from pathlib import Path

def run(audio_path, output_json, pyannote_models_dir, model_size):
    try:
        from faster_whisper import WhisperModel
    except Exception as e:
        json.dump({'error': 'faster-whisper not installed in env: ' + str(e)}, open(output_json,'w'))
        return

    # Transcribe
    compute_type = 'int8' if os.environ.get('NOTARE_FORCE_CPU') else 'auto'
    try:
        model = WhisperModel(model_size, compute_type=compute_type)
    except Exception as e:
        json.dump({'error': f'Could not load Whisper model {model_size}: {e}'}, open(output_json,'w'))
        return

    print('DIAG: transcribing...', flush=True)
    segments_iter, info = model.transcribe(audio_path, word_timestamps=False, vad_filter=True)
    whisper_segments = []
    for seg in segments_iter:
        whisper_segments.append({
            'start_ms': int(seg.start * 1000),
            'end_ms':   int(seg.end * 1000),
            'text':     seg.text.strip(),
        })
    print(f'DIAG: {len(whisper_segments)} segments transcribed', flush=True)

    # Diarize via pyannote if models are available
    speaker_turns = []
    try:
        import torch
        from pyannote.audio import Pipeline
        cfg = Path(pyannote_models_dir) / 'config.yaml'
        if cfg.exists():
            pipe = Pipeline.from_pretrained(str(cfg))
            if torch.cuda.is_available():
                try:
                    pipe.to(torch.device('cuda'))
                except Exception:
                    pass
            diarization = pipe(audio_path)
            for turn, _, spk in diarization.itertracks(yield_label=True):
                speaker_turns.append({
                    'start_ms': int(turn.start * 1000),
                    'end_ms':   int(turn.end * 1000),
                    'speaker':  str(spk),
                })
            print(f'DIAG: {len(speaker_turns)} speaker turns', flush=True)
        else:
            print('DIAG: no pyannote config.yaml — skipping diarization', flush=True)
    except Exception as e:
        print(f'DIAG: diarization failed: {e}', flush=True)
        traceback.print_exc()
        speaker_turns = []

    # Align: for each whisper segment, pick the pyannote speaker with the
    # most overlap. If no speaker turns exist, label everything '00'.
    # Note: save_transcript_to_word re-prefixes with 'SPEAKER_' so we strip
    # the pyannote 'SPEAKER_' prefix here to avoid 'SPEAKER_SPEAKER_00'.
    def _strip_prefix(s):
        return s[len('SPEAKER_'):] if s.startswith('SPEAKER_') else s

    utterances = []
    for seg in whisper_segments:
        best_speaker = '00'
        if speaker_turns:
            best_overlap = 0
            seg_start, seg_end = seg['start_ms'], seg['end_ms']
            for turn in speaker_turns:
                overlap = max(0, min(seg_end, turn['end_ms']) - max(seg_start, turn['start_ms']))
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_speaker = _strip_prefix(turn['speaker'])
        utterances.append({
            'start':   seg['start_ms'],
            'end':     seg['end_ms'],
            'speaker': best_speaker,
            'text':    seg['text'],
        })

    json.dump({
        'ok': True,
        'utterances': utterances,
        'language': info.language if info else 'en',
        'audio_duration': info.duration if info else 0,
    }, open(output_json, 'w'))
    print('DIAG: done', flush=True)


if __name__ == '__main__':
    audio_path   = sys.argv[1]
    output_json  = sys.argv[2]
    models_dir   = sys.argv[3]
    model_size   = sys.argv[4] if len(sys.argv) > 4 else 'small.en'
    try:
        run(audio_path, output_json, models_dir, model_size)
    except Exception as e:
        traceback.print_exc()
        json.dump({'error': f'Whisper runner crashed: {e}'}, open(output_json, 'w'))
"""


def _transcribe_with_whisper(audio_path, base_dir, pyannote_models_dir,
                             model_size="small.en", progress_cb=None, timeout_minutes=60):
    """Runs Whisper + pyannote in the bundled venv. Returns a dict shaped
    like AssemblyAI's transcript response (has 'utterances' list).

    Raises RuntimeError if the venv isn't available or the subprocess fails.
    """
    import subprocess
    import tempfile

    def _emit(stage, **info):
        if progress_cb:
            try: progress_cb(stage, info)
            except Exception: pass

    _emit("loading_model", engine="whisper", model=model_size)

    venv_python = _discover_venv_python(base_dir)
    if not venv_python:
        raise RuntimeError(
            "Whisper engine requires the CPU or GPU pack to be installed. "
            "Run the Notare installer and choose a tier, or use the AssemblyAI engine instead."
        )

    # Write the runner to a temp file
    tmp_dir = tempfile.mkdtemp(prefix="notare_whisper_")
    runner_path = os.path.join(tmp_dir, "runner.py")
    output_json = os.path.join(tmp_dir, "out.json")
    try:
        with open(runner_path, "w", encoding="utf-8") as f:
            f.write(_WHISPER_RUNNER_SRC)

        _emit("transcribing", engine="whisper")
        cmd = [str(venv_python), runner_path, audio_path, output_json,
               str(pyannote_models_dir), model_size]
        # Stream stderr/stdout to capture DIAG lines for progress updates
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1)
        elapsed = 0
        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            if line.startswith("DIAG: "):
                msg = line[6:]
                if "transcribing" in msg:
                    _emit("transcribing", engine="whisper", detail="Whisper is processing audio")
                elif "transcribed" in msg:
                    _emit("transcribing", engine="whisper", detail=msg)
                elif "speaker turns" in msg:
                    _emit("diarizing", engine="whisper", detail=msg)
                elif "done" in msg:
                    _emit("aligning", engine="whisper")
            # Safety: kill if runaway
            elapsed += 1
            if elapsed > timeout_minutes * 60 * 2:  # rough upper bound
                proc.kill()
                raise RuntimeError(f"Whisper subprocess exceeded {timeout_minutes} minutes.")
        rc = proc.wait()
        if rc != 0:
            raise RuntimeError(f"Whisper subprocess exited with code {rc}.")

        if not os.path.exists(output_json):
            raise RuntimeError("Whisper subprocess produced no output JSON.")

        with open(output_json, "r", encoding="utf-8") as f:
            result = _json.load(f)
        if result.get("error"):
            raise RuntimeError(result["error"])

        return result
    finally:
        # Cleanup temp dir
        try:
            import shutil as _sh
            _sh.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


def ms_to_timestamp(ms):
    """Convert milliseconds to [HH:MM:SS] format."""
    total_seconds = ms // 1000
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f"[{hours:02d}:{minutes:02d}:{seconds:02d}]"


def save_transcript_to_word(transcript_result, speaker_label_map, output_path, show_timestamps=True):
    doc = Document()
    utterances = transcript_result.get("utterances", [])
    for utt in utterances:
        identified_name = speaker_label_map.get(utt["start"])
        label = identified_name.upper() if identified_name else f"SPEAKER_{utt['speaker']}"
        if show_timestamps:
            timestamp = ms_to_timestamp(utt["start"])
            line = f"{timestamp} {label}:  {utt['text']}"
        else:
            line = f"{label}:  {utt['text']}"
        doc.add_paragraph(line)
    doc.save(output_path)


# ─────────────────────────────────────────────
# NOTARE CONTRACT — this is what Notare calls
# ─────────────────────────────────────────────
def process(input_path, output_path, api_key="", show_timestamps=True,
            num_prosecutors=1, num_defense=1, has_interpreter=False,
            clerk_log_path=None, timeout_minutes=30, progress_cb=None,
            engine="assemblyai", whisper_model="small.en",
            base_dir=None, pyannote_models_dir=None):
    """
    Notare calls this function after saving the uploaded audio to a temp path.

    input_path       : string path to the uploaded audio file (.mp3/.wav/.m4a)
    output_path      : string path where the finished .docx should be written
    api_key          : user's AssemblyAI API key (required if engine='assemblyai')
    show_timestamps  : bool — prepend [HH:MM:SS] to each utterance if True
    num_prosecutors  : int — # of prosecutors (from case-setup form)
    num_defense      : int — # of defense attorneys (from case-setup form)
    has_interpreter  : bool — whether an interpreter is present
    clerk_log_path   : optional string path to a Multnomah-style .htm clerk log
    timeout_minutes  : how long to wait for transcription before giving up
    progress_cb      : optional callable(stage: str, info: dict)
    engine           : 'assemblyai' (default) or 'whisper'
    whisper_model    : faster-whisper model size (small.en, base.en, etc.)
    base_dir         : Notare install root (for locating _cpu_env/_gpu_env)
    pyannote_models_dir : path to _pyannote_models/ (for diarization)

    Returns output_path on success. Raises on failure.
    """

    def _emit(stage, **info):
        if progress_cb:
            try: progress_cb(stage, info)
            except Exception: pass

    # Build speakers list — for AssemblyAI this is sent to the API; for
    # Whisper it's informational only (Whisper+pyannote produces generic
    # SPEAKER_00 labels that WS2 Cleanup fills in later).
    case_name_parts = re.findall(r'\b([A-Z][a-z]+)\b', os.path.basename(input_path))
    log_path = clerk_log_path
    if not log_path:
        log_path = find_clerk_log(os.path.dirname(input_path), input_path)

    if log_path and os.path.exists(log_path):
        log_result = parse_htm_log(log_path, case_name_parts)
        if log_result['method'] != 'none':
            speakers, _ = build_speakers_from_log(log_result, case_name_parts)
            _emit("speakers_built", source="clerk_log", count=len(speakers))
        else:
            speakers = build_speakers_from_defaults(num_prosecutors, num_defense, has_interpreter)
            _emit("speakers_built", source="defaults_after_log_miss", count=len(speakers))
    else:
        speakers = build_speakers_from_defaults(num_prosecutors, num_defense, has_interpreter)
        _emit("speakers_built", source="defaults", count=len(speakers))

    # ─── Route to the chosen engine ────────────────────────────────────
    if engine == "whisper":
        if not base_dir or not pyannote_models_dir:
            raise RuntimeError(
                "Whisper engine requires base_dir and pyannote_models_dir. "
                "Notare's plugin supplies these; if you're calling process() "
                "directly, pass them explicitly."
            )
        result = _transcribe_with_whisper(
            input_path, base_dir, pyannote_models_dir,
            model_size=whisper_model,
            progress_cb=progress_cb,
            timeout_minutes=timeout_minutes,
        )
        # Whisper returns a result with 'utterances' list but no
        # speech_understanding section. get_speaker_labels() returns {} in
        # that case, and save_transcript_to_word falls back to raw speaker
        # field on each utterance (SPEAKER_00 etc.) — which is what we want.
        _emit("writing", engine="whisper", utterances=len(result.get("utterances", [])))
        speaker_label_map = get_speaker_labels(result)  # returns {}
        save_transcript_to_word(result, speaker_label_map, output_path, show_timestamps)
        return output_path

    # Default: AssemblyAI
    if not api_key:
        raise RuntimeError(
            "AssemblyAI engine requires an API key in Notare Settings. "
            "Add one (free signup gives 185 hours) or switch to the Whisper engine."
        )

    _emit("uploading", size_bytes=os.path.getsize(input_path))
    audio_url = upload_file(input_path, api_key)

    _emit("submitted", speakers=len(speakers))
    transcript_id = submit_transcription(audio_url, speakers, api_key)

    def _poll_cb(result):
        _emit("transcribing",
              status=result.get("status"),
              audio_duration=result.get("audio_duration"),
              percent=result.get("progress"))
    result = poll_transcript(transcript_id, api_key,
                             timeout_minutes=timeout_minutes,
                             progress_cb=_poll_cb)

    speaker_label_map = get_speaker_labels(result)
    _emit("writing", engine="assemblyai", utterances=len(result.get("utterances", [])))
    save_transcript_to_word(result, speaker_label_map, output_path, show_timestamps)

    return output_path
