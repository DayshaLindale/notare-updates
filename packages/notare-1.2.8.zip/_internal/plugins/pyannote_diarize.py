"""Pyannote diarization plugin — monkey-patches the diarization function
to use the on-demand _pyannote_env via subprocess.

This overrides the frozen exe's built-in _diarize_with_pyannote to handle
the subprocess path correctly with resolved model paths.
"""
import sys
import os
import json
import logging
import subprocess
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

# BASE_DIR is injected by the plugin loader namespace
# but we also need it from the app module for consistency
if 'BASE_DIR' not in dir():
    BASE_DIR = _app.BASE_DIR

logger = logging.getLogger("notare")

# ═══════════════════════════════════════════════════════════
# Discover pyannote Python env — manifest-based (smart installer)
# Priority: gpu_env > cpu_env > legacy _pyannote_env
# ═══════════════════════════════════════════════════════════
_pyannote_python = None
_manifest_path = BASE_DIR / "install_manifest.json"
if _manifest_path.exists():
    try:
        import json as _json_mod
        _manifest = _json_mod.loads(_manifest_path.read_text(encoding="utf-8"))
        _tiers = _manifest.get("installed_tiers", [])
        if "gpu" in _tiers:
            _candidate = BASE_DIR / "_gpu_env" / "Scripts" / "python.exe"
            if _candidate.exists():
                _pyannote_python = _candidate
                logger.info("Pyannote env: using installer GPU env (%s)", _candidate)
        if not _pyannote_python and "cpu" in _tiers:
            _candidate = BASE_DIR / "_cpu_env" / "Scripts" / "python.exe"
            if _candidate.exists():
                _pyannote_python = _candidate
                logger.info("Pyannote env: using installer CPU env (%s)", _candidate)
    except Exception as _e:
        logger.debug("Failed to read install manifest: %s", _e)

# Fallback to legacy on-demand env
if not _pyannote_python:
    _legacy = BASE_DIR / "_pyannote_env" / "Scripts" / "python.exe"
    if _legacy.exists() and not (BASE_DIR / "_pyannote_env" / ".downloading").exists():
        _pyannote_python = _legacy
        logger.info("Pyannote env: using legacy on-demand env (%s)", _legacy)

if _pyannote_python:
    # Fix relocatable venv — pyvenv.cfg may reference the build machine's Python.
    # Patch it to point to the venv's own python.exe so it works on any machine.
    _venv_root = _pyannote_python.parent.parent  # _cpu_env or _gpu_env
    _pyvenv_cfg = _venv_root / "pyvenv.cfg"
    if _pyvenv_cfg.exists():
        try:
            _cfg_text = _pyvenv_cfg.read_text(encoding="utf-8")
            _needs_patch = False
            _new_lines = []
            for _line in _cfg_text.splitlines():
                if _line.startswith("home = "):
                    _old_home = _line.split("=", 1)[1].strip()
                    _new_home = str(_pyannote_python.parent)
                    if _old_home != _new_home and not Path(_old_home).exists():
                        _line = f"home = {_new_home}"
                        _needs_patch = True
                _new_lines.append(_line)
            if _needs_patch:
                _pyvenv_cfg.write_text("\n".join(_new_lines) + "\n", encoding="utf-8")
                logger.info("Patched pyvenv.cfg: home -> %s", _new_home)
        except Exception as _pe:
            logger.debug("Could not patch pyvenv.cfg: %s", _pe)
    logger.info("Pyannote subprocess ready: %s", _pyannote_python)
else:
    logger.info("Pyannote subprocess not available — ONNX fallback will be used")


def _diarize_with_pyannote_patched(job):
    """Replacement diarization function that uses subprocess pyannote env."""
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return False

    segments = transcript["segments"]

    # Skip if segments already have real speaker labels
    real_labels = sum(1 for s in segments if s.get("speaker", "").strip()
                      and not s["speaker"].startswith("Speaker "))
    if real_labels > len(segments) * 0.5:
        return False

    # Find audio file
    audio_file = job.get("audio_file", "")
    job_dir = Path(job.get("dir", ""))
    audio_path = None
    if audio_file:
        candidate = job_dir / "audio" / audio_file
        if candidate.exists():
            audio_path = candidate
    if not audio_path:
        audio_dir = job_dir / "audio"
        if audio_dir.exists():
            wavs = list(audio_dir.glob("*.wav"))
            if wavs:
                audio_path = wavs[0]
    if not audio_path:
        return False

    # Check for pyannote env (module-level _pyannote_python set by manifest discovery above)
    if not _pyannote_python:
        # No env available — try native import as last resort
        try:
            from pyannote.audio import Pipeline
        except ImportError:
            return False

    # Find model directory — check pipeline/ subdirectory FIRST (root config has broken relative paths)
    model_dir = None
    for model_root in [BASE_DIR / "_internal" / "_pyannote_models", BASE_DIR / "_pyannote_models"]:
        for sub in [model_root / "pipeline", model_root]:
            if (sub / "config.yaml").exists():
                model_dir = str(sub)
                break
        if model_dir:
            break

    hf_token = _app.SETTINGS.get("hf_token", "") or os.environ.get("HF_TOKEN", "")

    # Speaker hints
    known_speakers = job.get("speakers", [])
    min_speakers = len(known_speakers) if known_speakers and len(known_speakers) >= 2 else 2
    max_speakers = max(min_speakers + 4, 10)

    # Build subprocess script with resolved paths
    # Uses soundfile for audio loading (bypasses torchcodec/FFmpeg dependency)
    # Uses result.speaker_diarization.itertracks() for pyannote v4 output
    script = f'''
import warnings, os, sys
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"

# Wrap EVERYTHING in try/except so errors always produce JSON, never raw text
import json
try:
    import tempfile
    import torch
    import soundfile as sf
    import numpy as np
    from pathlib import Path
except ImportError as ie:
    print(json.dumps({{"error": f"Missing package: {{ie}}"}}))
    sys.exit(1)
except Exception as e:
    print(json.dumps({{"error": f"Import failed: {{e}}"}}))
    sys.exit(1)

try:
    model_dir = {repr(model_dir)}
    hf_token = {repr(hf_token)}
    audio_path = {repr(str(audio_path))}

    # Load audio with soundfile (no torchcodec/FFmpeg needed)
    data, sr = sf.read(audio_path)
    if data.ndim == 1:
        data = data[None, :]
    else:
        data = data.T
    waveform = torch.from_numpy(data.astype(np.float32))

    # Resolve relative paths in config.yaml to absolute
    if model_dir:
        config_path = Path(model_dir) / "config.yaml"
        if config_path.exists():
            text = config_path.read_text()
            parent = str(Path(model_dir).parent).replace(chr(92), "/")
            if "../" in text:
                text = text.replace("../embedding", parent + "/embedding")
                text = text.replace("../segmentation", parent + "/segmentation")
                tmp_dir = Path(tempfile.mkdtemp(prefix="pyannote_"))
                (tmp_dir / "config.yaml").write_text(text)
                model_dir = str(tmp_dir)

    from pyannote.audio import Pipeline

    pipeline = None
    if model_dir:
        try:
            pipeline = Pipeline.from_pretrained(model_dir)
        except Exception:
            pass
    if pipeline is None and hf_token:
        pipeline = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", token=hf_token)
    if pipeline is None:
        print(json.dumps({{"error": "no model"}}))
        sys.exit(1)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pipeline.to(device)

    result = pipeline({{"waveform": waveform, "sample_rate": sr}}, min_speakers={min_speakers}, max_speakers={max_speakers})

    # pyannote v4 returns DiarizeOutput, v3 returns Annotation directly
    if hasattr(result, "speaker_diarization"):
        annotation = result.speaker_diarization
    else:
        annotation = result

    turns = []
    for turn, _, speaker in annotation.itertracks(yield_label=True):
        turns.append([round(turn.start * 1000), round(turn.end * 1000), speaker])
    print(json.dumps({{"turns": turns}}))
except Exception as e:
    print(json.dumps({{"error": f"Diarization failed: {{e}}"}}))
    sys.exit(1)
'''

    try:
        _python_exe = _pyannote_python  # Module-level, set by manifest discovery
        logger.info("Running pyannote via subprocess (%s)...", _python_exe)
        job["progress_message"] = "Analyzing speakers (pyannote)..."
        _app._save_job(job)

        # Write script to temp file to avoid Windows quoting issues with -c
        import tempfile as _tmpmod
        _script_file = Path(_tmpmod.mkdtemp(prefix="notare_")) / "run_pyannote.py"
        _script_file.write_text(script, encoding="utf-8")
        logger.info("Pyannote script written to %s", _script_file)

        result = subprocess.run(
            [str(_python_exe), str(_script_file)],
            capture_output=True, text=True, timeout=120,  # 2 min max — falls back to ONNX if slow
        )

        if result.returncode != 0:
            err_detail = result.stderr[-500:] if result.stderr else "no stderr"
            logger.warning("Pyannote subprocess failed (rc=%d): %s", result.returncode, err_detail)
            job["progress_message"] = f"Speaker reanalysis failed: {err_detail[-200:]}"
            _app._save_job(job)
            return False

        # Parse JSON from stdout — skip warning lines
        stdout = result.stdout.strip()
        json_start = stdout.rfind('{"')
        if json_start < 0:
            # No JSON — log what we DID get for debugging
            stdout_preview = stdout[-300:] if stdout else "empty"
            stderr_preview = result.stderr[-300:] if result.stderr else "empty"
            logger.warning("Pyannote subprocess produced no JSON. stdout=%s stderr=%s",
                          stdout_preview, stderr_preview)
            job["progress_message"] = f"Speaker reanalysis failed: no output from analysis engine. stderr={stderr_preview[:150]}"
            _app._save_job(job)
            return False

        try:
            data = json.loads(stdout[json_start:])
        except json.JSONDecodeError as je:
            logger.warning("Pyannote subprocess produced invalid JSON at pos %d: %s. Raw: %s",
                          json_start, je, stdout[json_start:json_start+200])
            job["progress_message"] = f"Speaker reanalysis failed: invalid response from analysis engine"
            _app._save_job(job)
            return False

        if "error" in data:
            logger.warning("Pyannote subprocess error: %s", data["error"])
            return False

        turns = data["turns"]
        if not turns:
            logger.info("Pyannote produced no speaker turns")
            return False

        logger.info("Pyannote found %d turns across %d speakers",
                    len(turns), len(set(t[2] for t in turns)))

        # Align turns with segments via majority overlap
        for seg in segments:
            seg_start = seg.get("start", 0)
            seg_end = seg.get("end", seg_start)
            speaker_overlap = {}
            for t_start, t_end, t_speaker in turns:
                overlap = max(0, min(seg_end, t_end) - max(seg_start, t_start))
                if overlap > 0:
                    speaker_overlap[t_speaker] = speaker_overlap.get(t_speaker, 0) + overlap
            if speaker_overlap:
                seg["speaker"] = max(speaker_overlap, key=speaker_overlap.get)

        transcript["diarization"] = "pyannote-3.1"
        unique = len(set(s.get("speaker", "") for s in segments if s.get("speaker")))
        logger.info("Pyannote complete: %d speakers across %d segments", unique, len(segments))
        return True

    except Exception as e:
        logger.warning("Pyannote subprocess failed: %s", e)
        return False


# Monkey-patch the module-level function
_app._diarize_with_pyannote = _diarize_with_pyannote_patched
# Also patch in the module's global namespace so other code calling it finds the patched version
import types
if hasattr(_app, '_diarize_with_pyannote'):
    _app._diarize_with_pyannote = _diarize_with_pyannote_patched
print("Plugin loaded: pyannote_diarize.py — subprocess diarization active")
