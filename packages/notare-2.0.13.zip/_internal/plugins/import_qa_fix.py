"""Import Q&A Fix — Better segment splitting for imported transcripts.

Patches the import parser to handle:
  1. Q./A. format (with period): "Q.  Did you see the defendant?"
  2. Q:/A: format (with colon): "Q:  Did you see the defendant?"
  3. Q/A with just spaces: "Q   Did you see the defendant?"
  4. Mid-line Q/A: "...end of answer. Q. Next question?" → split into two segments
  5. Colloquy labels mid-paragraph: "...text THE COURT: ruling text"

Also improves:
  - Line number stripping for imported court transcripts
  - Page header/footer removal
  - Empty line handling
"""
import re
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

_original_import = getattr(_app, "import_completed_transcript", None)

if _original_import:
    from fastapi import UploadFile, File, Form
    from fastapi.responses import JSONResponse as _JSONResponse
    from pathlib import Path as _Path
    import json as _json
    import io as _io

    # Speaker label pattern — explicit structure, no IGNORECASE. Court transcripts
    # use ALL CAPS for labels; case-insensitive matching caused false positives on
    # prose like "the Plaintiff" that chewed through to the next colon and created
    # garbage speaker names. Multi-word last names ("VAN DER HEIDE", "SMITH-JONES")
    # handled by the repeating (?:\s+[A-Z][A-Z'-]+)+ tail.
    _SPEAKER_BODY = (
        r"(?:BY\s+)?(?:MR|MS|MRS|DR)\.(?:\s+[A-Z]\.?)*(?:\s+[A-Z][A-Z'\-]+)+"
        r"|THE\s+(?:COURT|WITNESS|REPORTER|CLERK|BAILIFF|DEFENDANT|PLAINTIFF|INTERPRETER)"
        r"|PROSECUTOR|DEFENSE"
    )
    _SPEAKER_RE = re.compile(r'^(' + _SPEAKER_BODY + r'):\s*(.*)')

    # Q&A patterns — broader than the original
    _QA_RE = re.compile(r'^\s*([QA])\s*[.:]\s{0,4}(.*)')

    # Any-position finder — used to split paragraphs that have multiple speaker
    # turns mashed into a single line (common in imported .docx files where the
    # source already collapsed the dialog). No lookbehind requirement; \b handles
    # word boundaries. Compiled at module level so the split logic can reuse it.
    _ANY_SPEAKER_RE = re.compile(r'\b(' + _SPEAKER_BODY + r'):\s*')

    # Kept for backward-compat reference (unused now that _split_midline is
    # rewritten); left so any external code importing these names doesn't break.
    _MIDLINE_QA_RE = re.compile(r'(?<=[.?!])\s+([QA])\s*[.:]\s{1,4}(?=[A-Z])')
    _MIDLINE_SPEAKER_RE = _ANY_SPEAKER_RE

    # Line number pattern (1-25 at start of line, common in court transcripts)
    _LINE_NUM_RE = re.compile(r'^\s{0,4}\d{1,2}\s{2,}')

    # Page header/footer patterns
    _PAGE_HEADER_RE = re.compile(
        r'^\s*(?:Page \d+|^\d+$|\f|PROCEEDINGS|DIRECT EXAMINATION|CROSS.EXAMINATION|'
        r'REDIRECT EXAMINATION|RECROSS.EXAMINATION|EXAMINATION BY)',
        re.IGNORECASE
    )

    def _split_midline(line):
        """Split a line that contains multiple speaker turns into one-turn chunks.

        "MS. DOLAN: hello. THE COURT: okay. MR. ESTOK: thanks"
          → ["MS. DOLAN: hello.", "THE COURT: okay.", "MR. ESTOK: thanks"]

        Unlike the older version this does NOT require sentence-ending punctuation
        before each speaker label — real transcripts have plenty of "-- THE COURT:"
        and mid-word interjections. _ANY_SPEAKER_RE with \b word boundaries is
        precise enough on its own.

        Any text BEFORE the first speaker label is treated as a separate chunk so
        the caller can attribute it to the previous speaker (continuation).
        """
        matches = list(_ANY_SPEAKER_RE.finditer(line))
        if not matches:
            # Also try Q/A split if no speaker labels. Q/A only makes sense anchored
            # at start of line (the old mid-line Q/A regex produced more false
            # positives than true splits); leave continuation intact here.
            return [line]

        parts = []
        first = matches[0]
        if first.start() > 0:
            pre = line[:first.start()].strip()
            if pre:
                parts.append(pre)

        for i, m in enumerate(matches):
            end = matches[i + 1].start() if i + 1 < len(matches) else len(line)
            chunk = line[m.start():end].strip()
            if chunk:
                parts.append(chunk)

        return parts if parts else [line]

    # Word paragraph style → Notare style mapping
    _WORD_STYLE_MAP = {
        # Common court reporter Word styles
        "colloquy": "colloquy", "ccColloquy": "colloquy", "Colloquy": "colloquy",
        "qa": "qa", "ccQandA": "qa", "Q&A": "qa", "QandA": "qa",
        "question": "qa", "answer": "qa",
        "parenthetical": "parenthetical", "ccParenthetical": "parenthetical",
        "Paren": "parenthetical", "Stage Direction": "parenthetical",
        "speaker": "speaker_id", "Speaker ID": "speaker_id",
        "Attorney Name": "speaker_id", "ccSpeaker": "speaker_id",
        "exam header": "exam_header", "Examination": "exam_header",
        "Direct Examination": "exam_header", "Cross Examination": "exam_header",
        "Redirect Examination": "exam_header", "Recross Examination": "exam_header",
        "Normal": None,  # Skip — use content detection
    }

    def _parse_docx_with_styles(content_bytes):
        """Parse a .docx reading both text AND paragraph styles.

        Returns list of dicts: {"text": ..., "word_style": ..., "is_bold": ...}
        """
        from docx import Document as DocxDoc
        doc = DocxDoc(_io.BytesIO(content_bytes))
        paragraphs = []
        for p in doc.paragraphs:
            text = p.text.strip()
            if not text:
                continue
            style_name = p.style.name if p.style else ""
            is_bold = any(run.bold for run in p.runs if run.bold is not None) if p.runs else False
            paragraphs.append({
                "text": text,
                "word_style": style_name,
                "is_bold": is_bold,
            })
        return paragraphs

    def _parse_lines_to_segments(text_lines, word_styles=None):
        """Enhanced line parser with mid-line splitting, Q/A detection, and style awareness.

        Args:
            text_lines: List of text strings
            word_styles: Optional list of dicts with "word_style" per line (from .docx)
        """
        segments = []
        current_speaker = ""
        current_text = []
        current_style = None
        current_qa_role = None

        def flush():
            nonlocal current_text, current_style, current_qa_role
            if current_text:
                text = " ".join(current_text).strip()
                if text:
                    seg = {
                        "text": text,
                        "speaker": current_speaker,
                        "start": len(segments) * 1000,
                        "end": (len(segments) + 1) * 1000,
                        "confidence": 1.0,
                    }
                    # Apply style if detected
                    if current_style:
                        seg["style"] = current_style
                    if current_qa_role:
                        seg["qa_role"] = current_qa_role
                        seg["style"] = "qa"
                    # Parenthetical detection
                    if text.startswith("(") and text.endswith(")"):
                        seg["style"] = "parenthetical"
                    segments.append(seg)
                current_text = []
                current_style = None
                current_qa_role = None

        # Skip the transcript's preamble/caption (title page text before
        # proceedings actually start). Body begins at either "(Proceedings
        # convened at …)" or the first speaker designation. Everything before
        # that (Case No., APPEARANCES, I N D E X, court headers, etc.) isn't
        # dialog — it's metadata that Notare either already stores separately
        # or decorates via the caption block on export. Keeping it out of
        # segments gives Elizabeth's workflow a clean body-only transcript.
        body_started = False  # UNIQUE-MARKER-1776809714
        _body_start_patterns = (
            re.compile(r'^\s*\(?\s*Proceedings\s+(?:convened|began|commenced)', re.IGNORECASE),
            re.compile(r'^\s*\(?\s*(?:THE\s+CLERK|THE\s+COURT|THE\s+BAILIFF)\b', re.IGNORECASE),
        )
        logger.info("Import Q&A: preamble-skip engaged (body_started=False; %d input lines)", len(text_lines))

        for idx, raw_line in enumerate(text_lines):
            line = raw_line.strip() if isinstance(raw_line, str) else raw_line
            if not line:
                continue

            # Get Word style for this line if available
            line_word_style = None
            if word_styles and idx < len(word_styles):
                ws = word_styles[idx].get("word_style", "")
                line_word_style = _WORD_STYLE_MAP.get(ws)

            # Strip line numbers
            line = _LINE_NUM_RE.sub('', line).strip()
            if not line:
                continue

            # Preamble skip — wait for the first real body marker before we
            # start collecting content. Source .docx files sometimes collapse
            # the entire preamble AND the first few body turns into one giant
            # paragraph (case caption → APPEARANCES → INDEX → "(Proceedings
            # convened...)" → THE CLERK → THE COURT, all in one run-on line).
            # If that's the shape of the input, slice the line at the first
            # body marker found inside it rather than discarding the whole thing.
            if not body_started:
                starts_with_speaker = _SPEAKER_RE.match(line) is not None
                matches_body = any(p.match(line) for p in _body_start_patterns)
                if starts_with_speaker or matches_body:
                    body_started = True
                else:
                    # Scan for an embedded body marker anywhere in the line.
                    cut = None
                    m_spk = _ANY_SPEAKER_RE.search(line)
                    if m_spk:
                        cut = m_spk.start()
                    m_proc = re.search(
                        r'\(?\s*Proceedings\s+(?:convened|began|commenced)',
                        line, re.IGNORECASE,
                    )
                    if m_proc:
                        cut = m_proc.start() if cut is None else min(cut, m_proc.start())
                    if cut is None:
                        continue
                    line = line[cut:].strip()
                    body_started = True

            # Skip page headers/footers
            if _PAGE_HEADER_RE.match(line):
                exam_match = re.match(r'^\s*((?:DIRECT|CROSS|REDIRECT|RECROSS)\s+EXAMINATION.*)', line, re.IGNORECASE)
                if exam_match:
                    flush()
                    current_speaker = ""
                    current_style = "parenthetical"
                    current_text = [f"({exam_match.group(1).strip()})"]
                    flush()
                continue

            # Split mid-line Q/A and speaker changes
            sub_lines = _split_midline(line)

            for sub in sub_lines:
                sub = sub.strip()
                if not sub:
                    continue

                # Check for speaker label
                speaker_match = _SPEAKER_RE.match(sub)
                if speaker_match:
                    flush()
                    current_speaker = speaker_match.group(1).strip()
                    current_style = line_word_style or "colloquy"
                    remaining = speaker_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Check for Q/A
                qa_match = _QA_RE.match(sub)
                if qa_match:
                    flush()
                    qa_letter = qa_match.group(1).upper()
                    current_speaker = qa_letter
                    current_qa_role = qa_letter
                    current_style = "qa"
                    remaining = qa_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Check for "BY MR. SMITH:" introducing examination
                by_match = re.match(r'^BY\s+((?:MR\.|MS\.|MRS\.|DR\.)\s+[A-Z\s.\'-]+?):\s*(.*)', sub, re.IGNORECASE)
                if by_match:
                    flush()
                    current_speaker = f"BY {by_match.group(1).strip()}"
                    current_style = "exam_header"
                    remaining = by_match.group(2).strip()
                    if remaining:
                        current_text.append(remaining)
                    continue

                # Apply Word style if detected and no speaker change
                if line_word_style and not current_style:
                    current_style = line_word_style

                # Continuation of current speaker
                current_text.append(sub)

        flush()

        # Post-parse: assign styles to segments that don't have one
        # Use the style detection from app.py's _auto_detect_styles for consistency
        for seg in segments:
            if not seg.get("style"):
                # Quick heuristic — will be refined by _auto_detect_styles later
                speaker = seg.get("speaker", "").upper()
                if speaker in ("Q", "A"):
                    seg["style"] = "qa"
                    seg["qa_role"] = speaker

        return segments

    async def _patched_import_transcript(job_id: str, file: UploadFile = File(...),
                                          run_proofing: bool = Form(True)):
        """Enhanced transcript import with better Q/A splitting."""
        job = _app.JOBS.get(job_id)
        if not job:
            return _JSONResponse({"error": "Job not found"}, status_code=404)

        content = await file.read()
        ext = _Path(file.filename).suffix.lower()
        job_dir = _Path(job["dir"])

        # Save original
        imports_dir = job_dir / "imports"
        imports_dir.mkdir(exist_ok=True)
        (imports_dir / file.filename).write_bytes(content)

        # Parse text
        text_lines = []
        word_styles = None

        if ext == ".txt":
            text_lines = content.decode("utf-8", errors="replace").split("\n")

        elif ext in (".docx", ".doc"):
            try:
                word_data = _parse_docx_with_styles(content)
                text_lines = [p["text"] for p in word_data]
                word_styles = word_data  # Pass to parser for style-aware segmentation
            except Exception as e:
                return _JSONResponse({"error": f"Could not read .docx: {e}"}, status_code=400)

        elif ext == ".pdf":
            try:
                import pdfplumber
                with pdfplumber.open(_io.BytesIO(content)) as pdf:
                    for page in pdf.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text_lines.extend(page_text.split("\n"))
            except Exception as e:
                return _JSONResponse({"error": f"Could not read .pdf: {e}"}, status_code=400)
        else:
            return _JSONResponse({"error": f"Unsupported format: {ext}. Use .docx, .txt, or .pdf"}, status_code=400)

        if not text_lines:
            return _JSONResponse({"error": "No text found in the uploaded file"}, status_code=400)

        # Parse with enhanced splitter (style-aware for .docx)
        segments = _parse_lines_to_segments(text_lines, word_styles=word_styles)

        if not segments:
            return _JSONResponse({"error": "Could not parse any segments from the file"}, status_code=400)

        # Store as transcript
        job["transcript"] = {"segments": segments}
        job["status"] = "complete"
        try:
            _app._feed_word_live_on_complete(job)
        except Exception:
            pass
        job["progress"] = 100
        job["imported_from"] = file.filename

        # Run proofing
        if run_proofing:
            try:
                _app._auto_detect_styles(job)
                _app._apply_proofing_rules(job)
            except Exception as e:
                logger.warning("Proofing on imported transcript failed: %s", e)

        # Save
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            _json.dump(job["transcript"], f, indent=2)
        _app._save_job(job)

        logger.info("Import (enhanced): %s -> %d segments (proofing=%s)",
                    file.filename, len(segments), run_proofing)
        return _JSONResponse({
            "ok": True,
            "segments": len(segments),
            "imported_from": file.filename,
            "proofing_applied": run_proofing,
        })

    # Patch the route
    for route in _app.app.routes:
        if hasattr(route, "path") and route.path == "/api/job/{job_id}/import-transcript":
            route.endpoint = _patched_import_transcript
            logger.info("Import Q&A: Patched /api/job/{job_id}/import-transcript with enhanced parser")
            break
    else:
        logger.warning("Import Q&A: Could not find import-transcript route to patch")


print("Plugin loaded: import_qa_fix.py — enhanced Q&A import parsing active")
