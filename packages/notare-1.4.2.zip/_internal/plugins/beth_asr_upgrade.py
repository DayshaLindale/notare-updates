"""Beth's ASR Upgrade — Speaker identification + legal formatting enhancements.

Adds two capabilities that ship in Beth's standalone Oregon ASR scripts:

1. AssemblyAI speech_understanding API with role-based speaker identification
   and the universal-3-pro model. This sends structured speaker roles with
   descriptions to AssemblyAI, producing dramatically cleaner speaker labels.

2. Enhanced legal formatting rules in the proofing pass:
   - Em dash to double-dash (legal standard)
   - Two spaces after periods/question marks (legal standard)
   - Abbreviation exceptions (Mr. Mrs. Dr. Ms. get single space)
   - "the Court" / "the State" / "Defense" / "Defendant" / "Judge" capitalization
   - Filler word removal (um, ah, standalone uh) preserving uh-huh/mm-hmm

Loads after assemblyai_shim.py and engine_failover.py (alphabetical: 'b').
Monkey-patches _transcribe_single_aai and _apply_proofing_rules.
"""
import re
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")


# ─────────────────────────────────────────────
# PART 1: Patch AssemblyAI transcription to use speech_understanding
# ─────────────────────────────────────────────

_original_transcribe_single_aai = getattr(_app, "_transcribe_single_aai", None)

if _original_transcribe_single_aai:

    def _build_speaker_roles(job):
        """Convert Notare's job speakers into AssemblyAI speech_understanding format.

        Notare speakers look like:
            {"name": "The Court (Judge Smith)", "representing": "", ...}
            {"name": "Jane Doe", "representing": "Plaintiff/State", ...}
            {"name": "John Smith", "representing": "Defense", ...}

        We convert these into AssemblyAI's speaker_identification format with
        descriptive role hints.
        """
        speakers = job.get("speakers", [])
        if not speakers:
            return None

        role_list = []
        has_judge = False

        for spk in speakers:
            name = spk.get("name", "").strip()
            rep = spk.get("representing", "").strip().lower()

            if not name:
                continue

            # Detect role from name or representing field
            name_lower = name.lower()

            if "court" in name_lower or "judge" in name_lower or "hon." in name_lower:
                role_list.append({
                    "name": "THE COURT",
                    "description": "Judge presiding. Rules on objections, addresses parties, controls the courtroom."
                })
                has_judge = True

            elif rep in ("plaintiff/state", "plaintiff", "state", "prosecution", "prosecutor"):
                # Use actual name for the label
                display = name.upper()
                if len(speakers) > 4:
                    # Multiple attorneys — use name to distinguish
                    role_list.append({
                        "name": display,
                        "description": "Prosecutor or plaintiff's counsel. Asks questions on direct, objects, makes argument."
                    })
                else:
                    role_list.append({
                        "name": "PROSECUTOR",
                        "description": f"Prosecutor or plaintiff's counsel ({name}). Asks questions on direct, objects, makes argument."
                    })

            elif rep in ("defense", "defendant", "appellant"):
                display = name.upper()
                if len(speakers) > 4:
                    role_list.append({
                        "name": display,
                        "description": "Defense counsel. Asks questions on cross, objects, makes argument."
                    })
                else:
                    role_list.append({
                        "name": "DEFENSE",
                        "description": f"Defense counsel ({name}). Asks questions on cross, objects, makes argument."
                    })

            elif "witness" in name_lower:
                role_list.append({
                    "name": name.upper(),
                    "description": "Witness under oath. Answers questions from attorneys."
                })

            elif "clerk" in name_lower:
                role_list.append({
                    "name": "THE CLERK",
                    "description": "Court clerk. Administers oaths and manages exhibits."
                })

            elif "interpreter" in name_lower:
                role_list.append({
                    "name": "THE INTERPRETER",
                    "description": "Interpreter translating for a party or witness."
                })

            elif "defendant" in name_lower:
                role_list.append({
                    "name": "THE DEFENDANT",
                    "description": "Defendant speaking in colloquy, not under oath as a witness."
                })

            else:
                # Generic — could be a witness or other participant
                role_list.append({
                    "name": name.upper(),
                    "description": f"Participant in the proceeding: {name}."
                })

        # Always include an unidentified catch-all
        role_list.append({
            "name": "UNIDENTIFIED",
            "description": "Any speaker whose role cannot be determined from context."
        })

        return role_list if role_list else None

    def _patched_transcribe_single_aai(job, audio_path, aai):
        """Enhanced AssemblyAI transcription with speech_understanding speaker ID."""
        from pathlib import Path

        job["progress"] = 15
        job["progress_message"] = "Uploading to AssemblyAI..."

        # Build word boost and custom spelling from profile
        profile = job.get("profile", {})
        word_boost = profile.get("word_boost", [])
        custom_spelling = profile.get("custom_spelling", {})

        # Default legal term boost
        _default_boost = [
            "objection", "sustained", "overruled", "voir dire",
            "motion in limine", "Daubert", "Miranda", "Strickland",
            "appellant", "appellee", "amicus",
            "Multnomah", "Clackamas", "ORS", "ORCP",
        ]
        boost_set = set(w.lower() for w in _default_boost)
        combined_boost = list(_default_boost)
        for w in word_boost:
            if w.lower() not in boost_set:
                combined_boost.append(w)
                boost_set.add(w.lower())

        config_kwargs = {
            "speaker_labels": True,
            "language_code": "en",
            "punctuate": True,
            "format_text": True,
        }
        if combined_boost:
            config_kwargs["word_boost"] = combined_boost
        if custom_spelling:
            config_kwargs["custom_spelling"] = custom_spelling

        # --- Beth's enhancements ---

        # 1. Use universal-3-pro model
        config_kwargs["speech_models"] = ["universal-3-pro", "universal-2"]

        # 2. Add legal context prompt
        legal_prompt = profile.get("asr_prompt", "")
        if not legal_prompt:
            legal_prompt = (
                "Context: Legal court proceeding. "
                "Modified full verbatim transcription — include false starts, repetitions, "
                "incomplete sentences, and corrections. Do not remove filler words. "
                "Preserve exact spoken words. "
                "Spelling: "
                "'ORS' not 'ors', 'ORCP' not 'orcp', "
                "'Daubert' not 'daubert', 'Miranda' not 'miranda', "
                "'Defense' not 'defense', 'Defendant' not 'defendant'. "
                "Multiple speakers are present. Label each speaker consistently throughout."
            )
        config_kwargs["prompt"] = legal_prompt

        # 3. Build speech_understanding speaker identification
        speaker_roles = _build_speaker_roles(job)
        if speaker_roles:
            config_kwargs["speech_understanding"] = {
                "request": {
                    "speaker_identification": {
                        "speaker_type": "name",
                        "speakers": speaker_roles
                    }
                }
            }
            logger.info("Beth ASR: speech_understanding enabled with %d speaker roles", len(speaker_roles))

        config = aai.TranscriptionConfig(**config_kwargs)
        transcriber = aai.Transcriber()

        job["progress"] = 30
        job["progress_message"] = "Transcribing with AssemblyAI (enhanced)..."

        transcript = transcriber.transcribe(str(audio_path), config=config)

        if transcript.status == aai.TranscriptStatus.error:
            raise RuntimeError(f"AssemblyAI error: {transcript.error}")

        job["progress"] = 85
        job["progress_message"] = "Processing results..."

        # Extract speech_understanding speaker labels if available
        speaker_label_map = {}
        raw_data = getattr(transcript, "_raw", None)
        if raw_data and isinstance(raw_data, dict):
            try:
                identified = (
                    raw_data
                    .get("speech_understanding", {})
                    .get("results", {})
                    .get("speaker_identification", {})
                    .get("utterances", [])
                )
                speaker_label_map = {utt["start"]: utt["speaker"] for utt in identified}
                if speaker_label_map:
                    logger.info("Beth ASR: %d speaker identifications from speech_understanding",
                               len(speaker_label_map))
            except Exception as e:
                logger.warning("Beth ASR: Could not parse speech_understanding results: %s", e)

        # Build segments from utterances
        segments = []
        if transcript.utterances:
            for utt in transcript.utterances:
                # Use speech_understanding label if available, fall back to default
                identified_name = speaker_label_map.get(utt.start)
                if identified_name:
                    speaker = identified_name.upper()
                else:
                    speaker = utt.speaker or ""

                seg = {
                    "start": utt.start,
                    "end": utt.end,
                    "text": utt.text.strip(),
                    "speaker": speaker,
                    "confidence": round(utt.confidence, 3) if utt.confidence else 0.0,
                }
                if utt.words:
                    seg["words"] = [
                        {"word": w.text, "start": w.start, "end": w.end,
                         "confidence": round(w.confidence, 3) if w.confidence else 0.0}
                        for w in utt.words
                    ]
                segments.append(seg)
        elif transcript.words:
            current_seg = {"start": 0, "end": 0, "text": "", "speaker": "", "words": []}
            for w in transcript.words:
                current_seg["words"].append(
                    {"word": w.text, "start": w.start, "end": w.end,
                     "confidence": round(w.confidence, 3) if w.confidence else 0.0})
                current_seg["text"] += " " + w.text
                current_seg["end"] = w.end
                if w.text.rstrip().endswith(('.', '!', '?')):
                    current_seg["text"] = current_seg["text"].strip()
                    current_seg["confidence"] = round(
                        sum(wd["confidence"] for wd in current_seg["words"]) / len(current_seg["words"]), 3
                    ) if current_seg["words"] else 0.0
                    segments.append(current_seg)
                    current_seg = {"start": w.end, "end": w.end, "text": "", "speaker": "", "words": []}
            if current_seg["text"].strip():
                current_seg["text"] = current_seg["text"].strip()
                segments.append(current_seg)

        job["transcript"] = {
            "segments": segments,
            "full_text": transcript.text or "",
            "duration": segments[-1]["end"] if segments else 0,
            "engine": "assemblyai",
            "audio_duration": transcript.audio_duration,
        }
        job["audio_file"] = audio_path.name
        job["progress"] = 95
        job["progress_message"] = "Finalizing..."

    # Install the patched function
    _app._transcribe_single_aai = _patched_transcribe_single_aai
    logger.info("Beth ASR: Patched _transcribe_single_aai with speech_understanding + universal-3-pro")


# ─────────────────────────────────────────────
# PART 2: Enhance proofing rules
# ─────────────────────────────────────────────

_original_apply_proofing = getattr(_app, "_apply_proofing_rules", None)

if _original_apply_proofing:

    def _beth_proofing_pass(job):
        """Additional proofing rules from Beth's ASR Edit script.

        Runs AFTER the original proofing rules to add:
        - Em dash → double dash
        - Two spaces after periods/question marks (legal standard)
        - Abbreviation exceptions for double-spacing
        - "the Court" / "the State" / "Defense" / "Defendant" / "Judge"
        - Filler word removal (um, ah, standalone uh)
        """
        if not job.get("transcript"):
            return

        for seg in job["transcript"].get("segments", []):
            text = seg.get("text", "")

            # Em dash → double dash with spaces (legal standard)
            text = re.sub(r'\u2014', '--', text)
            text = re.sub(r'\u2013', '--', text)  # en dash too
            text = re.sub(r'\s*--\s*', ' -- ', text)

            # Filler word removal
            # Preserve: uh-huh, uh-uh, mm-hmm
            # Remove: um, ah, standalone uh
            text = re.sub(r'\b(um|ah)\b,?\s*', '', text, flags=re.IGNORECASE)
            text = re.sub(r'\buh\b(?!-),?\s*', '', text, flags=re.IGNORECASE)

            # Clean up double/triple spaces from removals
            text = re.sub(r'  +', ' ', text)

            # Legal capitalization in body text
            text = re.sub(r'\bthe court\b', 'the Court', text, flags=re.IGNORECASE)
            text = re.sub(r'\bthe state\b', 'the State', text, flags=re.IGNORECASE)
            text = re.sub(r'\bdefense\b', 'Defense', text)
            text = re.sub(r'\bdefendant\b', 'Defendant', text)
            text = re.sub(r'\bjudge\b', 'Judge', text, flags=re.IGNORECASE)

            # Two spaces after periods and question marks (legal standard)
            # First normalize to single space, then apply double
            text = re.sub(r'([.?!])\s+', r'\1 ', text)  # normalize
            text = re.sub(r'([.?]) ', r'\1  ', text)     # double space after . and ?

            # Fix abbreviations — only single space after these
            text = re.sub(r'\bMr\.  ', 'Mr. ', text)
            text = re.sub(r'\bMrs\.  ', 'Mrs. ', text)
            text = re.sub(r'\bMs\.  ', 'Ms. ', text)
            text = re.sub(r'\bDr\.  ', 'Dr. ', text)
            text = re.sub(r'\bSgt\.  ', 'Sgt. ', text)
            text = re.sub(r'\bDet\.  ', 'Det. ', text)
            text = re.sub(r'\bOfc\.  ', 'Ofc. ', text)
            text = re.sub(r'\bNo\.  ', 'No. ', text)
            text = re.sub(r'\bvs\.  ', 'vs. ', text)
            text = re.sub(r'\bv\.  ', 'v. ', text)
            text = re.sub(r'\bEsq\.  ', 'Esq. ', text)
            text = re.sub(r'\bSt\.  ', 'St. ', text)
            text = re.sub(r'\bAve\.  ', 'Ave. ', text)
            text = re.sub(r'\bBlvd\.  ', 'Blvd. ', text)

            # Strip [Speaker:WHATEVER] tags if any leaked through
            text = re.sub(r'\[Speaker:[^\]]*\]', '', text)
            text = re.sub(r'  +', ' ', text)

            seg["text"] = text.strip()

    def _patched_apply_proofing_rules(job):
        """Run original proofing, then Beth's enhancements."""
        _original_apply_proofing(job)
        _beth_proofing_pass(job)

    _app._apply_proofing_rules = _patched_apply_proofing_rules
    logger.info("Beth ASR: Patched _apply_proofing_rules with enhanced legal formatting")


print("Plugin loaded: beth_asr_upgrade.py — speech_understanding + legal formatting active")
