"""Force WebView2 (and any browser) to never cache HTML responses.

Older Notare.exe builds don't have the startup cache-clearing code that lives
in notare.py — they were built before that existed. If those users get an OTA
that updates the dashboard HTML on disk, WebView2 still renders the cached
OLD HTML indefinitely. The only ways out are (a) manually delete
%APPDATA%/pywebview/EBWebView/Default/Cache or (b) never let the response be
cached in the first place.

This plugin takes path (b): it adds middleware that sets
  Cache-Control: no-store, no-cache, must-revalidate
on every .html response and on any static file whose Content-Type is
text/html. Bandwidth impact is tiny (these files are small) and the app is
served from localhost so latency doesn't matter.
"""
import sys
import logging

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

from starlette.middleware.base import BaseHTTPMiddleware


class _NoCacheHTMLMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        try:
            ctype = response.headers.get("content-type", "").lower()
            path = request.url.path.lower()

            # Never-cache headers on HTML + API responses
            if "text/html" in ctype or path.endswith((".html", "/")) or path.startswith("/api/"):
                response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"

            # One-time cache purge via Clear-Site-Data on the next /api/* call.
            # Chromium (WebView2 is Chromium-based) respects this header and wipes
            # its cache for the origin automatically — no user action required.
            # Without this, users whose frozen .exe was built before the cache-
            # clearing startup code stay on old cached HTML indefinitely.
            if path.startswith("/api/"):
                response.headers["Clear-Site-Data"] = '"cache"'
        except Exception:
            pass
        return response


try:
    _app.app.add_middleware(_NoCacheHTMLMiddleware)
    logger.info("no_cache_html: Cache-Control: no-store active on all HTML responses")
except Exception as e:
    logger.warning("no_cache_html: could not attach middleware: %s", e)

print("Plugin loaded: no_cache_html.py — HTML is never cached")
