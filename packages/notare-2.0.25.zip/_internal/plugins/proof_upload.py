"""Proof Upload — Upload a .docx, run proofing, download flagged document.

Bundles the standalone proofing scripts into Notare:
  - proof_depo_direct (DepoDirect — Full Verbatim)
  - proof_legacy_oregon (Legacy Oregon — Modified Full Verbatim)
  - proof_legacy_texas (Legacy Texas/Florida — Clean Verbatim)

Endpoint: POST /api/proof-document
  - Upload a .docx file + select a proofing profile
  - Returns the _PROOFED.docx with Word comments inserted

No job creation, no editor — just upload, process, download.
"""
import sys
import os
import logging
import tempfile
import shutil
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")

import importlib.util

# Proofing profiles loaded only from user-uploaded scripts
_proof_available = {}


# ─────────────────────────────────────────────
# API Endpoints
# ─────────────────────────────────────────────

from fastapi import UploadFile, File, Form
from fastapi.responses import JSONResponse as _JSONResponse, FileResponse

_PROOF_DIR = _app.BASE_DIR / "_internal" / "proof_scripts"
_PROOF_DIR.mkdir(parents=True, exist_ok=True)

# Persistent history: where every proofed run is kept for re-download.
# Lives in the user's app-data folder so OTA updates don't wipe it and so
# uninstall-then-reinstall preserves past work.
_HISTORY_ROOT = Path(os.environ.get("APPDATA", str(_app.BASE_DIR))) / "Notare" / "proof_history"
_HISTORY_ROOT.mkdir(parents=True, exist_ok=True)
_HISTORY_INDEX = _HISTORY_ROOT / "proof_history.json"


def _load_history():
    """Return the list of past proofing runs, newest first."""
    import json as _json
    if not _HISTORY_INDEX.exists():
        return []
    try:
        data = _json.loads(_HISTORY_INDEX.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_history(entries):
    """Persist the list to disk."""
    import json as _json
    try:
        _HISTORY_INDEX.write_text(_json.dumps(entries, indent=2), encoding="utf-8")
    except Exception as e:
        logger.warning("Proof history: could not write index: %s", e)


def _prepare_docx_for_proofing(input_path):
    """Work-around for flat-Normal transcription-service output.

    Elizabeth's scripts key off a "P R O C E E D I N G S" anchor to decide
    where front matter ends and the body begins. Files that come out of
    Legacy Transcription Services arrive with every paragraph styled Normal
    and no such anchor, so her scripts (correctly, for safety) skip every
    Normal paragraph and insert zero comments.

    We do NOT modify her scripts. Instead, before handing the file over, we:
      1. Inspect the doc.
      2. Bail out unchanged if a PROCEEDING anchor is already present OR
         the file already has proper style tagging (Colloquy/Q&A/etc.).
      3. Otherwise, find the first paragraph that looks like the start of
         the transcript body (speaker tag: MR./MS./MRS./DR./THE COURT/
         THE WITNESS/BY MR./BY MS./Q./A.).
      4. Insert a single synthetic "P R O C E E D I N G S" paragraph
         immediately before it.
      5. Save in-place. Her script picks up the anchor, processes Normal
         paragraphs after it, and everything downstream works.

    Returns (changed: bool, info: str) for logging.
    """
    import re as _re
    try:
        from docx import Document
        from docx.oxml.ns import qn
        from copy import deepcopy
    except Exception as e:
        return (False, f"python-docx not available: {e}")

    try:
        doc = Document(input_path)
    except Exception as e:
        return (False, f"could not open docx: {e}")

    paragraphs = doc.paragraphs
    if not paragraphs:
        return (False, "empty document")

    # DepoDirect uses a ^-anchored regex for "PROCEEDING" (spaced or not).
    # If that regex matches ANY paragraph, her script can find its boundary
    # on its own and we leave the doc alone.
    # (Legacy Oregon/Texas look for "(Proceedings convened at" as a substring.
    # That substring can be embedded mid-paragraph in a caption block, so we
    # cannot use it as a "no injection needed" signal — DepoDirect's regex is
    # the only reliable one. Our injected marker satisfies BOTH anchors, so
    # injecting when DepoDirect's regex fails never hurts Legacy scripts.)
    proceeding_re = _re.compile(
        r'^P[\s]*R[\s]*O[\s]*C[\s]*E[\s]*E[\s]*D[\s]*I[\s]*N[\s]*G',
        _re.IGNORECASE,
    )

    styles_seen = set()
    has_top_level_anchor = False
    for p in paragraphs:
        txt = p.text.strip()
        if txt and proceeding_re.match(txt):
            has_top_level_anchor = True
        try:
            styles_seen.add(p.style.name)
        except Exception:
            pass
    if has_top_level_anchor:
        return (False, "PROCEEDING anchor already at paragraph start")

    # If the doc has proper court-reporter style tagging (either vanilla
    # Colloquy/Q&A/Parenthetical/Quoted or her template's cc* variants),
    # assume anchor-by-style and leave it alone.
    target_styles = {"Colloquy", "Q&A", "Parenthetical", "Quoted"}
    cc_prefix = {s for s in styles_seen if s.startswith("cc") and s not in {"ccNormal"}}
    if styles_seen & target_styles:
        return (False, f"doc already has style tagging: {sorted(styles_seen & target_styles)}")
    if cc_prefix:
        return (False, f"doc uses cc* template styles: {sorted(cc_prefix)[:4]}")

    # Flat-Normal case — find the first transcript-body paragraph.
    speaker_re = _re.compile(
        r'^\s*('
        r'MR\.|MS\.|MRS\.|DR\.|'
        r'THE\s+(COURT|WITNESS|CLERK|BAILIFF|REPORTER|DEFENDANT|PLAINTIFF|JUDGE|INTERPRETER)|'
        r'BY\s+(MR|MS|MRS|DR)\.|'
        r'Q\.|A\.'
        r')',
        _re.IGNORECASE,
    )
    body_idx = None
    for i, p in enumerate(paragraphs):
        if speaker_re.match(p.text):
            body_idx = i
            break

    if body_idx is None:
        # No speaker tags at all. Two possibilities:
        #   (a) file has court-reporter front matter but no speakers yet
        #   (b) file is pure body from raw speech-to-text (attorneys talking
        #       about "state of Oregon" and "bar numbers" in normal colloquy)
        # Use a TIGHT regex that only matches unambiguous structural labels
        # (not colloquial content that happens to mention those words). Labels
        # typically appear as paragraph-leading tokens or with a trailing colon.
        frontmatter_re = _re.compile(
            r'(^case\s+no\.?|'
            r'^docket\s+no|'
            r'^imported\s+transcript|'
            r'^date\s*:|^location\s*:|^reported\s+by\s*:|'
            r'^in\s+the\s+(circuit|district|supreme|superior)\s+court\s+of\s+the|'
            r'^appeal\s+case\s+no)',
            _re.IGNORECASE,
        )
        for p in paragraphs[:10]:
            if frontmatter_re.search(p.text.strip()):
                return (False, "front matter detected but no speaker-tag — can't locate body safely")
        body_idx = 0  # All-body file — inject at top.

    # Insert a synthetic PROCEEDINGS marker before the first body paragraph.
    # python-docx doesn't expose insert_paragraph_before on the body cleanly,
    # so we drop down to the underlying <w:body> element and insert a new
    # <w:p> sibling.
    first_body_p = paragraphs[body_idx]._p
    body = first_body_p.getparent()

    # Build a minimal <w:p> with centered text "P R O C E E D I N G S".
    # Copy an existing paragraph's structure so style inheritance stays sane.
    template = paragraphs[body_idx]._p
    new_p = deepcopy(template)
    # Strip all run/hyperlink children; keep pPr if present.
    for child in list(new_p):
        tag = child.tag
        if tag == qn('w:pPr'):
            continue
        new_p.remove(child)
    # Add a centered justification to the pPr (create one if missing).
    pPr = new_p.find(qn('w:pPr'))
    if pPr is None:
        from docx.oxml import OxmlElement
        pPr = OxmlElement('w:pPr')
        new_p.insert(0, pPr)
    # Remove existing jc if any, add our own.
    for jc in pPr.findall(qn('w:jc')):
        pPr.remove(jc)
    from docx.oxml import OxmlElement
    jc = OxmlElement('w:jc')
    jc.set(qn('w:val'), 'center')
    pPr.append(jc)
    # Add a run with the marker text. Satisfies BOTH:
    #   - DepoDirect's ^P\s*R\s*O\s*C\s*E\s*E\s*D\s*I\s*N\s*G regex
    #   - Legacy Oregon/Texas's "(Proceedings convened at" substring check
    r = OxmlElement('w:r')
    t = OxmlElement('w:t')
    t.text = 'P R O C E E D I N G S  (Proceedings convened at _____.)'
    t.set(qn('xml:space'), 'preserve')
    r.append(t)
    new_p.append(r)

    # Insert new_p before first_body_p.
    body.insert(list(body).index(first_body_p), new_p)

    try:
        doc.save(input_path)
    except Exception as e:
        return (False, f"could not save pre-processed doc: {e}")

    return (True, f"inserted synthetic anchor before para {body_idx} (styles seen: {sorted(styles_seen)[:3]})")


def _count_comments_in_docx(path):
    """Count Word comments in a .docx by inspecting the zip. Cheap + accurate —
    doesn't require python-docx to parse comments (python-docx comment support
    is uneven across versions). Each <w:comment> element in comments.xml is
    one comment regardless of runs it spans.

    Returns 0 if the file has no comments section or can't be opened.
    """
    import zipfile as _zf
    import re as _re
    try:
        with _zf.ZipFile(path) as zf:
            if "word/comments.xml" not in zf.namelist():
                return 0
            xml = zf.read("word/comments.xml").decode("utf-8", errors="replace")
        return len(_re.findall(r'<w:comment[ >]', xml))
    except Exception:
        return 0

# Add proof_scripts dir to path so uploaded scripts can find each other
if str(_PROOF_DIR) not in sys.path:
    sys.path.insert(0, str(_PROOF_DIR))


def _reload_proof_profiles():
    """Scan proof_scripts dir for available proofing profiles."""
    _proof_available.clear()
    # Guard sys.exit + input during module import — some uploaded scripts
    # are CLI-pattern and call these at top level on error.
    import sys as _sys, builtins as _bi
    _orig_exit, _orig_input = _sys.exit, _bi.input
    _sys.exit = lambda code=0: None
    _bi.input = lambda prompt="": ""
    for py_file in sorted(_PROOF_DIR.glob("proof_*.py")):
        try:
            mod_name = py_file.stem
            spec = importlib.util.spec_from_file_location(mod_name, str(py_file))
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                key = mod_name.replace("proof_", "")
                label = getattr(mod, "PROFILE_NAME", mod_name)
                _proof_available[key] = {
                    "module": mod,
                    "label": label,
                    "description": f"Proofing profile: {label}",
                    "filename": py_file.name,
                }
        except Exception as e:
            logger.warning("Proof Upload: could not load %s: %s", py_file.name, e)
    # Restore
    _sys.exit = _orig_exit
    _bi.input = _orig_input

_reload_proof_profiles()


@_app.app.get("/api/proof-profiles")
async def list_proof_profiles():
    """List available proofing profiles."""
    profiles = {}
    for key, info in _proof_available.items():
        profiles[key] = {
            "label": info["label"],
            "description": info["description"],
            "filename": info.get("filename", ""),
        }
    return _JSONResponse(profiles)


@_app.app.post("/api/proof-profiles/upload")
async def upload_proof_profile(file: UploadFile = File(...)):
    """Upload a new proofing script (.py)."""
    if not file.filename or not file.filename.lower().endswith(".py"):
        return _JSONResponse({"error": "Please upload a .py proofing script"}, status_code=400)

    content = await file.read()
    # Sanitize filename
    safe_name = file.filename.replace(" ", "_")
    if not safe_name.startswith("proof_"):
        safe_name = "proof_" + safe_name

    dest = _PROOF_DIR / safe_name
    dest.write_bytes(content)
    logger.info("Proof Upload: new script uploaded: %s (%d bytes)", safe_name, len(content))

    # Reload profiles
    _reload_proof_profiles()

    return _JSONResponse({"ok": True, "filename": safe_name, "profiles": len(_proof_available)})


@_app.app.delete("/api/proof-profiles/{profile_key}")
async def delete_proof_profile(profile_key: str):
    """Delete a proofing profile."""
    if profile_key not in _proof_available:
        return _JSONResponse({"error": "Profile not found"}, status_code=404)

    filename = _proof_available[profile_key].get("filename", "")
    if filename:
        target = _PROOF_DIR / filename
        if target.exists():
            target.unlink()
            logger.info("Proof Upload: deleted %s", filename)

    _reload_proof_profiles()
    return _JSONResponse({"ok": True, "remaining": len(_proof_available)})


@_app.app.post("/api/proof-document")
async def proof_document(file: UploadFile = File(...), profile: str = Form("depo_direct")):
    """Upload a .docx, run proofing, return the flagged document.

    Args:
        file: The .docx transcript to proof
        profile: Proofing profile key (depo_direct, legacy_oregon, legacy_texas)

    Returns:
        The proofed .docx file with Word comments
    """
    if not file.filename or not file.filename.lower().endswith(".docx"):
        return _JSONResponse({"error": "Please upload a .docx file"}, status_code=400)

    if profile not in _proof_available:
        available = ", ".join(_proof_available.keys()) if _proof_available else "none loaded"
        return _JSONResponse({
            "error": f"Unknown proofing profile: {profile}. Available: {available}"
        }, status_code=400)

    # Sanitize the filename before using it anywhere on the filesystem.
    # An attacker could send filename="../../../etc/evil.docx" or one with
    # path separators, NUL bytes, shell metacharacters, or 300+ chars that
    # exceed the OS path limit. Even though localhost-only middleware means
    # this only matters for defense-in-depth, a malformed filename shouldn't
    # crash the request with HTTP 500 either — clean, derive, store.
    import re as _re_fn
    raw_name = file.filename
    # 1. Strip any path components — take basename only.
    safe_name = os.path.basename(raw_name.replace("\\", "/"))
    # 2. Replace characters that are illegal in Windows/POSIX filenames or
    #    that shell tokenizers choke on. Leave spaces alone — those are fine
    #    and courtesy to the user (filenames in the wild often have spaces).
    safe_name = _re_fn.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", safe_name)
    # 3. Strip leading dots to kill ".." components.
    safe_name = safe_name.lstrip(".")
    # 4. Enforce .docx suffix (we already checked the incoming filename
    #    ended in .docx, but step 2 could have scrambled the extension).
    if not safe_name.lower().endswith(".docx"):
        safe_name = (safe_name or "upload") + ".docx"
    # 5. Cap length aggressively. Windows MAX_PATH is 260 and we concatenate
    #    this filename into `AppData\Roaming\Notare\proof_history\<ts>_<id>\`
    #    which already consumes ~90 chars. Keep the filename under 120 so
    #    even with the `_PROOFED.docx` suffix we stay well under MAX_PATH.
    if len(safe_name) > 120:
        safe_name = safe_name[:115] + ".docx"
    # Keep both — raw_name (display) is the user's original, preserved for
    # history and UI rendering (where _esc() escapes it). safe_name is used
    # for every filesystem operation. Never cross the streams.
    display_name = raw_name

    # Save uploaded file to temp location
    tmp_dir = tempfile.mkdtemp(prefix="notare_proof_")
    try:
        input_path = os.path.join(tmp_dir, safe_name)
        content = await file.read()
        with open(input_path, "wb") as f:
            f.write(content)

        # Validate it actually is a .docx that python-docx can parse.
        # A .docx is an OOXML zip with specific rels/content-types files. The
        # only cheap way to cover all malformed structures (missing rels,
        # wrong schema, truncated zip, plain text renamed to .docx, XML
        # without wordprocessingml namespace, etc.) is to try to open it.
        # If it fails here, return a clean 400 rather than letting the proof
        # script die mid-run with a cryptic "Package not found" / "no
        # relationship" / etc. 500.
        import zipfile as _zf_check
        try:
            with _zf_check.ZipFile(input_path) as _zcheck:
                if "word/document.xml" not in _zcheck.namelist():
                    return _JSONResponse(
                        {"error": "File is not a valid .docx transcript (missing word/document.xml)."},
                        status_code=400,
                    )
        except _zf_check.BadZipFile:
            return _JSONResponse(
                {"error": "File is not a valid .docx transcript (not a Word document)."},
                status_code=400,
            )
        except Exception as _ve:
            return _JSONResponse(
                {"error": f"Could not read .docx file: {_ve}"},
                status_code=400,
            )
        # Deeper validation — actually open with python-docx. Catches missing
        # package relationships, wrong schemas, and other structural issues
        # that zip-check alone won't detect.
        try:
            from docx import Document as _Doc
            _doc_check = _Doc(input_path)
            # Count paragraphs — warn (but still process) if empty, reject
            # on structural errors above. An empty doc has nothing to fix;
            # return 200 with 0 comments via the normal path? No — reject:
            # a zero-paragraph .docx is a malformed upload, not a valid
            # transcript to proof.
            if not _doc_check.paragraphs:
                return _JSONResponse(
                    {"error": "The .docx has no paragraphs — nothing to proof. Upload a transcript."},
                    status_code=400,
                )
        except Exception as _ve2:
            return _JSONResponse(
                {"error": f"The .docx appears malformed and couldn't be opened: {_ve2}"},
                status_code=400,
            )

        # Pre-process for flat-Normal transcription-service output.
        # Injects a "P R O C E E D I N G S" anchor so Elizabeth's untouched
        # proofing scripts can find their boundary. Safe no-op if the doc
        # already has an anchor or proper style tagging.
        try:
            pre_changed, pre_info = _prepare_docx_for_proofing(input_path)
            if pre_changed:
                logger.info("Proof Upload: pre-processed input — %s", pre_info)
            else:
                logger.info("Proof Upload: pre-processor skipped — %s", pre_info)
        except Exception as _pe:
            logger.warning("Proof Upload: pre-processor failed (continuing anyway): %s", _pe)

        # Run the proofing script. User-uploaded scripts are untrusted — some
        # call sys.exit(1) on error anchors (matches their CLI-run-interactively
        # pattern) which would kill the entire Notare process. Also input() in a
        # frozen exe without a console blocks forever. Patch both during the
        # script's execution and restore in a finally. Also runs in a worker
        # thread so the event loop stays responsive.
        import sys as _sys, builtins as _bi, asyncio as _ai, io as _io
        proof_module = _proof_available[profile]["module"]
        class _ProofScriptAborted(RuntimeError): pass
        _orig_exit = _sys.exit
        _orig_input = _bi.input
        _orig_stdout = _sys.stdout
        _orig_stderr = _sys.stderr
        def _safe_exit(code=0):
            raise _ProofScriptAborted(f"proof script called sys.exit({code})")
        def _safe_input(prompt=""):
            # Non-interactive — don't block the server. Mimic "enter pressed".
            return ""
        # Frozen Notare has no console, and Windows falls back to cp1252 for
        # stdout. Her scripts print smart quotes, em-dashes, ellipses etc.
        # which crash the encoder. Capture to an in-memory UTF-8 buffer with
        # replace-on-error so a misbehaving print can never take down a run.
        _captured_out = _io.StringIO()
        _safe_stream = _io.TextIOWrapper(
            _io.BytesIO(), encoding="utf-8", errors="replace",
            newline="", write_through=True,
        )
        try:
            _sys.exit = _safe_exit
            _bi.input = _safe_input
            _sys.stdout = _captured_out
            _sys.stderr = _captured_out
            await _ai.get_running_loop().run_in_executor(
                None, proof_module.process, input_path
            )
        except _ProofScriptAborted as _pae:
            logger.error("Proof Upload: script aborted cleanly: %s", _pae)
            logger.info("Proof Upload: captured script output:\n%s", _captured_out.getvalue())
            return _JSONResponse(
                {"error": f"Proofing script stopped: {_pae}. "
                          f"Your transcript may be missing an expected anchor "
                          f"(e.g. 'Proceedings convened at')."},
                status_code=400,
            )
        finally:
            _sys.exit = _orig_exit
            _bi.input = _orig_input
            _sys.stdout = _orig_stdout
            _sys.stderr = _orig_stderr
            # Log the script's printed diagnostics (truncated) so we can
            # debug the proof run without spamming or losing info on crash.
            _out = _captured_out.getvalue()
            if _out.strip():
                logger.info("Proof script output (%d chars): %s",
                            len(_out), _out[:800].replace("\n"," | "))

        # Find the output file (_PROOFED.docx)
        base, ext = os.path.splitext(input_path)
        output_path = base + "_PROOFED" + ext

        if not os.path.exists(output_path):
            return _JSONResponse({"error": "Proofing completed but output file not found"}, status_code=500)

        # ─── Persist this run to history ────────────────────────────────────
        # Copy the input AND the proofed output to the permanent history dir,
        # record an index entry. Nothing auto-expires — user manages removal.
        import time as _time, uuid as _uuid, json as _json
        run_id = _uuid.uuid4().hex[:12]
        ts = int(_time.time())
        run_dir = _HISTORY_ROOT / f"{ts}_{run_id}"
        run_dir.mkdir(parents=True, exist_ok=True)

        preserved_input  = run_dir / safe_name
        preserved_output = run_dir / (os.path.splitext(safe_name)[0] + "_PROOFED.docx")
        try:
            shutil.copy2(input_path, str(preserved_input))
            shutil.copy2(output_path, str(preserved_output))
        except Exception as e:
            logger.warning("Proof history: could not preserve files for %s: %s", run_id, e)

        # Count the comments inserted — each comment = one fix/flag note.
        comment_count = _count_comments_in_docx(str(preserved_output))

        profile_label = _proof_available.get(profile, {}).get("label", profile)

        entry = {
            "id": run_id,
            "created_at": ts,
            "original_filename": display_name,  # user's original, shown in UI (escaped)
            "profile_key": profile,
            "profile_label": profile_label,
            "comment_count": comment_count,
            "output_path": str(preserved_output),
            "input_path": str(preserved_input),
        }
        history = _load_history()
        history.insert(0, entry)  # newest first
        _save_history(history)

        logger.info("Proof run saved to history: %s — %s via %s (%d comments)",
                    run_id, safe_name, profile, comment_count)

        # Return the proofed file — stream from the persistent copy so the
        # temp dir can be cleaned up later without affecting the response.
        return FileResponse(
            str(preserved_output),
            filename=preserved_output.name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            background=None,
            headers={"X-Notare-Run-Id": run_id, "X-Notare-Comment-Count": str(comment_count)},
        )

    except Exception as e:
        logger.error("Proof Upload: error processing %s: %s", safe_name, e)
        return _JSONResponse({"error": f"Proofing failed: {str(e)}"}, status_code=500)


# ─────────────────────────────────────────────
# History endpoints
# ─────────────────────────────────────────────

@_app.app.get("/api/proof-history")
async def get_proof_history():
    """Return the full list of past proofing runs, newest first."""
    entries = _load_history()
    # Strip internal paths from the response — UI doesn't need them exposed.
    stripped = []
    for e in entries:
        stripped.append({
            "id": e.get("id"),
            "created_at": e.get("created_at"),
            "original_filename": e.get("original_filename"),
            "profile_key": e.get("profile_key"),
            "profile_label": e.get("profile_label"),
            "comment_count": e.get("comment_count", 0),
            "has_output": bool(e.get("output_path")) and os.path.exists(e.get("output_path", "")),
        })
    return _JSONResponse({"entries": stripped, "total": len(stripped)})


@_app.app.get("/api/proof-history/{run_id}/download")
async def download_proof_history(run_id: str):
    """Re-download the _PROOFED output from a past run."""
    entries = _load_history()
    for e in entries:
        if e.get("id") == run_id:
            path = e.get("output_path", "")
            if path and os.path.exists(path):
                return FileResponse(
                    path,
                    filename=os.path.basename(path),
                    media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                )
            return _JSONResponse(
                {"error": "Output file missing from disk — may have been moved or deleted."},
                status_code=404,
            )
    return _JSONResponse({"error": "Run id not found in history."}, status_code=404)


@_app.app.delete("/api/proof-history/{run_id}")
async def delete_proof_history(run_id: str):
    """Remove a history entry and its preserved files from disk."""
    entries = _load_history()
    remaining = []
    removed = None
    for e in entries:
        if e.get("id") == run_id:
            removed = e
            continue
        remaining.append(e)
    if removed is None:
        return _JSONResponse({"error": "Run id not found."}, status_code=404)

    # Remove the run dir on disk (best-effort).
    try:
        out = removed.get("output_path", "")
        if out:
            run_dir = Path(out).parent
            if run_dir.exists() and run_dir.parent == _HISTORY_ROOT:
                shutil.rmtree(str(run_dir), ignore_errors=True)
    except Exception as e:
        logger.warning("Proof history: could not remove run dir for %s: %s", run_id, e)

    _save_history(remaining)
    return _JSONResponse({"ok": True, "removed": run_id, "remaining": len(remaining)})


# ─────────────────────────────────────────────
# Proof Upload UI Page
# ─────────────────────────────────────────────

_PROOF_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notare — Proof Document</title>
    <link rel="icon" href="/static/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="header">
        <a href="https://notarelegal.com" target="_blank" style="text-decoration:none;"><h1 style="margin:0;display:flex;align-items:center;gap:6px;"><img src="/static/quill_icon_only.png" style="height:24px;" alt=""><span style="font-family:Palatino,Georgia,serif;letter-spacing:1px;font-style:italic;color:var(--gold,#c8a55c);">Notare</span></h1></a>
        <nav>
            <a href="/static/index.html">Dashboard</a>
            <a href="/static/new_job.html">New Job</a>
            <a href="/static/batch.html">Batch</a>
            <a href="/static/proof.html">Proof</a>
            <a href="/static/cases.html">Cases</a>
            <a href="/static/compare.html">Compare</a>
            <a href="/static/voices.html">Voices</a>
            <a href="/static/profiles.html">Profiles</a>
            <a href="/static/settings.html">Settings</a>
            <a href="/static/help.html">Help</a>
        </nav>
    </div>

    <div class="container">
        <h2 class="page-title">Proof Document</h2>
        <p style="color:var(--text-muted); margin-bottom:24px;">Upload a transcript (.docx), select a proofing profile, and download the flagged document with Word comments showing auto-fixes and issues to review.</p>

        <div class="card" id="uploadCard">
            <h3>Upload Transcript</h3>

            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600;">Proofing Profile</label>
                <select id="profileSelect" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:6px; font-size:14px; background:var(--bg-secondary); color:var(--text-body);">
                </select>
                <small id="profileDesc" style="color:var(--text-muted); display:block; margin-top:4px;"></small>
            </div>

            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600;">Transcript File (.docx)</label>
                <input type="file" id="fileInput" accept=".docx"
                       style="width:100%; padding:10px; border:1px solid var(--border); border-radius:6px; font-size:14px; background:var(--bg-secondary); color:var(--text-body);">
            </div>

            <button onclick="runProof()" class="btn btn-primary" id="proofBtn" style="padding:12px 32px; font-size:16px;">Run Proofing</button>
        </div>

        <div class="card" style="margin-top:20px;">
            <h3>Manage Proofing Profiles</h3>
            <div id="profileList" style="margin-bottom:16px;"></div>
            <div style="display:flex; gap:8px; align-items:center;">
                <input type="file" id="uploadProfileInput" accept=".py" style="font-size:13px;">
                <button onclick="uploadProfile()" class="btn btn-secondary" style="font-size:13px;">Upload New Profile</button>
            </div>
            <small style="color:var(--text-muted); display:block; margin-top:6px;">Upload a .py proofing script. Must follow the Notare proofing format with a process() function.</small>
        </div>

        <div class="card" id="resultCard" style="display:none;">
            <h3 id="resultTitle">Processing...</h3>
            <p id="resultMessage" style="color:var(--text-muted);"></p>
            <a id="downloadLink" href="#" class="btn btn-primary" style="display:none; padding:12px 32px; font-size:16px; text-decoration:none; margin-top:12px;">Download Proofed Document</a>
            <button onclick="resetForm()" class="btn btn-secondary" style="margin-top:12px; margin-left:8px;">Proof Another</button>
        </div>
    </div>

    <script>
    let profileData = {};

    // Load profiles
    fetch('/api/proof-profiles').then(r => r.json()).then(profiles => {
        profileData = profiles;
        const sel = document.getElementById('profileSelect');
        for (const [key, info] of Object.entries(profiles)) {
            const opt = document.createElement('option');
            opt.value = key;
            opt.textContent = info.label;
            sel.appendChild(opt);
        }
        updateDesc();
    });

    document.getElementById('profileSelect').addEventListener('change', updateDesc);

    function updateDesc() {
        const key = document.getElementById('profileSelect').value;
        const desc = profileData[key]?.description || '';
        document.getElementById('profileDesc').textContent = desc;
    }

    async function runProof() {
        const fileInput = document.getElementById('fileInput');
        const profile = document.getElementById('profileSelect').value;

        if (!fileInput.files.length) {
            alert('Please select a .docx file.');
            return;
        }

        const file = fileInput.files[0];
        if (!file.name.toLowerCase().endsWith('.docx')) {
            alert('Please select a .docx file.');
            return;
        }

        const btn = document.getElementById('proofBtn');
        btn.disabled = true;
        btn.textContent = 'Processing...';

        document.getElementById('uploadCard').style.display = 'none';
        document.getElementById('resultCard').style.display = '';
        document.getElementById('resultTitle').textContent = 'Processing...';
        document.getElementById('resultMessage').textContent = 'Running proofing rules against ' + file.name + '. This may take a moment for large documents.';

        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('profile', profile);

            const resp = await fetch('/api/proof-document', {
                method: 'POST',
                body: formData,
            });

            if (resp.ok) {
                const blob = await resp.blob();
                const url = URL.createObjectURL(blob);
                const outputName = file.name.replace('.docx', '_PROOFED.docx');

                document.getElementById('resultTitle').textContent = 'Proofing Complete';
                document.getElementById('resultMessage').textContent = 'Your document has been proofed. Open the downloaded file in Word and review the comments in the Review tab.';
                const link = document.getElementById('downloadLink');
                link.href = url;
                link.download = outputName;
                link.style.display = 'inline-block';
                link.textContent = 'Download ' + outputName;

                // Auto-trigger download
                link.click();
            } else {
                const data = await resp.json();
                document.getElementById('resultTitle').textContent = 'Error';
                document.getElementById('resultMessage').textContent = data.error || 'Proofing failed. Please try again.';
            }
        } catch (e) {
            document.getElementById('resultTitle').textContent = 'Error';
            document.getElementById('resultMessage').textContent = 'Connection error: ' + e.message;
        }

        btn.disabled = false;
        btn.textContent = 'Run Proofing';
    }

    function resetForm() {
        document.getElementById('uploadCard').style.display = '';
        document.getElementById('resultCard').style.display = 'none';
        document.getElementById('downloadLink').style.display = 'none';
        document.getElementById('fileInput').value = '';
    }

    function renderProfiles() {
        const container = document.getElementById('profileList');
        if (!Object.keys(profileData).length) {
            container.innerHTML = '<p style="color:var(--text-muted); font-size:13px;">No proofing profiles loaded.</p>';
            return;
        }
        container.innerHTML = Object.entries(profileData).map(([key, info]) =>
            '<div style="display:flex; justify-content:space-between; align-items:center; padding:8px 12px; border:1px solid var(--border); border-radius:6px; margin-bottom:6px;">' +
                '<div>' +
                    '<strong style="font-size:14px;">' + info.label + '</strong>' +
                    '<div style="font-size:12px; color:var(--text-muted);">' + (info.filename || '') + '</div>' +
                '</div>' +
                '<button onclick="deleteProfile(\\'' + key + '\\')" class="btn btn-sm" style="font-size:12px; color:#e74c3c; border:1px solid #e74c3c; background:none; cursor:pointer;">Delete</button>' +
            '</div>'
        ).join('');
    }

    async function deleteProfile(key) {
        if (!confirm('Delete proofing profile "' + (profileData[key]?.label || key) + '"?')) return;
        const resp = await fetch('/api/proof-profiles/' + key, {method: 'DELETE'});
        const data = await resp.json();
        if (data.ok) {
            delete profileData[key];
            // Refresh profiles
            const r = await fetch('/api/proof-profiles');
            profileData = await r.json();
            renderProfiles();
            // Rebuild dropdown
            const sel = document.getElementById('profileSelect');
            sel.innerHTML = '';
            for (const [k, info] of Object.entries(profileData)) {
                const opt = document.createElement('option');
                opt.value = k;
                opt.textContent = info.label;
                sel.appendChild(opt);
            }
            updateDesc();
        }
    }

    async function uploadProfile() {
        const input = document.getElementById('uploadProfileInput');
        if (!input.files.length) { alert('Select a .py file first.'); return; }
        const formData = new FormData();
        formData.append('file', input.files[0]);
        const resp = await fetch('/api/proof-profiles/upload', {method: 'POST', body: formData});
        const data = await resp.json();
        if (data.ok) {
            input.value = '';
            // Refresh everything
            const r = await fetch('/api/proof-profiles');
            profileData = await r.json();
            renderProfiles();
            const sel = document.getElementById('profileSelect');
            sel.innerHTML = '';
            for (const [k, info] of Object.entries(profileData)) {
                const opt = document.createElement('option');
                opt.value = k;
                opt.textContent = info.label;
                sel.appendChild(opt);
            }
            updateDesc();
            alert('Profile uploaded successfully.');
        } else {
            alert(data.error || 'Upload failed.');
        }
    }

    // Initial render of profile list
    fetch('/api/proof-profiles').then(r => r.json()).then(p => { profileData = p; renderProfiles(); });
    </script>
<script src="/static/theme.js"></script>
<script src="/static/support_widget.js"></script>
</body>
</html>"""

# Write the static HTML file
_static_dir = _app.BASE_DIR / "_internal" / "static"
_static_dir_exe = _app.BASE_DIR / "static"
for d in [_static_dir, _static_dir_exe]:
    try:
        (d / "proof.html").write_text(_PROOF_HTML, encoding="utf-8")
    except Exception:
        pass

logger.info("Proof Upload: endpoint active at /api/proof-document, page at /static/proof.html")
print("Plugin loaded: proof_upload.py — document proofing with Word comments active")
