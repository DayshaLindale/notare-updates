"""Notare Desktop — Native window launcher with license validation.

This is the main entry point for the standalone desktop application.
Starts the FastAPI server in a background thread, validates the license,
then opens a native window (no browser chrome).
"""
import sys
import os
import json
import time
import threading
import socket

# Fix for windowed exe: stdout/stderr are None when no console is attached.
# Redirect to devnull so logging/print don't crash.
if getattr(sys, 'frozen', False) and (sys.stdout is None or sys.stderr is None):
    _log_path = os.path.join(os.path.dirname(sys.executable), "notare.log")
    _log_file = open(_log_path, "w", encoding="utf-8")
    if sys.stdout is None:
        sys.stdout = _log_file
    if sys.stderr is None:
        sys.stderr = _log_file

# Set working directory to exe location (not PyInstaller temp dir)
if getattr(sys, 'frozen', False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(APP_DIR)

# ---------------------------------------------------------------------------
# License Management
# ---------------------------------------------------------------------------

SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
LICENSE_FILE = os.path.join(APP_DIR, "license.json")


def load_license():
    """Load stored license key."""
    if os.path.exists(LICENSE_FILE):
        try:
            with open(LICENSE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_license(data):
    """Save license key locally."""
    with open(LICENSE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def validate_license_local(key):
    """Validate license key — checks local database first, then remote server."""
    from datetime import datetime

    # Step 1: Check local admin databases (app-level + _internal fallback)
    admin_files = [
        os.path.join(APP_DIR, "admin_data.json"),
        os.path.join(APP_DIR, "_internal", "admin_data.json"),
    ]
    for admin_file in admin_files:
        if not os.path.exists(admin_file):
            continue
        try:
            with open(admin_file, "r") as f:
                admin_data = json.load(f)
            for l in admin_data.get("licenses", []):
                if l.get("key", "").upper() == key.upper() and l.get("status") == "active":
                    exp = l.get("expires", "")
                    if exp and exp != "" and exp < datetime.now().strftime("%Y-%m-%d"):
                        return {"valid": False, "reason": "expired"}
                    return {
                        "valid": True,
                        "tier": l.get("tier", "solo"),
                        "expires": l.get("expires", ""),
                        "customer": l.get("customer_name", ""),
                    }
        except Exception:
            pass

    # Step 2: Remote validation — check the server if local doesn't have the key
    try:
        import urllib.request
        payload = json.dumps({"key": key}).encode()
        req = urllib.request.Request(
            "https://notare-updates.onrender.com/api/validate-license",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
            if result.get("valid"):
                # Cache the license locally so it works offline next time
                _cache_license_locally(key, result)
                return result
    except Exception:
        pass  # Network error — don't block startup

    return {"valid": False, "reason": "invalid_key"}


def _cache_license_locally(key, result):
    """Save a remotely-validated license to local admin_data.json for offline use."""
    try:
        admin_file = os.path.join(APP_DIR, "admin_data.json")
        if not os.path.exists(admin_file):
            admin_file = os.path.join(APP_DIR, "_internal", "admin_data.json")
        admin_data = {}
        if os.path.exists(admin_file):
            with open(admin_file, "r") as f:
                admin_data = json.load(f)
        # Add the license if not already present
        licenses = admin_data.setdefault("licenses", [])
        if not any(l.get("key") == key for l in licenses):
            licenses.append({
                "key": key,
                "tier": result.get("tier", "solo"),
                "customer_name": result.get("customer", ""),
                "status": "active",
                "expires": result.get("expires", ""),
                "cached_from_server": True,
            })
            with open(admin_file, "w") as f:
                json.dump(admin_data, f, indent=2)
    except Exception:
        pass  # Non-critical — remote validation already succeeded


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

def find_free_port():
    """Find an available port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        return s.getsockname()[1]


_server_error = None

def start_server(port):
    """Start the FastAPI server in a background thread."""
    global _server_error
    try:
        import uvicorn
        import logging
        logging.getLogger("uvicorn").setLevel(logging.WARNING)

        # Add app directory to Python path so app.py can be found
        sys.path.insert(0, APP_DIR)
        os.chdir(APP_DIR)

        # Load app.py from DISK so OTA patches take effect immediately.
        # PyInstaller's FrozenImporter would load bundled bytecode, ignoring
        # any OTA-patched app.py on disk. Using importlib.util bypasses that.
        import importlib.util as _ilu
        _app_path = os.path.join(APP_DIR, "app.py")
        if not os.path.exists(_app_path):
            _app_path = os.path.join(APP_DIR, "_internal", "app.py")
        _spec = _ilu.spec_from_file_location("app", _app_path)
        notare_app = _ilu.module_from_spec(_spec)
        sys.modules["app"] = notare_app  # Make it importable as "app" by plugins
        _spec.loader.exec_module(notare_app)

        # Plugin loader — load .py files from _internal/plugins/
        _plugins_dir = os.path.join(APP_DIR, "_internal", "plugins") if getattr(sys, 'frozen', False) else os.path.join(APP_DIR, "plugins")
        os.makedirs(_plugins_dir, exist_ok=True)
        for _pf in sorted(os.listdir(_plugins_dir)):
            if _pf.endswith('.py'):
                _ppath = os.path.join(_plugins_dir, _pf)
                try:
                    _code = open(_ppath, 'r', encoding='utf-8').read()
                    _ns = {
                        "app": notare_app.app,
                        "BASE_DIR": notare_app.BASE_DIR,
                        "UPLOAD_DIR": notare_app.UPLOAD_DIR,
                        "SESSION_DIR": notare_app.SESSION_DIR,
                        "JOBS": notare_app.JOBS,
                        "PROFILES": notare_app.PROFILES,
                        "Path": notare_app.Path,
                        "json": notare_app.json,
                        "re": notare_app.re,
                        "os": os,
                        "shutil": notare_app.shutil,
                        "datetime": notare_app.datetime,
                        "JSONResponse": notare_app.JSONResponse,
                        "FileResponse": notare_app.FileResponse,
                        "Request": notare_app.Request,
                        "UploadFile": notare_app.UploadFile,
                        "File": notare_app.File,
                    }
                    exec(compile(_code, _ppath, "exec"), _ns)
                    print(f"Plugin loaded: {_pf}")
                except Exception as _pe:
                    print(f"Plugin failed: {_pf} — {_pe}")

        # Bind to 0.0.0.0 to accept connections from local network (needed for
        # remote management and multi-device testing)
        uvicorn.run(notare_app.app, host="0.0.0.0", port=port, log_level="warning")
    except Exception as e:
        import traceback
        _server_error = traceback.format_exc()
        log_path = os.path.join(APP_DIR, "notare_crash.log")
        try:
            with open(log_path, "w") as f:
                f.write(f"Server crashed at {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n{_server_error}")
        except Exception:
            pass


def wait_for_server(port, timeout=30):
    """Wait until the server is accepting connections."""
    import urllib.request
    start = time.time()
    while time.time() - start < timeout:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/jobs", timeout=2)
            return True
        except Exception:
            time.sleep(0.5)
    return False


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

def show_license_dialog():
    """Show a license key entry dialog using tkinter."""
    import tkinter as tk
    from tkinter import messagebox

    result = {"key": None}

    root = tk.Tk()
    root.title("Notare — License Activation")
    root.geometry("440x300")
    root.configure(bg="#f7f5f2")
    root.resizable(False, False)

    # Center on screen
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 220
    y = (root.winfo_screenheight() // 2) - 150
    root.geometry(f"+{x}+{y}")

    tk.Label(root, text="Notare", font=("Georgia", 24, "bold"),
             fg="#0f1b2d", bg="#f7f5f2").pack(pady=(28, 2))
    tk.Label(root, text="Legal Transcription Platform",
             font=("Segoe UI", 9), fg="#6b6b7b", bg="#f7f5f2").pack(pady=(0, 4))
    tk.Label(root, text="Enter your license key to activate",
             font=("Segoe UI", 10), fg="#3d3d4e", bg="#f7f5f2").pack(pady=(8, 16))

    entry = tk.Entry(root, font=("Consolas", 13), width=34, justify="center",
                     bg="#ffffff", fg="#0f1b2d", insertbackground="#0f1b2d",
                     relief="solid", bd=1, highlightthickness=1,
                     highlightcolor="#c8a55c", highlightbackground="#e0ddd8")
    entry.pack(pady=(0, 8))
    entry.focus()

    error_label = tk.Label(root, text="", font=("Segoe UI", 9),
                           fg="#b84040", bg="#f7f5f2")
    error_label.pack()

    def activate():
        key = entry.get().strip()
        if not key:
            error_label.config(text="Please enter a license key")
            return
        validation = validate_license_local(key)
        if validation.get("valid"):
            save_license({"key": key, **validation})
            result["key"] = key
            root.destroy()
        else:
            reason = validation.get("reason", "unknown")
            if reason == "expired":
                error_label.config(text="This license has expired. Contact support to renew.")
            else:
                error_label.config(text="Invalid license key. Check your key and try again.")

    btn_frame = tk.Frame(root, bg="#f7f5f2")
    btn_frame.pack(pady=(12, 0))

    activate_btn = tk.Button(btn_frame, text="Activate", command=activate,
                             font=("Segoe UI", 10, "bold"), bg="#0f1b2d", fg="white",
                             relief="flat", padx=24, pady=8, cursor="hand2")
    activate_btn.pack(side="left", padx=4)

    quit_btn = tk.Button(btn_frame, text="Quit", command=root.destroy,
                         font=("Segoe UI", 10), bg="#e0ddd8", fg="#3d3d4e",
                         relief="flat", padx=24, pady=8, cursor="hand2")
    quit_btn.pack(side="left", padx=4)

    entry.bind("<Return>", lambda e: activate())
    root.mainloop()

    return result["key"]


_BUNDLED_VERSION = "1.2.0"
UPDATE_SERVER = "https://notare-updates.onrender.com"


def _get_app_version():
    """Read version from disk (updated by OTA), falling back to bundled version.

    The exe bundles this file, so APP_VERSION hardcoded here is frozen at build time.
    OTA updates write the new version to version.txt on disk, which this reads.
    """
    version_file = os.path.join(APP_DIR, "version.txt")
    if os.path.exists(version_file):
        try:
            with open(version_file, "r") as f:
                v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    # Also check settings.json
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                s = json.load(f)
                if s.get("version"):
                    return s["version"]
        except Exception:
            pass
    return _BUNDLED_VERSION


APP_VERSION = _get_app_version()


def check_for_updates():
    """Silent auto-update. Runs on every launch — user never sees it.

    Checks the update server for a newer version. If found, downloads the zip,
    replaces app files (preserving user data), and restarts the app.
    The entire process is invisible to the user.
    """
    if not UPDATE_SERVER:
        return False

    try:
        import urllib.request
        import zipfile
        import shutil

        r = urllib.request.urlopen(
            f"{UPDATE_SERVER}/api/update?current={APP_VERSION}", timeout=10
        )
        data = json.loads(r.read().decode())

        if not data.get("update_available"):
            return False

        new_version = data.get("version", "")
        download_path = data.get("url", "")

        if not download_path:
            return False

        # Build absolute download URL
        if download_path.startswith("/"):
            download_url = f"{UPDATE_SERVER}{download_path}"
        else:
            download_url = download_path

        # Download update package
        update_zip = os.path.join(APP_DIR, "_update.zip")
        update_dir = os.path.join(APP_DIR, "_update")

        urllib.request.urlretrieve(download_url, update_zip)

        # Extract to temp directory
        if os.path.exists(update_dir):
            shutil.rmtree(update_dir)
        with zipfile.ZipFile(update_zip, 'r') as z:
            z.extractall(update_dir)

        # Apply update — replace files but preserve user data
        preserve = {"settings.json", "license.json", "admin_data.json",
                    "profiles.json", "speakers.json", "contacts.json",
                    "jobs.json", "cases.json", "voice_profiles.json",
                    "sessions", "uploads"}

        for root_dir, dirs, files in os.walk(update_dir):
            rel_root = os.path.relpath(root_dir, update_dir)
            dest_root = os.path.join(APP_DIR, rel_root) if rel_root != "." else APP_DIR

            # Skip preserved directories
            dirs[:] = [d for d in dirs if d not in preserve]

            for f in files:
                if f in preserve:
                    continue
                src = os.path.join(root_dir, f)
                dst = os.path.join(dest_root, f)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)

        # Cleanup
        os.remove(update_zip)
        shutil.rmtree(update_dir, ignore_errors=True)

        # Save new version to disk so the exe reads it on next launch
        # (the exe's bundled APP_VERSION is frozen at build time)
        try:
            with open(os.path.join(APP_DIR, "version.txt"), "w") as vf:
                vf.write(new_version)
        except Exception:
            pass

        settings = {}
        settings_path = os.path.join(APP_DIR, "settings.json")
        if os.path.exists(settings_path):
            with open(settings_path) as sf:
                settings = json.load(sf)
        settings["version"] = new_version
        settings["last_update"] = time.strftime("%Y-%m-%d %H:%M")
        settings["updated_silently"] = True
        with open(settings_path, "w") as sf:
            json.dump(settings, sf, indent=2)

        return True

    except Exception as e:
        # Silent failure — never block app startup for update issues
        # But log it so we can debug if needed
        try:
            with open(os.path.join(APP_DIR, "update.log"), "a") as uf:
                uf.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} Update failed: {e}\n")
        except Exception:
            pass
        return False


def main():
    print("=" * 50)
    print(f"  NOTARE v{APP_VERSION} — Legal Transcription Platform")
    print("=" * 50)

    # Show splash screen during startup
    splash = None
    try:
        import tkinter as tk
        splash = tk.Tk()
        splash.overrideredirect(True)
        splash.configure(bg="#f7f5f2")
        sw, sh = 400, 200
        x = (splash.winfo_screenwidth() // 2) - (sw // 2)
        y = (splash.winfo_screenheight() // 2) - (sh // 2)
        splash.geometry(f"{sw}x{sh}+{x}+{y}")
        splash.attributes('-topmost', True)

        tk.Label(splash, text="Notare", font=("Georgia", 28, "bold"),
                 fg="#0f1b2d", bg="#f7f5f2").pack(pady=(40, 4))
        tk.Label(splash, text="Legal Transcription Platform",
                 font=("Segoe UI", 10), fg="#6b6b7b", bg="#f7f5f2").pack()
        splash_status = tk.Label(splash, text="Starting...",
                                 font=("Segoe UI", 9), fg="#c8a55c", bg="#f7f5f2")
        splash_status.pack(pady=(16, 0))

        def update_splash(msg):
            try:
                splash_status.config(text=msg)
                splash.update()
            except Exception:
                pass

        splash.update()
    except Exception:
        splash = None
        def update_splash(msg):
            print(f"  {msg}")

    # Silent update check
    # Skip if we just applied an update (prevents restart loop —
    # exe still reports old version but files on disk are already new)
    _just_updated = os.path.join(APP_DIR, "_just_updated")
    if os.path.exists(_just_updated):
        try:
            os.remove(_just_updated)
        except Exception:
            pass  # OneDrive or antivirus may lock — ignore, it'll get cleaned next time
        update_splash("Update applied — starting...")
    else:
        update_splash("Checking for updates...")
        updated = check_for_updates()
        if updated:
            # Write marker so next launch doesn't re-check
            try:
                with open(_just_updated, "w") as f:
                    f.write("1")
            except Exception:
                pass  # If we can't write marker, update still applied — just may re-check once
            print("Update applied. Restarting...")
            # Use subprocess + exit on Windows (os.execv is unreliable with frozen exes)
            import subprocess as _sp
            _sp.Popen([sys.executable] + sys.argv)
            sys.exit(0)

    # Check license
    update_splash("Validating license...")
    license_data = load_license()
    if not license_data.get("valid"):
        # Check if stored key is still valid
        stored_key = license_data.get("key", "")
        if stored_key:
            validation = validate_license_local(stored_key)
            if validation.get("valid"):
                license_data = {"key": stored_key, **validation}
                save_license(license_data)
            else:
                license_data = {}

    if not license_data.get("valid"):
        if splash:
            splash.destroy()
            splash = None
        key = show_license_dialog()
        if not key:
            print("No license key provided. Exiting.")
            return
        license_data = load_license()

    tier = license_data.get("tier", "solo")
    customer = license_data.get("customer", "")
    print(f"License: {tier.upper()} — {customer}")

    # Find port and start server
    port = 8080
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('127.0.0.1', port))
        s.close()
    except OSError:
        port = find_free_port()
        print(f"Port 8080 in use, using {port}")

    # Close splash — webview takes over
    if splash:
        try:
            splash.destroy()
        except Exception:
            pass

    # Start server in background
    print(f"Starting server on port {port}...")
    server_thread = threading.Thread(target=start_server, args=(port,), daemon=True)
    server_thread.start()

    # Wait for server — show loading page via http once server is up
    print("Waiting for server...")
    if not wait_for_server(port, timeout=30):
        print("Server failed to start!")
        show_error("Notare — Server Error",
                   "Notare's internal server failed to start within 30 seconds.\n\n"
                   "This may be caused by:\n"
                   "- Antivirus blocking the connection\n"
                   "- Port 8080 being used by another app\n"
                   "- Missing runtime files\n\n"
                   "Try running Notare.exe as Administrator,\n"
                   "or check notare_crash.log for details.")
        return

    print("Server ready. Opening window...")

    # Clear WebView2 cache on startup so OTA HTML updates always take effect
    try:
        _cache_dir = os.path.join(os.environ.get("APPDATA", ""), "pywebview", "EBWebView", "Default", "Cache")
        if os.path.isdir(_cache_dir):
            import shutil
            shutil.rmtree(_cache_dir, ignore_errors=True)
            print("WebView2 cache cleared")
    except Exception:
        pass

    # Ensure WebView2 Runtime is installed BEFORE trying to open the window
    try:
        import winreg
        _wv2_found = False
        for _hive in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            for _subkey in [
                r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",
                r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",
            ]:
                try:
                    _k = winreg.OpenKey(_hive, _subkey)
                    winreg.CloseKey(_k)
                    _wv2_found = True
                    break
                except FileNotFoundError:
                    pass
            if _wv2_found:
                break
        if not _wv2_found:
            print("WebView2 Runtime not found — installing...")
            _wv2_path = os.path.join(APP_DIR, "MicrosoftEdgeWebview2Setup.exe")
            if not os.path.exists(_wv2_path):
                import urllib.request
                urllib.request.urlretrieve(
                    "https://go.microsoft.com/fwlink/p/?LinkId=2124703",
                    _wv2_path)
            import subprocess as _sp2
            _sp2.run([_wv2_path, "/silent", "/install"], timeout=120)
            print("WebView2 Runtime installed")
    except Exception as _wv2_err:
        print(f"WebView2 check/install failed: {_wv2_err}")

    try:
        import webview
        import ctypes

        def set_icon():
            try:
                ico_path = os.path.join(APP_DIR, "static", "favicon.ico")
                if os.path.exists(ico_path):
                    icon = ctypes.windll.user32.LoadImageW(0, ico_path, 1, 0, 0, 0x00000010)
                    if icon:
                        time.sleep(2)
                        hwnd = ctypes.windll.user32.FindWindowW(None, "Notare")
                        if hwnd:
                            ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 0, icon)
                            ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 1, icon)
            except Exception:
                pass

        window = webview.create_window(
            "Notare",
            f"http://127.0.0.1:{port}/static/index.html",
            width=1280,
            height=800,
            min_size=(900, 600),
            text_select=True,
        )

        def _grant_permissions(w):
            """Grant microphone/camera permissions for WebView2.

            WebView2 blocks getUserMedia by default unlike a regular browser.
            We need to hook into the underlying COM control to auto-grant permissions.
            """
            try:
                time.sleep(2)
                # Access the WebView2 control through pywebview internals
                if hasattr(w, 'gui') and w.gui:
                    widget = getattr(w.gui, 'browser', None) or getattr(w.gui, 'webview', None)
                    if widget and hasattr(widget, 'PermissionRequested'):
                        def on_permission(sender, args):
                            # Auto-grant microphone and camera permissions
                            args.State = 1  # COREWEBVIEW2_PERMISSION_STATE_ALLOW
                        widget.PermissionRequested += on_permission
                        print("WebView2 permissions handler installed")
            except Exception as e:
                print(f"Permission handler setup: {e}")

        threading.Thread(target=set_icon, daemon=True).start()
        threading.Thread(target=_grant_permissions, args=(window,), daemon=True).start()
        webview.start(private_mode=False)  # Persist permissions (mic, camera) across sessions
    except Exception as webview_err:
        # Fallback to browser if pywebview fails (import error, .NET runtime missing, etc.)
        print(f"PyWebView unavailable ({webview_err}), opening in browser...")
        import webbrowser
        webbrowser.open(f"http://127.0.0.1:{port}")
        print("Press Ctrl+C to stop the server.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass


def show_error(title, message):
    """Show a visible error dialog — works even when no console exists."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(title, message)
        root.destroy()
    except Exception:
        pass


if __name__ == "__main__":
    LOG_FILE = os.path.join(
        os.path.dirname(sys.executable) if getattr(sys, 'frozen', False)
        else os.path.dirname(os.path.abspath(__file__)),
        "notare_crash.log"
    )
    try:
        main()
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        try:
            with open(LOG_FILE, "w") as f:
                f.write(f"Notare crashed at {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n{tb}")
        except Exception:
            pass
        show_error("Notare — Startup Error", f"Notare failed to start:\n\n{e}\n\nDetails saved to notare_crash.log")
