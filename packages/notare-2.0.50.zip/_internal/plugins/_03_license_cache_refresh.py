"""License cache self-heal — runs at startup before workspaces gate.

Stale cache symptom: local license.json has an `entitlements` object with empty
or missing `proof_profiles`/`workspaces` lists. The frontend gates strictly on
server-authoritative entitlements when the object is present (empty list = deny),
so a stale cache from before entitlements were properly populated will block
profiles and workspaces that the user is actually entitled to.

Fix: on startup, if license.json has an entitlements object with empty inner
lists AND the key is present in the fallback allowlist, REMOVE the entitlements
field. The fallback resolution path then grants the bundled profiles.

For keys NOT in the fallback allowlist (newer customers), re-query the server
once to refresh entitlements. Network-fail = leave alone; don't lock anyone out
on first-launch-with-no-internet.

Tracked once-per-startup via a stamp file so we don't hammer the server every
launch.
"""
import json
import os
import time
import urllib.request
from pathlib import Path

import app as _app

logger = _app.logger if hasattr(_app, "logger") else None


def _log(msg, level="info"):
    if logger:
        getattr(logger, level)(msg)
    else:
        print(f"[license_cache_refresh] {msg}")


def _stamp_path():
    return _app.BASE_DIR / "_internal" / "_license_refresh.stamp"


# Bumped every version that has a real fix to the self-heal logic. When the
# stored stamp's plugin_version doesn't match this constant, we force-run
# regardless of how recently the plugin last fired. Prevents users who hit
# v2.0.45's earlier (broken) detection from being locked out by their own
# stamp file until 6 hours pass.
_PLUGIN_VERSION = "2.0.50"


def _should_run():
    """Run if the stamp is missing, older than 6 hours, OR was written by a
    plugin version with a known bug. The version check forces an at-least-once
    run after upgrading even if the previous version's stamp is recent."""
    stamp = _stamp_path()
    if not stamp.exists():
        return True
    try:
        text = stamp.read_text().strip()
        # Newer stamp format: "<version>|<timestamp>". Older format: just timestamp.
        if "|" in text:
            ver, ts = text.split("|", 1)
            if ver != _PLUGIN_VERSION:
                _log(f"stamp from {ver}, current is {_PLUGIN_VERSION} — forcing run")
                return True
            return (time.time() - float(ts)) > 6 * 3600
        else:
            # Old-format stamp from v2.0.45-2.0.48. Force-run once to apply
            # the new detection logic; subsequent runs will use new format.
            _log("legacy stamp format detected — forcing run")
            return True
    except Exception:
        return True


def _mark_done():
    try:
        _stamp_path().write_text(f"{_PLUGIN_VERSION}|{time.time()}")
    except Exception:
        pass


def _clean_admin_data_partial_caches():
    """Notare.py's _cache_license_locally writes license entries to
    admin_data.json WITHOUT entitlements. Subsequent validations short-circuit
    on those partial entries and never re-fetch from the server — which is
    why Alyssa's flow kept producing license.json with empty entitlements
    even after deleting and re-entering her key.

    Fix: scan admin_data.json files; remove any license entry that has
    cached_from_server=True OR is missing entitlements entirely. Next
    validation will fall through to the remote check and get full data.
    """
    cleaned = 0
    for admin_file in (_app.BASE_DIR / "admin_data.json",
                       _app.BASE_DIR / "_internal" / "admin_data.json"):
        if not admin_file.exists():
            continue
        try:
            data = json.loads(admin_file.read_text(encoding="utf-8"))
            licenses = data.get("licenses", [])
            kept = []
            for lic in licenses:
                # Drop entries that came from the partial-cache path. They
                # never had entitlements; they need a fresh server query.
                if lic.get("cached_from_server") and not lic.get("entitlements"):
                    cleaned += 1
                    continue
                kept.append(lic)
            if cleaned > 0:
                data["licenses"] = kept
                admin_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                _log(f"cleaned {cleaned} partial-cached license entries from {admin_file.name}")
        except Exception as e:
            _log(f"could not clean {admin_file}: {e}", "warning")
    return cleaned


def _license_files():
    """Both potential locations for license.json — prefer the app-level one."""
    return [
        _app.BASE_DIR / "license.json",
        _app.BASE_DIR / "_internal" / "license.json",
    ]


def _entitlements_are_stale(data):
    """Stale = entitlements key present but at least one inner list is
    empty/missing. Either workspaces OR proof_profiles being empty is enough
    to gate a user out of features they should see, so we treat either case
    as stale and re-pull from the server."""
    ent = data.get("entitlements")
    if not isinstance(ent, dict):
        return False  # No entitlements field = use fallback, not stale
    profs = ent.get("proof_profiles")
    works = ent.get("workspaces")
    # Wrong type for either = corrupt cache, refresh
    if not isinstance(profs, list) or not isinstance(works, list):
        return True
    # Either list empty = stale-for-some-purpose. Original logic required
    # BOTH to be empty which missed the partial-cache case (workspaces
    # populated but proof_profiles dropped to empty). Frontend gates each
    # list independently, so either being empty is a real failure mode.
    if len(profs) == 0 or len(works) == 0:
        return True
    return False


def _server_signaled_refresh(local_data, server_data):
    """Did the admin signal a force-refresh more recently than our last cache?
    Server returns force_refresh_at and entitlements_updated_at when present
    on the license entry. If either is newer than our cached version, the
    local cache is out of date even if entitlements look populated."""
    if not isinstance(server_data, dict):
        return False
    server_force  = server_data.get("force_refresh_at", "")
    server_update = server_data.get("entitlements_updated_at", "")
    local_force   = local_data.get("force_refresh_at", "")
    local_update  = local_data.get("entitlements_updated_at", "")
    if server_force and server_force > local_force:
        return True
    if server_update and server_update > local_update:
        return True
    return False


def _query_server(key, machine_id=""):
    """Re-validate against the update server. Returns dict or None on failure."""
    try:
        payload = json.dumps({"key": key, "machine_id": machine_id}).encode()
        req = urllib.request.Request(
            "https://notare-updates.onrender.com/api/validate-license",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        _log(f"server query failed: {e}", "warning")
        return None


def _refresh_one(license_path):
    """Self-heal a single license.json. Returns (changed, reason).

    Two trigger paths:
      A) Local cache is stale (entitlements present but empty) — the original
         self-heal case for clients cached before entitlements were populated.
      B) Server signaled a refresh — admin clicked "Force Refresh" or edited
         entitlements; server's timestamps are newer than our cached copy.
    """
    try:
        data = json.loads(license_path.read_text(encoding="utf-8"))
    except Exception:
        return (False, "could not read")

    key = (data.get("key") or "").strip().upper()
    if not key:
        return (False, "no key")

    is_stale = _entitlements_are_stale(data)

    # Always query the server when we can — cheap and lets us detect
    # admin-signaled refreshes even when local entitlements look populated.
    fresh = _query_server(key, data.get("machine_id", ""))
    server_signaled = _server_signaled_refresh(data, fresh) if fresh else False

    if not is_stale and not server_signaled:
        return (False, "entitlements already healthy and server hasn't signaled")

    if server_signaled:
        _log(f"server signaled refresh for {key} — re-pulling entitlements")
    else:
        _log(f"detected stale entitlements for {key} — refreshing")

    # Strategy 1: use the server response (already fetched above).
    if fresh and fresh.get("valid") and isinstance(fresh.get("entitlements"), dict):
        new_ent = fresh["entitlements"]
        if (isinstance(new_ent.get("proof_profiles"), list) and
                len(new_ent["proof_profiles"]) > 0):
            data["entitlements"] = new_ent
            # Carry forward the server timestamps so we won't keep refreshing
            # on every launch for the same admin signal.
            if fresh.get("force_refresh_at"):
                data["force_refresh_at"] = fresh["force_refresh_at"]
            if fresh.get("entitlements_updated_at"):
                data["entitlements_updated_at"] = fresh["entitlements_updated_at"]
            license_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            _log(f"refreshed entitlements from server for {key}: "
                 f"{new_ent.get('proof_profiles')}")
            return (True, "refreshed from server")

    # Strategy 2: server unreachable or returned no entitlements. If local was
    # stale, drop the entitlements field so the fallback allowlist takes over.
    # If we got here from a server-signaled refresh that returned bad data,
    # leave the local cache alone — better stale than wrong.
    if is_stale:
        data.pop("entitlements", None)
        license_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        _log(f"removed stale entitlements field for {key}; fallback will resolve")
        return (True, "cleared stale entitlements; fallback active")

    return (False, "server signal received but no fresh entitlements to apply")


def _run():
    if not _should_run():
        return

    # Clean admin_data.json BEFORE running license.json self-heal. Order matters:
    # if admin_data has a partial-cached entry, the next validation will
    # short-circuit on it and overwrite our license.json fix with stale data.
    # By cleaning admin_data first, the next validation falls through to remote.
    try:
        _clean_admin_data_partial_caches()
    except Exception as e:
        _log(f"admin_data cleanup failed: {e}", "warning")

    any_changed = False
    for lf in _license_files():
        if not lf.exists():
            continue
        try:
            changed, reason = _refresh_one(lf)
            if changed:
                any_changed = True
                _log(f"{lf.name}: {reason}")
        except Exception as e:
            _log(f"refresh failed for {lf.name}: {e}", "warning")

    _mark_done()
    if any_changed:
        _log("license cache refresh complete; restart Notare for changes to take effect")


# Run at plugin load time (startup). Wrap in try so a failure here never
# blocks app boot — license functionality survives this plugin failing.
try:
    _run()
except Exception as e:
    _log(f"plugin failed: {e}", "error")
