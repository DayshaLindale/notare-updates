"""Notare — Real-Time Legal Transcription Platform (Cloud Edition)

Uses AssemblyAI for transcription — no local GPU or Whisper needed.
Lightweight, runs on any machine.

Usage:
    python app_cloud.py
    → opens http://localhost:8080
"""

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
# Suppress console window flash on Windows for ALL subprocess calls
_NO_WINDOW = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
_orig_run = subprocess.run
_orig_check_call = subprocess.check_call
subprocess.run = lambda *a, **kw: _orig_run(*a, **{**kw, 'creationflags': kw.get('creationflags', _NO_WINDOW)})
subprocess.check_call = lambda *a, **kw: _orig_check_call(*a, **{**kw, 'creationflags': kw.get('creationflags', _NO_WINDOW)})

import sys
import threading
import time
import uuid
import wave
from datetime import datetime
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------
try:
    from fastapi import FastAPI, UploadFile, File, Form, WebSocket, Request
    from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles
    from fastapi.templating import Jinja2Templates
    import uvicorn
except ImportError:
    print("Installing dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install",
                           "fastapi", "uvicorn", "python-multipart", "jinja2",
                           "aiofiles", "assemblyai", "httpx",
                           "websockets", "numpy"])
    from fastapi import FastAPI, UploadFile, File, Form, WebSocket, Request
    from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles
    from fastapi.templating import Jinja2Templates
    import uvicorn

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("notare")

# Handle PyInstaller frozen exe path
if getattr(sys, 'frozen', False):
    BASE_DIR = Path(sys.executable).parent
    _internal = BASE_DIR / "_internal"

    # Add NVIDIA CUDA libs to PATH so ctranslate2/faster-whisper can find cublas
    for _cuda_dir in [
        _internal / "nvidia" / "cublas" / "bin",
        _internal / "nvidia" / "cudnn" / "bin",
        _internal / "nvidia" / "cuda_nvrtc" / "bin",
    ]:
        if _cuda_dir.exists():
            os.environ["PATH"] = str(_cuda_dir) + os.pathsep + os.environ.get("PATH", "")

    # PyInstaller bundles data into _internal/. On first run (or fresh install),
    # copy everything needed to the exe's parent so they're editable by OTA updates.
    for _data_dir in ("static", "templates"):
        if not (BASE_DIR / _data_dir).exists() and (_internal / _data_dir).exists():
            shutil.copytree(str(_internal / _data_dir), str(BASE_DIR / _data_dir))
            logging.getLogger("notare").info("Copied %s from _internal to app directory", _data_dir)
    for _data_file in ("admin_data.json", "settings.json", "ffmpeg.exe", "app.py", "depo_pdf.py"):
        if not (BASE_DIR / _data_file).exists() and (_internal / _data_file).exists():
            shutil.copy2(str(_internal / _data_file), str(BASE_DIR / _data_file))
            logging.getLogger("notare").info("Copied %s from _internal to app directory", _data_file)
    # Ensure WebView2 Runtime is installed (needed for native window)
    try:
        import winreg
        _wv2_installed = False
        for _hive in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            for _subkey in [
                r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",
                r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",
            ]:
                try:
                    _key = winreg.OpenKey(_hive, _subkey)
                    winreg.CloseKey(_key)
                    _wv2_installed = True
                    break
                except FileNotFoundError:
                    pass
            if _wv2_installed:
                break
        if not _wv2_installed:
            logging.getLogger("notare").info("WebView2 not found — downloading and installing...")
            _wv2_installer = BASE_DIR / "MicrosoftEdgeWebview2Setup.exe"
            if not _wv2_installer.exists():
                import urllib.request
                urllib.request.urlretrieve(
                    "https://go.microsoft.com/fwlink/p/?LinkId=2124703",
                    str(_wv2_installer))
            subprocess.run([str(_wv2_installer), "/silent", "/install"], timeout=120)
            logging.getLogger("notare").info("WebView2 Runtime installed")
    except Exception as e:
        logging.getLogger("notare").warning("WebView2 install check failed: %s", e)
else:
    BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
SESSION_DIR = BASE_DIR / "sessions"
UPLOAD_DIR.mkdir(exist_ok=True)
SESSION_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Notare", version="1.2.0")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.mount("/sessions", StaticFiles(directory=str(SESSION_DIR)), name="session_files")

# Disable Jinja2 template cache and auto_reload for max compatibility
from jinja2 import Environment, FileSystemLoader
_tmpl_dir = BASE_DIR / "templates"
_tmpl_dir.mkdir(exist_ok=True)
_jinja_env = Environment(
    loader=FileSystemLoader(str(_tmpl_dir)),
    cache_size=0,
    auto_reload=False,
)
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
templates.env = _jinja_env

# Settings — configurable API key and engine
_settings_path = BASE_DIR / "settings.json"
SETTINGS = {"engine": "assemblyai", "api_key": "",
            "whisper_model": "small.en", "default_mode": "D", "port": 8080,
            # proofreader_mode: when true, the UI gates proofreaders off
            # from live-reporting controls (share view/edit, streaming).
            # Reporters and proofreaders can share the same app install;
            # this setting flips the surface area per user.
            "proofreader_mode": False}
if _settings_path.exists():
    try:
        SETTINGS.update(json.loads(_settings_path.read_text(encoding="utf-8")))
    except Exception:
        pass

# Always sync version on startup — ensures Settings page shows correct version
# even if the user's settings.json has a stale version from a previous install.
APP_CODE_VERSION = "1.2.0"
if SETTINGS.get("version") != APP_CODE_VERSION:
    SETTINGS["version"] = APP_CODE_VERSION
    try:
        _settings_path.write_text(json.dumps(SETTINGS, indent=2), encoding="utf-8")
    except Exception:
        pass

def _save_settings():
    _settings_path.write_text(json.dumps(SETTINGS, indent=2), encoding="utf-8")

# ── OTA Auto-Update — check remote server on startup ──────────────────────
UPDATE_SERVER = "https://notare-updates.onrender.com"

def _auto_update_on_startup():
    """Check the remote update server and silently apply patches.

    Runs once at startup. Downloads the update zip, extracts patchable files
    (_internal/plugins/, _internal/static/, static/) over the local install.
    The frozen exe itself is not replaced — only overlay files that the plugin
    loader and static file server pick up on next request.
    """
    local_version = SETTINGS.get("version", "0.0.0")
    try:
        import urllib.request as _ur

        # Check for update
        check_url = f"{UPDATE_SERVER}/api/update?current={local_version}"
        with _ur.urlopen(check_url, timeout=10) as resp:
            data = json.loads(resp.read())

        if not data.get("update_available"):
            logger.info("OTA: up to date (v%s)", local_version)
            return

        server_version = data.get("version", "0.0.0")
        download_url = data.get("url", "")
        is_patch = data.get("patch", False)

        # Build full download URL
        if download_url.startswith("/"):
            download_url = UPDATE_SERVER + download_url
        elif not download_url.startswith("http"):
            download_url = f"{UPDATE_SERVER}/api/update/download/{server_version}"

        logger.info("OTA: update available v%s -> v%s, downloading...", local_version, server_version)

        # Download to temp file
        import tempfile as _tf
        tmp = Path(_tf.mktemp(suffix=".zip", prefix="notare_update_"))
        _ur.urlretrieve(download_url, str(tmp))
        logger.info("OTA: downloaded %s (%d bytes)", tmp.name, tmp.stat().st_size)

        # Extract — blacklist user data, allow everything else.
        # app.py is loaded from disk by notare.py (via importlib), so OTA
        # patches to app.py take effect on the next restart.
        import zipfile as _zf
        _never_overwrite = (
            "license.json", "admin_data.json", "settings.json",
            "install_manifest.json", "sessions/", "uploads/",
            "exports/", "templates/",
        )
        extracted = 0
        with _zf.ZipFile(str(tmp), "r") as zf:
            for member in zf.namelist():
                if member.startswith("/") or ".." in member:
                    continue
                if member.endswith("/"):
                    (BASE_DIR / member).mkdir(parents=True, exist_ok=True)
                    continue
                if any(member == p or member.startswith(p) for p in _never_overwrite):
                    continue
                target = BASE_DIR / member
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                extracted += 1

        logger.info("OTA: extracted %d files from v%s", extracted, server_version)

        # Update local version and flag for banner
        SETTINGS["version"] = server_version
        SETTINGS["last_update"] = __import__("datetime").datetime.now().isoformat()
        SETTINGS["updated_silently"] = True
        _save_settings()

        # Cleanup
        try:
            tmp.unlink()
        except Exception:
            pass

        logger.info("OTA: updated to v%s successfully", server_version)

    except Exception as e:
        logger.debug("OTA: update check failed (non-critical): %s", e)

# Run auto-update before anything else loads
try:
    _auto_update_on_startup()
except Exception:
    pass  # Never let update failure block startup


# Persistent state — survives server restart
JOBS = {}
PROFILES = {}
CASES = {}
VOICE_PROFILES = {}  # speaker_name -> embedding data
SPEAKERS_DB = []

_profiles_path = BASE_DIR / "profiles.json"
_speakers_path = BASE_DIR / "speakers.json"
_jobs_path = BASE_DIR / "jobs.json"
_cases_path = BASE_DIR / "cases.json"
_voices_path = BASE_DIR / "voice_profiles.json"

if _profiles_path.exists():
    PROFILES = json.loads(_profiles_path.read_text(encoding="utf-8"))

if _speakers_path.exists():
    SPEAKERS_DB = json.loads(_speakers_path.read_text(encoding="utf-8"))

# Reload jobs from disk (scan session directories)
if SESSION_DIR.exists():
    for job_dir in SESSION_DIR.iterdir():
        if job_dir.is_dir():
            job_file = job_dir / "job.json"
            if job_file.exists():
                try:
                    job = json.loads(job_file.read_text(encoding="utf-8"))
                    job_id = job.get("id", job_dir.name)
                    # Reload transcript if exists
                    transcript_file = job_dir / "transcript.json"
                    if transcript_file.exists() and not job.get("transcript"):
                        job["transcript"] = json.loads(transcript_file.read_text(encoding="utf-8"))
                    if job.get("status") == "processing":
                        job["status"] = "created"  # Reset stuck jobs
                    job["dir"] = str(job_dir)
                    JOBS[job_id] = job
                except Exception:
                    pass
    if JOBS:
        logger.info("Restored %d jobs from disk", len(JOBS))

# ---------------------------------------------------------------------------
# Editor Collaboration — 2-seat transcript sync (Agency tier)
# ---------------------------------------------------------------------------
EDITOR_SESSIONS: dict[str, dict] = {}  # job_id -> {editors: {token: info}, segment_locks: {idx: token}}

# ---------------------------------------------------------------------------
# SSE Infrastructure — shared by live streaming and transcript sync
# Pattern: SSE over WebSockets, corrections flow, privacy-first token auth
# ---------------------------------------------------------------------------
import secrets as _secrets

SSE_CLIENTS: dict[str, list[asyncio.Queue]] = {}  # job_id -> [client queues]
LIVE_SHARES: dict[str, dict] = {}  # share_token -> {job_id, active, created}
TRANSCRIPT_SHARES: dict[str, dict] = {}  # token -> {job_id, created_at, expires_at, permissions}
EXHIBITS: dict[str, list] = {}  # job_id -> [exhibit dicts]

# Persist transcript shares and exhibits
_shares_path = BASE_DIR / "transcript_shares.json"
_exhibits_path = BASE_DIR / "exhibits.json"
if _shares_path.exists():
    try:
        TRANSCRIPT_SHARES = json.loads(_shares_path.read_text(encoding="utf-8"))
    except Exception:
        pass
if _exhibits_path.exists():
    try:
        EXHIBITS = json.loads(_exhibits_path.read_text(encoding="utf-8"))
    except Exception:
        pass

def _save_shares():
    _shares_path.write_text(json.dumps(TRANSCRIPT_SHARES, indent=2, default=str), encoding="utf-8")

def _save_exhibits():
    _exhibits_path.write_text(json.dumps(EXHIBITS, indent=2, default=str), encoding="utf-8")


def _sse_connect(job_id: str) -> asyncio.Queue:
    """Register a new SSE client for a job. Returns their message queue."""
    if job_id not in SSE_CLIENTS:
        SSE_CLIENTS[job_id] = []
    queue = asyncio.Queue()
    SSE_CLIENTS[job_id].append(queue)
    logger.info("SSE client connected for job %s (total: %d)", job_id, len(SSE_CLIENTS[job_id]))
    return queue


def _sse_disconnect(job_id: str, queue: asyncio.Queue):
    """Remove an SSE client. Cleans up empty job entries."""
    if job_id in SSE_CLIENTS:
        try:
            SSE_CLIENTS[job_id].remove(queue)
        except ValueError:
            pass
        if not SSE_CLIENTS[job_id]:
            del SSE_CLIENTS[job_id]
    logger.info("SSE client disconnected for job %s", job_id)


async def _sse_broadcast(job_id: str, event: str, data: dict):
    """Push an event to all connected SSE clients for a job."""
    clients = SSE_CLIENTS.get(job_id, [])
    if not clients:
        return
    msg = f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"
    for queue in list(clients):  # copy list in case of concurrent modification
        try:
            queue.put_nowait(msg)
        except asyncio.QueueFull:
            pass  # drop message rather than block


async def _sse_stream(queue: asyncio.Queue):
    """Async generator that yields SSE messages with keepalive pings."""
    while True:
        try:
            msg = await asyncio.wait_for(queue.get(), timeout=15.0)
            yield msg
        except asyncio.TimeoutError:
            yield ": ping\n\n"  # keepalive — colon prefix = SSE comment
        except asyncio.CancelledError:
            break


@app.get("/api/stream/{job_id}")
async def sse_stream_endpoint(job_id: str, token: str = ""):
    """SSE endpoint — used by live attorney view and editor sync."""
    from starlette.responses import StreamingResponse

    # Validate: either a valid live share token or a valid job ID
    if token:
        share = LIVE_SHARES.get(token)
        if not share or not share.get("active") or share.get("job_id") != job_id:
            return JSONResponse({"error": "Invalid or expired share link"}, status_code=403)
    elif job_id not in JOBS:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    queue = _sse_connect(job_id)

    async def generate():
        try:
            async for msg in _sse_stream(queue):
                yield msg
        finally:
            _sse_disconnect(job_id, queue)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

if _cases_path.exists():
    CASES = json.loads(_cases_path.read_text(encoding="utf-8"))

if _voices_path.exists():
    VOICE_PROFILES = json.loads(_voices_path.read_text(encoding="utf-8"))


def _save_profiles():
    _profiles_path.write_text(json.dumps(PROFILES, indent=2), encoding="utf-8")

def _save_speakers():
    _speakers_path.write_text(json.dumps(SPEAKERS_DB, indent=2), encoding="utf-8")

def _save_cases():
    _cases_path.write_text(json.dumps(CASES, indent=2), encoding="utf-8")

def _save_voices():
    _voices_path.write_text(json.dumps(VOICE_PROFILES, indent=2), encoding="utf-8")

def _feed_word_live_on_complete(job: dict):
    """Feed the entire transcript to Word Live if a session is active. Called on job completion."""
    try:
        from plugins.word_live import feed_word_live, get_word_live_status
        job_id = job.get("id", "")
        if job_id and get_word_live_status(job_id).get("active"):
            segments = job.get("transcript", {}).get("segments", [])
            if segments:
                feed_word_live(job_id, segments)
                logger.info("Word Live: fed %d segments on completion", len(segments))
    except Exception:
        pass  # Word Live is optional — never block transcription


def _save_job(job: dict):
    """Persist job metadata to disk."""
    job_dir = Path(job.get("dir", ""))
    if job_dir.exists():
        # Save job without transcript (transcript saved separately)
        job_data = {k: v for k, v in job.items() if k != "transcript"}
        with open(job_dir / "job.json", "w", encoding="utf-8") as f:
            json.dump(job_data, f, indent=2, default=str)


# ---------------------------------------------------------------------------
# Routes — Static pages (no Jinja2 templates — pure HTML + JS)
# ---------------------------------------------------------------------------
from fastapi.responses import RedirectResponse

@app.get("/")
async def home():
    return RedirectResponse("/static/index.html")

# JSON API endpoints for the static pages
@app.get("/api/jobs")
async def list_jobs():
    return JSONResponse({k: {**v, "dir": ""} for k, v in JOBS.items()})

@app.get("/api/profiles")
async def list_profiles():
    return JSONResponse(PROFILES)


# ---------------------------------------------------------------------------
# Routes — API
# ---------------------------------------------------------------------------

@app.post("/api/job/create")
async def create_job(
    capture_mode: str = Form("D"),
    title: str = Form(""),
    court_name: str = Form(""),
    case_number: str = Form(""),
    case_caption: str = Form(""),
    proceeding_type: str = Form("Hearing"),
    date: str = Form(""),
    location: str = Form(""),
    reporter_name: str = Form(""),
    reporter_credential: str = Form(""),
    time_in: str = Form(""),
    time_out: str = Form(""),
    job_number: str = Form(""),
    jurisdiction_profile: str = Form(""),
    speakers: str = Form("[]"),
    channels: str = Form("[]"),
    files: list[UploadFile] = File(None),
):
    # Tier gate — Mode D (batch processing) requires Professional+
    if capture_mode.upper() == "D":
        gate = _require_pro("Batch processing (Mode D)")
        if gate:
            return gate

    job_id = str(uuid.uuid4())[:8]
    job_dir = SESSION_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    audio_dir = job_dir / "audio"
    audio_dir.mkdir(exist_ok=True)

    uploaded_files = []
    if files:
        for f in files:
            if f.filename:
                dest = audio_dir / f.filename
                with open(dest, "wb") as out:
                    content = await f.read()
                    out.write(content)
                uploaded_files.append(str(dest))

    try:
        speaker_list = json.loads(speakers)
    except (json.JSONDecodeError, TypeError):
        speaker_list = []

    try:
        channel_list = json.loads(channels)
    except (json.JSONDecodeError, TypeError):
        channel_list = []

    for s in speaker_list:
        name = s.get("name", "")
        if name and name not in [x.get("name") for x in SPEAKERS_DB]:
            SPEAKERS_DB.append(s)
    if speaker_list:
        _save_speakers()

    profile = PROFILES.get(jurisdiction_profile, {})

    # Build title from case info if not provided
    if not title and case_caption:
        title = case_caption
        if proceeding_type:
            title += f" — {proceeding_type}"
        if date:
            title += f" {date}"

    job = {
        "id": job_id,
        "title": title,
        "capture_mode": capture_mode,
        "court_name": court_name or profile.get("court_name", ""),
        "case_number": case_number,
        "case_caption": case_caption,
        "proceeding_type": proceeding_type,
        "date": date or datetime.now().strftime("%Y-%m-%d"),
        "location": location or profile.get("location", ""),
        "reporter_name": reporter_name or profile.get("reporter_name", ""),
        "reporter_credential": reporter_credential or profile.get("reporter_credential", ""),
        "time_in": time_in,
        "time_out": time_out,
        "job_number": job_number,
        "jurisdiction_profile": jurisdiction_profile,
        "profile": profile,
        "speakers": speaker_list,
        "channels": channel_list,
        "files": uploaded_files,
        "status": "created",
        "created_at": datetime.now().isoformat(),
        "transcript": None,
        "flags": [],
        "dir": str(job_dir),
    }
    JOBS[job_id] = job

    with open(job_dir / "job.json", "w", encoding="utf-8") as f:
        json.dump(job, f, indent=2, default=str)

    return JSONResponse({"job_id": job_id, "status": "created"})


@app.get("/api/job/{job_id}/detect-channels")
async def detect_channels(job_id: str):
    """Detect number of audio channels in uploaded WAV files.
    Multi-channel WAV (e.g. from FTR Manager export) = one channel per microphone."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    job_dir = Path(job["dir"]) / "audio"
    if not job_dir.exists():
        return JSONResponse({"channels": 1})
    wav_files = sorted(job_dir.glob("*.wav"))
    if not wav_files:
        return JSONResponse({"channels": 1})
    try:
        import wave
        with wave.open(str(wav_files[0]), "rb") as wf:
            n = wf.getnchannels()
        return JSONResponse({"channels": n, "file": wav_files[0].name})
    except Exception as e:
        return JSONResponse({"channels": 1, "error": str(e)})


@app.post("/api/job/{job_id}/channel-labels")
async def set_channel_labels(job_id: str, request: Request):
    """Set speaker labels for each audio channel.
    Body: {"labels": {"0": "THE COURT", "1": "THE WITNESS", "2": "Counsel"}}"""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    data = await request.json()
    labels = data.get("labels", {})
    job["channel_labels"] = labels
    _save_job(job)
    logger.info("Channel labels set for job %s: %s", job_id, labels)
    return JSONResponse({"ok": True, "labels": labels})


@app.post("/api/parse-ftr-log")
async def parse_ftr_log(file: UploadFile = File(...)):
    """Parse an FTR .htm sidecar log file to extract case info and session metadata.

    FTR log files are HTML tables with:
    - Header rows: Description (judge/case), Date, Location
    - Data rows: Time (with FTR timestamp link) | Speaker | Note
    - Notes contain case numbers, hearing types, defendant names, attorney announcements

    Returns structured data that can auto-populate job fields and suggest channel labels.
    """
    from html.parser import HTMLParser

    content_bytes = await file.read()
    # Try common encodings
    content = None
    for enc in ("utf-8", "utf-16", "cp1252", "latin-1"):
        try:
            content = content_bytes.decode(enc)
            break
        except (UnicodeDecodeError, UnicodeError):
            continue
    if content is None:
        return JSONResponse({"error": "Could not decode file"}, status_code=400)

    class _FTRLogParser(HTMLParser):
        def __init__(self):
            super().__init__()
            self.metadata = {}
            self.entries = []
            self._in_td = False
            self._in_th = False
            self._current_row = []
            self._current_text = ""
            self._current_href = ""
            self._in_a = False
            self._past_headers = False
            self._header_rows_seen = 0

        def handle_starttag(self, tag, attrs):
            attrs_d = dict(attrs)
            if tag == "tr":
                self._current_row = []
                self._current_text = ""
                self._current_href = ""
            elif tag in ("td", "th"):
                self._in_td = tag == "td"
                self._in_th = tag == "th"
                self._current_text = ""
                self._current_href = ""
            elif tag == "a":
                self._in_a = True
                self._current_href = attrs_d.get("href", "")
            elif tag == "br":
                self._current_text += "\n"

        def handle_endtag(self, tag):
            if tag in ("td", "th"):
                self._current_row.append({
                    "text": self._current_text.strip(),
                    "href": self._current_href,
                    "is_header": self._in_th,
                })
                self._in_td = False
                self._in_th = False
            elif tag == "a":
                self._in_a = False
            elif tag == "tr":
                self._process_row()

        def handle_data(self, data):
            if self._in_td or self._in_th or self._in_a:
                self._current_text += data

        def handle_entityref(self, name):
            entities = {"nbsp": " ", "quot": '"', "amp": "&", "lt": "<", "gt": ">"}
            self._current_text += entities.get(name, "")

        def _process_row(self):
            cells = self._current_row
            if not cells:
                return
            # Header rows: Description, Date/Location, column headers
            if not self._past_headers:
                if any(c.get("is_header") for c in cells):
                    text_vals = [c["text"] for c in cells]
                    if any("description" in t.lower() for t in text_vals):
                        for c in cells:
                            if not c["is_header"] and c["text"]:
                                self.metadata["description"] = c["text"]
                    elif any("date" in t.lower() for t in text_vals):
                        for i, c in enumerate(cells):
                            if "date" in c["text"].lower() and i + 1 < len(cells):
                                self.metadata["date"] = cells[i + 1]["text"]
                            if "location" in c["text"].lower() and i + 1 < len(cells):
                                self.metadata["location"] = cells[i + 1]["text"]
                    elif any("time" in t.lower() for t in text_vals):
                        self._past_headers = True
                    self._header_rows_seen += 1
                    if self._header_rows_seen >= 3:
                        self._past_headers = True
                return
            # Data rows: Time | Speaker | Note
            texts = [c["text"] for c in cells]
            if all(not t or t.isspace() for t in texts):
                return
            entry = {"time": "", "speaker": "", "note": ""}
            if cells:
                entry["time"] = cells[0]["text"].strip()
            if len(cells) > 1:
                entry["speaker"] = cells[1]["text"].strip()
            if len(cells) > 2:
                note_parts = [cells[i]["text"].strip() for i in range(2, len(cells)) if cells[i]["text"].strip()]
                entry["note"] = " ".join(note_parts)
            # Extract case info from notes
            import re as _re
            cn = _re.search(r'Case Number:\s*(\S+)', entry["note"])
            if cn:
                entry["case_number"] = cn.group(1)
            vs = _re.search(r'(?:State of \w+ vs\.?\s+|vs\.?\s+)(.+?)(?:\s+Case Number:|\s*$)', entry["note"])
            if vs:
                entry["defendant"] = vs.group(1).strip().rstrip(",")
            ht = _re.search(r'Hearing\s*-\s*([^;,]+)', entry["note"])
            if ht:
                entry["hearing_type"] = ht.group(1).strip()
            self.entries.append(entry)

    parser = _FTRLogParser()
    parser.feed(content)

    # Extract judge from description
    judge = ""
    desc = parser.metadata.get("description", "")
    jm = re.search(r'Judge\s+(\w[\w\s]*\w)', desc, re.IGNORECASE)
    if jm:
        judge = f"Judge {jm.group(1).strip()}"

    # Collect unique speakers from entries
    speakers = list(dict.fromkeys(e["speaker"] for e in parser.entries if e["speaker"]))

    # Find case info from first "Called" entry
    case_info = {}
    for e in parser.entries:
        if e["speaker"] in ("Called", "Called:") and e.get("case_number"):
            case_info = {
                "case_number": e.get("case_number", ""),
                "defendant": e.get("defendant", ""),
                "hearing_type": e.get("hearing_type", ""),
            }
            break

    result = {
        "metadata": parser.metadata,
        "judge": judge,
        "speakers": speakers,
        "case_info": case_info,
        "entry_count": len(parser.entries),
        "entries": parser.entries[:50],  # First 50 for preview
    }
    logger.info("FTR log parsed: %d entries, judge=%s, speakers=%s",
                len(parser.entries), judge, speakers[:5])
    return JSONResponse(result)


@app.post("/api/job/{job_id}/process")
async def process_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    job["status"] = "processing"
    threading.Thread(target=_run_transcription, args=(job,), daemon=True).start()
    return JSONResponse({"status": "processing"})


@app.get("/api/job/{job_id}/status")
async def job_status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    profile = job.get("profile", {})
    return JSONResponse({
        "status": job["status"],
        "progress": job.get("progress", 0),
        "progress_message": job.get("progress_message", ""),
        "transcript": job.get("transcript"),
        "error": job.get("error"),
        "audio_file": job.get("audio_file", ""),
        "court_name": job.get("court_name", ""),
        "case_number": job.get("case_number", ""),
        "case_caption": job.get("case_caption", ""),
        "proceeding_type": job.get("proceeding_type", ""),
        "date": job.get("date", ""),
        "reporter_name": job.get("reporter_name", ""),
        "reporter_credential": job.get("reporter_credential", ""),
        "time_in": job.get("time_in", ""),
        "time_out": job.get("time_out", ""),
        "job_number": job.get("job_number", ""),
        "location": job.get("location", ""),
        "speakers": job.get("speakers", []),
        "flags": job.get("flags", []),
        "hotkeys": profile.get("hotkeys", {}),
    })


@app.post("/api/job/{job_id}/update-segment")
async def update_segment(job_id: str, request: Request):
    job = JOBS.get(job_id)
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Not found"}, status_code=404)
    data = await request.json()
    idx = data.get("index")
    new_text = data.get("text", "")
    new_style = data.get("style")
    new_qa_role = data.get("qa_role")
    segments = job["transcript"].get("segments", [])
    if idx is not None and 0 <= idx < len(segments):
        # Style update (can be sent without text)
        if new_style:
            segments[idx]["style"] = new_style
            if new_qa_role:
                segments[idx]["qa_role"] = new_qa_role
            if not new_text:
                job_dir = Path(job["dir"])
                with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
                    json.dump(job["transcript"], f, indent=2)
                return JSONResponse({"ok": True, "style": new_style})

        original_text = segments[idx].get("text", "")
        segments[idx]["text"] = new_text
        segments[idx]["edited"] = True
        job_dir = Path(job["dir"])

        # Log correction for training data collection
        # Only log if text actually changed (not just a click-away)
        if original_text.strip() != new_text.strip() and original_text.strip():
            try:
                correction_log = job_dir / "corrections.jsonl"
                seg = segments[idx]
                correction = {
                    "original": original_text,
                    "corrected": new_text,
                    "timestamp": seg.get("start", 0),
                    "end": seg.get("end", 0),
                    "speaker": seg.get("speaker", ""),
                    "confidence": seg.get("confidence", 0),
                    "audio_file": job.get("audio_file", ""),
                    "edited_at": datetime.now().isoformat(),
                }
                with open(correction_log, "a", encoding="utf-8") as cl:
                    cl.write(json.dumps(correction) + "\n")
            except Exception:
                pass  # Never block editing for logging
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            json.dump(job["transcript"], f, indent=2)
        # Broadcast correction to live viewers and synced editors
        await _sse_broadcast(job_id, "segment_update", {
            "index": idx, "text": new_text,
            "speaker": segments[idx].get("speaker", ""),
        })
        return JSONResponse({"ok": True})
    return JSONResponse({"error": "Invalid index"}, status_code=400)


@app.post("/api/open-folder")
async def open_folder(request: Request):
    """Open the containing folder in Explorer and select the file."""
    data = await request.json()
    file_path = data.get("path", "")
    if not file_path or not os.path.exists(file_path):
        return JSONResponse({"ok": False})
    # Only allow paths we own — BASE_DIR tree, session/upload dirs, or the
    # user's Documents. Prevents a LAN caller from coaxing Explorer into opening
    # arbitrary system locations via this endpoint.
    try:
        resolved = Path(file_path).resolve()
        allowed_roots = [
            BASE_DIR.resolve(),
            SESSION_DIR.resolve() if 'SESSION_DIR' in globals() else None,
            UPLOAD_DIR.resolve() if 'UPLOAD_DIR' in globals() else None,
            Path.home().resolve() / "Documents",
        ]
        if not any(root is not None and str(resolved).startswith(str(root)) for root in allowed_roots):
            return JSONResponse({"ok": False, "error": "Path outside allowed directories"})
    except Exception:
        return JSONResponse({"ok": False})
    try:
        # List-form Popen — no shell, no command injection via embedded quotes.
        subprocess.Popen(["explorer", f"/select,{resolved}"])
        return JSONResponse({"ok": True})
    except Exception:
        return JSONResponse({"ok": False})


@app.post("/api/upload-template")
async def upload_template(file: UploadFile = File(...)):
    """Upload a Word template (.dotm/.dotx), store it, and auto-detect styles."""
    templates_dir = BASE_DIR / "templates"
    templates_dir.mkdir(exist_ok=True)
    dest = templates_dir / file.filename
    content = await file.read()
    # DOCX/DOTM/DOCM/DOTX are all Open Office XML (zip) containers — reject
    # anything that isn't a valid zip so we don't store garbage the user will
    # hit later when they try to use the template.
    import zipfile as _zf_check, io as _io_check
    if not _zf_check.is_zipfile(_io_check.BytesIO(content)):
        return JSONResponse(
            {"ok": False, "error": "Not a valid Word template — the file is not an Open Office XML document (.docx / .dotx / .docm / .dotm)."},
            status_code=400,
        )
    with open(dest, "wb") as f:
        f.write(content)
    logger.info("Template uploaded: %s (%d bytes)", file.filename, len(content))

    # Auto-detect paragraph styles from the template
    detected_styles = {}
    try:
        from docx import Document as _Doc
        import zipfile as _zf, io as _io

        # Convert .dotm to .docx for reading
        ext = Path(file.filename).suffix.lower()
        if ext in ('.dotm', '.docm'):
            with _zf.ZipFile(str(dest), 'r') as zin:
                buf = _io.BytesIO()
                with _zf.ZipFile(buf, 'w', _zf.ZIP_DEFLATED) as zout:
                    for item in zin.namelist():
                        if 'vbaProject' in item:
                            continue
                        data = zin.read(item)
                        if item == '[Content_Types].xml':
                            data = data.replace(
                                b'application/vnd.ms-word.template.macroEnabledTemplate.main+xml',
                                b'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml')
                            data = re.sub(rb'<Default Extension="bin"[^/]*/>', b'', data)
                            data = re.sub(rb'<Override[^>]*vbaProject[^>]*/>', b'', data)
                        elif item == 'word/_rels/document.xml.rels':
                            data = re.sub(rb'<Relationship[^>]*vbaProject[^>]*/>', b'', data)
                        zout.writestr(item, data)
                _tmp = templates_dir / "_detect_tmp.docx"
                with open(str(_tmp), 'wb') as tf:
                    tf.write(buf.getvalue())
                doc = _Doc(str(_tmp))
                _tmp.unlink(missing_ok=True)
        else:
            doc = _Doc(str(dest))

        # Scan all paragraph styles — map common court transcript style names
        style_names = [s.name for s in doc.styles if s.type is not None and s.type.name == 'PARAGRAPH']

        # Auto-map by common naming patterns
        _style_patterns = {
            "colloquy": ["colloquy", "cccolloquy", "dialog", "dialogue", "speaker"],
            "qa": ["qanda", "q&a", "ccqanda", "question", "examination"],
            "parenthetical": ["parenthetical", "ccparenthetical", "paren", "direction", "stage"],
            "speaker_id": ["speakerid", "speaker_id", "speakername", "witness", "attorney"],
            "quoted": ["quoted", "ccquoted", "quote", "blockquote"],
        }

        for field, patterns in _style_patterns.items():
            for style_name in style_names:
                name_lower = style_name.lower().replace(" ", "").replace("_", "")
                if any(p in name_lower for p in patterns):
                    detected_styles[field] = style_name
                    break

        logger.info("Auto-detected %d styles from template: %s", len(detected_styles), detected_styles)

    except Exception as e:
        logger.warning("Style detection failed: %s", e)

    return JSONResponse({
        "ok": True,
        "path": str(dest),
        "filename": file.filename,
        "detected_styles": detected_styles,
        "all_styles": [s for s in style_names] if 'style_names' in dir() else [],
    })


@app.post("/api/job/{job_id}/update-title")
async def update_title(job_id: str, request: Request):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)
    data = await request.json()
    job["title"] = data.get("title", "")
    _save_job(job)
    return JSONResponse({"ok": True})


@app.post("/api/job/{job_id}/update-speaker")
async def update_speaker(job_id: str, request: Request):
    job = JOBS.get(job_id)
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Not found"}, status_code=404)
    data = await request.json()
    idx = data.get("index")
    new_speaker = data.get("speaker", "")
    segments = job["transcript"].get("segments", [])
    if idx is not None and 0 <= idx < len(segments):
        old_speaker = segments[idx].get("speaker", "")
        segments[idx]["speaker"] = new_speaker

        # Propagate: rename ALL segments with the same old speaker label
        renamed_count = 0
        if old_speaker and old_speaker != new_speaker:
            for i, seg in enumerate(segments):
                if i != idx and seg.get("speaker") == old_speaker:
                    seg["speaker"] = new_speaker
                    renamed_count += 1
                    # Broadcast each change to live viewers
                    await _sse_broadcast(job_id, "segment_update", {
                        "index": i, "text": seg.get("text", ""),
                        "speaker": new_speaker,
                    })

        # Update speaker map if one exists
        speaker_map = job["transcript"].get("speaker_map", {})
        if old_speaker in speaker_map:
            speaker_map[old_speaker] = new_speaker

        # Persist to disk
        job_dir = Path(job["dir"])
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            json.dump(job["transcript"], f, indent=2)

        # Broadcast the initial change
        await _sse_broadcast(job_id, "segment_update", {
            "index": idx, "text": segments[idx].get("text", ""),
            "speaker": new_speaker,
        })

        logger.info("Speaker renamed: '%s' → '%s' (%d additional segments updated)",
                    old_speaker, new_speaker, renamed_count)
        return JSONResponse({"ok": True, "renamed": renamed_count + 1})
    return JSONResponse({"error": "Invalid index"}, status_code=400)


def _get_license_tier():
    """Get the current license tier. Returns tier string or 'unknown'."""
    license_file = BASE_DIR / "license.json"
    if license_file.exists():
        try:
            data = json.loads(license_file.read_text(encoding="utf-8"))
            return data.get("tier", "unknown")
        except Exception:
            pass
    return "unknown"


_PROFESSIONAL_TIERS = {"professional", "agency", "enterprise", "support", "trial"}


def _require_pro(feature_name: str):
    """Check if the current license tier is Professional or above.
    Returns None if allowed, or a JSONResponse to return if not."""
    tier = _get_license_tier()
    if tier not in _PROFESSIONAL_TIERS:
        return JSONResponse({
            "status": "upgrade_required",
            "message": f"{feature_name} is available on Professional plans and above.",
            "current_tier": tier,
        })
    return None


@app.post("/api/compare-documents")
async def compare_documents(original: UploadFile = File(...), revised: UploadFile = File(...)):
    """Compare two documents and generate a visual redline.

    Standalone comparison — not tied to a job. Upload any two documents
    (.docx, .txt, .pdf) and get a detailed diff with line-by-line changes.

    Use cases: proofreading verification, edit tracking, academic integrity,
    compliance auditing, legal transcript review.
    """
    gate = _require_pro("Document comparison & redline")
    if gate:
        return gate

    import difflib

    def _extract_text(content, ext):
        lines = []
        if ext == ".txt":
            lines = content.decode("utf-8", errors="replace").split("\n")
        elif ext in (".docx", ".doc"):
            from docx import Document as DocxDoc
            import io
            doc = DocxDoc(io.BytesIO(content))
            lines = [p.text for p in doc.paragraphs if p.text.strip()]
        elif ext == ".pdf":
            import pdfplumber
            import io
            with pdfplumber.open(io.BytesIO(content)) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        lines.extend(page_text.split("\n"))
        return [l.strip() for l in lines if l.strip()]

    try:
        orig_content = await original.read()
        rev_content = await revised.read()
        orig_ext = Path(original.filename).suffix.lower()
        rev_ext = Path(revised.filename).suffix.lower()

        orig_lines = _extract_text(orig_content, orig_ext)
        rev_lines = _extract_text(rev_content, rev_ext)

        if not orig_lines:
            return JSONResponse({"error": "Could not extract text from original document"}, status_code=400)
        if not rev_lines:
            return JSONResponse({"error": "Could not extract text from revised document"}, status_code=400)

        # Generate diff
        differ = difflib.SequenceMatcher(None, orig_lines, rev_lines)
        changes = []
        summary = {"additions": 0, "deletions": 0, "modifications": 0, "unchanged": 0}

        for tag, i1, i2, j1, j2 in differ.get_opcodes():
            if tag == "equal":
                summary["unchanged"] += (i2 - i1)
                for idx in range(i1, i2):
                    changes.append({"type": "unchanged", "line": idx + 1, "text": orig_lines[idx]})
            elif tag == "replace":
                for idx in range(max(i2 - i1, j2 - j1)):
                    orig = orig_lines[i1 + idx] if (i1 + idx) < i2 else ""
                    rev = rev_lines[j1 + idx] if (j1 + idx) < j2 else ""
                    if orig and rev:
                        changes.append({"type": "modified", "line": i1 + idx + 1, "original": orig, "revised": rev})
                        summary["modifications"] += 1
                    elif orig:
                        changes.append({"type": "deleted", "line": i1 + idx + 1, "original": orig})
                        summary["deletions"] += 1
                    else:
                        changes.append({"type": "added", "line": j1 + idx + 1, "revised": rev})
                        summary["additions"] += 1
            elif tag == "delete":
                for idx in range(i1, i2):
                    changes.append({"type": "deleted", "line": idx + 1, "original": orig_lines[idx]})
                    summary["deletions"] += 1
            elif tag == "insert":
                for idx in range(j1, j2):
                    changes.append({"type": "added", "line": idx + 1, "revised": rev_lines[idx]})
                    summary["additions"] += 1

        total_changes = summary["additions"] + summary["deletions"] + summary["modifications"]
        similarity = round(differ.ratio() * 100, 1)

        return JSONResponse({
            "ok": True,
            "original_file": original.filename,
            "revised_file": revised.filename,
            "original_lines": len(orig_lines),
            "revised_lines": len(rev_lines),
            "total_changes": total_changes,
            "similarity": similarity,
            "summary": summary,
            "changes": changes,
        })
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/job/{job_id}/reanalyze-speakers")
async def reanalyze_speakers(job_id: str):
    """Re-run speaker diarization on a completed job.

    Tries pyannote first (best quality), falls back to ONNX, then heuristic.
    If pyannote isn't installed, returns a prompt to download it.
    Professional tier and above only.
    """
    gate = _require_pro("Enhanced speaker analysis")
    if gate:
        return gate

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)

    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return JSONResponse({"error": "No transcript to reanalyze"}, status_code=400)

    # Check if pyannote is available
    pyannote_available = False

    # Priority 1: Smart installer provided env (manifest-based)
    _manifest_path = BASE_DIR / "install_manifest.json"
    if _manifest_path.exists():
        try:
            _manifest = json.loads(_manifest_path.read_text(encoding="utf-8"))
            _installed = _manifest.get("installed_tiers", [])
            for _env_name in ["_gpu_env", "_cpu_env"]:
                if _env_name.replace("_env", "") in [t for t in _installed if t in ("gpu", "cpu")]:
                    _candidate = BASE_DIR / _env_name / "Scripts" / "python.exe"
                    if _candidate.exists():
                        pyannote_available = True
                        break
        except Exception:
            pass

    # Priority 2: Native import (dev machine with pyannote installed)
    if not pyannote_available:
        try:
            from pyannote.audio import Pipeline as _TestPipeline
            for model_root in [BASE_DIR / "_internal" / "_pyannote_models", BASE_DIR / "_pyannote_models"]:
                for model_dir in [model_root, model_root / "pipeline"]:
                    if (model_dir / "config.yaml").exists():
                        pyannote_available = True
                        break
                if pyannote_available:
                    break
            if not pyannote_available:
                hf_token = SETTINGS.get("hf_token", "") or os.environ.get("HF_TOKEN", "")
                if hf_token:
                    pyannote_available = True
        except Exception:
            pass

    # Priority 3: Legacy on-demand env
    _pyannote_env = BASE_DIR / "_pyannote_env"
    if not pyannote_available and (_pyannote_env / "Scripts" / "python.exe").exists():
        if not (_pyannote_env / ".downloading").exists():
            pyannote_available = True

    if not pyannote_available:
        # Check if download is already in progress
        if _pyannote_env.exists() and (_pyannote_env / ".downloading").exists():
            return JSONResponse({
                "status": "downloading",
                "message": "Enhanced speaker analysis engine is downloading. This may take a few minutes."
            })
        return JSONResponse({
            "status": "needs_download",
            "message": "For best results, Notare can download an enhanced speaker analysis engine (~2GB). This is a one-time download.",
            "download_size": "~2 GB",
        })

    # Clear existing speaker labels so diarization runs fresh
    for seg in transcript["segments"]:
        seg["speaker"] = ""
    transcript.pop("diarization", None)
    transcript.pop("speaker_map", None)
    transcript.pop("speakers_identified", None)

    # Estimate processing time based on audio duration and hardware
    _has_gpu = False
    try:
        import torch as _torch_check
        _has_gpu = _torch_check.cuda.is_available() if hasattr(_torch_check, 'cuda') else False
    except Exception:
        pass  # No torch on this machine — CPU assumed
    _duration_s = transcript.get("duration", 0) / 1000 if transcript.get("duration", 0) > 1000 else transcript.get("duration", 0)
    # Rough estimates: GPU ~0.1x realtime, CPU ~0.8-1.2x realtime
    if _has_gpu:
        _est_minutes = max(1, int(_duration_s * 0.1 / 60))
    else:
        _est_minutes = max(1, int(_duration_s * 1.0 / 60))
    _est_label = f"~{_est_minutes} minute{'s' if _est_minutes != 1 else ''}"
    if _est_minutes > 60:
        _est_label = f"~{_est_minutes // 60}h {_est_minutes % 60}m"

    # Run diarization pipeline in background
    import threading
    import time as _time

    _reanalyze_done = threading.Event()

    def _heartbeat():
        """Update progress message periodically so the user knows it's still working."""
        device_label = "GPU" if _has_gpu else "CPU"
        _start = _time.time()
        _messages = [
            "Analyzing audio patterns",
            "Processing speaker voices",
            "Mapping speaker segments",
            "Refining speaker boundaries",
            "Cross-referencing voice profiles",
            "Building speaker model",
            "Verifying speaker assignments",
        ]
        _idx = 0
        while not _reanalyze_done.wait(timeout=30):
            elapsed = int((_time.time() - _start) / 60)
            msg = _messages[_idx % len(_messages)]
            remaining = max(0, _est_minutes - elapsed)
            if remaining > 60:
                time_note = f"{remaining // 60}h {remaining % 60}m remaining"
            elif remaining > 0:
                time_note = f"~{remaining} min remaining"
            else:
                time_note = "almost done"
            job["progress_message"] = f"{msg} ({device_label}, {time_note})... This is normal for longer recordings — your transcript is safe."
            _save_job(job)
            _idx += 1

    threading.Thread(target=_heartbeat, daemon=True).start()

    def _reanalyze():
        try:
            device_label = "GPU" if _has_gpu else "CPU"
            job["progress_message"] = f"Reanalyzing speakers ({device_label}, estimated {_est_label})..."
            _save_job(job)

            # Save existing speaker names so we can remap after diarization
            _old_speakers = {}
            for seg in transcript.get("segments", []):
                spk = seg.get("speaker", "").strip()
                if spk and not spk.startswith("Speaker "):
                    _old_speakers[seg.get("start", 0)] = spk

            # Clear labels so diarization doesn't skip
            for seg in transcript.get("segments", []):
                seg["speaker"] = ""

            if not _diarize_with_pyannote(job):
                if not _diarize_audio(job):
                    _assign_speakers_heuristic(job)
            _reanalyze_done.set()

            # Remap cluster labels to real speaker names using overlap
            # The diarization assigned generic labels (Speaker 1, etc.)
            # Map them back to known names by checking which old name
            # most frequently appears at the same timestamps
            if _old_speakers:
                _new_to_old = {}
                for seg in transcript.get("segments", []):
                    new_label = seg.get("speaker", "")
                    old_label = _old_speakers.get(seg.get("start", 0), "")
                    if new_label and old_label:
                        _new_to_old.setdefault(new_label, []).append(old_label)
                # For each new label, pick the most common old name
                from collections import Counter
                _label_map = {}
                for new_label, old_labels in _new_to_old.items():
                    most_common = Counter(old_labels).most_common(1)
                    if most_common:
                        _label_map[new_label] = most_common[0][0]
                # Apply the mapping
                if _label_map:
                    for seg in transcript.get("segments", []):
                        spk = seg.get("speaker", "")
                        if spk in _label_map:
                            seg["speaker"] = _label_map[spk]
                    logger.info("Reanalyze name remap: %s", _label_map)

            try:
                _identify_speakers_from_appearances(job)
            except Exception:
                pass
            try:
                _cleanup_speaker_names(job)
            except Exception:
                pass

            # Save updated transcript
            job_dir = Path(job.get("dir", ""))
            if job_dir.exists():
                # Re-fetch transcript from job in case plugin modified the reference
                _transcript = job.get("transcript", transcript)
                with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
                    json.dump(_transcript, f, indent=2)

            _transcript = job.get("transcript", transcript)
            engine = _transcript.get("diarization", "unknown")
            unique = len(set(s.get("speaker", "") for s in _transcript.get("segments", []) if s.get("speaker")))
            job["progress_message"] = f"Speaker reanalysis complete ({engine}, {unique} speakers)"
            _save_job(job)
            logger.info("Speaker reanalysis complete: %s, %d speakers", engine, unique)
        except Exception as e:
            _reanalyze_done.set()
            # Check if speakers were actually generated despite the error
            _transcript = job.get("transcript", {})
            _segments = _transcript.get("segments", [])
            _speakers = set(s.get("speaker", "") for s in _segments if s.get("speaker", "").strip())
            if len(_speakers) >= 2:
                # Diarization succeeded but post-processing failed — report success with warning
                logger.warning("Speaker reanalysis post-processing error (%s) but %d speakers found — reporting success", e, len(_speakers))
                job["progress_message"] = f"Speaker reanalysis complete ({len(_speakers)} speakers, with warnings)"
                _save_job(job)
                # Still save the transcript with the good speaker data
                job_dir = Path(job.get("dir", ""))
                if job_dir.exists():
                    try:
                        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
                            json.dump(_transcript, f, indent=2)
                    except Exception:
                        pass
            else:
                logger.warning("Speaker reanalysis failed: %s", e)
                job["progress_message"] = f"Speaker reanalysis failed: {e}"
                _save_job(job)
        finally:
            # Guarantee the heartbeat stops and a final status is always set
            _reanalyze_done.set()
            if "complete" not in job.get("progress_message", "") and "failed" not in job.get("progress_message", ""):
                job["progress_message"] = "Speaker reanalysis complete (finished with unknown status)"
                _save_job(job)

    threading.Thread(target=_reanalyze, daemon=True).start()
    device_label = "GPU" if _has_gpu else "CPU"
    return JSONResponse({
        "status": "running",
        "message": f"Reanalyzing speakers ({device_label}, estimated {_est_label})...",
        "estimated_minutes": _est_minutes,
        "device": device_label,
    })


@app.post("/api/pyannote/download")
async def download_pyannote():
    """Download and install the enhanced speaker analysis engine (pyannote + PyTorch).

    One-time download (~2GB). Installs to _pyannote_env/ as a self-contained Python environment.
    If the smart installer already provided an env, return immediately.
    """
    # Short-circuit if smart installer already handled this
    _manifest_path = BASE_DIR / "install_manifest.json"
    if _manifest_path.exists():
        try:
            _manifest = json.loads(_manifest_path.read_text(encoding="utf-8"))
            _installed = _manifest.get("installed_tiers", [])
            for _env_name, _tier in [("_gpu_env", "gpu"), ("_cpu_env", "cpu")]:
                if _tier in _installed and (BASE_DIR / _env_name / "Scripts" / "python.exe").exists():
                    return JSONResponse({"status": "available", "source": f"installer_{_env_name}"})
        except Exception:
            pass

    _pyannote_env = BASE_DIR / "_pyannote_env"
    if (_pyannote_env / ".downloading").exists():
        return JSONResponse({"status": "already_downloading"})

    import threading
    def _install():
        try:
            # Clean up any failed previous attempt
            if _pyannote_env.exists():
                import shutil as _sh
                _sh.rmtree(str(_pyannote_env), ignore_errors=True)

            _pyannote_env.mkdir(parents=True, exist_ok=True)
            (_pyannote_env / ".downloading").touch()
            logger.info("Starting pyannote environment download...")

            import subprocess as _sp

            # Find the system Python — frozen exe's sys.executable is Notare.exe
            _python = None
            for _candidate in [
                r"C:\Users\Owner\AppData\Local\Programs\Python\Python312\python.exe",
                r"C:\Python312\python.exe",
                r"C:\Python311\python.exe",
            ]:
                if Path(_candidate).exists():
                    _python = _candidate
                    break
            if not _python:
                # Try to find python on PATH
                _r = _sp.run(["where", "python"], capture_output=True, text=True, timeout=10)
                if _r.returncode == 0 and _r.stdout.strip():
                    _python = _r.stdout.strip().split("\n")[0].strip()

            if not _python:
                raise RuntimeError("System Python not found — cannot create pyannote environment")

            logger.info("Using system Python: %s", _python)

            # Create a self-contained venv
            _r = _sp.run([_python, "-m", "venv", str(_pyannote_env)],
                         capture_output=True, text=True, timeout=120)
            if _r.returncode != 0:
                raise RuntimeError(f"venv creation failed: {_r.stderr[:200]}")
            logger.info("Venv created at %s", _pyannote_env)

            _pip = str(_pyannote_env / "Scripts" / "pip.exe")

            # Install torch (CPU version to keep size down unless CUDA available)
            logger.info("Installing PyTorch (this may take several minutes)...")
            (_pyannote_env / ".status").write_text("Installing PyTorch...")
            _r = _sp.run([_pip, "install", "torch", "torchaudio", "--index-url",
                          "https://download.pytorch.org/whl/cpu"],
                         capture_output=True, text=True, timeout=1800)
            if _r.returncode != 0:
                raise RuntimeError(f"PyTorch install failed: {_r.stderr[-300:]}")
            logger.info("PyTorch installed")

            # Install pyannote.audio
            logger.info("Installing pyannote.audio + soundfile...")
            (_pyannote_env / ".status").write_text("Installing pyannote.audio...")
            _r = _sp.run([_pip, "install", "pyannote.audio", "soundfile"],
                         capture_output=True, text=True, timeout=600)
            if _r.returncode != 0:
                raise RuntimeError(f"pyannote install failed: {_r.stderr[-300:]}")

            (_pyannote_env / ".downloading").unlink(missing_ok=True)
            (_pyannote_env / ".status").write_text("Ready")
            logger.info("Pyannote environment installed at %s", _pyannote_env)
        except Exception as e:
            logger.warning("Pyannote download failed: %s", e)
            (_pyannote_env / ".downloading").unlink(missing_ok=True)
            (_pyannote_env / ".status").write_text(f"Failed: {e}")

    threading.Thread(target=_install, daemon=True).start()
    return JSONResponse({"status": "downloading", "message": "Downloading enhanced speaker analysis engine (~2GB). This may take a few minutes."})


@app.get("/api/pyannote/status")
async def pyannote_status():
    """Check if pyannote is available or downloading."""

    # Priority 1: Smart installer provided env
    _manifest_path = BASE_DIR / "install_manifest.json"
    if _manifest_path.exists():
        try:
            _manifest = json.loads(_manifest_path.read_text(encoding="utf-8"))
            _installed = _manifest.get("installed_tiers", [])
            if "gpu" in _installed and (BASE_DIR / "_gpu_env" / "Scripts" / "python.exe").exists():
                return JSONResponse({"status": "available", "source": "installer_gpu_env"})
            if "cpu" in _installed and (BASE_DIR / "_cpu_env" / "Scripts" / "python.exe").exists():
                return JSONResponse({"status": "available", "source": "installer_cpu_env"})
        except Exception:
            pass

    # Priority 2: Native import
    try:
        from pyannote.audio import Pipeline as _P
        return JSONResponse({"status": "available", "source": "bundled"})
    except Exception:
        pass

    # Priority 3: Legacy on-demand env
    _pyannote_env = BASE_DIR / "_pyannote_env"
    _status_file = _pyannote_env / ".status"
    _status_msg = _status_file.read_text().strip() if _status_file.exists() else ""

    if (_pyannote_env / ".downloading").exists():
        return JSONResponse({"status": "downloading", "message": _status_msg or "Downloading..."})

    if (_pyannote_env / "Scripts" / "python.exe").exists():
        if _status_msg.startswith("Failed"):
            return JSONResponse({"status": "failed", "message": _status_msg})
        return JSONResponse({"status": "available", "source": "local_env"})

    return JSONResponse({"status": "not_installed"})


@app.post("/api/job/{job_id}/flag")
async def flag_segment(job_id: str, request: Request):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)
    data = await request.json()
    flag = {
        "segment_index": data.get("index"),
        "timestamp": data.get("timestamp"),
        "text": data.get("text", ""),
        "type": data.get("type", "review"),
        "created_at": datetime.now().isoformat(),
    }
    job.setdefault("flags", []).append(flag)
    _save_job(job)
    return JSONResponse({"ok": True, "flag_count": len(job["flags"])})


@app.post("/api/job/{job_id}/flag/remove")
async def remove_flag(job_id: str, request: Request):
    """Remove a specific flag by index, or clear all flags."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)
    data = await request.json()

    if data.get("clear_all"):
        job["flags"] = []
    elif data.get("flag_index") is not None:
        idx = data["flag_index"]
        flags = job.get("flags", [])
        if 0 <= idx < len(flags):
            flags.pop(idx)
    elif data.get("segment_index") is not None:
        # Remove all flags for a specific segment
        seg_idx = data["segment_index"]
        job["flags"] = [f for f in job.get("flags", []) if f.get("segment_index") != seg_idx]

    _save_job(job)
    return JSONResponse({"ok": True, "flag_count": len(job.get("flags", []))})


@app.post("/api/job/{job_id}/global-replace")
async def global_replace(job_id: str, request: Request):
    job = JOBS.get(job_id)
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Not found"}, status_code=404)
    data = await request.json()
    find_text = data.get("find", "")
    replace_text = data.get("replace", "")
    field = data.get("field", "text")
    count = 0
    for seg in job["transcript"].get("segments", []):
        if field == "speaker" and seg.get("speaker") == find_text:
            seg["speaker"] = replace_text
            count += 1
        elif field == "text" and find_text in seg.get("text", ""):
            seg["text"] = seg["text"].replace(find_text, replace_text)
            count += 1
    # Persist to disk
    if count > 0:
        job_dir = Path(job["dir"])
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            json.dump(job["transcript"], f, indent=2)
    return JSONResponse({"ok": True, "replacements": count})


    # Preview endpoints are registered by the preview_pane.py plugin
    # (which uses Word template → PDF via COM). Do NOT register them here
    # or they will shadow the plugin's version (FastAPI matches first route).

    # --- REMOVED: preview/hash and preview endpoints ---
    # See _internal/plugins/preview_pane.py for the live implementation.

    _preview_placeholder = True  # Marker so we know this was intentionally removed


@app.get("/api/job/{job_id}/export")
async def export_job(job_id: str, format: str = "txt", condensed: bool = False,
                     save_local: bool = True):
    """Export transcript. By default saves to local exports folder (no browser download).
    Set save_local=false to get a browser download instead."""
    job = JOBS.get(job_id)
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Not found"}, status_code=404)
    job_dir = Path(job["dir"])

    # Build clean filename from job title
    _title = job.get("title", "") or job.get("case_caption", "") or job_id
    _safe_name = re.sub(r'[<>:"/\\|?*]', '', _title).strip()[:80]
    if not _safe_name:
        _safe_name = job_id

    # Create exports directory
    _exports_dir = BASE_DIR / "exports"
    _exports_dir.mkdir(exist_ok=True)

    def _deliver_export(source_path, filename, media_type):
        """Save to local exports folder and return path — no browser download needed."""
        dest = _exports_dir / filename
        # Copy to exports folder (don't move — keep original in session)
        shutil.copy2(str(source_path), str(dest))
        # No Zone.Identifier since we're not going through the browser
        local_path = str(dest).replace("/", "\\")
        logger.info("Export saved: %s", local_path)
        if save_local:
            return JSONResponse({
                "ok": True,
                "path": local_path,
                "filename": filename,
                "format": format,
            })
        else:
            return FileResponse(str(source_path), filename=filename, media_type=media_type)

    if format == "json":
        return _deliver_export(job_dir / "transcript.json", f"{_safe_name}.json",
                              "application/json")

    if format == "reference":
        return _export_reference_doc(job, job_dir, filename=_safe_name)

    if format == "docx":
        return _export_word(job, job_dir, filename=_safe_name)

    if format == "pdf":
        return _export_pdf(job, job_dir, condensed=condensed, filename=_safe_name)

    if format == "word_index":
        gate = _require_pro("Word index export")
        if gate:
            return gate
        return _export_word_index(job, job_dir, filename=_safe_name)

    if format == "raw":
        return _export_raw_transcript(job, job_dir, filename=_safe_name)

    if format == "ascii":
        return _export_ascii(job, job_dir, filename=_safe_name)

    if format == "condensed":
        return _export_condensed_pdf(job, job_dir, filename=_safe_name)

    if format == "lef":
        gate = _require_pro("LEF export")
        if gate:
            return gate
        return _export_lef(job, job_dir, filename=_safe_name)

    if format == "ptx":
        gate = _require_pro("PTX export")
        if gate:
            return gate
        return _export_ptx(job, job_dir, filename=_safe_name)

    if format == "sync":
        return _export_video_sync(job, job_dir, filename=_safe_name)

    if format == "deposition":
        gate = _require_pro("Deposition PDF export")
        if gate:
            return gate
        from depo_pdf import generate_deposition_pdf
        export_path = generate_deposition_pdf(job, job_dir, filename=_safe_name)
        return _local_export(export_path, f"{_safe_name}_deposition.pdf")

    if format == "package":
        gate = _require_pro("Full package export")
        if gate:
            return gate
        return _export_full_package(job, job_dir, filename=_safe_name)

    # Plain text export
    lines = []
    lines.append(job.get("court_name", ""))
    lines.append(f"Case No. {job.get('case_number', '')}")
    lines.append(job.get("case_caption", ""))
    lines.append(f"{job.get('proceeding_type', '')} — {job.get('date', '')}")
    lines.append(f"Reported by: {job.get('reporter_name', '')}, {job.get('reporter_credential', '')}")
    lines.append("")
    lines.append("=" * 60)
    lines.append("")
    current_speaker = ""
    pending_txt = []
    for seg in job["transcript"].get("segments", []):
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        if not text:
            continue
        if speaker and speaker != current_speaker:
            # Flush previous speaker's merged text
            if pending_txt:
                lines.append("  " + " ".join(pending_txt))
                pending_txt.clear()
            current_speaker = speaker
            label = _format_speaker_label_export(speaker)
            lines.append(f"\n{label}:")
        pending_txt.append(text)
    if pending_txt:
        lines.append("  " + " ".join(pending_txt))
    # Flag report is in the REFERENCE document only — not in the transcript
    export_path = job_dir / f"notare_{job_id}_export.txt"
    export_path.write_text("\n".join(lines), encoding="utf-8")
    return _deliver_export(export_path, f"{_safe_name}.txt", "text/plain")


def _format_speaker_label_export(name):
    """Format speaker name for transcript body — MR./MS. LASTNAME convention.

    Smart handling: roles (Juror, Interpreter, etc.) are left as-is in uppercase.
    Only actual personal names get the MR./MS. treatment.
    """
    if not name:
        return name
    name_clean = name.rstrip(":")
    name_lower = name_clean.lower()

    # THE COURT is a title — always all caps (stands in for judge's name)
    if name_lower in {"the court"}:
        return "THE COURT"

    # COUNSEL — when used as a speaker label, it's a name substitute (like THE COURT)
    if name_lower in {"counsel", "co-counsel"}:
        return name_clean.upper()
    # "Counsel for the defense/plaintiff" — descriptive, capitalize Counsel only
    if name_lower.startswith("counsel for"):
        return "Counsel " + name_clean.split(None, 1)[1] if " " in name_clean else "COUNSEL"

    # Roles with "the" — these are role descriptors, not titles. Lowercase "the", capitalized role.
    _the_roles = {"the witness", "the clerk", "the defendant", "the plaintiff",
                  "the bailiff", "the interpreter", "the reporter",
                  "the videographer", "the monitor"}
    if name_lower in _the_roles:
        # "the clerk", "the witness" — lowercase "the", capitalize role word
        words = name_clean.split()
        return "the " + " ".join(w.capitalize() for w in words[1:])

    # Role prefixes without "the" — return uppercase
    _role_prefixes = ("juror", "witness", "speaker", "interpreter", "clerk",
                      "bailiff", "reporter", "videographer", "monitor",
                      "unidentified", "unknown", "male voice", "female voice",
                      "court officer", "court reporter", "court clerk",
                      "off the record", "multiple", "group", "all")
    if name_lower.startswith(_role_prefixes):
        return name_clean.upper()

    # Judge with parenthetical — "Judge Smith (presiding)" → THE COURT
    if "judge" in name_lower and "(" in name_clean:
        return "THE COURT"
    # Plain "Judge" or "Judge Smith" — keep as-is
    if name_lower.startswith("judge"):
        return name_clean.upper()

    # Already has a title — MR., MS., MRS., DR., HON., etc.
    if name_clean.upper().startswith(("MR.", "MS.", "MRS.", "DR.", "HON.")):
        return name_clean.upper()

    # If name contains digits, it's likely a role label (Juror 7, Speaker 3)
    if any(c.isdigit() for c in name_clean):
        return name_clean.upper()

    # If it's a single word that isn't clearly a first name, return as-is
    parts = name_clean.split()
    if not parts:
        return name_clean
    if len(parts) == 1:
        # Single word — could be a last name used alone, return uppercase
        return parts[0].upper()

    # Multi-word personal name — apply MR./MS. LASTNAME
    last_name = parts[-1].upper()
    if last_name.startswith("(") or last_name.endswith(")"):
        last_name = parts[-2].upper() if len(parts) >= 2 else last_name
    first = parts[0].lower()
    _fem = {'elizabeth','stephanie','jessica','jennifer','sarah','amanda','ashley',
            'emily','hannah','mary','patricia','linda','barbara','susan','margaret',
            'lisa','nancy','karen','betty','sandra','donna','carol','ruth','sharon',
            'michelle','laura','kim','kimberly','deborah','diane','rebecca','rachel',
            'katherine','katharine','catherine','christine','ann','anne','annamaria',
            'grace','allyson','allison','megan','heather','amber','nicole','crystal',
            'tiffany','brittany','cynthia','tammy','theresa','kelly','andrea','victoria',
            'daysha','alyssa','lori','beth'}
    _fem_end = ('a','ie','ey','ah','na','ne','ia','yn','le','ly','en','in','ce','se')
    if first in _fem or first.endswith(_fem_end):
        return f"MS. {last_name}"
    return f"MR. {last_name}"


def _local_export(source_path, filename):
    """Save export to local exports folder — no browser download, no web flag."""
    exports_dir = BASE_DIR / "exports"
    exports_dir.mkdir(exist_ok=True)
    dest = exports_dir / filename
    shutil.copy2(str(source_path), str(dest))
    local_path = str(dest).replace("/", "\\")
    logger.info("Export saved locally: %s", local_path)
    return JSONResponse({
        "ok": True,
        "path": local_path,
        "filename": filename,
    })


def _export_word(job: dict, job_dir: Path, filename: str = ""):
    """Export transcript as Word document using the jurisdiction profile template.

    If a Word template (.dotm/.dotx/.docx) is specified in the profile,
    opens that template and uses its paragraph styles. Fills bookmarks
    for caption fields. Otherwise creates a new document with default styles.
    """
    try:
        from docx import Document
        from docx.shared import Pt, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        return JSONResponse({"error": "python-docx not installed. Run: pip install python-docx"}, status_code=500)

    profile = job.get("profile", {})
    # Also check the CURRENT profile (not just the snapshot from job creation)
    profile_name = profile.get("name", "") or job.get("jurisdiction_profile", "")
    if profile_name and profile_name in PROFILES:
        current_profile = PROFILES[profile_name]
        # Merge current profile into job profile — current wins for template
        for k, v in current_profile.items():
            if v and not profile.get(k):
                profile[k] = v
        # Template always uses current profile
        if current_profile.get("word_styles", {}).get("template_path"):
            profile.setdefault("word_styles", {})["template_path"] = current_profile["word_styles"]["template_path"]

    word_styles = profile.get("word_styles", {})
    template_path = word_styles.get("template_path", "")

    # Resolve the template — try multiple locations
    if template_path:
        _resolved = Path(template_path)
        if not _resolved.exists():
            # Try stored templates directory (uploaded copies)
            _stored = BASE_DIR / "templates" / Path(template_path).name
            if _stored.exists():
                template_path = str(_stored)
                logger.info("Using stored template: %s", _stored)
            else:
                # Search common locations
                fname = Path(template_path).name
                for search_dir in [
                    BASE_DIR / "templates",
                    BASE_DIR,
                    Path.home() / "Documents",
                    Path.home() / "Desktop",
                    Path.home() / "Documents" / "Custom Office Templates",
                    Path.home() / "AppData" / "Roaming" / "Microsoft" / "Templates",
                ]:
                    candidate = search_dir / fname
                    if candidate.exists():
                        template_path = str(candidate)
                        logger.info("Found template at: %s", candidate)
                        break
                else:
                    logger.warning("Template not found: %s — exporting without template", template_path)
                    template_path = ""

    # Style names from profile
    style_colloquy = word_styles.get("colloquy", "")
    style_qa = word_styles.get("qa", "")
    style_paren = word_styles.get("parenthetical", "")
    style_speaker = word_styles.get("speaker_id", "")
    style_exam = word_styles.get("exam_header", "")

    # Flag: auto-detect styles from template if profile fields are empty
    _need_style_detect = not any([style_colloquy, style_qa, style_paren])

    # Load template — .dotm files need content type conversion for python-docx
    _using_template = False
    _vba_files = {}
    if template_path and Path(template_path).exists():
        try:
            ext = Path(template_path).suffix.lower()

            if ext in ('.dotm', '.docm'):
                # Strategy: strip VBA for python-docx editing, save VBA files
                # to re-inject after editing. This preserves macros in the final output.
                import zipfile as _zf, io as _io

                _vba_files = {}  # Save VBA files for re-injection
                _original_content_types = None
                _original_rels = None

                with _zf.ZipFile(template_path, 'r') as zin:
                    # Save VBA files
                    for item in zin.namelist():
                        if 'vbaProject' in item or 'vbaData' in item:
                            _vba_files[item] = zin.read(item)
                    _original_content_types = zin.read('[Content_Types].xml')
                    if 'word/_rels/document.xml.rels' in zin.namelist():
                        _original_rels = zin.read('word/_rels/document.xml.rels')

                    # Build stripped version for python-docx
                    buffer = _io.BytesIO()
                    with _zf.ZipFile(buffer, 'w', _zf.ZIP_DEFLATED) as zout:
                        for item in zin.namelist():
                            if 'vbaProject' in item or 'vbaData' in item:
                                continue
                            data = zin.read(item)
                            if item == '[Content_Types].xml':
                                data = data.replace(
                                    b'application/vnd.ms-word.template.macroEnabledTemplate.main+xml',
                                    b'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml')
                                data = re.sub(rb'<Default Extension="bin"[^/]*/>', b'', data)
                                data = re.sub(rb'<Override[^>]*vbaProject[^>]*/>', b'', data)
                                data = re.sub(rb'<Override[^>]*vbaData[^>]*/>', b'', data)
                            elif item == 'word/_rels/document.xml.rels':
                                data = re.sub(rb'<Relationship[^>]*vbaProject[^>]*/>', b'', data)
                            zout.writestr(item, data)

                _tmp = job_dir / f"_template_conv.docx"
                with open(str(_tmp), 'wb') as f:
                    f.write(buffer.getvalue())
                doc = Document(str(_tmp))
                _tmp.unlink(missing_ok=True)
                _using_template = True
                logger.info("Loaded .dotm template (converted): %s — %d paragraphs, %d styles",
                           template_path, len(doc.paragraphs),
                           len(set(p.style.name for p in doc.paragraphs)))
            else:
                doc = Document(template_path)
                _using_template = True
                logger.info("Loaded Word template: %s", template_path)
        except Exception as e:
            logger.warning("Could not load template %s: %s — using blank document", template_path, e)
            doc = Document()
    else:
        if template_path:
            logger.warning("Template not found at resolved path: %s", template_path)
        doc = Document()

    # Auto-detect styles from template if profile didn't specify them
    if _using_template and _need_style_detect:
        _tmpl_styles = {s.name.lower().replace(" ", ""): s.name for s in doc.styles
                        if s.type is not None}
        _detect_map = {
            "colloquy": ["cccolloquy", "colloquy", "dialog"],
            "qa": ["ccqanda", "qanda", "q&a", "examination"],
            "parenthetical": ["ccparenthetical", "parenthetical", "paren"],
            "speaker_id": ["speakerid", "speakername"],
            "quoted": ["ccquoted", "quoted"],
        }
        for field, patterns in _detect_map.items():
            for p in patterns:
                if p in _tmpl_styles:
                    if field == "colloquy" and not style_colloquy:
                        style_colloquy = _tmpl_styles[p]
                    elif field == "qa" and not style_qa:
                        style_qa = _tmpl_styles[p]
                    elif field == "parenthetical" and not style_paren:
                        style_paren = _tmpl_styles[p]
                    elif field == "speaker_id" and not style_speaker:
                        style_speaker = _tmpl_styles[p]
                    break
        logger.info("Auto-detected template styles: colloquy=%s, qa=%s, paren=%s, speaker=%s",
                    style_colloquy, style_qa, style_paren, style_speaker)

    def _safe_style(name):
        """Return style name if it exists in the document, else None."""
        if not name:
            return None
        try:
            doc.styles[name]
            return name
        except KeyError:
            return None

    def _add_para(text, style_name=None):
        """Add a paragraph with the given style, falling back to Normal."""
        s = _safe_style(style_name)
        if s:
            return doc.add_paragraph(text, style=s)
        else:
            return doc.add_paragraph(text)

    # --- Fill bookmarks if template has them ---
    # Common bookmark names for court transcripts
    # Build bookmark values from job data.
    # The profile can define custom bookmark mappings so any template works.
    # Available data fields that can be mapped to any bookmark name:
    #   {court_name}, {case_number}, {case_caption}, {proceeding_type},
    #   {date}, {location}, {reporter_name}, {reporter_credential},
    #   {plaintiff_name}, {defendant_name}, {plt_atty_name}, {plt_atty_firm},
    #   {def_atty_name}, {def_atty_firm}, {judge_name}

    speakers = job.get("speakers", [])
    plt_atty = next((s for s in speakers if "plaintiff" in s.get("representing", "").lower()
                      or "state" in s.get("representing", "").lower()), {})
    def_atty = next((s for s in speakers if "defendant" in s.get("representing", "").lower()
                      or "defense" in s.get("representing", "").lower()), {})

    # Parse plaintiff/defendant from caption
    caption = job.get("case_caption", "")
    plt_name = def_name = ""
    for sep in [" v. ", " vs. ", " vs ", " V. "]:
        if sep in caption:
            parts = caption.split(sep, 1)
            plt_name, def_name = parts[0].strip(), parts[1].strip()
            break

    # Find judge
    judge_name = ""
    judge_speaker = next((s for s in speakers if "court" in s.get("name", "").lower()
                          or "judge" in s.get("name", "").lower()), None)
    if judge_speaker:
        raw = judge_speaker.get("name", "")
        # Extract just the judge's name from "The Court (Judge Katharine von Ter Stegge)"
        judge_match = re.search(r'Judge\s+(.+?)(?:\)|$)', raw)
        if judge_match:
            judge_name = judge_match.group(1).strip()
        else:
            judge_name = re.sub(r'(?i)the court|[\(\)]', '', raw).strip()
    elif job.get("transcript", {}).get("speaker_map"):
        import re as _re
        for label, name in job["transcript"]["speaker_map"].items():
            if "COURT" in name or "Judge" in name:
                m = _re.search(r'Judge\s+(\w+)', name)
                if m:
                    judge_name = m.group(1)

    # Available data for bookmark mapping
    data_fields = {
        "court_name": job.get("court_name", ""),
        "case_number": job.get("case_number", ""),
        "case_caption": caption,
        "proceeding_type": job.get("proceeding_type", ""),
        "date": job.get("date", ""),
        "location": job.get("location", ""),
        "reporter_name": job.get("reporter_name", ""),
        "reporter_credential": job.get("reporter_credential", ""),
        "plaintiff_name": plt_name,
        "defendant_name": def_name,
        "plt_atty_name": plt_atty.get("name", ""),
        "plt_atty_firm": plt_atty.get("firm", ""),
        "plt_atty_address": "",  # Future: extract from case docs
        "plt_atty_csz": "",
        "plt_atty_phone": "",
        "def_atty_name": def_atty.get("name", ""),
        "def_atty_firm": def_atty.get("firm", ""),
        "def_atty_address": "",
        "def_atty_csz": "",
        "def_atty_phone": "",
        "judge_name": judge_name,
        "judge_title": f"Judge {judge_name}" if judge_name else "",
        "volume": "",
        "time": job.get("time_in", ""),
    }

    # Check if profile has custom bookmark mappings
    custom_bookmarks = profile.get("bookmark_mapping", {})
    if custom_bookmarks:
        # Custom mapping: bookmark_name -> data_field_name
        # e.g., {"Division": "court_name", "docketno": "case_number"}
        bookmark_values = {}
        for bm_name, field_name in custom_bookmarks.items():
            if field_name in data_fields:
                bookmark_values[bm_name] = data_fields[field_name]
    else:
        # Auto-detect: try common bookmark naming conventions
        bookmark_values = {}
        # Map common patterns to data fields
        auto_map = {
            "court_name": ["Division", "CourtName", "court"],
            "case_number": ["docketno", "cano", "CaseNumber", "casenumber", "caseno"],
            "plaintiff_name": ["plaintiffname", "plaintiff", "PlaintiffName"],
            "defendant_name": ["defname", "defendant", "DefendantName"],
            "date": ["date", "Date", "hearingdate", "daydate"],
            "location": ["courtcity", "courtcitytwo", "Location", "location", "VenueName", "venue"],
            "proceeding_type": ["hearingtype", "HearingType", "proceedingtype"],
            "judge_name": ["judgename", "JudgeName", "judge"],
            "plt_atty_name": ["pltattyname", "PlaintiffAttorney", "pltattorney"],
            "plt_atty_firm": ["pltattyfirm", "PlaintiffFirm"],
            "def_atty_name": ["defattyname", "DefenseAttorney", "defattorney"],
            "def_atty_firm": ["defattyfirm", "DefenseFirm"],
            "reporter_name": ["reportername", "ReporterName", "reporter"],
            "reporter_credential": ["credential", "Credential", "reportercred"],
        }
        for field, bm_names in auto_map.items():
            if data_fields.get(field):
                for bm in bm_names:
                    bookmark_values[bm] = data_fields[field]

    # Walk document XML to fill bookmarks — REPLACE existing content
    try:
        from docx.oxml.ns import qn
        from lxml import etree
        filled = 0

        # Collect all bookmark start/end pairs first
        bm_starts = {}
        bm_ends = {}
        for el in doc.element.iter():
            if el.tag == qn('w:bookmarkStart'):
                bm_id = el.get(qn('w:id'))
                bm_name = el.get(qn('w:name'))
                if bm_name and bm_id:
                    bm_starts[bm_id] = (el, bm_name)
            elif el.tag == qn('w:bookmarkEnd'):
                bm_id = el.get(qn('w:id'))
                if bm_id:
                    bm_ends[bm_id] = el

        for bm_id, (bm_start_el, bm_name) in bm_starts.items():
            if bm_name not in bookmark_values or not bookmark_values[bm_name]:
                continue

            value = bookmark_values[bm_name]
            bm_end_el = bm_ends.get(bm_id)
            parent = bm_start_el.getparent()

            if bm_end_el is not None and bm_end_el.getparent() == parent:
                # Remove all elements between bookmarkStart and bookmarkEnd
                removing = False
                to_remove = []
                for child in list(parent):
                    if child is bm_start_el:
                        removing = True
                        continue
                    if child is bm_end_el:
                        removing = False
                        continue
                    if removing:
                        to_remove.append(child)
                for el in to_remove:
                    parent.remove(el)

            # Insert new run with the value after bookmarkStart
            new_run = etree.SubElement(parent, qn('w:r'))
            # Copy formatting from existing runs if any
            existing_runs = parent.findall(qn('w:r'))
            if len(existing_runs) > 1:
                existing_rpr = existing_runs[0].find(qn('w:rPr'))
                if existing_rpr is not None:
                    import copy
                    new_run.insert(0, copy.deepcopy(existing_rpr))

            new_t = etree.SubElement(new_run, qn('w:t'))
            new_t.text = value
            new_t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')

            bm_start_el.addnext(new_run)
            filled += 1
            logger.debug("Filled bookmark '%s' = '%s'", bm_name, value[:40])

        logger.info("Filled %d bookmarks", filled)
    except Exception as e:
        logger.warning("Bookmark fill error: %s", e)
        import traceback
        traceback.print_exc()

    # --- Caption page (if no template or template has no content) ---
    if not _using_template and len(doc.paragraphs) < 3:
        # Build caption from scratch
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(job.get("court_name", ""))
        run.bold = True
        run.font.size = Pt(14)

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run(job.get("case_caption", ""))

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run(f"Case No. {job.get('case_number', '')}")

        doc.add_paragraph("")
        p = doc.add_paragraph()
        p.add_run(f"{job.get('proceeding_type', '')}").bold = True

        doc.add_paragraph(f"Date: {job.get('date', '')}")
        doc.add_paragraph(f"Location: {job.get('location', '')}")
        doc.add_paragraph(f"Reported by: {job.get('reporter_name', '')}, {job.get('reporter_credential', '')}")
        doc.add_paragraph("")

        # Appearances
        speakers = job.get("speakers", [])
        if speakers:
            p = doc.add_paragraph()
            p.add_run("APPEARANCES:").bold = True
            for s in speakers:
                line = s.get("name", "")
                if s.get("firm"):
                    line += f", {s['firm']}"
                if s.get("representing"):
                    line += f" — {s['representing']}"
                doc.add_paragraph(line)
            doc.add_paragraph("")

        # Page break before transcript
        doc.add_page_break()

    # --- Transcript body ---
    # Smart formatting: only show speaker labels on change, merge consecutive
    # same-speaker text into flowing paragraphs, detect Q/A vs colloquy vs narrative
    segments = job.get("transcript", {}).get("segments", [])
    current_speaker = ""
    pending_text = []  # Buffer for merging consecutive same-speaker segments

    _pending_speaker_label = [None]

    # Speaker colors — read from profile if set, otherwise use standard defaults
    # These match common court reporter conventions (distinct, readable on white)
    from docx.shared import RGBColor
    _profile_colors = profile.get("speaker_colors", [])
    if _profile_colors:
        _speaker_colors = []
        for c in _profile_colors:
            try:
                r, g, b = int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)
                _speaker_colors.append(RGBColor(r, g, b))
            except Exception:
                pass
    if not _profile_colors or not _speaker_colors:
        _speaker_colors = [
            RGBColor(0x80, 0x00, 0x80),  # Violet
            RGBColor(0x80, 0x80, 0x00),  # Dark Yellow
            RGBColor(0xFF, 0x00, 0xFF),  # Pink
            RGBColor(0x00, 0x80, 0x80),  # Teal
            RGBColor(0x00, 0x00, 0x80),  # Dark Blue
            RGBColor(0x80, 0x00, 0x00),  # Dark Red
            RGBColor(0x00, 0x80, 0x00),  # Dark Green
            RGBColor(0x80, 0x40, 0x00),  # Brown
        ]
    _speaker_color_map = {}  # speaker name -> color
    _next_color_idx = [0]

    def _get_speaker_color(speaker_name):
        if speaker_name not in _speaker_color_map:
            _speaker_color_map[speaker_name] = _speaker_colors[_next_color_idx[0] % len(_speaker_colors)]
            _next_color_idx[0] += 1
        return _speaker_color_map[speaker_name]

    def _flush_pending(style=None):
        """Write buffered text with colored, bold, uppercase speaker label."""
        if pending_text:
            combined = " ".join(pending_text)
            combined = re.sub(r'  +', ' ', combined).strip()
            if combined:
                s = _safe_style(style or style_colloquy)
                p = doc.add_paragraph(style=s) if s else doc.add_paragraph()
                if _pending_speaker_label[0]:
                    label = _pending_speaker_label[0].upper()
                    color = _get_speaker_color(_pending_speaker_label[0])
                    label_run = p.add_run(f"{label}:")
                    label_run.bold = True
                    label_run.font.color.rgb = color
                    p.add_run("  ")  # Two spaces after colon
                    _pending_speaker_label[0] = None
                p.add_run(combined)
            pending_text.clear()

    for i, seg in enumerate(segments):
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()

        if not text:
            continue

        # Detect content type
        is_parenthetical = text.startswith("(") and text.endswith(")")
        is_qa = text[:2] in ("Q ", "A ", "Q.", "A.")

        # Speaker change — flush previous speaker's text, queue label for inline
        if speaker and speaker != current_speaker:
            _flush_pending()
            current_speaker = speaker

            # Queue speaker label for inline with next text paragraph
            if not is_qa:
                _pending_speaker_label[0] = _format_speaker_label_export(speaker)

        # Parenthetical — always its own paragraph
        if is_parenthetical:
            _flush_pending()
            _add_para(text, style_paren)
        # Q/A — colored Q (green) and A (red) with proper style
        elif is_qa:
            _flush_pending()
            s = _safe_style(style_qa)
            p = doc.add_paragraph(style=s) if s else doc.add_paragraph()
            qa_letter = text[0]  # "Q" or "A"
            qa_rest = text[1:].lstrip(". ")
            qa_run = p.add_run(qa_letter)
            qa_run.bold = True
            qa_run.font.color.rgb = RGBColor(0x00, 0x80, 0x00) if qa_letter == "Q" else RGBColor(0xFF, 0x00, 0x00)
            p.add_run("\t" + qa_rest)
        else:
            # Colloquy / narrative — buffer for merging
            pending_text.append(text)

    # Flush any remaining text
    _flush_pending()

    # --- Certificate page ---
    cert_template = profile.get("certificate_template", "")
    if cert_template:
        doc.add_page_break()
        # Fill placeholders in certificate
        cert_text = cert_template
        cert_text = cert_text.replace("[REPORTER_NAME]", job.get("reporter_name", ""))
        cert_text = cert_text.replace("[CREDENTIAL]", job.get("reporter_credential", ""))
        cert_text = cert_text.replace("[DATE]", job.get("date", ""))
        cert_text = cert_text.replace("[CASE_NUMBER]", job.get("case_number", ""))
        cert_text = cert_text.replace("[CASE_CAPTION]", job.get("case_caption", ""))
        cert_text = cert_text.replace("[COURT_NAME]", job.get("court_name", ""))

        p = doc.add_paragraph()
        p.add_run("CERTIFICATE").bold = True
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_paragraph("")
        for line in cert_text.split("\n"):
            doc.add_paragraph(line.strip())

    # Flag report is in the REFERENCE document only — not in the transcript
    # Save — re-inject VBA macros if the template had them
    if _using_template and _vba_files:
        # Save python-docx version first
        _tmp_save = job_dir / f"_pre_vba.docx"
        doc.save(str(_tmp_save))

        # Re-inject VBA: use the ORIGINAL content types and rels from the
        # template rather than reconstructing them. The template already has
        # the exact entries needed for VBA to function. We just need to:
        # 1. Take the edited document content (paragraphs, styles, bookmarks)
        # 2. Restore the original content types (macro-enabled type + VBA entries)
        # 3. Restore the original rels (VBA relationship)
        # 4. Add the VBA binary files back
        import zipfile as _zf, io as _io
        export_path = job_dir / f"notare_{job['id']}_transcript.docm"
        with _zf.ZipFile(str(_tmp_save), 'r') as zin:
            with _zf.ZipFile(str(export_path), 'w', _zf.ZIP_DEFLATED) as zout:
                for item in zin.namelist():
                    if item == '[Content_Types].xml' and _original_content_types:
                        # Use the original template's content types — they have
                        # the correct macro-enabled main type, VBA project entries,
                        # and vbaData overrides already configured.
                        # But we need to merge any new content types that python-docx added
                        # (e.g., new images, charts) by taking overrides from the edited doc
                        # that don't exist in the original.
                        edited_ct = zin.read(item)
                        original_ct = _original_content_types
                        # The original already has macro content types. Just use it,
                        # but swap the main document type from template to document.
                        final_ct = original_ct.replace(
                            b'application/vnd.ms-word.template.macroEnabledTemplate.main+xml',
                            b'application/vnd.ms-word.document.macroEnabled.main+xml')
                        zout.writestr(item, final_ct)
                    elif item == 'word/_rels/document.xml.rels' and _original_rels:
                        # Use original rels — they have the VBA relationship
                        # Merge any new relationships from python-docx editing
                        import xml.etree.ElementTree as _ET
                        try:
                            orig_tree = _ET.fromstring(_original_rels)
                            edit_tree = _ET.fromstring(zin.read(item))
                            orig_ids = {r.get('Id') for r in orig_tree}
                            # Add any new relationships from edited doc
                            for rel in edit_tree:
                                if rel.get('Id') not in orig_ids:
                                    orig_tree.append(rel)
                            merged = _ET.tostring(orig_tree, xml_declaration=True, encoding='UTF-8')
                            zout.writestr(item, merged)
                        except Exception:
                            # Fallback: use original rels as-is
                            zout.writestr(item, _original_rels)
                    else:
                        zout.writestr(item, zin.read(item))

                # Add VBA files back (vbaProject.bin, vbaData.xml, etc.)
                for vba_name, vba_data in _vba_files.items():
                    if vba_name not in zout.namelist():
                        zout.writestr(vba_name, vba_data)

        _tmp_save.unlink(missing_ok=True)
        media_type = "application/vnd.ms-word.document.macroEnabled.12"
        ext_out = ".docm"
        logger.info("Word export with macros: %s (%d VBA files restored)", export_path, len(_vba_files))
    else:
        export_path = job_dir / f"notare_{job['id']}_transcript.docx"
        doc.save(str(export_path))
        media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        ext_out = ".docx"
        logger.info("Word export: %s", export_path)

    case_num = job.get("case_number", job["id"])
    final_name = f"{filename or case_num}_transcript{ext_out}"

    # Copy to exports folder — local save, no browser download, no web flag
    exports_dir = BASE_DIR / "exports"
    exports_dir.mkdir(exist_ok=True)
    final_path = exports_dir / final_name
    shutil.copy2(str(export_path), str(final_path))

    local_path = str(final_path).replace("/", "\\")
    logger.info("Export saved locally: %s", local_path)

    return JSONResponse({
        "ok": True,
        "path": local_path,
        "filename": final_name,
        "format": "docx" if ext_out == ".docx" else "docm",
    })


def _export_reference_doc(job: dict, job_dir: Path, filename: str = ""):
    """Generate a reference document — table of contents, data sources,
    speaker index, and transcript summary.

    This is the 'show your work' document: every extracted field traced
    back to its source, plus an index of the transcript contents.
    """
    import re
    try:
        from docx import Document
        from docx.shared import Pt, Inches, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.table import WD_TABLE_ALIGNMENT
    except ImportError:
        return JSONResponse({"error": "python-docx required. Run: pip install python-docx"}, status_code=500)

    doc = Document()

    # --- Title ---
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("NOTARE — REFERENCE DOCUMENT")
    run.bold = True
    run.font.size = Pt(16)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(f"{job.get('case_caption', 'Untitled')} — {job.get('case_number', '')}")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f"Generated {datetime.now().strftime('%B %d, %Y at %I:%M %p')}")
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(128, 128, 128)

    doc.add_paragraph("")

    # --- Section 1: Case Information ---
    h = doc.add_heading("1. Case Information", level=1)

    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    hdr[0].text = "Field"
    hdr[1].text = "Value"
    for cell in hdr:
        for p in cell.paragraphs:
            for run in p.runs:
                run.bold = True

    fields = [
        ("Court / Venue", job.get("court_name", "")),
        ("Case Number", job.get("case_number", "")),
        ("Case Caption", job.get("case_caption", "")),
        ("Proceeding Type", job.get("proceeding_type", "")),
        ("Date", job.get("date", "")),
        ("Location", job.get("location", "")),
        ("Reporter", f"{job.get('reporter_name', '')} {job.get('reporter_credential', '')}".strip()),
    ]
    for label, value in fields:
        if value:
            row = table.add_row().cells
            row[0].text = label
            row[1].text = value

    doc.add_paragraph("")

    # --- Section 2: Participants ---
    doc.add_heading("2. Participants", level=1)

    speakers = job.get("speakers", [])
    transcript = job.get("transcript", {})
    speaker_map = transcript.get("speaker_map", {})

    if speakers or speaker_map:
        table = doc.add_table(rows=1, cols=4)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        hdr[0].text = "Name / Designation"
        hdr[1].text = "Firm / Title"
        hdr[2].text = "Representing"
        hdr[3].text = "Source"
        for cell in hdr:
            for p in cell.paragraphs:
                for run in p.runs:
                    run.bold = True

        seen = set()
        for s in speakers:
            name = s.get("name", "")
            if name and name not in seen:
                row = table.add_row().cells
                row[0].text = name
                row[1].text = s.get("firm", "")
                row[2].text = s.get("representing", "")
                row[3].text = "Job setup / Document extraction"
                seen.add(name)

        # Add auto-detected speakers
        for label, name in speaker_map.items():
            if name not in seen:
                row = table.add_row().cells
                row[0].text = name
                row[1].text = ""
                row[2].text = ""
                row[3].text = f"Auto-detected from transcript (was {label})"
                seen.add(name)
    else:
        doc.add_paragraph("No participants identified.")

    doc.add_paragraph("")

    # --- Section 3: Transcript Table of Contents ---
    doc.add_heading("3. Transcript Table of Contents", level=1)

    segments = transcript.get("segments", [])
    if segments:
        # Speaker change index
        doc.add_heading("Speaker Changes", level=2)
        table = doc.add_table(rows=1, cols=3)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        hdr[0].text = "Timestamp"
        hdr[1].text = "Speaker"
        hdr[2].text = "First Words"
        for cell in hdr:
            for p in cell.paragraphs:
                for run in p.runs:
                    run.bold = True

        current_speaker = ""
        for seg in segments:
            speaker = seg.get("speaker", "")
            if speaker and speaker != current_speaker:
                current_speaker = speaker
                row = table.add_row().cells
                row[0].text = _fmt_time(seg.get("start", 0))
                row[1].text = speaker
                row[2].text = seg.get("text", "")[:60] + ("..." if len(seg.get("text", "")) > 60 else "")

        doc.add_paragraph("")

        # Exhibits / evidence mentions
        doc.add_heading("Exhibit References", level=2)
        exhibit_count = 0
        for seg in segments:
            text = seg.get("text", "")
            if re.search(r'\b(?:exhibit|evidence|marked as|admitted|offered)\b', text, re.IGNORECASE):
                p = doc.add_paragraph()
                p.add_run(f"{_fmt_time(seg.get('start', 0))}  ").bold = True
                p.add_run(text[:120])
                exhibit_count += 1
        if exhibit_count == 0:
            doc.add_paragraph("No exhibit references detected.")

        # Linked exhibits (from exhibit hyperlinking system)
        job_exhibits = EXHIBITS.get(job.get("id", ""), [])
        if job_exhibits:
            doc.add_paragraph("")
            doc.add_heading("Exhibit Index (Hyperlinked)", level=2)
            ex_table = doc.add_table(rows=1, cols=4)
            ex_table.style = "Table Grid"
            ex_hdr = ex_table.rows[0].cells
            ex_hdr[0].text = "Exhibit"
            ex_hdr[1].text = "Description"
            ex_hdr[2].text = "File Reference"
            ex_hdr[3].text = "Linked Segments"
            for cell in ex_hdr:
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.bold = True
            for ex in job_exhibits:
                row = ex_table.add_row().cells
                row[0].text = ex.get("exhibit_id", "")
                row[1].text = ex.get("description", "")
                row[2].text = ex.get("file_reference", "")
                linked = ex.get("linked_segments", [])
                if linked and segments:
                    # Show timestamp and first words of each linked segment
                    seg_refs = []
                    for seg_idx in linked:
                        if 0 <= seg_idx < len(segments):
                            s = segments[seg_idx]
                            seg_refs.append(f"{_fmt_time(s.get('start', 0))}: {s.get('text', '')[:40]}...")
                    row[3].text = "\n".join(seg_refs) if seg_refs else str(linked)
                else:
                    row[3].text = str(linked) if linked else ""

        doc.add_paragraph("")

        # Objections
        doc.add_heading("Objections", level=2)
        obj_count = 0
        for seg in segments:
            text = seg.get("text", "")
            if re.search(r'\b(?:objection|sustained|overruled|strike|stricken)\b', text, re.IGNORECASE):
                p = doc.add_paragraph()
                p.add_run(f"{_fmt_time(seg.get('start', 0))}  [{seg.get('speaker', '')}]  ").bold = True
                p.add_run(text[:120])
                obj_count += 1
        if obj_count == 0:
            doc.add_paragraph("No objections detected.")

        doc.add_paragraph("")

        # Low confidence / flagged segments
        doc.add_heading("Flagged / Low Confidence Segments", level=2)
        flags = job.get("flags", [])
        flag_count = 0
        for seg in segments:
            conf = seg.get("confidence", seg.get("avg_word_confidence", 1.0))
            if conf < 0.6 or seg.get("retranscribed"):
                p = doc.add_paragraph()
                p.add_run(f"{_fmt_time(seg.get('start', 0))}  ").bold = True
                p.add_run(f"[Confidence: {conf:.0%}] ")
                p.add_run(seg.get("text", "")[:100])
                flag_count += 1
        for f in flags:
            p = doc.add_paragraph()
            p.add_run(f"{_fmt_time(f.get('timestamp', 0))}  ").bold = True
            p.add_run(f"[{f.get('type', 'review').upper()}] ")
            p.add_run(f.get("text", "")[:100])
            flag_count += 1
        if flag_count == 0:
            doc.add_paragraph("No flagged segments.")
    else:
        doc.add_paragraph("No transcript data available.")

    doc.add_paragraph("")

    # --- Section 4: Statistics ---
    doc.add_heading("4. Statistics", level=1)
    full_text = transcript.get("full_text", "")
    word_count = len(full_text.split()) if isinstance(full_text, str) else 0
    duration = transcript.get("duration", 0)
    unique_speakers = len(set(s.get("speaker", "") for s in segments if s.get("speaker")))

    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    hdr[0].text = "Metric"
    hdr[1].text = "Value"
    for cell in hdr:
        for p in cell.paragraphs:
            for run in p.runs:
                run.bold = True

    stats = [
        ("Total Segments", str(len(segments))),
        ("Total Words", f"{word_count:,}"),
        ("Duration", _fmt_time(duration)),
        ("Unique Speakers", str(unique_speakers)),
        ("Flagged Segments", str(len(job.get("flags", [])))),
        ("Transcription Engine", transcript.get("engine", "unknown")),
    ]
    for label, value in stats:
        row = table.add_row().cells
        row[0].text = label
        row[1].text = value

    # Save
    ref_path = job_dir / f"notare_{job['id']}_reference.docx"
    doc.save(str(ref_path))
    logger.info("Reference doc exported: %s", ref_path)

    case_num = job.get("case_number", job["id"])
    return _local_export(ref_path, f"{filename or case_num}_reference.docx")


def _export_pdf(job: dict, job_dir: Path, condensed: bool = False, filename: str = ""):
    """Export transcript as a court-compliant PDF with line numbers and proper formatting."""
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import inch
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                        PageBreak, Frame, PageTemplate, BaseDocTemplate)
        from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
        from reportlab.pdfgen import canvas as pdf_canvas
    except ImportError:
        # Auto-install reportlab
        subprocess.check_call([sys.executable, "-m", "pip", "install", "reportlab"])
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import inch
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                        PageBreak, Frame, PageTemplate, BaseDocTemplate)
        from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
        from reportlab.pdfgen import canvas as pdf_canvas

    profile = job.get("profile", {})
    lines_per_page = profile.get("lines_per_page") or 25
    page_width, page_height = letter  # 8.5 x 11 inches

    # Margins: 1.5" left, 1" right, 1" top/bottom
    left_margin = 1.5 * inch
    right_margin = 1.0 * inch
    top_margin = 1.0 * inch
    bottom_margin = 1.0 * inch

    export_path = job_dir / f"notare_{job['id']}_transcript.pdf"

    # Custom canvas for headers, footers, and line numbers
    class TranscriptCanvas(pdf_canvas.Canvas):
        def __init__(self, *args, **kwargs):
            self._job = kwargs.pop('job_data', job)
            super().__init__(*args, **kwargs)
            self._page_number = 0

        def showPage(self):
            self._draw_header_footer()
            super().showPage()
            self._page_number += 1

        def _draw_header_footer(self):
            self.saveState()
            # Header
            self.setFont("Courier", 8)
            caption = self._job.get("case_caption", "")
            case_num = self._job.get("case_number", "")
            date_str = self._job.get("date", "")
            header_left = f"{caption}"
            header_right = f"Case No. {case_num}  |  {date_str}"
            self.drawString(left_margin, page_height - 0.6 * inch, header_left[:60])
            self.drawRightString(page_width - right_margin, page_height - 0.6 * inch, header_right)
            # Thin line under header
            self.setLineWidth(0.5)
            self.line(left_margin, page_height - 0.7 * inch,
                     page_width - right_margin, page_height - 0.7 * inch)

            # Footer
            reporter = self._job.get("reporter_name", "")
            credential = self._job.get("reporter_credential", "")
            footer_left = f"{reporter}, {credential}" if reporter else ""
            footer_right = f"Page {self._page_number + 1}"
            self.drawString(left_margin, 0.5 * inch, footer_left)
            self.drawRightString(page_width - right_margin, 0.5 * inch, footer_right)
            self.restoreState()

    # Build transcript lines — smart formatting: label only on speaker change,
    # merge consecutive same-speaker segments, detect Q/A vs colloquy
    import textwrap
    transcript_lines = []
    segments = job.get("transcript", {}).get("segments", [])
    current_speaker = ""
    pending_text = []

    def _flush_pdf():
        if pending_text:
            combined = " ".join(pending_text)
            combined = re.sub(r'  +', ' ', combined).strip()
            if combined:
                for wline in textwrap.wrap(combined, width=65):
                    transcript_lines.append(f"    {wline}")
            pending_text.clear()

    for seg in segments:
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        if not text:
            continue

        is_qa = text[:2] in ("Q ", "A ", "Q.", "A.")
        is_parenthetical = text.startswith("(") and text.endswith(")")

        if speaker and speaker != current_speaker:
            _flush_pdf()
            current_speaker = speaker
            transcript_lines.append("")
            if not is_qa:
                label = _format_speaker_label_export(speaker)
                transcript_lines.append(f"{label}:")

        if is_parenthetical:
            _flush_pdf()
            transcript_lines.append(f"    {text}")
        elif is_qa:
            _flush_pdf()
            for wline in textwrap.wrap(text, width=65):
                transcript_lines.append(f"    {wline}")
        else:
            pending_text.append(text)

    _flush_pdf()

    # Build PDF using low-level canvas for precise line number control
    c = TranscriptCanvas(str(export_path), pagesize=letter)
    c._job = job

    # Font setup
    font_name = "Courier"
    font_size = 12 if not condensed else 8
    line_height = (page_height - top_margin - bottom_margin - 0.3 * inch) / lines_per_page
    if condensed:
        line_height = line_height * 0.6
        font_size = 7

    content_top = page_height - top_margin - 0.3 * inch  # below header
    line_num_x = left_margin - 0.4 * inch  # line numbers in left margin
    text_x = left_margin

    # Title page
    c.setFont("Courier-Bold", 14)
    y = page_height - 2.5 * inch
    c.drawCentredString(page_width / 2, y, job.get("court_name", ""))
    y -= 0.4 * inch
    c.setFont("Courier", 12)
    c.drawCentredString(page_width / 2, y, job.get("case_caption", ""))
    y -= 0.3 * inch
    c.drawCentredString(page_width / 2, y, f"Case No. {job.get('case_number', '')}")
    y -= 0.5 * inch
    c.setFont("Courier-Bold", 12)
    c.drawCentredString(page_width / 2, y, job.get("proceeding_type", ""))
    y -= 0.3 * inch
    c.setFont("Courier", 11)
    c.drawCentredString(page_width / 2, y, f"Date: {job.get('date', '')}")
    y -= 0.25 * inch
    c.drawCentredString(page_width / 2, y, f"Location: {job.get('location', '')}")
    y -= 0.5 * inch
    reporter = job.get("reporter_name", "")
    credential = job.get("reporter_credential", "")
    c.drawCentredString(page_width / 2, y, f"Reported by: {reporter}, {credential}")

    # Appearances
    speakers = job.get("speakers", [])
    if speakers:
        y -= 0.6 * inch
        c.setFont("Courier-Bold", 11)
        c.drawString(left_margin, y, "APPEARANCES:")
        c.setFont("Courier", 10)
        for s in speakers:
            y -= 0.25 * inch
            line = s.get("name", "")
            if s.get("firm"):
                line += f", {s['firm']}"
            if s.get("representing"):
                line += f" — {s['representing']}"
            c.drawString(left_margin + 0.3 * inch, y, line)

    c.showPage()  # End title page

    # Transcript body pages with line numbers
    page_line = 0
    for tline in transcript_lines:
        if page_line >= lines_per_page:
            c.showPage()
            page_line = 0

        y = content_top - (page_line * line_height)

        # Line number (right-aligned in margin)
        c.setFont("Courier", font_size - 1)
        c.drawRightString(line_num_x + 0.3 * inch, y, str(page_line + 1))

        # Text
        c.setFont(font_name, font_size)
        if tline == tline.upper() and tline.strip() and not tline.startswith("    "):
            # Speaker label — bold
            c.setFont("Courier-Bold", font_size)
        c.drawString(text_x, y, tline)
        page_line += 1

    # Certificate page
    cert_template = profile.get("certificate_template", "")
    if cert_template:
        c.showPage()
        c.setFont("Courier-Bold", 14)
        c.drawCentredString(page_width / 2, page_height - 2 * inch, "CERTIFICATE")
        cert_text = cert_template
        cert_text = cert_text.replace("[REPORTER_NAME]", job.get("reporter_name", ""))
        cert_text = cert_text.replace("[CREDENTIAL]", job.get("reporter_credential", ""))
        cert_text = cert_text.replace("[DATE]", job.get("date", ""))
        cert_text = cert_text.replace("[CASE_NUMBER]", job.get("case_number", ""))
        cert_text = cert_text.replace("[CASE_CAPTION]", job.get("case_caption", ""))
        cert_text = cert_text.replace("[COURT_NAME]", job.get("court_name", ""))
        c.setFont("Courier", 11)
        cert_y = page_height - 2.8 * inch
        for cert_line in cert_text.split("\n"):
            c.drawString(left_margin, cert_y, cert_line.strip())
            cert_y -= 0.22 * inch
            if cert_y < bottom_margin:
                c.showPage()
                cert_y = content_top
    c.showPage()
    c.save()

    # Condensed format: 4 pages on 1
    if condensed:
        try:
            from reportlab.lib.pagesizes import letter as _letter
            from io import BytesIO
            # Use PyPDF2 or reportlab to composite — for now, the condensed
            # flag already reduces font size and line height above
            pass
        except Exception:
            pass

    logger.info("PDF export: %s", export_path)
    case_num = job.get("case_number", job["id"])
    return _local_export(export_path, f"{filename or case_num}_transcript.pdf")


@app.get("/api/job/{job_id}/audio/{filename}")
async def serve_audio(job_id: str, filename: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)
    audio_path = Path(job["dir"]) / "audio" / filename
    if not audio_path.exists():
        return JSONResponse({"error": "Audio not found"}, status_code=404)
    return FileResponse(audio_path)


@app.post("/api/profile/save")
async def save_profile(request: Request):
    data = await request.json()
    name = data.get("name", "").strip()
    if not name:
        return JSONResponse({"error": "Profile name required"}, status_code=400)
    PROFILES[name] = data
    _save_profiles()
    return JSONResponse({"ok": True})


@app.post("/api/extract-case-info")
async def extract_case_info(files: list[UploadFile] = File(...)):
    """Extract case info from uploaded documents (PDF, DOCX, TXT).

    Accepts multiple files — reads all of them, merges extracted info.
    Uses regex patterns to find case numbers, party names, attorneys,
    judges, court names, etc.
    """
    import re

    # Read all files and combine text
    all_text = []
    for file in files:
        tmp_path = UPLOAD_DIR / file.filename
        content_bytes = await file.read()
        with open(tmp_path, "wb") as f:
            f.write(content_bytes)

        ext = Path(file.filename).suffix.lower()
        text = ""
        try:
            if ext == ".pdf":
                # Try available PDF libraries in order of preference
                _pdf_read = False
                for _pdf_method in ["pdfplumber", "fitz", "pypdf", "builtin"]:
                    if _pdf_read:
                        break
                    try:
                        if _pdf_method == "pdfplumber":
                            import pdfplumber
                            with pdfplumber.open(str(tmp_path)) as pdf:
                                text = "\n".join(p.extract_text() or "" for p in pdf.pages)
                            _pdf_read = True
                        elif _pdf_method == "fitz":
                            import fitz
                            doc = fitz.open(str(tmp_path))
                            text = "\n".join(page.get_text() for page in doc)
                            doc.close()
                            _pdf_read = True
                        elif _pdf_method == "pypdf":
                            from pypdf import PdfReader
                            reader = PdfReader(str(tmp_path))
                            text = "\n".join(page.extract_text() or "" for page in reader.pages)
                            _pdf_read = True
                        elif _pdf_method == "builtin":
                            # Last resort: raw binary text extraction
                            import re as _re
                            with open(tmp_path, "rb") as _pf:
                                raw = _pf.read()
                            # Extract text between BT/ET markers (PDF text objects)
                            _chunks = []
                            for match in _re.finditer(rb'\(([^)]+)\)', raw):
                                try:
                                    _chunks.append(match.group(1).decode("latin-1", errors="replace"))
                                except Exception:
                                    pass
                            if _chunks:
                                text = " ".join(_chunks)
                                _pdf_read = True
                    except ImportError:
                        continue
                    except Exception as e:
                        logger.warning("PDF method %s failed: %s", _pdf_method, e)
                        continue
                if not _pdf_read:
                    logger.warning("Could not read PDF: %s — no PDF library available", file.filename)
            elif ext in (".docx", ".doc"):
                try:
                    from docx import Document as DocxDoc
                    doc = DocxDoc(str(tmp_path))
                    text = "\n".join(p.text for p in doc.paragraphs)
                except Exception:
                    pass
            elif ext in (".htm", ".html"):
                import re as _hre
                html_text = content_bytes.decode("utf-8", errors="replace")
                # Strip HTML tags, keep text content
                text = _hre.sub(r'<style[^>]*>.*?</style>', '', html_text, flags=_hre.DOTALL | _hre.IGNORECASE)
                text = _hre.sub(r'<script[^>]*>.*?</script>', '', text, flags=_hre.DOTALL | _hre.IGNORECASE)
                text = _hre.sub(r'<[^>]+>', ' ', text)
                text = _hre.sub(r'&nbsp;', ' ', text)
                text = _hre.sub(r'&amp;', '&', text)
                text = _hre.sub(r'&lt;', '<', text)
                text = _hre.sub(r'&gt;', '>', text)
                text = _hre.sub(r'&#\d+;', '', text)
                text = _hre.sub(r'\s+', ' ', text).strip()
            elif ext == ".txt":
                text = content_bytes.decode("utf-8", errors="replace")
        finally:
            tmp_path.unlink(missing_ok=True)

        if text.strip():
            all_text.append(f"--- {file.filename} ---\n{text}")

    # Separate document texts by type for intelligent merging
    _doc_texts = []  # (filename, text, file_ext)
    for entry in all_text:
        # Parse out filename from "--- filename ---\ntext"
        lines = entry.split("\n", 1)
        fname = lines[0].replace("--- ", "").replace(" ---", "").strip()
        txt = lines[1] if len(lines) > 1 else ""
        ext = Path(fname).suffix.lower()
        _doc_texts.append((fname, txt, ext))

    text = "\n\n".join(all_text)
    if not text.strip():
        return JSONResponse({"error": "Could not extract text from any document"})

    # Separate legal docs (PDFs, DOCX) from docket logs (HTM)
    _legal_text = "\n\n".join(t for _, t, e in _doc_texts if e in (".pdf", ".docx", ".doc"))
    _docket_text = "\n\n".join(t for _, t, e in _doc_texts if e in (".htm", ".html"))

    # Use legal docs as primary for case info, full text for everything else
    _primary_text = _legal_text if _legal_text.strip() else text
    # Keep 'text' as full combined text — don't overwrite

    result = {"raw_text": text[:500]}

    # --- Step 1: Identify document type (check ALL text) ---
    text_upper = text.upper()
    doc_type = "unknown"
    if "NOTICE OF APPEAL" in text_upper:
        doc_type = "notice_of_appeal"
    elif "NOTICE OF DEPOSITION" in text_upper or "DEPOSITION OF" in text_upper:
        doc_type = "deposition_notice"
    elif "SUBPOENA" in text_upper:
        doc_type = "subpoena"
    elif "DOCKET" in text_upper or "REGISTER OF ACTIONS" in text_upper or "CALLED:" in text_upper:
        doc_type = "docket"
    elif "JUDGMENT" in text_upper and "SENTENCE" in text_upper:
        doc_type = "judgment"
    elif "MOTION" in text_upper and ("FILED" in text_upper or "HEARING" in text_upper):
        doc_type = "motion"
    elif "COMPLAINT" in text_upper or "INDICTMENT" in text_upper or "INFORMATION" in text_upper:
        doc_type = "charging"
    elif "ORDER" in text_upper and ("COURT" in text_upper or "JUDGE" in text_upper):
        doc_type = "order"
    result["document_type"] = doc_type
    logger.info("Document type detected: %s", doc_type)

    # --- Step 2: Extract case number (use MOST FREQUENT, not first) ---
    from collections import Counter
    _all_case_nums = re.findall(
        r"(?:Case\s*(?:No\.?|Number|#)\s*:?\s*)([A-Z0-9][-A-Z0-9]+)",
        text, re.IGNORECASE)
    if not _all_case_nums:
        _all_case_nums = re.findall(r"\b(\d{2}[A-Z]{2}\d{4,})\b", text)
    if not _all_case_nums:
        _all_case_nums = re.findall(r"\b(\d{4}-[A-Z]{2,3}-\d+)\b", text)
    if _all_case_nums:
        # Most frequent = most likely the correct one for this case
        case_counts = Counter(_all_case_nums)
        result["case_number"] = case_counts.most_common(1)[0][0]
        if len(case_counts) > 1:
            logger.info("Multiple case numbers found: %s — using most frequent: %s",
                       dict(case_counts), result["case_number"])

    # --- Step 3: Extract caption block ---
    # Look for the formal caption structure: party names around "v." or "vs."
    # This is the most reliable way to get plaintiff, defendant, and caption

    # Pattern 1: Multi-line caption with role labels
    caption = re.search(
        r"([\w\s.,']+?)\s*,?\s*\n\s*(?:Plaintiff|Respondent|Petitioner|Complainant)[-\w\s]*?"
        r"\s*\n\s*v[s.]?\s*\.?\s*\n\s*([\w\s.,']+?)\s*,?\s*\n\s*(?:Defendant|Appellant|Respondent)",
        text, re.IGNORECASE | re.DOTALL)
    if caption:
        plt = caption.group(1).strip().rstrip(",. ")
        dft = caption.group(2).strip().rstrip(",. ")
        # Clean up — remove stray newlines and extra spaces
        plt = re.sub(r'\s+', ' ', plt).strip()
        dft = re.sub(r'\s+', ' ', dft).strip()
        result["case_caption"] = f"{plt} v. {dft}"
        result["plaintiff_name"] = plt
        result["defendant_name"] = dft

    if not result.get("case_caption"):
        # Pattern 2: "State of Oregon vs Raymond Lavaughn Grant" (docket/HTM format)
        caption2 = re.search(
            r"(State of [A-Z][a-z]+|United States)\s+v[s.]?\s+([A-Z][A-Za-z\s.'-]+?)(?:\s+\d{2}[A-Z]{2}\d+|\s*,|\s*\n|\s*Case)",
            text, re.IGNORECASE)
        if caption2:
            plt = caption2.group(1).strip().rstrip(",. ")
            dft = caption2.group(2).strip().rstrip(",. ")
            result["case_caption"] = f"{plt} v. {dft}"
            result["plaintiff_name"] = plt
            result["defendant_name"] = dft

    # Clean up caption — truncate if too long (shouldn't be a paragraph)
    if result.get("case_caption") and len(result["case_caption"]) > 100:
        # Take just the first sentence/clause
        result["case_caption"] = re.split(r'[.\n]', result["case_caption"])[0].strip()[:100]

    # --- Step 4: Extract court name (with county/location embedded) ---
    # Look for the full court name with FOR THE COUNTY OF pattern
    court = re.search(
        r"(?:IN THE\s+)?"
        r"((?:CIRCUIT|DISTRICT|SUPERIOR|COUNTY|COURT OF APPEALS|SUPREME|MUNICIPAL|FAMILY)"
        r"\s+COURT\s+OF\s+(?:THE\s+)?(?:STATE\s+OF\s+)?([A-Z][a-z]+))"
        r"(?:\s+FOR\s+(?:THE\s+)?(?:COUNTY\s+OF\s+)?([A-Z][a-z]+))?",
        text, re.IGNORECASE)
    if court:
        court_name = court.group(1).strip()
        county_name = court.group(3).strip() if court.group(3) else ""

        result["court_name"] = court_name
        if county_name:
            result["location"] = f"{county_name} County"

    # Fallback location — look for "County" near court name
    if not result.get("location"):
        county_match = re.search(r"(\w+)\s+County(?:\s+Circuit|\s+District|\s+Court)", text, re.IGNORECASE)
        if county_match:
            result["location"] = f"{county_match.group(1)} County"

    # Fallback: simpler pattern
    if not result.get("court_name"):
        court2 = re.search(
            r"((?:CIRCUIT|DISTRICT|SUPERIOR|SUPREME)\s+COURT\s+OF\s+[A-Z][A-Za-z\s]+?)(?:\n|,|FOR\b)",
            text, re.IGNORECASE)
        if court2:
            result["court_name"] = court2.group(1).strip()

    # Fallback location from "County" mentions
    if not result.get("location"):
        county = re.search(r"(\w+)\s+County\s+(?:Circuit|District|Superior|Court)", text, re.IGNORECASE)
        if county:
            result["location"] = f"{county.group(1)} County"

    # --- Step 5: Extract judge (context-aware) ---
    # In judgments/orders, the signing judge is the most relevant
    judge = None
    if doc_type in ("judgment", "order"):
        # Look for "by Judge X" or signature block
        judge = re.search(
            r"(?:by\s+(?:the\s+)?(?:Honorable\s+)?Judge|Presiding Judge|signed.*Judge)\s+"
            r"([A-Z][a-z]+(?:\s+(?:von|de|van|del|la|le|ter|der|den|di|Mac|Mc|O')[A-Za-z]*|\s+[A-Z][a-z]+)*)",
            text, re.IGNORECASE)
    if not judge:
        # General: "Judge [Name]" — but ONLY if followed by "presiding" or at start of doc
        # Avoid grabbing "Judge Albright on that motion" or "Judge emails from"
        judge = re.search(
            r"(?:Judge|Justice|Honorable|Hon\.?)\s+"
            r"([A-Z][a-z]+(?:\s+(?:von|de|van|del|la|le|ter|der|den|di|Mac|Mc|O')[A-Za-z]*|\s+[A-Z][a-z]+)*)"
            r"(?:\s*(?:presiding|,|\.|$))",
            text, re.IGNORECASE)
    if not judge:
        # Looser match but only from the FIRST page/500 chars of legal docs
        judge = re.search(
            r"(?:Judge|Justice|Honorable|Hon\.?)\s+"
            r"([A-Z][a-z]+(?:\s+(?:von|de|van|del|la|le|ter|der|den|di|Mac|Mc|O')[A-Za-z]*|\s+[A-Z][a-z]+)*)",
            text[:500], re.IGNORECASE)
    if judge:
        name = judge.group(1).strip()
        # Truncate at prepositions/context words that aren't part of the name
        name = re.split(r'\s+(?:in|at|of|for|the|on|from|during|emails|that|this|was|is)\s+', name, maxsplit=1)[0].strip()
        # Skip if the "name" is actually a common word
        if name.lower() not in ('emails', 'said', 'ordered', 'ruled', 'denied', 'granted', 'noted'):
            result["judge_name"] = name

    # --- Step 6: Extract defendant details (criminal cases) ---
    if doc_type in ("judgment", "notice_of_appeal", "charging"):
        # "True Name: Raymond Lavaughn Grant"
        true_name = re.search(r"True Name:\s*(.+?)(?:\s+Sex:|\n|$)", text, re.IGNORECASE)
        if true_name and not result.get("defendant_name"):
            result["defendant_name"] = true_name.group(1).strip()
        # DOB
        dob = re.search(r"Date\s*(?:Of|of)\s*Birth:\s*(\d{2}/\d{2}/\d{4})", text)
        if dob:
            result["defendant_dob"] = dob.group(1)
        # SID
        sid = re.search(r"(?:SID|State Identification).*?:\s*(\w+)", text)
        if sid:
            result["defendant_sid"] = sid.group(1)

    # --- Fix plaintiff name if it's a role label instead of actual name ---
    plt_name = result.get("plaintiff_name", "")
    if plt_name.lower() in ("respondent", "petitioner", "plaintiff", "complainant", ""):
        # Look for "State of [State]" as plaintiff
        state_match = re.search(r"(State of [A-Z][a-z]+)", text, re.IGNORECASE)
        if state_match:
            result["plaintiff_name"] = state_match.group(1).strip()
        elif "United States" in text:
            result["plaintiff_name"] = "United States"

    # --- Step 7: NER enhancement (spaCy) ---
    # Use a lightweight NER model to find names, dates, orgs, locations
    # that regex missed. Validates and fills gaps in the regex results.
    try:
        import spacy
        try:
            _nlp = spacy.load("en_core_web_sm")
        except OSError:
            # In frozen exe, model is at _internal/en_core_web_sm/en_core_web_sm-X.X.X/
            _nlp = None
            _sm_dir = BASE_DIR / "_internal" / "en_core_web_sm"
            if _sm_dir.exists():
                for _sub in sorted(_sm_dir.iterdir()):
                    if _sub.is_dir() and (_sub / "config.cfg").exists():
                        _nlp = spacy.load(str(_sub))
                        break
        if _nlp is None:
            raise ImportError("spaCy model not found")
        # Process primary legal text (not the full docket with other cases)
        _ner_source = _primary_text[:5000] if _primary_text.strip() else text[:5000]
        doc = _nlp(_ner_source)

        _ner_persons = []
        _ner_orgs = []
        _ner_dates = []
        _ner_locations = []

        for ent in doc.ents:
            if ent.label_ == "PERSON":
                _ner_persons.append(ent.text.strip())
            elif ent.label_ == "ORG":
                _ner_orgs.append(ent.text.strip())
            elif ent.label_ == "DATE":
                _ner_dates.append(ent.text.strip())
            elif ent.label_ in ("GPE", "LOC"):
                _ner_locations.append(ent.text.strip())

        # Fill gaps with NER results

        # Judge: if regex missed it, look for PERSON near "Judge"/"Honorable"
        if not result.get("judge_name") and _ner_persons:
            for person in _ner_persons:
                # Check if this person appears near "Judge" or "Honorable" in the text
                judge_context = re.search(
                    r"(?:Judge|Justice|Honorable|Hon\.?)\s+" + re.escape(person),
                    text[:5000], re.IGNORECASE)
                if judge_context:
                    result["judge_name"] = person
                    break

        # Court name: if regex missed it, use the largest ORG entity with "Court" in it
        if not result.get("court_name"):
            for org in _ner_orgs:
                if "court" in org.lower():
                    result["court_name"] = org
                    break

        # Location: if regex missed it
        if not result.get("location") and _ner_locations:
            # Prefer locations with "County" in them
            for loc in _ner_locations:
                if "county" in loc.lower():
                    result["location"] = loc
                    break
            if not result.get("location"):
                result["location"] = _ner_locations[0]

        # Defendant name: if regex missed it but we have persons not matched elsewhere
        if not result.get("defendant_name") and len(_ner_persons) >= 2:
            # In criminal cases, the defendant is usually the second person named
            # after the state/plaintiff. Skip names that match the judge.
            judge_name = result.get("judge_name", "").lower()
            for person in _ner_persons:
                if (person.lower() != judge_name and
                        "state" not in person.lower() and
                        len(person.split()) >= 2):
                    result["defendant_name"] = person
                    break

        # Dates: if regex missed, use NER dates
        if not result.get("date") and _ner_dates:
            # Prefer dates that look like proceeding dates (skip filing dates)
            for d in _ner_dates:
                if re.search(r'\d{4}', d):  # Has a year
                    result["date"] = d
                    break

        # Attorneys: NER can find person names near "attorney"/"counsel"/"represent"
        # Store for use in attorney extraction below
        result["_ner_persons"] = _ner_persons
        result["_ner_orgs"] = _ner_orgs

        logger.info("NER found: %d persons, %d orgs, %d dates, %d locations",
                    len(_ner_persons), len(_ner_orgs), len(_ner_dates), len(_ner_locations))

    except ImportError:
        logger.debug("spaCy not available — using regex-only extraction")
    except Exception as e:
        logger.warning("NER extraction failed: %s", e)

    # --- Extract attorneys ---
    speakers = []

    # For attorney extraction, use case-isolated docket text if available
    _extract_text = text
    case_num = result.get("case_number", "")

    # If we have docket text (HTM), isolate the specific case
    if _docket_text.strip() and case_num:
        _blocks = re.split(r'(?=Called:)', _docket_text)
        for _block in _blocks:
            if case_num in _block:
                _extract_text = _block
                logger.info("Isolated case block for %s from docket (%d chars)", case_num, len(_extract_text))
                break
        else:
            # Case number not found in docket — use legal docs for attorneys
            _extract_text = text
            logger.info("Case %s not found in docket — extracting attorneys from legal docs", case_num)
    elif "Called:" in text and case_num:
        # The combined text has docket entries — isolate
        _blocks = re.split(r'(?=Called:)', text)
        for _block in _blocks:
            if case_num in _block:
                _extract_text = _block
                logger.info("Isolated case block for %s (%d chars)", case_num, len(_extract_text))
                break

    # Pattern 1: Docket log format — "District Attorney: Name 123456" / "Defense Attorney: Name 123456"
    # Docket log: "District Attorney: Name 123456; Name2 234567"
    # Stop at next role label, timestamp, or newline
    docket_atty_lines = re.finditer(
        r"(District Attorney|Defense Attorney|Prosecutor|Public Defender):\s*"
        r"(.+?)(?=District Attorney|Defense Attorney|Prosecutor|Public Defender|\d{1,2}:\d{2}:\d{2}\s*[AP]M|\n|$)",
        _extract_text, re.IGNORECASE)
    for m in docket_atty_lines:
        role = m.group(1).strip().lower()
        atty_line = m.group(2).strip()

        if "defense" in role or "public defender" in role:
            rep = "Defense"
        else:
            rep = "Plaintiff/State"

        # Split on semicolons for multiple attorneys
        for part in re.split(r'[;]', atty_line):
            part = part.strip()
            if not part:
                continue
            # Extract "Name BarNum"
            am = re.match(r"([A-Za-z][A-Za-z\s.'-]+?)\s+(\d{5,})", part)
            if am:
                name = am.group(1).strip().rstrip(" ,.")
                bar_num = am.group(2)
                speakers.append({
                    "name": name,
                    "firm": f"Bar #{bar_num}",
                    "representing": rep,
                    "hotkey": "",
                })

    # Pattern 2: Notice/motion format — "Attorney for Appellant/Plaintiff/Defendant:"
    if not speakers:
        atty_sections = re.finditer(
            r"Attorney\s+for\s+(Appellant|Respondent|Plaintiff|Defendant|State|Defense):\s*\n"
            r"\s*([A-Z][\w\s.'-]+?)(?:\s+OSB|\s+#|\s+\d{5,}|\s*\n)",
            _extract_text, re.IGNORECASE)
        for m in atty_sections:
            party = m.group(1).strip()
            name = m.group(2).strip()

            # Try to get firm name (usually next line)
            firm_match = re.search(
                re.escape(name) + r".*?\n\s*(.+?)(?:\n|$)",
                text, re.IGNORECASE)
            firm = ""
            if firm_match:
                firm_line = firm_match.group(1).strip()
                if not re.match(r'\d', firm_line) and len(firm_line) > 3:
                    firm = firm_line

            # Map party to representation label
            rep = party.title()
            if party.lower() in ("appellant", "defendant", "defense"):
                rep = "Defense"
            elif party.lower() in ("respondent", "plaintiff", "state"):
                rep = "Plaintiff/State"

            speakers.append({
                "name": name,
                "firm": firm,
                "representing": rep,
                "hotkey": "",
            })

    # NER-assisted attorney discovery (if regex found none)
    if not speakers and result.get("_ner_persons"):
        judge_name = result.get("judge_name", "").lower()
        defendant_name = result.get("defendant_name", "").lower()
        for person in result["_ner_persons"]:
            p_lower = person.lower()
            # Skip judge, defendant, and single-word names
            if (p_lower == judge_name or p_lower == defendant_name or
                    len(person.split()) < 2):
                continue
            # Check context — is this person near "attorney"/"counsel"/"represent"?
            ctx = re.search(
                re.escape(person) + r".{0,100}(?:attorney|counsel|represent|bar|OSB|esq)",
                text[:5000], re.IGNORECASE | re.DOTALL)
            if not ctx:
                ctx = re.search(
                    r"(?:attorney|counsel|represent).{0,100}" + re.escape(person),
                    text[:5000], re.IGNORECASE | re.DOTALL)
            if ctx:
                # Try to determine which side
                side_ctx = ctx.group(0).lower()
                if any(w in side_ctx for w in ("defendant", "appellant", "defense")):
                    rep = "Defendant"
                elif any(w in side_ctx for w in ("plaintiff", "respondent", "state", "prosecution")):
                    rep = "Plaintiff/State"
                else:
                    rep = ""
                # Try to find firm from NER orgs near this person
                firm = ""
                for org in result.get("_ner_orgs", []):
                    if org.lower() not in ("state", "court", "oregon"):
                        org_near = re.search(
                            re.escape(person) + r".{0,150}" + re.escape(org),
                            text[:5000], re.IGNORECASE | re.DOTALL)
                        if org_near:
                            firm = org
                            break
                speakers.append({
                    "name": person,
                    "firm": firm,
                    "representing": rep,
                    "hotkey": "",
                })

    # Add judge as a speaker
    if result.get("judge_name"):
        speakers.insert(0, {
            "name": f"The Court (Judge {result['judge_name']})",
            "firm": "",
            "representing": "The Court",
            "hotkey": "Alt+U",
        })

    # Remove the defendant from speakers — they're a party, not a speaking role
    defendant_name = (result.get("defendant_name") or "").lower()
    if defendant_name:
        speakers = [s for s in speakers if s["name"].lower() != defendant_name]

    # Deduplicate speakers by name (multiple PDFs may list the same person)
    seen_names = set()
    unique_speakers = []
    for spk in speakers:
        name_key = spk["name"].lower().strip()
        if name_key not in seen_names:
            seen_names.add(name_key)
            unique_speakers.append(spk)

    if unique_speakers:
        result["speakers"] = unique_speakers

    # --- Ensure plaintiff/defendant are in the result ---
    # Extract from caption if not already found
    if not result.get("plaintiff_name") and result.get("case_caption"):
        parts = re.split(r'\s+v\.?\s+', result["case_caption"], maxsplit=1)
        if len(parts) == 2:
            result["plaintiff_name"] = parts[0].strip()
            result["defendant_name"] = parts[1].strip()

    # Also try to extract from "Plaintiff:" / "Defendant:" labels
    if not result.get("plaintiff_name"):
        plt_match = re.search(r"(?:Plaintiff|Petitioner|Complainant)\s*[:\-]\s*(.+?)(?:\n|$)", text, re.IGNORECASE)
        if plt_match:
            result["plaintiff_name"] = plt_match.group(1).strip().rstrip(",")
    if not result.get("defendant_name"):
        def_match = re.search(r"(?:Defendant|Respondent|Appellant)\s*[:\-]\s*(.+?)(?:\n|$)", text, re.IGNORECASE)
        if def_match:
            result["defendant_name"] = def_match.group(1).strip().rstrip(",")

    # Try "True Name:" for defendant (common in criminal cases)
    if not result.get("defendant_name"):
        true_name = re.search(r"True Name:\s*(.+?)(?:\s+Sex:|\n|$)", text, re.IGNORECASE)
        if true_name:
            result["defendant_name"] = true_name.group(1).strip()

    # --- Extract proceeding type ---
    proc = re.search(
        r"(?:NOTICE OF\s+)?(APPEAL|ARRAIGNMENT|TRIAL|HEARING|DEPOSITION|SENTENCING|MOTION)",
        text, re.IGNORECASE)
    if proc:
        result["proceeding_type"] = proc.group(1).title()

    # --- Extract dates ---
    # Look for common date formats in court documents
    date_patterns = [
        # "February 9, 2026" or "December 11, 2025"
        (r"(?:(?:hearing|proceeding|sentencing|trial|entered|filed|dated)\s+(?:on\s+)?)"
         r"(\w+ \d{1,2},?\s*\d{4})", "long"),
        # "Proceeding Date: 12/11/2025"
        (r"(?:Proceeding|Hearing|Trial|Sentencing)\s*Date:\s*(\d{1,2}/\d{1,2}/\d{2,4})", "slash"),
        # "on or about December 11, 2025"
        (r"on or about\s+(\w+ \d{1,2},?\s*\d{4})", "long"),
        # Standalone date near judgment/order: "02/09/2026"
        (r"(?:judgment|order|entered)\s+.*?(\d{1,2}/\d{1,2}/\d{4})", "slash"),
    ]
    dates_found = []
    for pattern, fmt in date_patterns:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            dates_found.append({"date": m.group(1).strip(), "format": fmt})

    if dates_found and not result.get("date"):
        # Use the first proceeding-related date found
        result["date"] = dates_found[0]["date"]
    if len(dates_found) > 1:
        result["dates_found"] = [d["date"] for d in dates_found[:5]]

    # --- Extract time information ---
    time_patterns = [
        r"(?:commenced|convened|began|called to order)\s+at\s+(\d{1,2}:\d{2}\s*(?:a\.?m\.?|p\.?m\.?))",
        r"(?:Time|Start(?:ed)?|Began):\s*(\d{1,2}:\d{2}\s*(?:a\.?m\.?|p\.?m\.?)?)",
    ]
    for tp in time_patterns:
        tm = re.search(tp, text, re.IGNORECASE)
        if tm and not result.get("time_in"):
            result["time_in"] = tm.group(1).strip()
            break

    # --- Cross-reference with audio filenames and metadata ---
    # Merge information from audio filenames, flag conflicts, avoid duplicates
    _audio_dates = []
    _audio_times = []
    for f in files:
        fname = f.filename or ""
        # Pattern: YYYYMMDD or YYYY-MM-DD in filename
        audio_date = re.search(r'(\d{4})[-_]?(\d{2})[-_]?(\d{2})', fname)
        if audio_date:
            y, m, d = audio_date.group(1), audio_date.group(2), audio_date.group(3)
            audio_date_str = f"{y}-{m}-{d}"
            if audio_date_str not in _audio_dates:
                _audio_dates.append(audio_date_str)

        # Pattern: HHMM time in filename
        audio_time = re.search(r'[-_](\d{2})(\d{2})(?:[-_.]|\b)', fname)
        if audio_time:
            h, mn = int(audio_time.group(1)), int(audio_time.group(2))
            if 0 <= h <= 23 and 0 <= mn <= 59:
                ampm = "a.m." if h < 12 else "p.m."
                h12 = h if h <= 12 else h - 12
                if h12 == 0: h12 = 12
                time_str = f"{h12}:{mn:02d} {ampm}"
                if time_str not in _audio_times:
                    _audio_times.append(time_str)

    # Merge dates — document date is primary, audio confirms or supplements
    doc_date = result.get("date", "")
    if _audio_dates:
        if not doc_date:
            # No document date — use audio
            result["date"] = _audio_dates[0]
        else:
            # Check if audio date conflicts with document date
            # Normalize both for comparison
            for ad in _audio_dates:
                if ad not in doc_date and ad.replace("-", "") not in doc_date.replace("/", "").replace("-", ""):
                    result.setdefault("date_conflicts", []).append({
                        "document_date": doc_date,
                        "audio_date": ad,
                        "note": "Audio filename date differs from document date — verify which is the proceeding date"
                    })
        # Add all unique audio dates to dates_found
        existing_dates = set(str(d) for d in result.get("dates_found", []))
        for ad in _audio_dates:
            label = f"{ad} (audio)"
            if label not in existing_dates and ad not in doc_date:
                result.setdefault("dates_found", []).append(label)

    # Merge times — audio time fills in if document didn't have one
    if _audio_times:
        if not result.get("time_in"):
            result["time_in"] = _audio_times[0]
        # If multiple audio files have different start times, note the earliest
        if len(_audio_times) > 1:
            result["time_note"] = f"Multiple audio start times found: {', '.join(_audio_times)}"

    # --- Calculate time_out from audio duration ---
    if result.get("time_in") and not result.get("time_out"):
        # Get duration from any uploaded audio files
        total_duration_sec = 0
        for f in files:
            fname = f.filename or ""
            f_ext = Path(fname).suffix.lower()
            if f_ext in (".wav", ".mp3", ".m4a", ".webm", ".flac", ".trm", ".javs"):
                # Try to get duration using ffprobe/ffmpeg
                try:
                    audio_path = UPLOAD_DIR / fname
                    if audio_path.exists():
                        ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
                        probe = subprocess.run(
                            [ffmpeg_bin, "-i", str(audio_path), "-f", "null", "-"],
                            capture_output=True, text=True, timeout=15)
                        dur_match = re.search(r"Duration:\s*(\d+):(\d+):(\d+)", probe.stderr)
                        if dur_match:
                            h = int(dur_match.group(1))
                            m = int(dur_match.group(2))
                            s = int(dur_match.group(3))
                            total_duration_sec = max(total_duration_sec, h * 3600 + m * 60 + s)
                except Exception:
                    pass

        if total_duration_sec > 0:
            # Parse time_in and add duration
            try:
                time_in_str = result["time_in"]
                ti_match = re.match(r"(\d{1,2}):(\d{2})\s*(a\.?m\.?|p\.?m\.?)?", time_in_str, re.IGNORECASE)
                if ti_match:
                    ti_h = int(ti_match.group(1))
                    ti_m = int(ti_match.group(2))
                    ti_ampm = (ti_match.group(3) or "").lower().replace(".", "")
                    # Convert to 24h
                    if "pm" in ti_ampm and ti_h < 12:
                        ti_h += 12
                    elif "am" in ti_ampm and ti_h == 12:
                        ti_h = 0
                    # Add duration
                    total_min = ti_h * 60 + ti_m + (total_duration_sec // 60)
                    to_h = (total_min // 60) % 24
                    to_m = total_min % 60
                    to_ampm = "a.m." if to_h < 12 else "p.m."
                    to_h12 = to_h if to_h <= 12 else to_h - 12
                    if to_h12 == 0:
                        to_h12 = 12
                    result["time_out"] = f"{to_h12}:{to_m:02d} {to_ampm}"
                    result["audio_duration"] = f"{total_duration_sec // 3600}h {(total_duration_sec % 3600) // 60}m"
            except Exception:
                pass

    # Clean up internal fields before returning
    result.pop("_ner_persons", None)
    result.pop("_ner_orgs", None)

    logger.info("Extracted case info: %d fields, %d speakers (doc_type: %s)",
                len([k for k in result if k not in ('raw_text', 'speakers', 'dates_found', 'document_type') and result[k]]),
                len(unique_speakers), doc_type)

    return JSONResponse(result)


@app.post("/api/detect-bookmarks")
async def detect_bookmarks(request: Request):
    """Scan a Word template for bookmarks and auto-map them to data fields."""
    data = await request.json()
    template_path = data.get("template_path", "")

    if not template_path:
        return JSONResponse({"error": "No template path provided. Drag a .dotm file onto the template field or type the full path."})

    # Resolve the path — try as-is first, then common locations
    resolved = Path(template_path)
    if not resolved.exists():
        # Try relative to app directory
        resolved = BASE_DIR / template_path
    if not resolved.exists():
        # Try just the filename in common template locations
        fname = Path(template_path).name
        for search_dir in [
            BASE_DIR / "templates",
            BASE_DIR,
            Path.home() / "Documents",
            Path.home() / "Desktop",
        ]:
            candidate = search_dir / fname
            if candidate.exists():
                resolved = candidate
                break
    if not resolved.exists():
        return JSONResponse({"error": f"Template not found: {template_path}. Try dragging the file directly onto the field, or use the full path (e.g. C:\\Users\\You\\Documents\\template.dotm)."})

    try:
        import zipfile
        import xml.etree.ElementTree as ET

        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        z = zipfile.ZipFile(str(resolved))
        doc_xml = z.read('word/document.xml')
        root = ET.fromstring(doc_xml)

        bookmarks = []
        for bm in root.iter(f'{{{ns["w"]}}}bookmarkStart'):
            name = bm.get(f'{{{ns["w"]}}}name')
            if name and not name.startswith('_'):
                bookmarks.append(name)
        z.close()

        # Auto-map bookmarks to likely data fields
        # Ordered from most specific to least — first match wins
        # EXACT matches checked first, then substring
        field_hints = [
            # Attorney fields — most specific first to avoid broad matches
            ("plt_atty_name", ["pltattyname", "plaintiffattorney", "plaintiffcounsel"]),
            ("plt_atty_firm", ["pltattyfirm", "plaintifffirm", "pltfirm"]),
            ("plt_atty_address", ["pltattyadd", "plaintiffaddress"]),
            ("plt_atty_csz", ["pltattycsz", "plaintiffcsz"]),
            ("plt_atty_phone", ["pltattyphone", "plaintiffphone"]),
            ("def_atty_name", ["defattyname", "defenseattorney", "defensecounsel"]),
            ("def_atty_firm", ["defattyfirm", "defensefirm", "deffirm"]),
            ("def_atty_address", ["defattyadd", "defenseaddress"]),
            ("def_atty_csz", ["defattycsz", "defensecsz"]),
            ("def_atty_phone", ["defattyphone", "defensephone"]),
            # Case fields
            ("case_number", ["docketno", "caseno", "casenumber", "cano"]),
            ("case_caption", ["casecaption", "caption"]),
            ("location", ["division"]),
            ("court_name", ["courtname", "venuename"]),
            ("location", ["courtcity", "courtcitytwo", "courtlocation", "location", "city"]),
            ("plaintiff_name", ["plaintiffname", "pltname", "plaintiff"]),
            ("defendant_name", ["defname", "defendantname", "defendant"]),
            ("date", ["hearingdate", "daydate", "trialdate", "date"]),
            ("proceeding_type", ["hearingtype", "proceedingtype"]),
            ("judge_name", ["judgename", "jurist", "judge"]),
            ("judge_title", ["judgetitle"]),
            ("reporter_name", ["reportername", "reporter", "transcriber"]),
            ("reporter_credential", ["credential", "reportercred", "certification"]),
            ("volume", ["volumeno", "volume"]),
            ("time", ["timetwo", "time"]),
        ]

        mappings = []
        for bm in bookmarks:
            bm_lower = bm.lower().replace("_", "").replace("-", "").replace(" ", "")
            matched = False
            for field, hints in field_hints:
                # Exact match first
                if bm_lower in hints:
                    mappings.append({"bookmark": bm, "field": field})
                    matched = True
                    break
            if not matched:
                # Substring match — but only if no more specific match exists
                for field, hints in field_hints:
                    if any(bm_lower == hint or bm_lower.endswith(hint) for hint in hints):
                        mappings.append({"bookmark": bm, "field": field})
                        matched = True
                        break
            if not matched:
                mappings.append({"bookmark": bm, "field": f"? ({bm})"})

        return JSONResponse({"bookmarks": bookmarks, "mappings": mappings})
    except Exception as e:
        return JSONResponse({"error": str(e)})


@app.post("/api/detect-bookmarks-upload")
async def detect_bookmarks_upload(file: UploadFile = File(...)):
    """Scan an uploaded Word template for bookmarks. Alternative to path-based detection."""
    import tempfile
    try:
        # Save uploaded file temporarily
        suffix = Path(file.filename or "template.dotm").suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        import zipfile
        import xml.etree.ElementTree as ET
        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        z = zipfile.ZipFile(tmp_path)
        doc_xml = z.read('word/document.xml')
        root = ET.fromstring(doc_xml)

        bookmarks = []
        for bm in root.iter(f'{{{ns["w"]}}}bookmarkStart'):
            name = bm.get(f'{{{ns["w"]}}}name')
            if name and not name.startswith('_'):
                bookmarks.append(name)
        z.close()
        os.unlink(tmp_path)

        # Same auto-mapping logic
        field_hints = {
            "court_name": ["division", "court", "venue", "courtname", "venuename"],
            "case_number": ["docket", "cano", "casenumber", "caseno", "docketno"],
            "case_caption": ["caption", "casecaption", "title"],
            "plaintiff_name": ["plaintiff", "plaintiffname", "pltname"],
            "defendant_name": ["defendant", "defname", "defendantname"],
            "date": ["date", "hearingdate", "daydate", "trialdate"],
            "location": ["city", "courtcity", "location", "courtlocation"],
            "proceeding_type": ["hearing", "hearingtype", "proceedingtype", "type"],
            "judge_name": ["judge", "judgename", "jurist"],
            "plt_atty_name": ["pltatty", "pltattyname", "plaintiffattorney", "plaintiffcounsel"],
            "plt_atty_firm": ["pltfirm", "pltattyfirm", "plaintifffirm"],
            "def_atty_name": ["defatty", "defattyname", "defensecounsel", "defenseattorney"],
            "def_atty_firm": ["deffirm", "defattyfirm", "defensefirm"],
            "reporter_name": ["reporter", "reportername", "transcriber"],
            "reporter_credential": ["credential", "reportercred", "certification"],
        }
        mappings = []
        for bm in bookmarks:
            bm_lower = bm.lower().replace("_", "").replace("-", "").replace(" ", "")
            matched = False
            for field, hints in field_hints.items():
                if any(hint in bm_lower for hint in hints):
                    mappings.append({"bookmark": bm, "field": field})
                    matched = True
                    break
            if not matched:
                mappings.append({"bookmark": bm, "field": f"? ({bm})"})

        return JSONResponse({"bookmarks": bookmarks, "mappings": mappings})
    except Exception as e:
        return JSONResponse({"error": str(e)})


@app.delete("/api/job/{job_id}")
async def delete_job(job_id: str):
    job = JOBS.pop(job_id, None)
    if job and job.get("dir"):
        shutil.rmtree(job["dir"], ignore_errors=True)
    return JSONResponse({"ok": True})


@app.delete("/api/profile/{name}")
async def delete_profile(name: str):
    if name in PROFILES:
        del PROFILES[name]
        _save_profiles()
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# Case Management API
# ---------------------------------------------------------------------------

@app.get("/api/cases")
async def list_cases():
    """List all cases with job counts."""
    gate = _require_pro("Case management")
    if gate:
        return gate
    result = {}
    for cid, c in CASES.items():
        case_data = dict(c)
        # Count related jobs by case number
        cn = c.get("case_number", "")
        case_data["job_count"] = sum(
            1 for j in JOBS.values()
            if j.get("case_number", "").strip() == cn.strip() and cn
        )
        result[cid] = case_data
    return JSONResponse(result)


@app.post("/api/case/save")
async def save_case(request: Request):
    gate = _require_pro("Case management")
    if gate:
        return gate
    data = await request.json()
    case_id = data.get("id") or str(uuid.uuid4())[:8]
    data["id"] = case_id
    if "created_at" not in data:
        data["created_at"] = datetime.now().strftime("%Y-%m-%d")
    CASES[case_id] = data
    _save_cases()
    return JSONResponse({"ok": True, "id": case_id})


@app.get("/api/case/{case_id}/detail")
async def case_detail(case_id: str):
    gate = _require_pro("Case management")
    if gate:
        return gate
    c = CASES.get(case_id)
    if not c:
        return JSONResponse({"error": "Not found"}, status_code=404)
    cn = c.get("case_number", "")
    related = [
        {"id": jid, "proceeding_type": j.get("proceeding_type", ""),
         "date": j.get("date", ""), "status": j.get("status", "")}
        for jid, j in JOBS.items()
        if j.get("case_number", "").strip() == cn.strip() and cn
    ]
    return JSONResponse({"case_info": c, "related_jobs": related})


@app.delete("/api/case/{case_id}")
async def delete_case(case_id: str):
    gate = _require_pro("Case management")
    if gate:
        return gate
    CASES.pop(case_id, None)
    _save_cases()
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# Voice Profile API
# ---------------------------------------------------------------------------

@app.get("/api/voice-profiles")
async def list_voice_profiles():
    gate = _require_pro("Voice profiles")
    if gate:
        return gate
    return JSONResponse(VOICE_PROFILES)


@app.post("/api/voice-profile/save")
async def save_voice_profile(request: Request):
    gate = _require_pro("Voice profiles")
    if gate:
        return gate
    data = await request.json()
    name = data.get("name", "").strip()
    if not name:
        return JSONResponse({"error": "Name required"}, status_code=400)
    VOICE_PROFILES[name] = {
        "name": name,
        "firm": data.get("firm", ""),
        "role": data.get("role", ""),
        "notes": data.get("notes", ""),
        "created_at": datetime.now().isoformat(),
        "session_count": data.get("session_count", 0),
    }
    _save_voices()
    return JSONResponse({"ok": True})


@app.delete("/api/voice-profile/{name}")
async def delete_voice_profile(name: str):
    gate = _require_pro("Voice profiles")
    if gate:
        return gate
    VOICE_PROFILES.pop(name, None)
    _save_voices()
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# Live Capture API (Modes A, B, C)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Server-Side Audio Capture (replaces browser getUserMedia)
# ---------------------------------------------------------------------------

_live_capture = {}  # job_id -> capture state

@app.get("/api/audio-devices")
async def list_audio_devices():
    """List available audio input devices using ffmpeg (no extra packages needed)."""
    try:
        ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
        result = subprocess.run(
            [ffmpeg_bin, "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True, text=True, timeout=10,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        # Parse device names from stderr (ffmpeg outputs device list to stderr)
        output = result.stderr
        inputs = []
        device_idx = 0
        for line in output.split("\n"):
            if "(audio)" in line:
                # Extract device name between quotes
                match = re.search(r'"([^"]+)"', line)
                if match:
                    name = match.group(1)
                    inputs.append({
                        "id": device_idx,
                        "name": name,
                        "channels": 1,
                        "sample_rate": 16000,
                        "is_loopback": "stereo mix" in name.lower() or "loopback" in name.lower(),
                    })
                    device_idx += 1
        return JSONResponse({"devices": inputs})
    except Exception as e:
        return JSONResponse({"devices": [], "error": str(e)})


@app.post("/api/live/start")
async def start_live_capture(request: Request):
    """Start a live capture session with server-side audio capture."""
    data = await request.json()
    job_id = data.get("job_id")
    mode = data.get("mode", "C")  # A=Remote, B=Multi-Mic, C=Room
    device_id = data.get("device_id")  # Audio device index
    device_name = data.get("device_name", "")  # Audio device name for ffmpeg
    loopback_id = data.get("loopback_id")  # System audio device for Mode A

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    job["status"] = "recording"
    job["live_mode"] = mode
    job["recording_start"] = datetime.now().isoformat()
    if data.get("channel_labels"):
        job["channel_labels"] = data["channel_labels"]
    _save_job(job)

    # Start server-side audio capture in background thread
    if device_name or device_id is not None:
        import threading
        capture_state = {
            "running": True,
            "device_id": int(device_id) if device_id is not None else 0,
            "device_name": device_name,
            "loopback_id": int(loopback_id) if loopback_id is not None else None,
            "segments": [],
            "buffer": bytearray(),
            "total_ms": 0,
        }
        _live_capture[job_id] = capture_state

        def _capture_thread():
            _server_side_capture(job_id, job, capture_state)

        threading.Thread(target=_capture_thread, daemon=True,
                        name=f"live-capture-{job_id}").start()
        logger.info("Server-side audio capture started: device=%s, loopback=%s",
                    device_id, loopback_id)

    return JSONResponse({"ok": True, "status": "recording", "server_capture": device_id is not None})


def _server_side_capture(job_id, job, state):
    """Server-side audio capture using ffmpeg (no extra packages needed).

    Captures from the system mic via ffmpeg's DirectShow input, writes to
    a WAV pipe, and transcribes chunks in real-time with Whisper.
    """
    import numpy as np
    import wave

    SAMPLE_RATE = 16000
    SEGMENT_SECONDS = 3
    SEGMENT_BYTES = SAMPLE_RATE * 2 * SEGMENT_SECONDS  # 16-bit mono

    device_name = state.get("device_name", "")
    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)

    # Full recording path
    recording_path = audio_dir / "live_recording.wav"

    model = _get_streaming_model()
    if not model:
        logger.error("Could not load streaming model for live capture")
        state["running"] = False
        return

    # Find ffmpeg
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"

    logger.info("Live capture starting: device='%s', rate=%d, ffmpeg=%s",
                device_name, SAMPLE_RATE, ffmpeg_bin)

    # Start ffmpeg capturing from mic, outputting raw PCM to pipe
    # Also save full recording to WAV file simultaneously
    try:
        proc = subprocess.Popen(
            [
                ffmpeg_bin, "-y",
                "-f", "dshow",
                "-i", f"audio={device_name}",
                "-ar", str(SAMPLE_RATE),
                "-ac", "1",
                "-f", "s16le",  # Raw 16-bit signed little-endian PCM to stdout
                "-acodec", "pcm_s16le",
                "pipe:1",       # Output raw PCM to stdout
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )

        # Also start a second ffmpeg to save the full recording
        save_proc = subprocess.Popen(
            [
                ffmpeg_bin, "-y",
                "-f", "dshow",
                "-i", f"audio={device_name}",
                "-ar", str(SAMPLE_RATE),
                "-ac", "1",
                "-acodec", "pcm_s16le",
                str(recording_path),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )

    except Exception as e:
        logger.error("Failed to start ffmpeg capture: %s", e)
        state["running"] = False
        return

    logger.info("FFmpeg capture started (PID %d)", proc.pid)
    audio_buffer = bytearray()

    try:
        while state["running"]:
            # Read audio data from ffmpeg pipe
            chunk = proc.stdout.read(8192)
            if not chunk:
                break
            audio_buffer.extend(chunk)

            # Once we have enough audio, transcribe
            if len(audio_buffer) >= SEGMENT_BYTES:
                segment_data = bytes(audio_buffer[:SEGMENT_BYTES])
                audio_buffer = audio_buffer[SEGMENT_BYTES:]

                # Convert to float32 for Whisper
                audio_np = np.frombuffer(segment_data, dtype=np.int16).astype(np.float32) / 32768.0

                try:
                    with _transcribe_lock:
                        segments_out, _info = model.transcribe(
                            audio_np,
                            language="en",
                            vad_filter=True,
                            vad_parameters={"min_silence_duration_ms": 300},
                            word_timestamps=True,
                        )

                        for seg in segments_out:
                            text = seg.text.strip()
                            if not text:
                                continue

                            result = {
                                "type": "final",
                                "text": text,
                                "speaker": "",
                                "start": state["total_ms"] + int(seg.start * 1000),
                                "end": state["total_ms"] + int(seg.end * 1000),
                                "confidence": round(
                                    seg.avg_logprob if hasattr(seg, 'avg_logprob') else 0.85, 3),
                            }
                            state["segments"].append(result)
                            _append_segment_to_job(job, result)

                except Exception as e:
                    logger.warning("Live transcription error: %s", e)

                state["total_ms"] += SEGMENT_SECONDS * 1000

    except Exception as e:
        logger.error("Audio capture error: %s", e)
    finally:
        state["running"] = False
        # Kill ffmpeg processes
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        try:
            save_proc.terminate()
            save_proc.wait(timeout=5)
        except Exception:
            save_proc.kill()

        # Set audio file reference for editor playback
        if recording_path.exists() and recording_path.stat().st_size > 1000:
            job["audio_file"] = "live_recording.wav"
            logger.info("Live recording saved: %s", recording_path)

        logger.info("Live capture thread ended for job %s", job_id)


@app.get("/api/live/segments/{job_id}")
async def get_live_segments(job_id: str, since: int = 0):
    """Get live transcription segments since a given index. Polled by frontend."""
    state = _live_capture.get(job_id)
    if not state:
        # Fall back to job transcript
        job = JOBS.get(job_id)
        if job and job.get("transcript"):
            segs = job["transcript"].get("segments", [])
            return JSONResponse({"segments": segs[since:], "total": len(segs), "recording": False})
        return JSONResponse({"segments": [], "total": 0, "recording": False})

    segs = state["segments"]
    return JSONResponse({
        "segments": segs[since:],
        "total": len(segs),
        "recording": state["running"],
    })


@app.post("/api/live/stop")
async def stop_live_capture(request: Request):
    """Stop live capture and process the recorded audio."""
    data = await request.json()
    job_id = data.get("job_id")

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    # Stop server-side capture if running
    state = _live_capture.get(job_id)
    if state and state["running"]:
        state["running"] = False
        logger.info("Server-side capture stopped for job %s", job_id)
        # Give capture thread time to save the recording
        time.sleep(1)

    job["status"] = "processing"
    job["recording_end"] = datetime.now().isoformat()
    _save_job(job)

    # Only run full transcription if we don't already have segments from live capture
    existing_segs = len(job.get("transcript", {}).get("segments", []))
    if existing_segs > 0:
        # Already have live segments — just run post-processing
        _auto_flag_issues(job)
        _context_review(job)
        _auto_detect_styles(job)
        _apply_proofing_rules(job)
        job["status"] = "complete"
        _feed_word_live_on_complete(job)
        job["progress"] = 100
        _save_job(job)
        logger.info("Live capture complete: %d segments already transcribed", existing_segs)
    else:
        # No live segments — run full transcription on saved audio
        threading.Thread(target=_run_transcription, args=(job,), daemon=True).start()
    return JSONResponse({"ok": True, "status": "processing"})


# ═══════════════════════════════════════════════════════════
# Word Live — Real-time transcription into Microsoft Word
# ═══════════════════════════════════════════════════════════

@app.post("/api/job/{job_id}/word-live/start")
async def start_word_live_endpoint(job_id: str):
    """Open the reporter's Word template and start feeding transcript in real time."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    profile = job.get("profile", {})
    profile_name = profile.get("name", "") or job.get("jurisdiction_profile", "")
    if profile_name and profile_name in PROFILES:
        profile = PROFILES[profile_name]

    word_styles = profile.get("word_styles", {})
    template_path = word_styles.get("template_path", "")

    if not template_path:
        return JSONResponse({"error": "No Word template configured in the jurisdiction profile. Upload a .dotm template first."})

    # Resolve template path
    resolved = Path(template_path)
    if not resolved.exists():
        stored = BASE_DIR / "templates" / Path(template_path).name
        if stored.exists():
            template_path = str(stored)
        else:
            return JSONResponse({"error": f"Template not found: {template_path}"})

    try:
        from plugins.word_live import start_word_live
        styles = {
            "speaker_designation": word_styles.get("style_speaker", ""),
            "body_text": word_styles.get("style_colloquy", word_styles.get("style_qa", "")),
            "colloquy": word_styles.get("style_colloquy", ""),
            "qa": word_styles.get("style_qa", ""),
        }
        result = start_word_live(job_id, template_path, job, styles)
        return JSONResponse(result)
    except ImportError:
        return JSONResponse({"error": "Word Live requires Microsoft Word and pywin32"})
    except Exception as e:
        return JSONResponse({"error": f"Word Live error: {e}"})


@app.post("/api/job/{job_id}/word-live/feed")
async def feed_word_live_endpoint(job_id: str, request: Request):
    """Feed new transcript segments to the Word document."""
    data = await request.json()
    segments = data.get("segments", [])
    try:
        from plugins.word_live import feed_word_live
        feed_word_live(job_id, segments)
        return JSONResponse({"ok": True, "fed": len(segments)})
    except Exception as e:
        return JSONResponse({"error": str(e)})


@app.post("/api/job/{job_id}/word-live/stop")
async def stop_word_live_endpoint(job_id: str):
    """Stop the Word Live session (Word stays open for editing)."""
    try:
        from plugins.word_live import stop_word_live
        result = stop_word_live(job_id)
        return JSONResponse(result)
    except Exception as e:
        return JSONResponse({"error": str(e)})


@app.get("/api/job/{job_id}/word-live/status")
async def word_live_status_endpoint(job_id: str):
    """Check if Word Live is active for this job."""
    try:
        from plugins.word_live import get_word_live_status
        return JSONResponse(get_word_live_status(job_id))
    except Exception:
        return JSONResponse({"active": False})


@app.post("/api/job/{job_id}/upload-corrected")
async def upload_corrected_transcript(job_id: str, file: UploadFile = File(...)):
    """Upload a corrected transcript back into the case.

    Accepts .docx, .txt, or .pdf. Stores as a revision alongside the original.
    The case manager can view revision history and compare versions.
    """
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    job_dir = Path(job["dir"])
    revisions_dir = job_dir / "revisions"
    revisions_dir.mkdir(exist_ok=True)

    # Save the uploaded file
    rev_num = len(list(revisions_dir.glob("*"))) + 1
    ext = Path(file.filename).suffix.lower()
    rev_filename = f"revision_{rev_num}{ext}"
    dest = revisions_dir / rev_filename

    content = await file.read()
    dest.write_bytes(content)

    # Track revision metadata
    rev_meta = {
        "revision": rev_num,
        "filename": file.filename,
        "saved_as": rev_filename,
        "uploaded": datetime.now().isoformat(),
        "size": len(content),
        "format": ext,
    }

    # Update job revision history
    if "revisions" not in job:
        job["revisions"] = []
    job["revisions"].append(rev_meta)
    _save_job(job)

    logger.info("Corrected transcript uploaded: %s (revision %d)", file.filename, rev_num)
    return JSONResponse({
        "ok": True,
        "revision": rev_num,
        "filename": rev_filename,
        "message": f"Revision {rev_num} saved successfully.",
    })


@app.get("/api/job/{job_id}/revisions")
async def get_revisions(job_id: str):
    """Get revision history for a job."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    return JSONResponse({"revisions": job.get("revisions", [])})


@app.post("/api/job/{job_id}/upload-audio")
async def upload_audio(job_id: str, file: UploadFile = File(...)):
    """Upload a recorded audio file to an existing job."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    audio_dir.mkdir(exist_ok=True)
    dest = audio_dir / file.filename
    with open(dest, "wb") as f:
        content = await file.read()
        f.write(content)
    job.setdefault("files", []).append(str(dest))
    job["audio_file"] = file.filename
    _save_job(job)
    return JSONResponse({"ok": True, "file": file.filename})


# ---------------------------------------------------------------------------
# Live Chunk Transcription — rolling transcript during recording
# ---------------------------------------------------------------------------

@app.post("/api/live/chunk")
async def live_chunk(job_id: str = Form(""), file: UploadFile = File(...)):
    """Receive a 30-second audio chunk during live recording, transcribe it,
    return segments, and broadcast via SSE for attorney live view."""
    import tempfile

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    # Save chunk temporarily
    try:
        suffix = Path(file.filename or "chunk.webm").suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix, dir=str(UPLOAD_DIR)) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        # Convert to WAV for transcription
        wav_path = tmp_path + ".wav"
        ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
        subprocess.run([ffmpeg_bin, "-y", "-i", tmp_path,
                       "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                       wav_path], capture_output=True, creationflags=_NO_WINDOW, timeout=30)

        segments = []
        engine = SETTINGS.get("engine", "assemblyai")

        if engine == "assemblyai" and SETTINGS.get("api_key"):
            # Quick transcription via AssemblyAI
            try:
                import assemblyai as aai
                aai.settings.api_key = SETTINGS["api_key"]
                config = aai.TranscriptionConfig(
                    speaker_labels=True,
                    language_code="en",
                )
                transcript = aai.Transcriber().transcribe(wav_path, config=config)
                if transcript.status == aai.TranscriptStatus.completed:
                    for utt in (transcript.utterances or []):
                        segments.append({
                            "text": utt.text,
                            "speaker": f"Speaker {utt.speaker}",
                            "start": utt.start,
                            "end": utt.end,
                            "confidence": utt.confidence or 0.9,
                        })
            except Exception as e:
                logger.warning("Live chunk AssemblyAI error: %s", e)

        if not segments:
            # Fallback to Whisper
            try:
                from faster_whisper import WhisperModel
                model_size = SETTINGS.get("whisper_model", "small.en")
                try:
                    model = WhisperModel(model_size, device="cuda", compute_type="float16")
                except Exception:
                    model = WhisperModel(model_size, device="cpu", compute_type="int8")
                try:
                    segs, _ = model.transcribe(wav_path, vad_filter=True)
                except Exception:
                    # CUDA lib missing at inference — force CPU
                    model = WhisperModel(model_size, device="cpu", compute_type="int8")
                    segs, _ = model.transcribe(wav_path, vad_filter=True)
                for seg in segs:
                    segments.append({
                        "text": seg.text.strip(),
                        "speaker": "",
                        "start": int(seg.start * 1000),
                        "end": int(seg.end * 1000),
                        "confidence": 0.85,
                    })
            except Exception as e:
                logger.warning("Live chunk Whisper error: %s", e)

        # Clean up temp files
        try:
            os.unlink(tmp_path)
            os.unlink(wav_path)
        except Exception:
            pass

        # Append segments to job transcript
        if segments:
            if not job.get("transcript"):
                job["transcript"] = {"segments": [], "full_text": "", "engine": engine}
            existing = job["transcript"].setdefault("segments", [])

            # Offset timestamps by existing duration
            offset = 0
            if existing:
                offset = max(s.get("end", 0) for s in existing)

            for seg in segments:
                seg["start"] += offset
                seg["end"] += offset
                existing.append(seg)

            job["transcript"]["full_text"] = " ".join(s["text"] for s in existing)
            _save_job(job)

            # Feed to Word Live if active
            try:
                from plugins.word_live import feed_word_live, get_word_live_status
                if get_word_live_status(job_id).get("active"):
                    feed_word_live(job_id, segments)
            except Exception:
                pass

            # Broadcast via SSE for live attorney view
            for seg in segments:
                await _sse_broadcast(job_id, "new_segment", seg)

        return JSONResponse({"ok": True, "segments": segments, "count": len(segments)})

    except Exception as e:
        logger.error("Live chunk error: %s", e)
        return JSONResponse({"error": str(e)}, status_code=500)


# ---------------------------------------------------------------------------
# CC-Style Live Streaming Transcription (WebSocket)
# Words appear as spoken — true closed-captioning experience.
# Browser streams raw PCM audio via WebSocket; server runs Whisper in short
# segments and pushes partial/final text back immediately.
# ---------------------------------------------------------------------------

# Shared Whisper model for streaming — loaded once, reused across sessions
_streaming_model = None
_streaming_model_lock = threading.Lock()
_transcribe_lock = threading.Lock()  # CTranslate2 is not thread-safe for concurrent inference


def _get_streaming_model():
    """Get or lazily load the Whisper model for streaming transcription."""
    global _streaming_model
    if _streaming_model is not None:
        return _streaming_model
    with _streaming_model_lock:
        if _streaming_model is not None:
            return _streaming_model
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            logger.error("faster-whisper not installed — streaming transcription unavailable")
            return None
        model_size = SETTINGS.get("whisper_model", "small.en")

        # Ensure VAD model is findable
        try:
            import faster_whisper as _fw
            _fw_assets = Path(_fw.__file__).parent / "assets"
            _vad_file = _fw_assets / "silero_vad_v6.onnx"
            if not _vad_file.exists():
                for candidate in [
                    BASE_DIR / "_internal" / "faster_whisper" / "assets" / "silero_vad_v6.onnx",
                    BASE_DIR / "faster_whisper" / "assets" / "silero_vad_v6.onnx",
                ]:
                    if candidate.exists():
                        _fw_assets.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(str(candidate), str(_vad_file))
                        break
        except Exception:
            pass

        try:
            _streaming_model = WhisperModel(model_size, device="cuda", compute_type="float16")
            logger.info("Streaming Whisper model loaded on CUDA: %s", model_size)
        except Exception:
            _streaming_model = WhisperModel(model_size, device="cpu", compute_type="int8")
            logger.info("Streaming Whisper model loaded on CPU: %s", model_size)
        return _streaming_model


@app.websocket("/ws/live/stream/{job_id}")
async def ws_live_stream(websocket: WebSocket, job_id: str):
    """WebSocket endpoint for CC-style live transcription.

    Protocol:
    - Client sends binary frames: raw PCM 16-bit LE mono 16kHz audio
    - Client sends JSON text frames for control: {"action": "stop"}
    - Server sends JSON text frames back:
      {"type": "partial", "text": "...", "words": [...]}       — interim result
      {"type": "final",   "text": "...", "speaker": "...", "start": ms, "end": ms}  — committed segment
      {"type": "status",  "message": "..."}                    — status updates
    """
    await websocket.accept()
    logger.info("WS streaming session started for job %s", job_id)

    job = JOBS.get(job_id)
    if not job:
        await websocket.send_json({"type": "error", "message": "Job not found"})
        await websocket.close()
        return

    # Audio buffer — accumulates PCM samples (16-bit LE, 16kHz, mono)
    audio_buffer = bytearray()
    SAMPLE_RATE = 16000
    BYTES_PER_SAMPLE = 2  # 16-bit
    # Transcribe every N seconds of accumulated audio
    SEGMENT_SECONDS = 3
    SEGMENT_BYTES = SAMPLE_RATE * BYTES_PER_SAMPLE * SEGMENT_SECONDS
    # No overlap — Whisper's VAD handles segment boundaries well,
    # and overlap causes duplicate text that's harder to dedup than to avoid
    OVERLAP_BYTES = 0

    total_duration_ms = 0  # Running offset for timestamps
    last_transcribed_text = ""

    # Preload model (do it in background so WS doesn't block)
    model = None
    model_ready = asyncio.Event()

    async def load_model():
        nonlocal model
        try:
            model = await asyncio.get_event_loop().run_in_executor(None, _get_streaming_model)
            model_ready.set()
            await websocket.send_json({"type": "status", "message": "Transcription engine ready"})
        except Exception as e:
            await websocket.send_json({"type": "error", "message": f"Failed to load model: {e}"})
            model_ready.set()  # unblock even on failure

    asyncio.create_task(load_model())

    try:
        while True:
            msg = await websocket.receive()

            if msg.get("type") == "websocket.disconnect":
                break

            # Text frame = control message
            if "text" in msg:
                try:
                    ctrl = json.loads(msg["text"])
                    if ctrl.get("action") == "stop":
                        # Process any remaining audio
                        if len(audio_buffer) > SAMPLE_RATE * BYTES_PER_SAMPLE // 2:  # >0.5s remaining
                            await model_ready.wait()
                            if model:
                                result = await _transcribe_buffer(
                                    model, bytes(audio_buffer), SAMPLE_RATE, total_duration_ms
                                )
                                if result:
                                    for seg in result:
                                        await websocket.send_json(seg)
                                        if seg["type"] == "final":
                                            await _sse_broadcast(job_id, "new_segment", seg)
                                            _append_segment_to_job(job, seg)
                        await websocket.send_json({"type": "status", "message": "Stream ended"})
                        break
                except json.JSONDecodeError:
                    pass
                continue

            # Binary frame = audio data
            if "bytes" in msg:
                audio_buffer.extend(msg["bytes"])

                # Once we have enough audio, transcribe
                if len(audio_buffer) >= SEGMENT_BYTES:
                    await model_ready.wait()
                    if not model:
                        continue

                    # Take the segment to transcribe
                    segment_audio = bytes(audio_buffer)

                    # Send partial indicator
                    await websocket.send_json({"type": "partial", "text": "..."})

                    # Transcribe in thread pool (don't block the event loop)
                    result = await _transcribe_buffer(
                        model, segment_audio, SAMPLE_RATE, total_duration_ms
                    )

                    if result:
                        for seg in result:
                            if not seg or not isinstance(seg, dict):
                                continue
                            # Real-time context check before sending
                            try:
                                context_flags = _realtime_context_check(seg, job)
                                if context_flags:
                                    seg["context_flags"] = context_flags
                            except Exception:
                                pass
                            await websocket.send_json(seg)
                            if seg.get("type") == "final":
                                # Broadcast to attorney live view
                                await _sse_broadcast(job_id, "new_segment", seg)
                                # Persist to job
                                _append_segment_to_job(job, seg)

                    # Advance: keep overlap for continuity
                    consumed = len(audio_buffer) - OVERLAP_BYTES
                    total_duration_ms += int(consumed / BYTES_PER_SAMPLE / SAMPLE_RATE * 1000)
                    audio_buffer = audio_buffer[-OVERLAP_BYTES:] if OVERLAP_BYTES > 0 else bytearray()

    except Exception as e:
        logger.warning("WS streaming error for job %s: %s", job_id, e)
    finally:
        logger.info("WS streaming session ended for job %s", job_id)
        try:
            await websocket.close()
        except Exception:
            pass


async def _transcribe_buffer(model, audio_bytes: bytes, sample_rate: int, offset_ms: int):
    """Transcribe a PCM buffer using faster-whisper. Returns list of segment dicts."""
    import tempfile
    import numpy as np

    def _run():
        # Convert raw PCM to numpy float32
        audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0

        if len(audio_np) < sample_rate * 0.5:  # Skip if <0.5s
            return []

        with _transcribe_lock:
            segments, _info = model.transcribe(
                audio_np,
                language="en",
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300},
                word_timestamps=True,
            )

            results = []
            for seg in segments:
                text = seg.text.strip()
                if not text:
                    continue

                words = []
                if seg.words:
                    for w in seg.words:
                        words.append({
                            "word": w.word,
                            "start": offset_ms + int(w.start * 1000),
                            "end": offset_ms + int(w.end * 1000),
                            "probability": round(w.probability, 3),
                        })

                results.append({
                    "type": "final",
                    "text": text,
                    "speaker": "",
                    "start": offset_ms + int(seg.start * 1000),
                    "end": offset_ms + int(seg.end * 1000),
                    "confidence": round(seg.avg_logprob if hasattr(seg, 'avg_logprob') else 0.85, 3),
                    "words": words,
                })

        return results

    return await asyncio.get_event_loop().run_in_executor(None, _run)


def _realtime_context_check(seg: dict, job: dict) -> list:
    """Lightweight context check that runs on each streaming segment in real time.
    Returns a list of flag dicts, or empty list if clean."""
    flags = []
    text = seg.get("text", "")
    text_lower = text.lower()

    # Known legal term confusions
    for confused, correct in _LEGAL_CONFUSED_PAIRS.items():
        if correct is None:
            continue
        if confused in text_lower and correct not in text_lower:
            flags.append({
                "type": "context_legal_term",
                "detail": f'"{confused}" — did you mean "{correct}"?',
                "suggestion": correct,
            })

    # Unlikely words
    for unlikely in _UNLIKELY_IN_COURT:
        if unlikely in text_lower:
            flags.append({
                "type": "context_unlikely",
                "detail": f'"{unlikely}" — unusual in court transcript',
            })
            break

    # Check against known speakers — if a speaker's name appears garbled in text
    existing_segs = job.get("transcript", {}).get("segments", [])
    known_speakers = set()
    for s in existing_segs:
        spk = s.get("speaker", "")
        if spk and spk not in ("—", ""):
            for part in spk.split():
                if len(part) >= 4:
                    known_speakers.add(part.upper())

    # Look for near-misses of known names in the text
    for word in text.split():
        word_clean = word.strip(".,;:!?\"'()").upper()
        if len(word_clean) < 4:
            continue
        for name in known_speakers:
            if (word_clean != name and
                    word_clean[:3] == name[:3] and
                    len(word_clean) >= len(name) - 1 and
                    abs(len(word_clean) - len(name)) <= 2):
                flags.append({
                    "type": "context_name_variant",
                    "detail": f'"{word.strip(".,;:!?")}" may be "{name}"',
                    "suggestion": name.title(),
                })
                break

    return flags


def _append_segment_to_job(job: dict, seg: dict):
    """Append a streaming segment to the job's transcript (persistent)."""
    if not job.get("transcript"):
        job["transcript"] = {"segments": [], "full_text": "", "engine": "whisper_stream"}
    existing = job["transcript"].setdefault("segments", [])
    existing.append({
        "text": seg["text"],
        "speaker": seg.get("speaker", ""),
        "start": seg.get("start", 0),
        "end": seg.get("end", 0),
        "confidence": seg.get("confidence", 0.85),
    })
    job["transcript"]["full_text"] = " ".join(s["text"] for s in existing)
    _save_job(job)


# ---------------------------------------------------------------------------
# Live Share — attorney real-time transcript view
# ---------------------------------------------------------------------------

@app.post("/api/live/share/create")
async def create_live_share(request: Request):
    """Generate a shareable link for attorneys to view live transcript."""
    gate = _require_pro("Local network live sharing")
    if gate:
        return gate
    data = await request.json()
    job_id = data.get("job_id")
    if not job_id or job_id not in JOBS:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    token = _secrets.token_urlsafe(32)
    LIVE_SHARES[token] = {
        "job_id": job_id,
        "active": True,
        "created": datetime.now().isoformat(),
        "viewers": 0,
    }
    url = f"/static/live_view.html?token={token}&job={job_id}"
    logger.info("Live share created for job %s: token=%s...", job_id, token[:8])
    return JSONResponse({"ok": True, "token": token, "url": url})


@app.post("/api/live/share/stop")
async def stop_live_share(request: Request):
    """Deactivate all share links for a job."""
    data = await request.json()
    job_id = data.get("job_id")
    stopped = 0
    for token, share in list(LIVE_SHARES.items()):
        if share.get("job_id") == job_id:
            share["active"] = False
            stopped += 1
    if job_id:
        await _sse_broadcast(job_id, "session_ended", {"reason": "Reporter stopped sharing"})
    return JSONResponse({"ok": True, "stopped": stopped})


@app.get("/api/live/share/{token}/state")
async def live_share_state(token: str):
    """Get current transcript state for initial page load."""
    share = LIVE_SHARES.get(token)
    if not share or not share.get("active"):
        return JSONResponse({"error": "Invalid or expired link"}, status_code=403)
    job = JOBS.get(share["job_id"])
    if not job or not job.get("transcript"):
        return JSONResponse({"segments": [], "job_info": {}})
    return JSONResponse({
        "segments": job["transcript"].get("segments", []),
        "job_info": {
            "court_name": job.get("court_name", ""),
            "case_number": job.get("case_number", ""),
            "proceeding_type": job.get("proceeding_type", ""),
            "date": job.get("date", ""),
        },
    })


# ---------------------------------------------------------------------------
# Referral Program
# ---------------------------------------------------------------------------

@app.post("/api/admin/referral/generate")
async def generate_referral(request: Request):
    """Generate a referral code — can be tied to a license holder or standalone."""
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    data = await request.json()

    # Support both flows: admin UI (name/discount) and license-tied
    license_key = data.get("license_key", "")
    name = data.get("name", "")
    discount_pct = data.get("discount_pct", 10)
    max_uses = data.get("max_uses", 50)

    referrer_name = name
    if license_key:
        for l in ADMIN_DATA.get("licenses", []):
            if l["key"] == license_key:
                referrer_name = referrer_name or l.get("customer_name", "")
                break

    code = f"REF-{_secrets.token_hex(4).upper()}"

    ADMIN_DATA.setdefault("referrals", {})[code] = {
        "referrer_key": license_key,
        "referrer_name": referrer_name,
        "name": name,
        "discount_pct": discount_pct,
        "max_uses": max_uses,
        "status": "active",
        "created": datetime.now().strftime("%Y-%m-%d"),
        "uses": [],
    }
    _save_admin()
    return JSONResponse({"ok": True, "code": code})


@app.get("/api/admin/referrals")
async def list_referrals(request: Request):
    """List all referral codes and their usage."""
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    return JSONResponse(ADMIN_DATA.get("referrals", {}))


@app.get("/api/referral/{code}/validate")
async def validate_referral(code: str):
    """Public endpoint — check if a referral code is valid."""
    ref = ADMIN_DATA.get("referrals", {}).get(code)
    if not ref or ref.get("status") != "active":
        return JSONResponse({"valid": False})
    # Check max uses
    uses = ref.get("uses", [])
    max_uses = ref.get("max_uses", 0)
    if max_uses and isinstance(uses, list) and len(uses) >= max_uses:
        return JSONResponse({"valid": False, "reason": "max_uses_reached"})
    return JSONResponse({
        "valid": True,
        "referrer": ref.get("referrer_name", "").split()[0] if ref.get("referrer_name") else "A Notare user",
    })


# ---------------------------------------------------------------------------
# Academic License Batch Generation
# ---------------------------------------------------------------------------

@app.post("/api/admin/license/generate-batch")
async def generate_batch_licenses(request: Request):
    """Generate multiple academic licenses for a school."""
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    data = await request.json()
    count = min(data.get("count", 1), 100)  # Cap at 100
    school = data.get("school_name", "")
    contact_email = data.get("contact_email", "")
    tier = data.get("tier", "academic")
    duration_days = data.get("duration_days", 365)

    from datetime import timedelta
    if duration_days and duration_days > 0:
        expires = (datetime.now() + timedelta(days=duration_days)).strftime("%Y-%m-%d")
    else:
        expires = ""  # Unlimited

    keys = []
    for _ in range(count):
        key = f"NOTARE-ACAD-{_secrets.token_hex(3).upper()}-{_secrets.token_hex(3).upper()}"
        entry = {
            "key": key,
            "customer_name": f"Student — {school}",
            "email": contact_email,
            "org": school,
            "tier": tier,
            "status": "active",
            "created": datetime.now().strftime("%Y-%m-%d"),
            "expires": expires,
            "academic": True,
            "school_name": school,
        }
        ADMIN_DATA.setdefault("licenses", []).append(entry)
        keys.append(key)

    _save_admin()
    logger.info("Generated %d academic licenses for %s", count, school)
    return JSONResponse({"ok": True, "keys": keys, "count": count, "school": school})


# ---------------------------------------------------------------------------
# 2-Seat Editor Collaboration (Agency tier)
# ---------------------------------------------------------------------------

@app.post("/api/job/{job_id}/editor/join")
async def editor_join(job_id: str, request: Request):
    """Join an editing session. Professional tier required."""
    gate = _require_pro("Collaborative editing")
    if gate:
        return gate
    data = await request.json()
    editor_name = data.get("name", "Editor")

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    # Initialize session if needed
    if job_id not in EDITOR_SESSIONS:
        EDITOR_SESSIONS[job_id] = {"editors": {}, "segment_locks": {}}

    session = EDITOR_SESSIONS[job_id]
    token = _secrets.token_hex(16)
    session["editors"][token] = {
        "name": editor_name,
        "connected": datetime.now().isoformat(),
        "locked_segment": None,
    }

    # Broadcast to other editors
    await _sse_broadcast(job_id, "editor_joined", {
        "name": editor_name,
        "editor_count": len(session["editors"]),
    })

    logger.info("Editor '%s' joined job %s (%d editors)", editor_name, job_id, len(session["editors"]))
    return JSONResponse({
        "ok": True,
        "editor_token": token,
        "editors": [{"name": e["name"]} for e in session["editors"].values()],
    })


@app.post("/api/job/{job_id}/editor/leave")
async def editor_leave(job_id: str, request: Request):
    """Leave an editing session. Releases all locks."""
    data = await request.json()
    token = data.get("editor_token", "")

    session = EDITOR_SESSIONS.get(job_id)
    if not session:
        return JSONResponse({"ok": True})

    editor = session["editors"].pop(token, None)
    editor_name = editor["name"] if editor else "Unknown"

    # Release any locks held by this editor
    locks = session["segment_locks"]
    released = [idx for idx, t in list(locks.items()) if t == token]
    for idx in released:
        del locks[idx]
        await _sse_broadcast(job_id, "segment_unlocked", {"index": idx})

    # Clean up empty sessions
    if not session["editors"]:
        del EDITOR_SESSIONS[job_id]

    await _sse_broadcast(job_id, "editor_left", {"name": editor_name})
    return JSONResponse({"ok": True, "released_locks": released})


@app.post("/api/job/{job_id}/segment/{index}/lock")
async def lock_segment(job_id: str, index: int, request: Request):
    """Lock a segment for editing. Prevents other editors from modifying it."""
    data = await request.json()
    token = data.get("editor_token", "")

    session = EDITOR_SESSIONS.get(job_id)
    if not session or token not in session["editors"]:
        return JSONResponse({"error": "Not in editing session"}, status_code=403)

    locks = session["segment_locks"]
    existing_lock = locks.get(index)

    if existing_lock and existing_lock != token:
        # Locked by someone else
        other = session["editors"].get(existing_lock, {})
        return JSONResponse({
            "locked": False,
            "locked_by": other.get("name", "Another editor"),
        })

    # Lock it
    locks[index] = token
    session["editors"][token]["locked_segment"] = index
    editor_name = session["editors"][token]["name"]

    await _sse_broadcast(job_id, "segment_locked", {
        "index": index, "editor": editor_name,
    })
    return JSONResponse({"locked": True})


@app.post("/api/job/{job_id}/segment/{index}/unlock")
async def unlock_segment(job_id: str, index: int, request: Request):
    """Unlock a segment."""
    data = await request.json()
    token = data.get("editor_token", "")

    session = EDITOR_SESSIONS.get(job_id)
    if not session:
        return JSONResponse({"ok": True})

    locks = session["segment_locks"]
    if locks.get(index) == token:
        del locks[index]
        if token in session["editors"]:
            session["editors"][token]["locked_segment"] = None
        await _sse_broadcast(job_id, "segment_unlocked", {"index": index})

    return JSONResponse({"ok": True})


@app.get("/api/job/{job_id}/editor/status")
async def editor_status(job_id: str):
    """Get current editing session status — who's online, what's locked."""
    session = EDITOR_SESSIONS.get(job_id)
    if not session:
        return JSONResponse({"active": False, "editors": [], "locks": {}})
    return JSONResponse({
        "active": True,
        "editors": [{"name": e["name"]} for e in session["editors"].values()],
        "locks": {str(k): session["editors"].get(v, {}).get("name", "?")
                  for k, v in session["segment_locks"].items()},
    })


# ---------------------------------------------------------------------------
# Update Server API (serves updates to client installations)
# ---------------------------------------------------------------------------

CURRENT_VERSION = "1.2.0"  # v1.2.0: Complete audio fix, assemblyai bundled, engine failover

@app.get("/api/update")
async def check_update(current: str = "0.0.0"):
    """Client calls this on startup to check for updates."""
    update_zip = BASE_DIR / "updates" / f"notare-{CURRENT_VERSION}.zip"
    if current < CURRENT_VERSION and update_zip.exists():
        return JSONResponse({
            "update_available": True,
            "version": CURRENT_VERSION,
            "url": f"/api/update/download",
        })
    return JSONResponse({"update_available": False, "version": CURRENT_VERSION})


@app.get("/api/update/download")
async def download_update():
    """Serve the update package."""
    update_zip = BASE_DIR / "updates" / f"notare-{CURRENT_VERSION}.zip"
    if update_zip.exists():
        return FileResponse(str(update_zip), filename=f"notare-{CURRENT_VERSION}.zip")
    return JSONResponse({"error": "No update package found"}, status_code=404)


# ---------------------------------------------------------------------------
# Admin Panel & License Management API
# ---------------------------------------------------------------------------

import hashlib, secrets

_admin_path = BASE_DIR / "admin_data.json"
ADMIN_DATA = {
    "admins": [
        {"username": "admin", "password_hash": "8c53c5f862b5c799fad991c14a7ead36037a5e5f33ecfc904946e2f4996fdc7d", "role": "admin"},
    ],
    "licenses": [],
    "tokens": {},
}
if _admin_path.exists():
    try:
        ADMIN_DATA.update(json.loads(_admin_path.read_text(encoding="utf-8")))
    except Exception:
        pass

def _save_admin():
    _admin_path.write_text(json.dumps(ADMIN_DATA, indent=2), encoding="utf-8")

def _check_admin(request):
    token = request.headers.get("Authorization", "")
    return token in ADMIN_DATA.get("tokens", {})

TIER_PRICES = {
    "solo": 59.00, "solo_plus": 89.00,
    "professional": 119.00, "agency": 249.00,
    "enterprise": 0, "support": 0, "trial": 0, "academic": 0,
}
# Annual pricing: pay 10 get 12 (handled in admin/billing display)
TIER_ANNUAL = {k: round(v * 10, 2) for k, v in TIER_PRICES.items() if v > 0}


@app.post("/api/admin/login")
async def admin_login(request: Request):
    data = await request.json()
    username = data.get("username", "")
    pw_hash = hashlib.sha256(data.get("password", "").encode()).hexdigest()
    for admin in ADMIN_DATA.get("admins", []):
        if admin["username"] == username and admin["password_hash"] == pw_hash:
            token = secrets.token_hex(32)
            ADMIN_DATA.setdefault("tokens", {})[token] = username
            _save_admin()
            return JSONResponse({"ok": True, "token": token})
    return JSONResponse({"ok": False})


@app.get("/api/admin/dashboard")
async def admin_dashboard(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    licenses = ADMIN_DATA.get("licenses", [])
    active = [l for l in licenses if l.get("status") == "active"]
    revenue = sum(TIER_PRICES.get(l.get("tier", ""), 0) for l in active)
    contacts_file = BASE_DIR / "contacts.json"
    contacts = []
    if contacts_file.exists():
        try:
            contacts = json.loads(contacts_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    recent = []
    for l in sorted(licenses, key=lambda x: x.get("created", ""), reverse=True)[:5]:
        recent.append(f"License {l.get('key', '')[:8]}... created for {l.get('customer_name', 'unknown')} ({l.get('tier', '')})")
    return JSONResponse({
        "active_licenses": len(active),
        "total_customers": len(set(l.get("email") for l in licenses if l.get("email"))),
        "pending_contacts": len(contacts),
        "monthly_revenue": round(revenue, 2),
        "recent": recent,
    })


@app.get("/api/admin/licenses")
async def admin_licenses(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    return JSONResponse(ADMIN_DATA.get("licenses", []))


@app.post("/api/admin/license/generate")
async def generate_license(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    data = await request.json()
    key = f"NOTARE-{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}"
    duration = data.get("duration_days", 365)
    expires = ""
    if duration > 0:
        from datetime import timedelta
        expires = (datetime.now() + timedelta(days=duration)).strftime("%Y-%m-%d")
    license_entry = {
        "key": key,
        "customer_name": data.get("customer_name", ""),
        "email": data.get("email", ""),
        "org": data.get("org", ""),
        "tier": data.get("tier", "solo"),
        "status": "active",
        "created": datetime.now().strftime("%Y-%m-%d"),
        "expires": expires,
    }
    ADMIN_DATA.setdefault("licenses", []).append(license_entry)
    _save_admin()
    return JSONResponse({"ok": True, "key": key})


@app.post("/api/admin/license/upgrade")
async def upgrade_license(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    data = await request.json()
    old_key = data.get("old_key", "")
    new_tier = data.get("new_tier", "solo")
    duration = data.get("duration_days", 365)

    # Find and deactivate old license
    old_license = None
    for l in ADMIN_DATA.get("licenses", []):
        if l["key"] == old_key:
            old_license = l
            l["status"] = "expired"
            l["deactivated_reason"] = f"upgraded to {new_tier}"
            break
    if not old_license:
        return JSONResponse({"error": "Old license not found"}, status_code=404)

    # Generate new key at the new tier
    new_key = f"NOTARE-{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}"
    expires = ""
    if duration > 0:
        from datetime import timedelta
        expires = (datetime.now() + timedelta(days=duration)).strftime("%Y-%m-%d")

    new_license = {
        "key": new_key,
        "customer_name": old_license.get("customer_name", ""),
        "email": data.get("email", old_license.get("email", "")),
        "org": data.get("org", old_license.get("org", "")),
        "tier": new_tier,
        "status": "active",
        "created": datetime.now().strftime("%Y-%m-%d"),
        "expires": expires,
        "upgraded_from": old_key,
    }
    ADMIN_DATA.setdefault("licenses", []).append(new_license)
    _save_admin()
    return JSONResponse({"ok": True, "new_key": new_key, "old_key": old_key})


@app.post("/api/admin/license/{key}/deactivate")
async def deactivate_license(key: str, request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    for l in ADMIN_DATA.get("licenses", []):
        if l["key"] == key:
            l["status"] = "expired"
            _save_admin()
            return JSONResponse({"ok": True})
    return JSONResponse({"error": "Not found"}, status_code=404)


@app.post("/api/admin/license/{key}/activate")
async def activate_license(key: str, request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    for l in ADMIN_DATA.get("licenses", []):
        if l["key"] == key:
            l["status"] = "active"
            _save_admin()
            return JSONResponse({"ok": True})
    return JSONResponse({"error": "Not found"}, status_code=404)


@app.get("/api/admin/customers")
async def admin_customers(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    customers = []
    for l in ADMIN_DATA.get("licenses", []):
        if l.get("email"):
            customers.append({
                "name": l.get("customer_name", ""),
                "email": l.get("email", ""),
                "org": l.get("org", ""),
                "tier": l.get("tier", ""),
                "license_key": l.get("key", ""),
                "created": l.get("created", ""),
            })
    return JSONResponse(customers)


@app.get("/api/admin/contacts")
async def admin_contacts(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    contacts_file = BASE_DIR / "contacts.json"
    if contacts_file.exists():
        return JSONResponse(json.loads(contacts_file.read_text(encoding="utf-8")))
    return JSONResponse([])


@app.get("/api/admin/system")
async def admin_system(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    return JSONResponse({
        "version": "0.2",
        "active_jobs": len([j for j in JOBS.values() if j.get("status") in ("processing", "recording")]),
        "total_jobs": len(JOBS),
        "admins": [{"username": a["username"], "role": a["role"]} for a in ADMIN_DATA.get("admins", [])],
    })


@app.post("/api/admin/admin/create")
async def create_admin(request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    data = await request.json()
    ADMIN_DATA.setdefault("admins", []).append({
        "username": data["username"],
        "password_hash": hashlib.sha256(data["password"].encode()).hexdigest(),
        "role": data.get("role", "support"),
    })
    _save_admin()
    return JSONResponse({"ok": True})


@app.delete("/api/admin/admin/{username}")
async def remove_admin(username: str, request: Request):
    if not _check_admin(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    ADMIN_DATA["admins"] = [a for a in ADMIN_DATA.get("admins", []) if a["username"] != username]
    _save_admin()
    return JSONResponse({"ok": True})


# Public license validation (called by the app on startup)
@app.post("/api/validate-license")
async def validate_license(request: Request):
    data = await request.json()
    key = data.get("key", "")
    for l in ADMIN_DATA.get("licenses", []):
        if l["key"] == key and l["status"] == "active":
            if l.get("expires") and l["expires"] < datetime.now().strftime("%Y-%m-%d"):
                return JSONResponse({"valid": False, "reason": "expired"})
            return JSONResponse({
                "valid": True,
                "tier": l["tier"],
                "expires": l.get("expires", ""),
                "customer": l.get("customer_name", ""),
            })
    return JSONResponse({"valid": False, "reason": "invalid_key"})


# Support override — temp elevated access for troubleshooting
SUPPORT_CODE = os.environ.get("NOTARE_SUPPORT_CODE", "changeme")
_support_sessions = {}

@app.post("/api/support/activate")
async def activate_support(request: Request):
    data = await request.json()
    code = data.get("code", "")
    if code == SUPPORT_CODE:
        token = secrets.token_hex(16)
        _support_sessions[token] = {
            "activated": datetime.now().isoformat(),
            "active": True,
        }
        logger.info("Support mode activated")
        return JSONResponse({"ok": True, "token": token})
    return JSONResponse({"ok": False})


@app.post("/api/support/deactivate")
async def deactivate_support(request: Request):
    _support_sessions.clear()
    logger.info("Support mode deactivated")
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# Settings API
# ---------------------------------------------------------------------------

@app.get("/api/settings")
async def get_settings():
    s = dict(SETTINGS)
    # Send masked key for display, but also a flag so the UI knows it's set
    if s.get("api_key") and len(s["api_key"]) > 8:
        s["api_key_display"] = s["api_key"][:4] + "****" + s["api_key"][-4:]
        s["api_key_set"] = True
        del s["api_key"]  # Never send the real key to the browser
    elif s.get("api_key"):
        s["api_key_set"] = True
        del s["api_key"]
    else:
        s["api_key_set"] = False
    return JSONResponse(s)


@app.post("/api/settings")
async def update_settings(request: Request):
    data = await request.json()
    # If the API key field is empty or contains mask characters, don't overwrite
    new_key = data.get("api_key", "")
    if not new_key or "****" in new_key:
        data.pop("api_key", None)  # Keep existing key
    # Reject obviously-bad port values — a bad port bricks the next launch
    # because uvicorn fails to bind. Silently drop garbage instead of saving it.
    if "port" in data:
        try:
            p = int(data["port"])
            if p < 1 or p > 65535:
                data.pop("port")
        except (TypeError, ValueError):
            data.pop("port")
    SETTINGS.update(data)
    _save_settings()
    return JSONResponse({"ok": True})


@app.get("/api/settings/referral")
async def get_user_referral():
    """Return the current user's referral code if one is assigned to their license."""
    admin_file = BASE_DIR / "admin_data.json"
    if not admin_file.exists():
        return JSONResponse({})
    try:
        admin_data = json.loads(admin_file.read_text(encoding="utf-8"))
    except Exception:
        return JSONResponse({})

    # Referrals are stored as dict[code] -> {referrer_key, referrer_name, created, uses}
    # Match by the current installation's license key
    license_file = BASE_DIR / "license.json"
    current_key = ""
    if license_file.exists():
        try:
            current_key = json.loads(license_file.read_text(encoding="utf-8")).get("key", "")
        except Exception:
            pass

    referrals = admin_data.get("referrals", {})
    for code, ref in referrals.items():
        if ref.get("referrer_key") == current_key:
            uses = ref.get("uses", [])
            return JSONResponse({
                "code": code,
                "uses": len(uses) if isinstance(uses, list) else uses,
                "credits": len(uses) * 5 if isinstance(uses, list) else 0,  # $5 credit per referral
            })
    return JSONResponse({})


@app.post("/api/contact")
async def submit_contact(request: Request):
    """Save contact form submission locally and notify support."""
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid request"}, status_code=400)
    # Save locally
    contacts_file = BASE_DIR / "contacts.json"
    contacts = []
    if contacts_file.exists():
        try:
            contacts = json.loads(contacts_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    contacts.append(data)
    contacts_file.write_text(json.dumps(contacts, indent=2), encoding="utf-8")
    logger.info("Contact form submission from %s", data.get("email", "unknown"))
    # Notify support via Render relay (non-blocking)
    import threading
    def _notify():
        try:
            import urllib.request
            # Include tier info for priority routing
            _license_file = BASE_DIR / "license.json"
            _tier = "unknown"
            if _license_file.exists():
                try:
                    _tier = json.loads(_license_file.read_text(encoding="utf-8")).get("tier", "unknown")
                except Exception:
                    pass
            _is_dedicated = _tier in _PROFESSIONAL_TIERS and _tier != "trial"
            payload = json.dumps({
                "type": "support_request",
                "priority": "dedicated" if _is_dedicated else "standard",
                "tier": _tier,
                "name": data.get("name", ""),
                "email": data.get("email", ""),
                "org": data.get("org", ""),
                "interest": data.get("interest", ""),
                "message": data.get("message", ""),
                "timestamp": data.get("timestamp", ""),
            }).encode()
            req = urllib.request.Request(
                "https://notarelegal.com/api/notify",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
            logger.info("Support notification sent to relay")
        except Exception as e:
            logger.warning("Support notification relay failed: %s", e)
    threading.Thread(target=_notify, daemon=True).start()
    return JSONResponse({"ok": True})


@app.post("/api/support-request")
async def submit_support_request(request: Request):
    """Quick help request — notifies support team immediately."""
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid request"}, status_code=400)
    # Load license info for context
    license_file = BASE_DIR / "license.json"
    license_info = {}
    if license_file.exists():
        try:
            license_info = json.loads(license_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    tier = license_info.get("tier", "unknown")
    is_dedicated = tier in _PROFESSIONAL_TIERS and tier != "trial"
    support_data = {
        "type": "help_request",
        "priority": "dedicated" if is_dedicated else "standard",
        "tier": tier,
        "customer": license_info.get("customer_name", "Unknown"),
        "key": license_info.get("key", ""),
        "subject": data.get("subject", "Help requested"),
        "description": data.get("description", ""),
        "timestamp": data.get("timestamp", datetime.now().isoformat()),
    }
    # Save locally
    help_file = BASE_DIR / "help_requests.json"
    requests_list = []
    if help_file.exists():
        try:
            requests_list = json.loads(help_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    requests_list.append(support_data)
    help_file.write_text(json.dumps(requests_list, indent=2), encoding="utf-8")
    # Notify via relay
    import threading
    def _notify():
        try:
            import urllib.request
            payload = json.dumps(support_data).encode()
            req = urllib.request.Request(
                "https://notarelegal.com/api/notify",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            logger.warning("Help request relay failed: %s", e)
    threading.Thread(target=_notify, daemon=True).start()
    logger.info("Help request from %s: %s", support_data["customer"], support_data["subject"])
    return JSONResponse({"ok": True, "message": "Your request has been sent. We'll get back to you shortly."})


# ---------------------------------------------------------------------------
# Support Chat — Tier 1 automated, Tier 2 escalation
# ---------------------------------------------------------------------------

_support_kb = None

def _load_support_kb():
    global _support_kb
    kb_file = BASE_DIR / "static" / "support_kb.json"
    if not kb_file.exists():
        _int_kb = Path(sys.executable).parent / "_internal" / "static" / "support_kb.json" if getattr(sys, 'frozen', False) else None
        if _int_kb and _int_kb.exists():
            kb_file = _int_kb
    if kb_file.exists():
        try:
            _support_kb = json.loads(kb_file.read_text(encoding="utf-8"))
        except Exception:
            _support_kb = {"entries": []}
    else:
        _support_kb = {"entries": []}

_load_support_kb()


def _find_kb_answer(question):
    """Search knowledge base for a matching answer. Returns (answer, confidence)."""
    if not _support_kb:
        return None, 0
    q_lower = question.lower()
    q_words = set(q_lower.split())

    best_match = None
    best_score = 0

    for entry in _support_kb.get("entries", []):
        keywords = entry.get("keywords", [])
        # Score by keyword overlap
        matched = sum(1 for kw in keywords if kw in q_lower)
        # Bonus for exact multi-word keyword matches
        for kw in keywords:
            if " " in kw and kw in q_lower:
                matched += 1
        if matched > best_score:
            best_score = matched
            best_match = entry

    if best_score >= 1:
        confidence = min(best_score / 3.0, 1.0)
        return best_match, confidence
    return None, 0


@app.post("/api/support/ask")
async def support_ask(request: Request):
    """Tier 1 support — try to answer from knowledge base."""
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid request"}, status_code=400)

    question = data.get("question", "").strip()
    if not question:
        return JSONResponse({"error": "No question provided"}, status_code=400)

    match, confidence = _find_kb_answer(question)

    if match and confidence >= 0.3:
        return JSONResponse({
            "answered": True,
            "question": match.get("question", ""),
            "answer": match.get("answer", ""),
            "confidence": round(confidence, 2),
        })
    else:
        return JSONResponse({
            "answered": False,
            "message": "I couldn't find an answer to that. Would you like to contact support directly?",
        })


@app.post("/api/support/escalate")
async def support_escalate(request: Request):
    """Tier 2 — escalate to human support with conversation context."""
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid request"}, status_code=400)

    license_file = BASE_DIR / "license.json"
    license_info = {}
    if license_file.exists():
        try:
            license_info = json.loads(license_file.read_text(encoding="utf-8"))
        except Exception:
            pass

    import hashlib as _hl
    ticket_id = _hl.sha256(
        f"{license_info.get('key','')}{datetime.now().isoformat()}".encode()
    ).hexdigest()[:12]

    ticket = {
        "id": ticket_id,
        "type": "escalation",
        "status": "open",
        "customer": license_info.get("customer_name", "Unknown"),
        "reporter_key": license_info.get("key", ""),
        "question": data.get("question", ""),
        "conversation": data.get("conversation", []),
        "description": data.get("description", ""),
        "timestamp": datetime.now().isoformat(),
    }

    # Save as support ticket locally
    tickets = _load_support_tickets()
    tickets.append(ticket)
    _save_support_tickets(tickets)

    # Push to relay for broadcast to all support users
    import threading
    def _notify():
        try:
            import urllib.request
            payload = json.dumps(ticket).encode()
            req = urllib.request.Request(
                "https://notarelegal.com/api/support/submit",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            logger.warning("Ticket relay failed: %s", e)
    threading.Thread(target=_notify, daemon=True).start()

    logger.info("Support escalation from %s: %s", escalation["customer"], escalation["question"][:80])
    return JSONResponse({"ok": True, "message": "Your request has been sent to our support team. We'll get back to you shortly."})


# ---------------------------------------------------------------------------
# Support Ticket System — role-based routing, broadcast, auto-claim
# ---------------------------------------------------------------------------

_support_tickets_file = BASE_DIR / "support_tickets.json"


def _load_support_tickets():
    if _support_tickets_file.exists():
        try:
            return json.loads(_support_tickets_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def _save_support_tickets(tickets):
    _support_tickets_file.write_text(
        json.dumps(tickets, indent=2, ensure_ascii=False), encoding="utf-8")


def _is_support_user():
    """Check if the current installation is a support-designated user."""
    license_file = BASE_DIR / "license.json"
    if not license_file.exists():
        return False, {}
    try:
        lic = json.loads(license_file.read_text(encoding="utf-8"))
        key = lic.get("key", "")
        # Check admin_data for support flag on this key
        admin_file = BASE_DIR / "admin_data.json"
        if not admin_file.exists():
            _int_admin = BASE_DIR / "_internal" / "admin_data.json"
            if _int_admin.exists():
                admin_file = _int_admin
        if admin_file.exists():
            admin_data = json.loads(admin_file.read_text(encoding="utf-8"))
            for entry in admin_data.get("licenses", []):
                if entry.get("key") == key:
                    return entry.get("support", False) or entry.get("master", False), lic
        return False, lic
    except Exception:
        return False, {}


def _start_support_poller():
    """Poll Render relay for incoming support tickets. Support users only."""
    import threading
    is_support, lic = _is_support_user()
    if not is_support:
        return

    def _poll():
        import urllib.request
        logger.info("Support ticket poller started (support role detected)")
        while True:
            try:
                time.sleep(30)
                req = urllib.request.Request(
                    "https://notarelegal.com/api/support/pending",
                    headers={
                        "X-License-Key": lic.get("key", ""),
                        "Content-Type": "application/json",
                    },
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.loads(resp.read().decode())
                    remote_tickets = data.get("tickets", [])
                    if remote_tickets:
                        # Merge with local — don't duplicate by ticket ID
                        local = _load_support_tickets()
                        local_ids = {t.get("id") for t in local}
                        new_count = 0
                        for ticket in remote_tickets:
                            if ticket.get("id") not in local_ids:
                                ticket["status"] = "open"
                                local.append(ticket)
                                new_count += 1
                        if new_count:
                            _save_support_tickets(local)
                            logger.info("Received %d new support tickets", new_count)
            except Exception:
                pass

    threading.Thread(target=_poll, daemon=True, name="support-poller").start()

try:
    _start_support_poller()
except Exception:
    pass


@app.get("/api/support/tickets")
async def get_support_tickets():
    """Get all support tickets. Support users see open tickets; others see their own."""
    is_support, lic = _is_support_user()
    tickets = _load_support_tickets()
    if is_support:
        # Support users see all open/claimed-by-them tickets
        visible = [t for t in tickets if t.get("status") in ("open", "claimed")
                   or t.get("claimed_by") == lic.get("customer_name", "")]
        return JSONResponse({"tickets": visible, "is_support": True})
    else:
        # Regular users see only their own tickets
        my_key = lic.get("key", "")
        mine = [t for t in tickets if t.get("reporter_key") == my_key]
        return JSONResponse({"tickets": mine, "is_support": False})


@app.post("/api/support/tickets/claim")
async def claim_support_ticket(request: Request):
    """Claim a ticket — removes it from other support users' queues."""
    is_support, lic = _is_support_user()
    if not is_support:
        return JSONResponse({"error": "Not authorized"}, status_code=403)
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid request"}, status_code=400)

    ticket_id = data.get("ticket_id")
    tickets = _load_support_tickets()
    claimed = False
    for ticket in tickets:
        if ticket.get("id") == ticket_id and ticket.get("status") == "open":
            ticket["status"] = "claimed"
            ticket["claimed_by"] = lic.get("customer_name", "Unknown")
            ticket["claimed_at"] = datetime.now().isoformat()
            claimed = True
            break

    if claimed:
        _save_support_tickets(tickets)
        # Notify relay that ticket was claimed (so other pollers see it)
        import threading
        def _notify_claim():
            try:
                import urllib.request
                payload = json.dumps({
                    "ticket_id": ticket_id,
                    "claimed_by": lic.get("customer_name", ""),
                }).encode()
                req = urllib.request.Request(
                    "https://notarelegal.com/api/support/claim",
                    data=payload,
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=10)
            except Exception:
                pass
        threading.Thread(target=_notify_claim, daemon=True).start()
        logger.info("Ticket %s claimed by %s", ticket_id, lic.get("customer_name"))
        return JSONResponse({"ok": True})
    return JSONResponse({"error": "Ticket not found or already claimed"}, status_code=404)


@app.post("/api/support/tickets/resolve")
async def resolve_support_ticket(request: Request):
    """Mark a ticket as resolved."""
    is_support, lic = _is_support_user()
    if not is_support:
        return JSONResponse({"error": "Not authorized"}, status_code=403)
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid request"}, status_code=400)

    ticket_id = data.get("ticket_id")
    resolution = data.get("resolution", "")
    tickets = _load_support_tickets()
    for ticket in tickets:
        if ticket.get("id") == ticket_id:
            ticket["status"] = "resolved"
            ticket["resolved_by"] = lic.get("customer_name", "Unknown")
            ticket["resolved_at"] = datetime.now().isoformat()
            ticket["resolution"] = resolution
            break
    _save_support_tickets(tickets)
    logger.info("Ticket %s resolved by %s", ticket_id, lic.get("customer_name"))
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# Transcription Engine (uses configured settings)
# ---------------------------------------------------------------------------

def _fmt_time(ms):
    """Format milliseconds to HH:MM:SS."""
    if isinstance(ms, float) and ms < 1000:
        # Already in seconds
        s = int(ms)
    else:
        s = int(ms / 1000) if ms else 0
    h = s // 3600
    m = (s % 3600) // 60
    sec = s % 60
    return f"{h:02d}:{m:02d}:{sec:02d}"


def _export_raw_transcript(job: dict, job_dir: Path, filename: str = ""):
    """Export a bare-bones transcript — just ASR text in natural paragraphs.

    No speaker labels, no timestamps, no formatting. Just the spoken words
    broken into paragraphs where natural pauses or speaker changes occur.
    Useful as a quick rough draft or for text analysis.
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return JSONResponse({"error": "No transcript data"}, status_code=400)

    segments = transcript["segments"]
    paragraphs = []
    current_para = []
    last_speaker = None
    last_end = 0

    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            continue

        speaker = seg.get("speaker", "")
        start = seg.get("start", 0)

        # Start new paragraph on speaker change or significant pause (>2 seconds)
        gap = (start - last_end) / 1000 if last_end else 0
        if (speaker != last_speaker and last_speaker is not None) or gap > 2.0:
            if current_para:
                paragraphs.append(" ".join(current_para))
                current_para = []

        current_para.append(text)
        last_speaker = speaker
        last_end = seg.get("end", start)

    if current_para:
        paragraphs.append(" ".join(current_para))

    # Build output
    output = "\n\n".join(paragraphs)

    # Add minimal header
    header = f"{job.get('case_caption', '')}\n{job.get('date', '')}\n{'=' * 40}\n\n"
    output = header + output

    output_path = job_dir / f"notare_{job['id']}_raw.txt"
    output_path.write_text(output, encoding="utf-8")

    return _local_export(output_path, f"raw_transcript_{job.get('case_number', job['id'])}.txt")


def _export_word_index(job: dict, job_dir: Path, filename: str = ""):
    """Generate a comprehensive word index — every word with page/line/timestamp references.

    Output: a Word document (.docx) with a professional table layout.
    Columns: Word | Count | References (page:line or timestamp)
    Excludes common stop words. Groups by first letter with alphabetical headers.
    """
    try:
        from docx import Document
        from docx.shared import Pt, Inches, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.table import WD_TABLE_ALIGNMENT
    except ImportError:
        return JSONResponse({"error": "python-docx not installed"}, status_code=500)

    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return JSONResponse({"error": "No transcript data"}, status_code=400)

    segments = transcript["segments"]
    lines_per_page = job.get("profile", {}).get("lines_per_page") or 25

    # Stop words — common words to exclude from the index
    stop_words = {
        "a", "an", "the", "and", "or", "but", "is", "are", "was", "were", "be",
        "been", "being", "have", "has", "had", "do", "does", "did", "will", "would",
        "shall", "should", "may", "might", "must", "can", "could", "of", "to", "in",
        "for", "on", "with", "at", "by", "from", "as", "into", "through", "during",
        "before", "after", "above", "below", "between", "out", "off", "over", "under",
        "again", "further", "then", "once", "here", "there", "when", "where", "why",
        "how", "all", "each", "every", "both", "few", "more", "most", "other", "some",
        "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very",
        "just", "because", "if", "while", "about", "up", "down", "it", "its", "i", "me",
        "my", "myself", "we", "our", "ours", "you", "your", "yours", "he", "him", "his",
        "she", "her", "hers", "they", "them", "their", "theirs", "what", "which", "who",
        "whom", "this", "that", "these", "those", "am", "don't", "doesn't", "didn't",
        "won't", "wouldn't", "shouldn't", "couldn't", "isn't", "aren't", "wasn't",
        "weren't", "hasn't", "haven't", "hadn't", "well", "um", "uh", "okay", "yeah",
        "yes", "right", "going", "get", "got", "let", "know", "think", "said", "say",
        "like", "go", "went", "come", "came", "take", "took", "make", "made", "see",
        "saw", "give", "gave", "tell", "told",
    }

    import re
    word_refs = {}  # word -> [{seg_idx, timestamp, speaker, context}]

    for seg_idx, seg in enumerate(segments):
        text = seg.get("text", "")
        speaker = seg.get("speaker", "")
        timestamp = seg.get("start", 0)

        # Calculate approximate page and line
        page = (seg_idx // lines_per_page) + 1
        line = (seg_idx % lines_per_page) + 1

        # Extract words, clean punctuation
        words = re.findall(r"[a-zA-Z'-]+", text)
        for word in words:
            w_lower = word.lower().strip("'-")
            if len(w_lower) < 2 or w_lower in stop_words:
                continue

            # Capitalize proper nouns (keep original case if capitalized in source)
            display_word = word if word[0].isupper() else w_lower

            if w_lower not in word_refs:
                word_refs[w_lower] = {"display": display_word, "refs": []}

            # Keep the capitalized version if we see one
            if word[0].isupper() and not word_refs[w_lower]["display"][0].isupper():
                word_refs[w_lower]["display"] = word

            word_refs[w_lower]["refs"].append({
                "page": page,
                "line": line,
                "timestamp": timestamp,
                "speaker": speaker,
                "context": text[:60],
            })

    # Sort alphabetically
    sorted_words = sorted(word_refs.items(), key=lambda x: x[0])

    # Build the Word document
    doc = Document()

    # Title
    title = doc.add_heading("Word Index", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Subtitle
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = sub.add_run(f"{job.get('case_caption', 'Untitled')} — {job.get('case_number', '')}")
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(0x6b, 0x6b, 0x7b)

    stats = doc.add_paragraph()
    stats.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = stats.add_run(f"{len(word_refs)} unique words indexed from {len(segments)} segments")
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x9a, 0x9a, 0xaa)

    doc.add_paragraph("")

    # Group by first letter
    current_letter = ""
    for w_lower, data in sorted_words:
        first = w_lower[0].upper()

        if first != current_letter:
            current_letter = first
            heading = doc.add_heading(first, level=2)
            heading.runs[0].font.color.rgb = RGBColor(0xc8, 0xa5, 0x5c)

            # Create table for this letter group
            table = doc.add_table(rows=1, cols=3)
            table.style = "Light Shading Accent 1"
            table.alignment = WD_TABLE_ALIGNMENT.CENTER

            hdr = table.rows[0].cells
            for cell, text in zip(hdr, ["Word", "Count", "References (page:line)"]):
                cell.text = text
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.font.size = Pt(9)
                        run.font.bold = True

        refs = data["refs"]
        display = data["display"]

        # Deduplicate references by page:line
        ref_strs = []
        seen = set()
        for ref in refs:
            key = f"{ref['page']}:{ref['line']}"
            if key not in seen:
                seen.add(key)
                ref_strs.append(key)

        row = table.add_row().cells
        row[0].text = display
        row[0].paragraphs[0].runs[0].font.size = Pt(10) if row[0].paragraphs[0].runs else None
        row[1].text = str(len(refs))
        row[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Show references as hyperlinks with context tooltips
        ref_cell = row[2]
        ref_cell.text = ""  # Clear default
        ref_para = ref_cell.paragraphs[0]
        display_refs = ref_strs[:20]
        for ri, ref_str in enumerate(display_refs):
            # Find the context for this reference
            ref_parts = ref_str.split(":")
            ref_page = int(ref_parts[0]) if ref_parts[0].isdigit() else 0
            ref_line = int(ref_parts[1]) if len(ref_parts) > 1 and ref_parts[1].isdigit() else 0
            # Find context from original refs
            ctx = ""
            for orig_ref in refs:
                if orig_ref["page"] == ref_page and orig_ref["line"] == ref_line:
                    ctx = orig_ref.get("context", "")
                    break

            # Add as a styled run (hyperlink style — blue, underlined)
            from docx.oxml.ns import qn
            from docx.oxml import OxmlElement
            hyperlink = OxmlElement('w:hyperlink')
            hyperlink.set(qn('w:tooltip'), ctx or f"Page {ref_page}, Line {ref_line}")
            run_el = OxmlElement('w:r')
            rPr = OxmlElement('w:rPr')
            color = OxmlElement('w:color')
            color.set(qn('w:val'), '0563C1')
            rPr.append(color)
            u = OxmlElement('w:u')
            u.set(qn('w:val'), 'single')
            rPr.append(u)
            sz = OxmlElement('w:sz')
            sz.set(qn('w:val'), '18')  # 9pt
            rPr.append(sz)
            run_el.append(rPr)
            t = OxmlElement('w:t')
            t.text = ref_str
            run_el.append(t)
            hyperlink.append(run_el)
            ref_para._element.append(hyperlink)

            # Separator
            if ri < len(display_refs) - 1:
                sep_run = ref_para.add_run(", ")
                sep_run.font.size = Pt(9)

        if len(ref_strs) > 20:
            more_run = ref_para.add_run(f"  ...and {len(ref_strs) - 20} more")
            more_run.font.size = Pt(8)
            more_run.font.color.rgb = RGBColor(0x9a, 0x9a, 0xaa)

        # Font sizing for word and count cells
        for cell in [row[0], row[1]]:
            for p in cell.paragraphs:
                for run in p.runs:
                    run.font.size = Pt(9)

    # Footer
    doc.add_paragraph("")
    footer = doc.add_paragraph()
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run(f"Generated by Notare — {job.get('date', '')}")
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(0x9a, 0x9a, 0xaa)

    # Save
    output_path = job_dir / f"notare_{job['id']}_word_index.docx"
    doc.save(str(output_path))

    return _local_export(output_path, f"word_index_{job.get('case_number', job['id'])}.docx")


@app.post("/api/job/{job_id}/import-transcript")
async def import_completed_transcript(job_id: str, file: UploadFile = File(...),
                                       run_proofing: bool = Form(True)):
    """Import a completed/edited transcript into a job.

    Accepts .docx, .txt, or .pdf. Parses the text, creates segments,
    optionally runs proofing rules, and makes the transcript available
    for re-export in any format.
    """
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    content = await file.read()
    ext = Path(file.filename).suffix.lower()
    job_dir = Path(job["dir"])

    # Save the original uploaded file
    imports_dir = job_dir / "imports"
    imports_dir.mkdir(exist_ok=True)
    import_path = imports_dir / file.filename
    import_path.write_bytes(content)

    # Parse text from the file
    text_lines = []

    if ext == ".txt":
        text_lines = content.decode("utf-8", errors="replace").split("\n")

    elif ext in (".docx", ".doc"):
        try:
            from docx import Document as DocxDoc
            import io
            doc = DocxDoc(io.BytesIO(content))
            text_lines = [p.text for p in doc.paragraphs if p.text.strip()]
        except Exception as e:
            return JSONResponse({"error": f"Could not read .docx: {e}"}, status_code=400)

    elif ext == ".pdf":
        try:
            import pdfplumber
            import io
            with pdfplumber.open(io.BytesIO(content)) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_lines.extend(page_text.split("\n"))
        except Exception as e:
            return JSONResponse({"error": f"Could not read .pdf: {e}"}, status_code=400)
    else:
        return JSONResponse({"error": f"Unsupported format: {ext}. Use .docx, .txt, or .pdf"}, status_code=400)

    if not text_lines:
        return JSONResponse({"error": "No text found in the uploaded file"}, status_code=400)

    # Parse lines into segments — detect speaker labels
    segments = []
    current_speaker = ""
    current_text = []

    for line in text_lines:
        line = line.strip()
        if not line:
            continue

        # Remove line numbers (common in transcript imports)
        line = re.sub(r'^\s*\d{1,2}\s{2,}', '', line)

        # Detect speaker labels: "MR. SMITH:", "THE COURT:", "Q", "A"
        speaker_match = re.match(
            r'^((?:MR\.|MS\.|MRS\.|DR\.|THE COURT|THE WITNESS|THE REPORTER|THE CLERK|THE BAILIFF|'
            r'THE DEFENDANT|THE PLAINTIFF|BY )[A-Z\s.]+?):\s*(.*)',
            line, re.IGNORECASE
        )
        qa_match = re.match(r'^\s*([QA])\s{2,}(.*)', line)

        if speaker_match:
            # Flush previous speaker's text
            if current_text:
                segments.append({
                    "text": " ".join(current_text),
                    "speaker": current_speaker,
                    "start": len(segments) * 1000,
                    "end": (len(segments) + 1) * 1000,
                    "confidence": 1.0,
                })
                current_text = []
            current_speaker = speaker_match.group(1).strip()
            remaining = speaker_match.group(2).strip()
            if remaining:
                current_text.append(remaining)

        elif qa_match:
            if current_text:
                segments.append({
                    "text": " ".join(current_text),
                    "speaker": current_speaker,
                    "start": len(segments) * 1000,
                    "end": (len(segments) + 1) * 1000,
                    "confidence": 1.0,
                })
                current_text = []
            # Q = examining attorney, A = witness
            current_speaker = "Q" if qa_match.group(1) == "Q" else "A"
            remaining = qa_match.group(2).strip()
            if remaining:
                current_text.append(remaining)
        else:
            # Continuation of current speaker
            current_text.append(line)

    # Flush last segment
    if current_text:
        segments.append({
            "text": " ".join(current_text),
            "speaker": current_speaker,
            "start": len(segments) * 1000,
            "end": (len(segments) + 1) * 1000,
            "confidence": 1.0,
        })

    # Store as transcript
    job["transcript"] = {"segments": segments}
    job["status"] = "complete"
    _feed_word_live_on_complete(job)
    job["progress"] = 100
    job["imported_from"] = file.filename

    # Run proofing if requested
    if run_proofing:
        try:
            _auto_detect_styles(job)
            _apply_proofing_rules(job)
        except Exception as e:
            logger.warning("Proofing on imported transcript failed: %s", e)

    # Save
    with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
        json.dump(job["transcript"], f, indent=2)
    _save_job(job)

    logger.info("Imported transcript: %s → %d segments (proofing=%s)",
                file.filename, len(segments), run_proofing)
    return JSONResponse({
        "ok": True,
        "segments": len(segments),
        "imported_from": file.filename,
        "proofing_applied": run_proofing,
    })


@app.post("/api/job/{job_id}/compare-transcript")
async def compare_transcripts(job_id: str, file: UploadFile = File(...)):
    """Compare the current transcript against a proofed/edited version.

    Uploads the proofed .docx/.txt/.pdf, diffs it against the current transcript,
    and generates a redline showing every change (additions, deletions, modifications).
    Results are stored on the job for viewing and export.

    Typical workflow:
      1. Notare transcribes audio → export DOCX
      2. Transcriber edits in Word
      3. Upload edited version here → Notare generates redline
      4. Proofreaders review the redline
    """
    import difflib

    job = JOBS.get(job_id)
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Job not found or no transcript"}, status_code=404)

    # Parse the uploaded proofed transcript
    content = await file.read()
    ext = Path(file.filename).suffix.lower()
    job_dir = Path(job["dir"])

    # Save the proofed file
    imports_dir = job_dir / "imports"
    imports_dir.mkdir(exist_ok=True)
    proofed_path = imports_dir / f"proofed_{file.filename}"
    proofed_path.write_bytes(content)

    # Extract text from proofed file
    proofed_lines = []
    if ext == ".txt":
        proofed_lines = content.decode("utf-8", errors="replace").split("\n")
    elif ext in (".docx", ".doc"):
        try:
            from docx import Document as DocxDoc
            import io
            doc = DocxDoc(io.BytesIO(content))
            proofed_lines = [p.text for p in doc.paragraphs if p.text.strip()]
        except Exception as e:
            return JSONResponse({"error": f"Could not read .docx: {e}"}, status_code=400)
    elif ext == ".pdf":
        try:
            import pdfplumber
            import io
            with pdfplumber.open(io.BytesIO(content)) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        proofed_lines.extend(page_text.split("\n"))
        except Exception as e:
            return JSONResponse({"error": f"Could not read .pdf: {e}"}, status_code=400)
    else:
        return JSONResponse({"error": f"Unsupported format: {ext}"}, status_code=400)

    # Build original text from current transcript segments
    original_lines = []
    for seg in job["transcript"]["segments"]:
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        if speaker:
            original_lines.append(f"{speaker}: {text}")
        else:
            original_lines.append(text)

    # Clean proofed lines — strip line numbers, empty lines
    cleaned_proofed = []
    for line in proofed_lines:
        line = line.strip()
        if not line:
            continue
        # Strip leading line numbers (e.g., "  1  " or "14  ")
        line = re.sub(r'^\s*\d{1,3}\s{2,}', '', line).strip()
        if line:
            cleaned_proofed.append(line)

    # Generate diff
    differ = difflib.SequenceMatcher(None, original_lines, cleaned_proofed)
    changes = []
    change_count = {"additions": 0, "deletions": 0, "modifications": 0}

    for tag, i1, i2, j1, j2 in differ.get_opcodes():
        if tag == "equal":
            continue
        elif tag == "replace":
            # Modification — original text changed to new text
            for idx in range(max(i2 - i1, j2 - j1)):
                orig = original_lines[i1 + idx] if (i1 + idx) < i2 else ""
                proof = cleaned_proofed[j1 + idx] if (j1 + idx) < j2 else ""
                if orig and proof:
                    changes.append({
                        "type": "modified",
                        "line": i1 + idx + 1,
                        "original": orig,
                        "proofed": proof,
                    })
                    change_count["modifications"] += 1
                elif orig:
                    changes.append({
                        "type": "deleted",
                        "line": i1 + idx + 1,
                        "original": orig,
                    })
                    change_count["deletions"] += 1
                else:
                    changes.append({
                        "type": "added",
                        "line": j1 + idx + 1,
                        "proofed": proof,
                    })
                    change_count["additions"] += 1
        elif tag == "delete":
            for idx in range(i1, i2):
                changes.append({
                    "type": "deleted",
                    "line": idx + 1,
                    "original": original_lines[idx],
                })
                change_count["deletions"] += 1
        elif tag == "insert":
            for idx in range(j1, j2):
                changes.append({
                    "type": "added",
                    "line": idx + 1,
                    "proofed": cleaned_proofed[idx],
                })
                change_count["additions"] += 1

    # Store redline on the job
    redline = {
        "proofed_file": file.filename,
        "proofed_at": datetime.now().isoformat(),
        "original_lines": len(original_lines),
        "proofed_lines": len(cleaned_proofed),
        "changes": changes,
        "summary": change_count,
    }
    job["redline"] = redline

    # Save redline to disk
    with open(job_dir / "redline.json", "w", encoding="utf-8") as f:
        json.dump(redline, f, indent=2)
    _save_job(job)

    total_changes = sum(change_count.values())
    logger.info("Redline comparison: %s → %d changes (%d mod, %d add, %d del)",
                file.filename, total_changes, change_count["modifications"],
                change_count["additions"], change_count["deletions"])

    return JSONResponse({
        "ok": True,
        "proofed_file": file.filename,
        "total_changes": total_changes,
        "summary": change_count,
        "changes": changes[:50],  # First 50 for preview
    })


@app.get("/api/job/{job_id}/redline")
async def get_redline(job_id: str):
    """Get the redline comparison for a job."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Not found"}, status_code=404)
    redline = job.get("redline")
    if not redline:
        # Try loading from disk
        job_dir = Path(job.get("dir", ""))
        redline_path = job_dir / "redline.json"
        if redline_path.exists():
            redline = json.loads(redline_path.read_text(encoding="utf-8"))
            job["redline"] = redline
    if not redline:
        return JSONResponse({"error": "No redline comparison exists for this job"}, status_code=404)
    return JSONResponse(redline)


@app.post("/api/job/{job_id}/run-proofing")
async def run_proofing_on_job(job_id: str):
    """Run proofing rules on an existing transcript (imported or ASR-generated)."""
    job = JOBS.get(job_id)
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Job not found or no transcript"}, status_code=404)

    before_count = len(job["transcript"].get("segments", []))
    _auto_detect_styles(job)
    _apply_proofing_rules(job)

    # Save updated transcript
    job_dir = Path(job["dir"])
    with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
        json.dump(job["transcript"], f, indent=2)
    _save_job(job)

    return JSONResponse({"ok": True, "segments": before_count, "message": "Proofing rules applied."})


def _export_full_package(job: dict, job_dir: Path, filename: str = ""):
    """Generate a complete transcript package — all selected formats in one folder.

    Mimics YesLaw's "Generate" — creates a folder with:
    - Full deposition PDF (with caption, appearances, certificate, errata)
    - Condensed PDF (4-on-1)
    - ASCII transcript
    - Word index
    - LEF (LiveNote format)
    - PTX (Sanction format)
    - Video sync file
    - Word export (with macros if template provided)

    Returns a zip of the entire package.
    """
    import zipfile as _pkg_zf

    package_dir = job_dir / "package"
    package_dir.mkdir(exist_ok=True)
    case_num = job.get("case_number", job["id"])
    base = filename or case_num

    generated = []

    # 1. Deposition PDF
    try:
        from depo_pdf import generate_deposition_pdf
        path = generate_deposition_pdf(job, package_dir, filename=base)
        if path and Path(path).exists():
            generated.append(("deposition", path))
    except Exception as e:
        logger.warning("Package: deposition PDF failed: %s", e)

    # 2. Condensed PDF
    try:
        # Call the function but capture the path instead of returning a response
        _export_condensed_pdf_to_path(job, package_dir, base)
        cpath = package_dir / f"notare_{job['id']}_condensed.pdf"
        if cpath.exists():
            generated.append(("condensed", cpath))
    except Exception as e:
        logger.warning("Package: condensed PDF failed: %s", e)

    # 3. ASCII
    try:
        _export_ascii_to_path(job, package_dir, base)
        apath = package_dir / f"notare_{job['id']}_transcript.txt"
        if apath.exists():
            generated.append(("ascii", apath))
    except Exception as e:
        logger.warning("Package: ASCII failed: %s", e)

    # 4. Word Index
    try:
        # Generate word index as docx
        _export_word_index_to_path(job, package_dir)
        wpath = package_dir / f"notare_{job['id']}_word_index.docx"
        if wpath.exists():
            generated.append(("word_index", wpath))
    except Exception as e:
        logger.warning("Package: word index failed: %s", e)

    # 5. LEF
    try:
        _export_lef_to_path(job, package_dir, base)
        lpath = package_dir / f"notare_{job['id']}_transcript.lef"
        if lpath.exists():
            generated.append(("lef", lpath))
    except Exception as e:
        logger.warning("Package: LEF failed: %s", e)

    # 6. PTX
    try:
        _export_ptx_to_path(job, package_dir, base)
        ppath = package_dir / f"notare_{job['id']}_transcript.ptx"
        if ppath.exists():
            generated.append(("ptx", ppath))
    except Exception as e:
        logger.warning("Package: PTX failed: %s", e)

    # 7. Video Sync
    try:
        _export_sync_to_path(job, package_dir, base)
        spath = package_dir / f"notare_{job['id']}_sync.dvt"
        if spath.exists():
            generated.append(("sync", spath))
    except Exception as e:
        logger.warning("Package: video sync failed: %s", e)

    # 8. Word export
    try:
        _export_word(job, package_dir, filename=base)
    except Exception as e:
        logger.warning("Package: Word export failed: %s", e)

    # Bundle into a zip
    pkg_zip_path = job_dir / f"{base}_transcript_package.zip"
    with _pkg_zf.ZipFile(str(pkg_zip_path), 'w', _pkg_zf.ZIP_DEFLATED) as zf:
        for label, fpath in generated:
            zf.write(str(fpath), Path(fpath).name)
        # Include any Word exports in the package dir
        for wfile in package_dir.glob("*.docx"):
            zf.write(str(wfile), wfile.name)
        for wfile in package_dir.glob("*.docm"):
            zf.write(str(wfile), wfile.name)

    logger.info("Transcript package generated: %d files in %s", len(generated), pkg_zip_path)
    return _local_export(pkg_zip_path, f"{base}_transcript_package.zip")


# Helper functions for package export (write to specific directory instead of returning response)
def _export_condensed_pdf_to_path(job, out_dir, filename):
    """Generate condensed PDF to a specific directory."""
    # Reuse the existing function logic but save to out_dir
    _export_condensed_pdf(job, out_dir, filename)

def _export_ascii_to_path(job, out_dir, filename):
    _export_ascii(job, out_dir, filename)

def _export_word_index_to_path(job, out_dir):
    _export_word_index(job, out_dir)

def _export_lef_to_path(job, out_dir, filename):
    _export_lef(job, out_dir, filename)

def _export_ptx_to_path(job, out_dir, filename):
    _export_ptx(job, out_dir, filename)

def _export_sync_to_path(job, out_dir, filename):
    _export_video_sync(job, out_dir, filename)


def _export_ascii(job: dict, job_dir: Path, filename: str = ""):
    """Export transcript as standard ASCII text — the format deposition review tools expect.

    Line-numbered, page-delimited, with proper header/footer per page.
    This is the format that imports into LiveNote, Summation, CaseMap, etc.
    """
    profile = job.get("profile", {})
    lines_per_page = profile.get("lines_per_page") or 25
    segments = job.get("transcript", {}).get("segments", [])
    if not segments:
        return JSONResponse({"error": "No transcript"}, status_code=400)

    # Build transcript lines with speaker labels
    all_lines = []
    current_speaker = ""
    buffer = []

    for seg in segments:
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        if not text:
            continue

        if speaker and speaker != current_speaker:
            if buffer:
                all_lines.append("        " + " ".join(buffer))
                buffer.clear()
            current_speaker = speaker
            label = _format_speaker_label_export(speaker)
            all_lines.append("")
            all_lines.append(f"        {label}:")
        buffer.append(text)

    if buffer:
        all_lines.append("        " + " ".join(buffer))

    # Word-wrap long lines to ~70 chars
    wrapped_lines = []
    for line in all_lines:
        if len(line) > 75:
            words = line.split()
            current = ""
            indent = "   " if line.startswith("   ") else "        "
            for word in words:
                if len(current) + len(word) + 1 > 70:
                    wrapped_lines.append(current)
                    current = indent + word
                else:
                    current = (current + " " + word) if current else word
            if current:
                wrapped_lines.append(current)
        else:
            wrapped_lines.append(line)

    # Paginate with headers/footers
    case_num = job.get("case_number", "")
    case_caption = job.get("case_caption", "")
    pages = []
    page_num = 1
    line_idx = 0

    while line_idx < len(wrapped_lines):
        page_lines = []
        # Header
        page_lines.append(f"                    {case_caption}")
        page_lines.append("")

        # Content lines with line numbers
        for line_on_page in range(1, lines_per_page + 1):
            if line_idx < len(wrapped_lines):
                page_lines.append(f" {line_on_page:2d}   {wrapped_lines[line_idx]}")
                line_idx += 1
            else:
                page_lines.append(f" {line_on_page:2d}")

        # Footer
        page_lines.append("")
        page_lines.append(f"                         Page {page_num}")
        page_lines.append("\x0c")  # Form feed — standard ASCII page break

        pages.extend(page_lines)
        page_num += 1

    output = "\n".join(pages)
    export_path = job_dir / f"notare_{job['id']}_transcript.txt"
    export_path.write_text(output, encoding="ascii", errors="replace")

    case = case_num or job["id"]
    return _local_export(export_path, f"{filename or case}_transcript.txt")


def _export_condensed_pdf(job: dict, job_dir: Path, filename: str = ""):
    """Export condensed transcript — 4 pages per sheet.

    Standard deposition format: 4 mini-pages arranged in a 2x2 grid on
    each physical page. Each mini-page has line numbers and headers.
    Used by attorneys for review and markup.
    """
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import inch
        from reportlab.pdfgen import canvas as pdf_canvas
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "reportlab"])
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import inch
        from reportlab.pdfgen import canvas as pdf_canvas

    segments = job.get("transcript", {}).get("segments", [])
    if not segments:
        return JSONResponse({"error": "No transcript"}, status_code=400)

    profile = job.get("profile", {})
    lines_per_page = profile.get("lines_per_page") or 25
    page_width, page_height = letter

    # Build all transcript lines
    all_lines = []
    current_speaker = ""
    buffer = []
    for seg in segments:
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        if not text:
            continue
        if speaker and speaker != current_speaker:
            if buffer:
                all_lines.append("  " + " ".join(buffer))
                buffer.clear()
            current_speaker = speaker
            label = _format_speaker_label_export(speaker)
            all_lines.append("")
            all_lines.append(f"  {label}:")
        buffer.append(text)
    if buffer:
        all_lines.append("  " + " ".join(buffer))

    # Word-wrap to ~55 chars (smaller for mini-pages)
    wrapped = []
    for line in all_lines:
        if len(line) > 55:
            words = line.split()
            current = ""
            for word in words:
                if len(current) + len(word) + 1 > 52:
                    wrapped.append(current)
                    current = "  " + word
                else:
                    current = (current + " " + word) if current else word
            if current:
                wrapped.append(current)
        else:
            wrapped.append(line)

    # Split into logical pages
    logical_pages = []
    for i in range(0, len(wrapped), lines_per_page):
        logical_pages.append(wrapped[i:i + lines_per_page])

    # Draw condensed PDF — 4 logical pages per physical page
    export_path = job_dir / f"notare_{job['id']}_condensed.pdf"
    c = pdf_canvas.Canvas(str(export_path), pagesize=letter)

    case_caption = job.get("case_caption", "")
    case_num = job.get("case_number", "")

    # Mini-page positions (2x2 grid with margins)
    margin = 0.4 * inch
    gap = 0.15 * inch
    mini_w = (page_width - 2 * margin - gap) / 2
    mini_h = (page_height - 2 * margin - gap) / 2

    positions = [
        (margin, page_height - margin - mini_h),            # Top-left
        (margin + mini_w + gap, page_height - margin - mini_h),  # Top-right
        (margin, margin),                                      # Bottom-left
        (margin + mini_w + gap, margin),                       # Bottom-right
    ]

    font_size = 6.5
    line_height = 8
    header_height = 14

    for phys_page in range(0, len(logical_pages), 4):
        if phys_page > 0:
            c.showPage()

        for slot in range(4):
            lp_idx = phys_page + slot
            if lp_idx >= len(logical_pages):
                break

            x, y = positions[slot]
            lines = logical_pages[lp_idx]
            logical_page_num = lp_idx + 1

            # Draw mini-page border
            c.setStrokeColorRGB(0.8, 0.8, 0.8)
            c.setLineWidth(0.5)
            c.rect(x, y, mini_w, mini_h)

            # Header
            c.setFont("Helvetica-Bold", 5)
            c.setFillColorRGB(0.4, 0.4, 0.4)
            header_text = f"Page {logical_page_num}"
            if case_num:
                header_text = f"{case_num} — {header_text}"
            c.drawString(x + 4, y + mini_h - 10, header_text)

            # Lines with numbers
            c.setFont("Courier", font_size)
            c.setFillColorRGB(0, 0, 0)
            content_top = y + mini_h - header_height - 4

            for li, line in enumerate(lines):
                line_y = content_top - (li * line_height)
                if line_y < y + 4:
                    break
                # Line number
                c.setFont("Courier", 5)
                c.setFillColorRGB(0.6, 0.6, 0.6)
                c.drawRightString(x + 14, line_y, str(li + 1))
                # Content
                c.setFont("Courier", font_size)
                c.setFillColorRGB(0, 0, 0)
                c.drawString(x + 18, line_y, line[:80])

    c.save()

    case = case_num or job["id"]
    return _local_export(export_path, f"{filename or case}_condensed.pdf")


def _export_lef(job: dict, job_dir: Path, filename: str = ""):
    """Export transcript in LEF (LiveNote Evidence Format).

    LEF is a pipe-delimited text format used by LiveNote/CaseView.
    Format: PAGE|LINE|TEXT per line, with headers.
    """
    segments = job.get("transcript", {}).get("segments", [])
    if not segments:
        return JSONResponse({"error": "No transcript"}, status_code=400)

    profile = job.get("profile", {})
    lines_per_page = profile.get("lines_per_page") or 25

    # Build transcript lines
    all_lines = []
    current_speaker = ""
    buffer = []
    for seg in segments:
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        if not text:
            continue
        if speaker and speaker != current_speaker:
            if buffer:
                all_lines.append(" ".join(buffer))
                buffer.clear()
            current_speaker = speaker
            label = _format_speaker_label_export(speaker)
            all_lines.append(f"{label}:")
        buffer.append(text)
    if buffer:
        all_lines.append(" ".join(buffer))

    # Generate LEF content
    lef_lines = []
    # LEF header
    lef_lines.append(f"CN|{job.get('case_number', '')}")
    lef_lines.append(f"CA|{job.get('case_caption', '')}")
    lef_lines.append(f"DT|{job.get('date', '')}")
    lef_lines.append(f"RP|{job.get('reporter_name', '')}")
    lef_lines.append("BT")  # Begin transcript

    page = 1
    line_on_page = 1
    for text_line in all_lines:
        # Word wrap
        words = text_line.split()
        current = ""
        for word in words:
            if len(current) + len(word) + 1 > 70:
                lef_lines.append(f"{page}|{line_on_page}|{current.strip()}")
                line_on_page += 1
                if line_on_page > lines_per_page:
                    line_on_page = 1
                    page += 1
                current = word + " "
            else:
                current += word + " "
        if current.strip():
            lef_lines.append(f"{page}|{line_on_page}|{current.strip()}")
            line_on_page += 1
            if line_on_page > lines_per_page:
                line_on_page = 1
                page += 1

    lef_lines.append("ET")  # End transcript

    export_path = job_dir / f"notare_{job['id']}_transcript.lef"
    export_path.write_text("\n".join(lef_lines), encoding="utf-8")

    case = job.get("case_number", "") or job["id"]
    return _local_export(export_path, f"{filename or case}_transcript.lef")


def _export_ptx(job: dict, job_dir: Path, filename: str = ""):
    """Export transcript in PTX format (compatible with Sanction/trial presentation).

    PTX is an XML-based format that trial presentation software can import.
    Includes page/line references and timestamps for video sync.
    """
    segments = job.get("transcript", {}).get("segments", [])
    if not segments:
        return JSONResponse({"error": "No transcript"}, status_code=400)

    profile = job.get("profile", {})
    lines_per_page = profile.get("lines_per_page") or 25

    import xml.etree.ElementTree as ET
    root = ET.Element("TranscriptData")
    meta = ET.SubElement(root, "CaseInfo")
    ET.SubElement(meta, "CaseNumber").text = job.get("case_number", "")
    ET.SubElement(meta, "CaseCaption").text = job.get("case_caption", "")
    ET.SubElement(meta, "Date").text = job.get("date", "")
    ET.SubElement(meta, "Reporter").text = job.get("reporter_name", "")
    ET.SubElement(meta, "CourtName").text = job.get("court_name", "")

    # Add speakers
    speakers_el = ET.SubElement(root, "Speakers")
    seen_speakers = set()
    for seg in segments:
        spk = seg.get("speaker", "")
        if spk and spk not in seen_speakers:
            seen_speakers.add(spk)
            s = ET.SubElement(speakers_el, "Speaker")
            s.set("name", spk)
            s.set("label", _format_speaker_label_export(spk))

    # Add transcript lines with page/line/timestamp
    transcript_el = ET.SubElement(root, "Transcript")
    page = 1
    line_on_page = 1
    current_speaker = ""

    for seg in segments:
        speaker = seg.get("speaker", "")
        text = seg.get("text", "").strip()
        start = seg.get("start", 0)
        end = seg.get("end", 0)
        if not text:
            continue

        if speaker != current_speaker:
            current_speaker = speaker

        entry = ET.SubElement(transcript_el, "Line")
        entry.set("page", str(page))
        entry.set("line", str(line_on_page))
        entry.set("speaker", _format_speaker_label_export(speaker))
        entry.set("start", f"{start:.3f}")
        entry.set("end", f"{end:.3f}")
        entry.text = text

        line_on_page += 1
        if line_on_page > lines_per_page:
            line_on_page = 1
            page += 1

    tree = ET.ElementTree(root)
    export_path = job_dir / f"notare_{job['id']}_transcript.ptx"
    tree.write(str(export_path), encoding="utf-8", xml_declaration=True)

    case = job.get("case_number", "") or job["id"]
    return _local_export(export_path, f"{filename or case}_transcript.ptx")


def _export_video_sync(job: dict, job_dir: Path, filename: str = ""):
    """Export video synchronization file (.sync / .dvt).

    Maps transcript page:line positions to video timestamps.
    Compatible with trial presentation software for click-to-play.
    """
    segments = job.get("transcript", {}).get("segments", [])
    if not segments:
        return JSONResponse({"error": "No transcript"}, status_code=400)

    profile = job.get("profile", {})
    lines_per_page = profile.get("lines_per_page") or 25

    # Build sync map: page:line -> timestamp
    sync_entries = []
    page = 1
    line_on_page = 1

    for seg in segments:
        text = seg.get("text", "").strip()
        start = seg.get("start", 0)
        if not text:
            continue

        # Convert seconds to HH:MM:SS.mmm
        hours = int(start // 3600)
        minutes = int((start % 3600) // 60)
        seconds = int(start % 60)
        millis = int((start % 1) * 1000)
        tc = f"{hours:02d}:{minutes:02d}:{seconds:02d}.{millis:03d}"

        sync_entries.append(f"{page}:{line_on_page}\t{tc}")

        line_on_page += 1
        if line_on_page > lines_per_page:
            line_on_page = 1
            page += 1

    output = "PAGE:LINE\tTIMECODE\n"
    output += "\n".join(sync_entries)

    export_path = job_dir / f"notare_{job['id']}_sync.dvt"
    export_path.write_text(output, encoding="utf-8")

    case = job.get("case_number", "") or job["id"]
    return _local_export(export_path, f"{filename or case}_sync.dvt")


def _run_transcription(job: dict):
    """Transcribe using configured engine."""
    engine = SETTINGS.get("engine", "assemblyai")

    # Route to the right engine
    if engine == "whisper":
        return _run_transcription_whisper(job)
    if engine == "deepgram":
        return _run_transcription_deepgram(job)
    if engine == "rev":
        return _run_transcription_rev(job)

    # Default: AssemblyAI
    try:
        import assemblyai as aai
    except ImportError:
        logger.info("AssemblyAI not available, falling back to local Whisper")
        return _run_transcription_whisper(job)

    aai.settings.api_key = SETTINGS.get("api_key", "")
    if not aai.settings.api_key:
        logger.info("No API key configured, using local Whisper")
        return _run_transcription_whisper(job)

    job["progress"] = 5
    job["progress_message"] = "Preparing audio..."

    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"

    # Handle .trm files — FTR's proprietary format.
    # ffmpeg cannot decode .trm files (no codec support). Attempt conversion,
    # and if ALL files fail, give the user a clear message about FTR Manager.
    trm_files = sorted(audio_dir.glob("*.trm")) + sorted(audio_dir.glob("*.TRM"))
    if trm_files:
        job["progress_message"] = f"Attempting to convert {len(trm_files)} FTR .trm file(s)..."
        _save_job(job)
        ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
        converted = 0
        for trm in trm_files:
            wav_out = trm.with_suffix(".wav")
            try:
                cmd = [
                    ffmpeg_bin, "-y", "-i", str(trm),
                    "-acodec", "pcm_s16le", "-ar", "16000",
                    str(wav_out),
                ]
                r = subprocess.run(cmd, capture_output=True, text=True, creationflags=_NO_WINDOW, timeout=600)
                if r.returncode == 0 and wav_out.exists() and wav_out.stat().st_size > 1000:
                    logger.info("Converted %s -> %s", trm.name, wav_out.name)
                    converted += 1
                else:
                    logger.warning("TRM conversion failed for %s: %s", trm.name, r.stderr[-200:] if r.stderr else "unknown")
            except FileNotFoundError:
                break  # No ffmpeg at all
            except Exception as e:
                logger.warning("TRM conversion error for %s: %s", trm.name, e)
        # If no TRM files converted, give clear guidance
        if converted == 0 and trm_files:
            job["status"] = "error"
            job["error"] = (
                f"Could not convert {len(trm_files)} FTR .trm file(s). "
                "The FTR format is proprietary and may not be supported by the built-in converter. "
                "Please use FTR Manager or FTR Player to export your recording as a WAV file, "
                "then upload the WAV instead.")
            _save_job(job)
            logger.info("All %d TRM files failed conversion — user needs FTR Manager export", len(trm_files))
            return

    # Convert webm/mp4 to WAV (browser live recordings come as webm)
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
    for media_file in sorted(audio_dir.glob("*")):
        if media_file.suffix.lower() in (".webm", ".mp4", ".m4a", ".aac", ".flac", ".javs"):
            wav_out = media_file.with_suffix(".wav")
            if not wav_out.exists():
                try:
                    r = subprocess.run([ffmpeg_bin, "-y", "-i", str(media_file),
                                       "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                                       str(wav_out)],
                                      capture_output=True, text=True, timeout=600)
                    if r.returncode == 0:
                        logger.info("Converted %s → %s", media_file.name, wav_out.name)
                except Exception as e:
                    logger.warning("Audio conversion error for %s: %s", media_file.name, e)

    audio_files = sorted(audio_dir.glob("*.wav")) + sorted(audio_dir.glob("*.mp3"))

    if not audio_files:
        job["status"] = "error"
        job["error"] = "No audio files found or conversion failed. Supported: WAV, MP3, M4A, AAC, FLAC, MP4, WEBM, TRM, JAVS"
        return

    try:
        # Detect if these are TRM session segments (many files, same session)
        # vs actual separate-speaker files (one file per mic/person)
        # TRM segments are sequential 5-min chunks — always concatenate them
        # Multi-speaker mode: multiple files with speakers assigned per file
        multi_speaker = (len(audio_files) > 1
                        and len(job.get("speakers", [])) > 1)

        # Concatenate if multiple files from same session (TRM segments or unassigned)
        if len(audio_files) > 1 and not multi_speaker:
            job["progress"] = 10
            job["progress_message"] = f"Concatenating {len(audio_files)} audio segments..."
            concat_path = audio_dir / "full_session.wav"
            try:
                ffmpeg_bin = "ffmpeg"
                local_ffmpeg = BASE_DIR / "ffmpeg.exe"
                if local_ffmpeg.exists():
                    ffmpeg_bin = str(local_ffmpeg)
                # Build ffmpeg concat file list
                concat_list = audio_dir / "_concat.txt"
                with open(concat_list, "w") as f:
                    for af in audio_files:
                        f.write(f"file '{af.as_posix()}'\n")
                # Preserve channel count — TRM multi-channel = speaker separation
                cmd = [
                    ffmpeg_bin, "-y", "-f", "concat", "-safe", "0",
                    "-i", str(concat_list),
                    "-acodec", "pcm_s16le", "-ar", "16000",
                    str(concat_path),
                ]
                r = subprocess.run(cmd, capture_output=True, text=True, creationflags=_NO_WINDOW, timeout=1800)
                if r.returncode == 0:
                    logger.info("Concatenated %d files → %s", len(audio_files), concat_path.name)
                    audio_files = [concat_path]
                else:
                    logger.warning("Concatenation failed, using first file: %s", r.stderr[-200:])
                    audio_files = [audio_files[0]]
                concat_list.unlink(missing_ok=True)
            except Exception as e:
                logger.warning("Concatenation error, using first file: %s", e)
                audio_files = [audio_files[0]]

        # Detect multi-channel audio (e.g. from FTR Manager export) — channels = speakers
        _multichannel = 0
        if len(audio_files) == 1 and audio_files[0].suffix.lower() == ".wav":
            try:
                import wave
                with wave.open(str(audio_files[0]), "rb") as wf:
                    _multichannel = wf.getnchannels()
                if _multichannel > 1:
                    logger.info("Multi-channel WAV detected: %d channels in %s",
                                _multichannel, audio_files[0].name)
                    job["audio_channels"] = _multichannel
                    job["progress_message"] = f"Multi-channel audio detected ({_multichannel} channels — one per microphone)"
                    _save_job(job)
                else:
                    _multichannel = 0  # Mono — don't use channel splitting
            except Exception as e:
                logger.warning("Channel detection failed: %s", e)

        if multi_speaker:
            _transcribe_multi_file_aai(job, audio_files, aai)
        elif _multichannel > 1:
            # Multi-channel WAV: split channels, transcribe each, merge with speaker labels
            _transcribe_trm_multichannel(job, audio_files[0], _multichannel)
        else:
            _transcribe_single_aai(job, audio_files[0], aai)

        # Assign speakers — skip diarization if channels already provide speaker mapping
        if _multichannel > 1:
            logger.info("Skipping diarization — channel separation used for speakers")
        elif not _diarize_with_pyannote(job):
            if not _diarize_audio(job):
                _assign_speakers_heuristic(job)

        # Post-processing — each step wrapped to prevent hangs
        job["progress_message"] = "Identifying speakers from announcements..."
        _save_job(job)
        try:
            _identify_speakers_from_appearances(job)
        except Exception as e:
            logger.warning("Appearance scan failed: %s", e)

        job["progress_message"] = "Applying speaker labels..."
        _save_job(job)
        try:
            _apply_channel_speaker_mapping(job)
        except Exception as e:
            logger.warning("Channel mapping failed: %s", e)

        try:
            _cleanup_speaker_names(job)
        except Exception as e:
            logger.warning("Name cleanup failed: %s", e)

        # Save transcript
        if job.get("transcript"):
            with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
                json.dump(job["transcript"], f, indent=2)

        # Proofing rules and context review
        _auto_flag_issues(job)
        _context_review(job)
        _auto_detect_styles(job)
        _apply_proofing_rules(job)

        job["status"] = "complete"
        _feed_word_live_on_complete(job)
        job["progress"] = 100
        job["progress_message"] = "Complete"
        _save_job(job)
        logger.info("Job %s complete: %d segments",
                    job["id"], len(job.get("transcript", {}).get("segments", [])))

    except Exception as e:
        logger.error("Transcription failed for job %s: %s", job["id"], e)
        job["status"] = "error"
        job["error"] = str(e)


def _transcribe_trm_multichannel(job: dict, audio_path: Path, num_channels: int):
    """Transcribe a multi-channel TRM WAV by splitting channels and transcribing each.

    Each channel represents a physical microphone in the courtroom/deposition room.
    Channel separation IS the speaker diarization — no pyannote needed.

    Strategy:
    1. Split multi-channel WAV into per-channel mono WAV files using ffmpeg
    2. Transcribe each channel independently (Whisper local or configured engine)
    3. Merge all segments chronologically with channel-based speaker labels
    """
    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    channel_labels = job.get("channel_labels", {})  # {0: "Judge", 1: "Attorney", ...}

    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"

    # Step 1: Split channels
    job["progress_message"] = f"Splitting {num_channels} audio channels..."
    _save_job(job)
    channel_files = []
    for ch in range(num_channels):
        ch_path = audio_dir / f"channel_{ch}.wav"
        cmd = [
            ffmpeg_bin, "-y", "-i", str(audio_path),
            "-filter_complex", f"[0:a]pan=mono|c0=c{ch}[out]",
            "-map", "[out]",
            "-acodec", "pcm_s16le", "-ar", "16000",
            str(ch_path),
        ]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                               creationflags=_NO_WINDOW, timeout=600)
            if r.returncode == 0 and ch_path.exists() and ch_path.stat().st_size > 1000:
                channel_files.append((ch, ch_path))
                logger.info("Split channel %d → %s", ch, ch_path.name)
            else:
                logger.warning("Channel %d split failed or empty: %s", ch, r.stderr[-200:] if r.stderr else "empty file")
        except Exception as e:
            logger.warning("Channel %d split error: %s", ch, e)

    if not channel_files:
        logger.warning("No channels extracted — falling back to single-file transcription")
        job["progress_message"] = "Channel split failed, transcribing as single file..."
        _save_job(job)
        # Fall back — try to get the configured engine
        engine = SETTINGS.get("engine", "whisper")
        if engine == "whisper":
            _transcribe_whisper_local(job, audio_path)
        else:
            try:
                import assemblyai as aai
                aai.settings.api_key = SETTINGS.get("api_key", "")
                _transcribe_single_aai(job, audio_path, aai)
            except Exception:
                _transcribe_whisper_local(job, audio_path)
        return

    # Step 2: Transcribe each channel
    all_segments = []
    for ch_idx, ch_path in channel_files:
        speaker_label = channel_labels.get(str(ch_idx),
                         channel_labels.get(ch_idx,
                         f"Channel {ch_idx + 1}"))
        pct_base = 15 + int(70 * ch_idx / len(channel_files))
        pct_range = int(70 / len(channel_files))  # How much progress this channel covers
        job["progress"] = pct_base
        job["progress_message"] = f"Transcribing channel {ch_idx + 1}/{len(channel_files)} ({speaker_label})..."
        _save_job(job)

        # Progress callback for within-channel updates
        def _ch_progress(elapsed_s, total_s, seg_count, _job=job, _base=pct_base, _range=pct_range, _ch=ch_idx, _total=len(channel_files), _label=speaker_label):
            if total_s > 0:
                pct = _base + int(_range * min(elapsed_s / total_s, 1.0))
                _job["progress"] = min(85, pct)
            mins_left = max(0, int((total_s - elapsed_s) / 60)) if total_s > 0 else 0
            _job["progress_message"] = f"Transcribing channel {_ch + 1}/{_total} ({_label}) — {seg_count} segments, ~{mins_left}m remaining"
            _save_job(_job)

        # Use the user's chosen engine for per-channel transcription
        engine_choice = SETTINGS.get("engine", "whisper")
        try:
            if engine_choice in ("assemblyai", "aai") and SETTINGS.get("api_key"):
                ch_segments = _transcribe_channel_aai(ch_path)
            elif engine_choice in ("deepgram",) and SETTINGS.get("api_key"):
                ch_segments = _transcribe_channel_aai(ch_path)  # Deepgram uses same wrapper
            else:
                ch_segments = _transcribe_channel_whisper(ch_path, progress_cb=_ch_progress)
            for seg in ch_segments:
                seg["speaker"] = speaker_label
                seg["channel"] = ch_idx
            all_segments.extend(ch_segments)
            logger.info("Channel %d (%s): %d segments via %s", ch_idx, speaker_label, len(ch_segments), engine_choice)
        except Exception as e:
            logger.warning("Channel %d transcription failed via %s: %s — trying Whisper fallback", ch_idx, engine_choice, e)
            try:
                ch_segments = _transcribe_channel_whisper(ch_path, progress_cb=_ch_progress)
                for seg in ch_segments:
                    seg["speaker"] = speaker_label
                    seg["channel"] = ch_idx
                all_segments.extend(ch_segments)
            except Exception as e2:
                logger.warning("Channel %d Whisper fallback also failed: %s", ch_idx, e2)

    # Step 3: Deduplicate cross-channel bleed
    # Four-layer approach:
    #   L1: Per-channel noise floor (already handled by VAD in Whisper)
    #   L2: Energy-dominant channel wins when same text appears on multiple mics
    #   L3: Text deduplication — near-identical segments at same timestamp = bleed
    #   L4: Cross-talk flagging — multiple channels with different text = genuine overlap
    job["progress_message"] = "Deduplicating cross-channel bleed..."
    _save_job(job)

    all_segments.sort(key=lambda s: s.get("start", 0))

    def _text_similar(a, b):
        """Simple word-overlap similarity for dedup."""
        wa = set(a.lower().split())
        wb = set(b.lower().split())
        if not wa or not wb:
            return 0
        return len(wa & wb) / min(len(wa), len(wb))

    deduped = []
    skip_indices = set()

    for i, seg in enumerate(all_segments):
        if i in skip_indices:
            continue

        # Find overlapping segments from OTHER channels within 2-second window
        overlaps = []
        for j in range(i + 1, len(all_segments)):
            if j in skip_indices:
                continue
            other = all_segments[j]
            # Stop looking if we're past the time window
            if other.get("start", 0) > seg.get("end", 0) + 2000:
                break
            # Same channel = not bleed
            if other.get("channel") == seg.get("channel"):
                continue
            # Check time overlap
            overlap_start = max(seg.get("start", 0), other.get("start", 0))
            overlap_end = min(seg.get("end", 0), other.get("end", 0))
            if overlap_end - overlap_start > 500:  # At least 0.5s overlap
                overlaps.append((j, other))

        if not overlaps:
            deduped.append(seg)
            continue

        # Check each overlap — is it bleed (same text) or cross-talk (different text)?
        is_bleed = False
        for j, other in overlaps:
            similarity = _text_similar(seg.get("text", ""), other.get("text", ""))
            if similarity > 0.6:
                # Same text on different channels — bleed. Keep the one with more words
                # (proxy for dominant channel — louder mic captures more clearly)
                if len(seg.get("text", "").split()) >= len(other.get("text", "").split()):
                    skip_indices.add(j)  # Skip the weaker copy
                else:
                    skip_indices.add(i)  # This one is weaker
                    break
                is_bleed = True
            else:
                # Different text — genuine cross-talk. Flag both for review
                seg["cross_talk"] = True
                other["cross_talk"] = True

        if i not in skip_indices:
            deduped.append(seg)

    bleed_removed = len(all_segments) - len(deduped)
    cross_talk_count = sum(1 for s in deduped if s.get("cross_talk"))
    if bleed_removed > 0 or cross_talk_count > 0:
        logger.info("Channel dedup: removed %d bleed segments, flagged %d cross-talk",
                     bleed_removed, cross_talk_count)

    all_segments = deduped

    # Calculate duration from the last segment
    duration = max((s.get("end", 0) for s in all_segments), default=0) if all_segments else 0

    job["transcript"] = {
        "segments": all_segments,
        "full_text": " ".join(s.get("text", "") for s in all_segments),
        "duration": duration,
        "diarization": f"channel-split ({num_channels} channels)",
        "engine": f"{SETTINGS.get('engine', 'whisper')}-multichannel",
    }
    job["progress"] = 90
    job["progress_message"] = f"Transcribed {len(all_segments)} segments across {len(channel_files)} channels"
    job["status"] = "complete"
    _feed_word_live_on_complete(job)
    job["audio_file"] = audio_path.name

    # Save transcript to disk (separate from job.json)
    job_dir = Path(job.get("dir", ""))
    if job_dir.exists() and job.get("transcript"):
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            json.dump(job["transcript"], f, indent=2)

    _save_job(job)
    logger.info("TRM multi-channel transcription complete: %d segments, %d channels",
                len(all_segments), len(channel_files))


def _transcribe_channel_aai(audio_path: Path) -> list:
    """Transcribe a single mono channel WAV using AssemblyAI.
    Returns a list of segment dicts with start, end, text, confidence."""
    import assemblyai as aai
    aai.settings.api_key = SETTINGS.get("api_key", "")

    config = aai.TranscriptionConfig(
        language_code="en",
        punctuate=True,
        format_text=True,
    )
    transcriber = aai.Transcriber()
    transcript = transcriber.transcribe(str(audio_path), config=config)

    if transcript.status == aai.TranscriptStatus.error:
        raise RuntimeError(f"AssemblyAI error: {transcript.error}")

    segments = []
    if transcript.utterances:
        for utt in transcript.utterances:
            segments.append({
                "start": utt.start,
                "end": utt.end,
                "text": utt.text.strip(),
                "confidence": round(utt.confidence, 3) if utt.confidence else 0.0,
            })
    elif transcript.words:
        # Fall back to word-level grouping if no utterances
        current = {"start": 0, "end": 0, "text": "", "words": []}
        for w in transcript.words:
            if current["text"] and (w.start - current["end"] > 1500):
                segments.append(current)
                current = {"start": w.start, "end": w.end, "text": w.text, "words": []}
            else:
                if not current["text"]:
                    current["start"] = w.start
                current["end"] = w.end
                current["text"] = (current["text"] + " " + w.text).strip()
        if current["text"]:
            segments.append(current)

    return segments


def _transcribe_channel_whisper(audio_path: Path, progress_cb=None) -> list:
    """Transcribe a single mono channel WAV using faster-whisper.
    Returns a list of segment dicts with start, end, text, confidence.
    progress_cb(elapsed_s, total_s, seg_count) called periodically."""
    from faster_whisper import WhisperModel
    model_size = SETTINGS.get("whisper_model", "small.en")

    try:
        model = WhisperModel(model_size, device="cuda", compute_type="float16")
    except Exception:
        model = WhisperModel(model_size, device="cpu", compute_type="int8")

    segments_iter, info = model.transcribe(
        str(audio_path), language="en", beam_size=5,
        word_timestamps=True, vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=200),
    )

    total_duration = info.duration if hasattr(info, 'duration') else 0
    segments = []
    for seg in segments_iter:
        words = []
        avg_conf = 0.0
        if seg.words:
            words = [{"word": w.word.strip(), "start": int(w.start * 1000),
                       "end": int(w.end * 1000), "confidence": round(w.probability, 3)}
                      for w in seg.words if w.word.strip()]
            avg_conf = sum(w.probability for w in seg.words) / len(seg.words) if seg.words else 0
        segments.append({
            "start": int(seg.start * 1000),
            "end": int(seg.end * 1000),
            "text": seg.text.strip(),
            "confidence": round(avg_conf, 3),
            "words": words,
        })
        # Update progress every 10 segments
        if progress_cb and len(segments) % 10 == 0:
            try:
                progress_cb(seg.end, total_duration, len(segments))
            except Exception:
                pass
    return segments


def _transcribe_single_aai(job: dict, audio_path: Path, aai):
    """Transcribe a single file with AssemblyAI, with speaker diarization."""
    job["progress"] = 15
    job["progress_message"] = "Uploading to AssemblyAI..."

    # Build word boost and custom spelling from profile
    profile = job.get("profile", {})
    word_boost = profile.get("word_boost", [])
    custom_spelling = profile.get("custom_spelling", {})

    # Default legal term boost (always included)
    _default_boost = [
        "objection", "sustained", "overruled", "voir dire",
        "motion in limine", "Daubert", "Miranda", "Strickland",
        "appellant", "appellee", "amicus",
    ]
    # Merge profile boost with defaults (no duplicates)
    boost_set = set(w.lower() for w in _default_boost)
    combined_boost = list(_default_boost)
    for w in word_boost:
        if w.lower() not in boost_set:
            combined_boost.append(w)
            boost_set.add(w.lower())

    config_kwargs = {
        "speaker_labels": True,
        "language_code": "en",
        "punctuate": True,
        "format_text": True,
    }
    if combined_boost:
        config_kwargs["word_boost"] = combined_boost
    if custom_spelling:
        config_kwargs["custom_spelling"] = custom_spelling

    config = aai.TranscriptionConfig(**config_kwargs)

    transcriber = aai.Transcriber()

    job["progress"] = 30
    job["progress_message"] = "Transcribing with AssemblyAI..."

    transcript = transcriber.transcribe(str(audio_path), config=config)

    if transcript.status == aai.TranscriptStatus.error:
        raise RuntimeError(f"AssemblyAI error: {transcript.error}")

    job["progress"] = 85
    job["progress_message"] = "Processing results..."

    # Build segments from utterances (speaker-labeled)
    segments = []
    if transcript.utterances:
        for utt in transcript.utterances:
            seg = {
                "start": utt.start,  # milliseconds
                "end": utt.end,
                "text": utt.text.strip(),
                "speaker": utt.speaker or "",
                "confidence": round(utt.confidence, 3) if utt.confidence else 0.0,
            }
            if utt.words:
                seg["words"] = [
                    {"word": w.text, "start": w.start, "end": w.end,
                     "confidence": round(w.confidence, 3) if w.confidence else 0.0}
                    for w in utt.words
                ]
            segments.append(seg)
    elif transcript.words:
        # Fallback: no utterances, build from words
        current_seg = {"start": 0, "end": 0, "text": "", "speaker": "", "words": []}
        for w in transcript.words:
            current_seg["words"].append(
                {"word": w.text, "start": w.start, "end": w.end,
                 "confidence": round(w.confidence, 3) if w.confidence else 0.0})
            current_seg["text"] += " " + w.text
            current_seg["end"] = w.end
            # Split on sentence boundaries
            if w.text.rstrip().endswith(('.', '!', '?')):
                current_seg["text"] = current_seg["text"].strip()
                current_seg["confidence"] = round(
                    sum(wd["confidence"] for wd in current_seg["words"]) / len(current_seg["words"]), 3
                ) if current_seg["words"] else 0.0
                segments.append(current_seg)
                current_seg = {"start": w.end, "end": w.end, "text": "", "speaker": "", "words": []}
        if current_seg["text"].strip():
            current_seg["text"] = current_seg["text"].strip()
            segments.append(current_seg)

    job["transcript"] = {
        "segments": segments,
        "full_text": transcript.text or "",
        "duration": segments[-1]["end"] if segments else 0,
        "engine": "assemblyai",
        "audio_duration": transcript.audio_duration,
    }
    job["audio_file"] = audio_path.name
    job["progress"] = 95
    job["progress_message"] = "Finalizing..."


def _transcribe_multi_file_aai(job: dict, audio_files: list, aai):
    """Transcribe multiple files (one per speaker) and merge."""
    speakers = job.get("speakers", [])
    all_segments = []

    for i, audio_path in enumerate(audio_files):
        speaker_name = speakers[i]["name"] if i < len(speakers) else f"Speaker {i+1}"
        job["progress"] = 10 + int(70 * i / len(audio_files))
        job["progress_message"] = f"Transcribing {speaker_name}..."

        config = aai.TranscriptionConfig(
            language_code="en",
            punctuate=True,
            format_text=True,
        )
        transcriber = aai.Transcriber()
        transcript = transcriber.transcribe(str(audio_path), config=config)

        if transcript.status == aai.TranscriptStatus.error:
            logger.warning("Channel %d failed: %s", i, transcript.error)
            continue

        if transcript.utterances:
            for utt in transcript.utterances:
                all_segments.append({
                    "start": utt.start,
                    "end": utt.end,
                    "text": utt.text.strip(),
                    "speaker": speaker_name,
                    "channel": i,
                    "confidence": round(utt.confidence, 3) if utt.confidence else 0.0,
                })
        elif transcript.words:
            # Build segments from words
            text_parts = []
            seg_start = transcript.words[0].start if transcript.words else 0
            for w in transcript.words:
                text_parts.append(w.text)
                if w.text.rstrip().endswith(('.', '!', '?')):
                    all_segments.append({
                        "start": seg_start,
                        "end": w.end,
                        "text": " ".join(text_parts).strip(),
                        "speaker": speaker_name,
                        "channel": i,
                        "confidence": 0.0,
                    })
                    text_parts = []
                    seg_start = w.end
            if text_parts:
                all_segments.append({
                    "start": seg_start,
                    "end": transcript.words[-1].end,
                    "text": " ".join(text_parts).strip(),
                    "speaker": speaker_name,
                    "channel": i,
                    "confidence": 0.0,
                })

    # Sort by timestamp (TranscriptMerger)
    all_segments.sort(key=lambda s: s["start"])

    job["transcript"] = {
        "segments": all_segments,
        "full_text": " ".join(s["text"] for s in all_segments),
        "duration": max((s["end"] for s in all_segments), default=0),
        "channels": len(audio_files),
        "engine": "assemblyai",
    }
    job["audio_file"] = audio_files[0].name
    job["progress"] = 90
    job["progress_message"] = "Merging channels..."


def _compute_mel_fbank(audio, sr=16000, n_fft=512, hop_length=160, n_mels=80):
    """Compute 80-dim mel filterbank features using numpy only. No external deps."""
    import numpy as np
    n_frames = 1 + (len(audio) - n_fft) // hop_length
    if n_frames < 1:
        return np.zeros((1, n_mels), dtype=np.float32)
    frames = np.stack([audio[i*hop_length:i*hop_length+n_fft] for i in range(n_frames)])
    window = np.hanning(n_fft)
    spectrum = np.abs(np.fft.rfft(frames * window, n=n_fft))
    power = spectrum ** 2
    fmin, fmax = 0, sr / 2
    mel_min = 2595 * np.log10(1 + fmin / 700)
    mel_max = 2595 * np.log10(1 + fmax / 700)
    mel_points = np.linspace(mel_min, mel_max, n_mels + 2)
    hz_points = 700 * (10 ** (mel_points / 2595) - 1)
    bin_points = np.floor((n_fft + 1) * hz_points / sr).astype(int)
    fbank = np.zeros((n_mels, n_fft // 2 + 1))
    for m in range(n_mels):
        for k in range(bin_points[m], bin_points[m+1]):
            fbank[m, k] = (k - bin_points[m]) / max(1, bin_points[m+1] - bin_points[m])
        for k in range(bin_points[m+1], bin_points[m+2]):
            fbank[m, k] = (bin_points[m+2] - k) / max(1, bin_points[m+2] - bin_points[m+1])
    mel_spec = np.log(np.dot(power, fbank.T) + 1e-6)
    return mel_spec.astype(np.float32)


def _diarize_with_pyannote(job: dict) -> bool:
    """Speaker diarization using pyannote.audio — neural pipeline.

    Runs pyannote's pretrained speaker diarization on the raw audio, producing
    high-quality speaker turns (start, end, speaker_label).  Each Whisper segment
    is then assigned the speaker who owns the majority of its time range.

    Returns True if diarization was applied, False otherwise (caller should
    fall back to ONNX or heuristic).

    Model loading priority:
      1. Local bundled models at _internal/_pyannote_models/ or _pyannote_models/
         (no internet or token needed — ships with the installer)
      2. HuggingFace download with token (dev/build machines only)
         Set via settings.json "hf_token" or env var HF_TOKEN
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return False

    segments = transcript["segments"]

    # Skip if segments already have real speaker labels (from AssemblyAI)
    real_labels = sum(1 for s in segments if s.get("speaker", "").strip()
                      and not s["speaker"].startswith("Speaker "))
    if real_labels > len(segments) * 0.5:
        return False

    # Find the audio file
    audio_file = job.get("audio_file", "")
    job_dir = Path(job.get("dir", ""))
    audio_path = None
    if audio_file:
        candidate = job_dir / "audio" / audio_file
        if candidate.exists():
            audio_path = candidate
    if not audio_path:
        audio_dir = job_dir / "audio"
        if audio_dir.exists():
            wavs = list(audio_dir.glob("*.wav"))
            if wavs:
                audio_path = wavs[0]
    if not audio_path:
        logger.info("No audio file found for pyannote diarization")
        return False

    try:
        from pyannote.audio import Pipeline as PyannotePipeline
        import torch

        logger.info("Running pyannote diarization on %s...", audio_path.name)
        job["progress_message"] = "Analyzing speakers (pyannote)..."
        _save_job(job)

        # Load pipeline — try local bundled models first, then HuggingFace
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        pipeline = None

        # Priority 1: Local bundled model (ships with installer — no token needed)
        for model_root in [
            BASE_DIR / "_internal" / "_pyannote_models",
            BASE_DIR / "_pyannote_models",
        ]:
            # Check both flat layout (config.yaml at root) and
            # snapshot layout (pipeline/config.yaml with sibling model dirs)
            for model_dir in [model_root, model_root / "pipeline"]:
                config_file = model_dir / "config.yaml"
                if config_file.exists():
                    logger.info("Loading pyannote from bundled models: %s", model_dir)
                    pipeline = PyannotePipeline.from_pretrained(str(model_dir))
                    break
            if pipeline is not None:
                break

        # Priority 2: HuggingFace download (dev machine with token)
        if pipeline is None:
            hf_token = SETTINGS.get("hf_token", "") or os.environ.get("HF_TOKEN", "")
            if hf_token:
                logger.info("Downloading pyannote model from HuggingFace...")
                pipeline = PyannotePipeline.from_pretrained(
                    "pyannote/speaker-diarization-3.1",
                    token=hf_token,
                )
            else:
                logger.info("No bundled pyannote model and no HF token — skipping")
                return False

        pipeline.to(device)

        # Hint speaker count from case documents — use as floor, not ceiling
        # Court proceedings regularly have 6-12+ voices: judge, multiple attorneys
        # per side, witnesses, clerk, interpreter, court reporter, etc.
        known_speakers = job.get("speakers", [])
        params = {}
        if known_speakers and len(known_speakers) >= 2:
            params["min_speakers"] = len(known_speakers)
            params["max_speakers"] = max(len(known_speakers) + 4, 10)

        # Run diarization
        diarization = pipeline(str(audio_path), **params)

        # Collect speaker turns: [(start_ms, end_ms, speaker_label), ...]
        turns = []
        for turn, _, speaker in diarization.itertracks(yield_label=True):
            turns.append((
                round(turn.start * 1000),
                round(turn.end * 1000),
                speaker,
            ))

        if not turns:
            logger.info("Pyannote produced no speaker turns")
            return False

        logger.info("Pyannote found %d speaker turns across %d unique speakers",
                    len(turns), len(set(t[2] for t in turns)))

        # Align pyannote turns with Whisper segments via majority overlap
        for seg in segments:
            seg_start = seg.get("start", 0)
            seg_end = seg.get("end", seg_start)

            # Calculate overlap with each speaker turn
            speaker_overlap = {}  # speaker -> total overlap ms
            for t_start, t_end, t_speaker in turns:
                overlap_start = max(seg_start, t_start)
                overlap_end = min(seg_end, t_end)
                overlap = max(0, overlap_end - overlap_start)
                if overlap > 0:
                    speaker_overlap[t_speaker] = speaker_overlap.get(t_speaker, 0) + overlap

            if speaker_overlap:
                # Assign the speaker with the most overlap
                best_speaker = max(speaker_overlap, key=speaker_overlap.get)
                seg["speaker"] = best_speaker
            # Segments with no overlap keep their existing (possibly blank) speaker

            # Progress
            if seg_end > 0 and transcript.get("duration", 0) > 0:
                pct = 89 + int(10 * seg_end / transcript["duration"])
                job["progress"] = min(99, pct)

        transcript["diarization"] = "pyannote-3.1"
        unique = len(set(s.get("speaker", "") for s in segments if s.get("speaker")))
        logger.info("Pyannote diarization complete: %d speakers across %d segments", unique, len(segments))
        return True

    except ImportError:
        # Native import failed — try the on-demand pyannote environment
        _pyannote_env = BASE_DIR / "_pyannote_env"
        _pyannote_python = _pyannote_env / "Scripts" / "python.exe"
        if _pyannote_python.exists() and not (_pyannote_env / ".downloading").exists():
            return _diarize_with_pyannote_subprocess(job, audio_path, segments, transcript)
        logger.info("pyannote.audio not installed — falling back to ONNX diarization")
        return False
    except Exception as e:
        logger.warning("Pyannote diarization failed: %s — falling back", e)
        return False


def _diarize_with_pyannote_subprocess(job, audio_path, segments, transcript):
    """Run pyannote via the on-demand _pyannote_env as a subprocess."""
    import subprocess as _sp
    import json as _json
    import tempfile

    _pyannote_python = str(BASE_DIR / "_pyannote_env" / "Scripts" / "python.exe")

    # Find model directory
    model_dir = None
    for model_root in [BASE_DIR / "_internal" / "_pyannote_models", BASE_DIR / "_pyannote_models"]:
        for sub in [model_root, model_root / "pipeline"]:
            if (sub / "config.yaml").exists():
                model_dir = str(sub)
                break
        if model_dir:
            break

    # HF token fallback
    hf_token = SETTINGS.get("hf_token", "") or os.environ.get("HF_TOKEN", "")

    # Known speaker count
    known_speakers = job.get("speakers", [])
    min_speakers = len(known_speakers) if known_speakers and len(known_speakers) >= 2 else 2
    max_speakers = max(min_speakers + 4, 10)

    # Build a small script to run pyannote and output JSON turns
    # Resolve relative paths in config.yaml to absolute before loading
    script = f'''
import json, sys, os, shutil, tempfile, warnings
from pathlib import Path

# Suppress all warnings to stderr so they don't corrupt JSON output on stdout
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"

model_dir = {repr(model_dir)}
hf_token = {repr(hf_token)}
audio_path = {repr(str(audio_path))}

# Fix relative paths in config.yaml — resolve ../embedding etc to absolute
if model_dir:
    config_path = Path(model_dir) / "config.yaml"
    if config_path.exists():
        text = config_path.read_text()
        parent = str(Path(model_dir).parent).replace(chr(92), "/")
        text = text.replace("../embedding", parent + "/embedding")
        text = text.replace("../segmentation", parent + "/segmentation")
        # Write to a temp copy so we don't modify the original
        tmp_dir = Path(tempfile.mkdtemp(prefix="pyannote_"))
        tmp_config = tmp_dir / "config.yaml"
        tmp_config.write_text(text)
        model_dir = str(tmp_dir)

from pyannote.audio import Pipeline
import torch

pipeline = None
if model_dir:
    try:
        pipeline = Pipeline.from_pretrained(model_dir)
    except Exception as e:
        print(json.dumps({{"error": f"model load failed: {{e}}"}}))
if pipeline is None and hf_token:
    pipeline = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", token=hf_token)
if pipeline is None:
    print(json.dumps({{"error": "no model"}}))
    sys.exit(1)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
pipeline.to(device)

diarization = pipeline(audio_path, min_speakers={min_speakers}, max_speakers={max_speakers})
turns = []
for turn, _, speaker in diarization.itertracks(yield_label=True):
    turns.append([round(turn.start * 1000), round(turn.end * 1000), speaker])
print(json.dumps({{"turns": turns}}))
'''

    try:
        logger.info("Running pyannote via subprocess (%s)...", _pyannote_python)
        job["progress_message"] = "Analyzing speakers (pyannote)..."
        _save_job(job)

        # Write script to temp file — Windows -c flag truncates complex scripts
        script_file = Path(tempfile.mktemp(suffix=".py", prefix="pyannote_run_"))
        script_file.write_text(script, encoding="utf-8")

        try:
            result = _sp.run(
                [_pyannote_python, str(script_file)],
                capture_output=True, text=True, timeout=600,
            )
        finally:
            try:
                script_file.unlink(missing_ok=True)
            except Exception:
                pass

        if result.returncode != 0:
            logger.warning("Pyannote subprocess failed (rc=%d): %s", result.returncode,
                          result.stderr[-300:] if result.stderr else "no stderr")
            return False

        # Parse JSON from stdout — skip any warning/info lines before the JSON
        stdout = result.stdout.strip()
        json_start = stdout.rfind('{"')
        if json_start < 0:
            logger.warning("Pyannote subprocess produced no JSON output. stdout=%s stderr=%s",
                          stdout[-200:] if stdout else "empty",
                          result.stderr[-200:] if result.stderr else "empty")
            return False
        data = _json.loads(stdout[json_start:])
        if "error" in data:
            logger.warning("Pyannote subprocess error: %s", data["error"])
            return False

        turns = data["turns"]
        if not turns:
            logger.info("Pyannote produced no speaker turns")
            return False

        logger.info("Pyannote subprocess found %d turns across %d speakers",
                    len(turns), len(set(t[2] for t in turns)))

        # Align turns with segments via majority overlap
        for seg in segments:
            seg_start = seg.get("start", 0)
            seg_end = seg.get("end", seg_start)
            speaker_overlap = {}
            for t_start, t_end, t_speaker in turns:
                overlap = max(0, min(seg_end, t_end) - max(seg_start, t_start))
                if overlap > 0:
                    speaker_overlap[t_speaker] = speaker_overlap.get(t_speaker, 0) + overlap
            if speaker_overlap:
                seg["speaker"] = max(speaker_overlap, key=speaker_overlap.get)

        transcript["diarization"] = "pyannote-3.1"
        unique = len(set(s.get("speaker", "") for s in segments if s.get("speaker")))
        logger.info("Pyannote subprocess complete: %d speakers across %d segments", unique, len(segments))
        return True

    except Exception as e:
        logger.warning("Pyannote subprocess failed: %s", e)
        return False


def _diarize_audio(job: dict):
    """Speaker diarization using ONNX speaker embeddings — no PyTorch needed.

    Uses a 24MB ECAPA-TDNN model (downloads on first use from HuggingFace).
    Extracts voice embeddings per segment, clusters them, maps to known speakers.
    Runs on CPU via onnxruntime — works in the exe without any extra frameworks.
    Falls back to heuristic if speechbrain is unavailable or audio can't be processed.
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return False

    segments = transcript["segments"]

    # Skip if segments already have real speaker labels (from AssemblyAI/Deepgram)
    real_labels = sum(1 for s in segments if s.get("speaker", "").strip()
                      and not s["speaker"].startswith("Speaker "))
    if real_labels > len(segments) * 0.5:
        return False  # Already have good labels

    # Find the audio file
    audio_file = job.get("audio_file", "")
    job_dir = Path(job.get("dir", ""))
    audio_path = None

    if audio_file:
        candidate = job_dir / "audio" / audio_file
        if candidate.exists():
            audio_path = candidate
    if not audio_path:
        # Find any WAV file
        audio_dir = job_dir / "audio"
        if audio_dir.exists():
            wavs = list(audio_dir.glob("*.wav"))
            if wavs:
                audio_path = wavs[0]

    if not audio_path:
        logger.info("No audio file found for diarization")
        return False

    try:
        import onnxruntime as ort
        import numpy as np
        import wave

        # Find ONNX model — check root, _internal (PyInstaller), then download
        model_path = BASE_DIR / "_speaker_models" / "ecapa_tdnn.onnx"
        if not model_path.exists():
            _alt = BASE_DIR / "_internal" / "_speaker_models" / "ecapa_tdnn.onnx"
            if _alt.exists():
                model_path = _alt
        if not model_path.exists():
            model_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info("Downloading speaker embedding model (24MB)...")
            job["progress_message"] = "Downloading speaker model..."
            import urllib.request
            urllib.request.urlretrieve(
                "https://huggingface.co/Wespeaker/wespeaker-ecapa-tdnn512-LM/resolve/main/voxceleb_ECAPA512_LM.onnx",
                str(model_path))
            logger.info("Speaker model downloaded to %s", model_path)

        logger.info("Running ONNX speaker diarization on %s...", audio_path.name)
        job["progress_message"] = "Analyzing speakers..."

        # Load model
        session = ort.InferenceSession(str(model_path), providers=['CPUExecutionProvider'])

        # Load audio
        with wave.open(str(audio_path), 'rb') as wf:
            sr = wf.getframerate()
            audio = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0

        # Extract embeddings for each segment — with progress updates and timeout
        import time as _diar_time
        _diar_start = _diar_time.time()
        _DIAR_TIMEOUT = 120  # 2 minute max for diarization

        embeddings = []
        total = len(segments)
        for idx, seg in enumerate(segments):
            # Timeout check
            if _diar_time.time() - _diar_start > _DIAR_TIMEOUT:
                logger.warning("Diarization timed out after %ds (%d/%d segments)",
                              _DIAR_TIMEOUT, idx, total)
                break

            # Progress update
            if idx % 5 == 0:
                pct = 89 + int((idx / total) * 10)  # 89-99%
                job["progress"] = pct
                job["progress_message"] = f"Analyzing speakers ({idx+1}/{total})..."
                _save_job(job)

            start_sample = int((seg.get("start", 0) / 1000) * sr)
            end_sample = int((seg.get("end", seg.get("start", 0)) / 1000) * sr)
            end_sample = min(end_sample, len(audio))
            start_sample = min(start_sample, end_sample)

            if end_sample - start_sample < sr:  # Less than 1 second — too short
                embeddings.append(None)
                continue

            chunk = audio[start_sample:end_sample]
            feats = _compute_mel_fbank(chunk, sr)
            feats = feats.reshape(1, feats.shape[0], feats.shape[1])
            result = session.run(None, {'feats': feats})
            embeddings.append(result[0][0])

        # Cluster embeddings
        valid_embeddings = [(i, e) for i, e in enumerate(embeddings) if e is not None]
        if len(valid_embeddings) < 2:
            logger.info("Too few valid embeddings for clustering (%d)", len(valid_embeddings))
            return False

        from sklearn.cluster import AgglomerativeClustering
        from collections import Counter

        emb_matrix = np.stack([e for _, e in valid_embeddings])

        # Normalize embeddings
        norms = np.linalg.norm(emb_matrix, axis=1, keepdims=True)
        emb_matrix = emb_matrix / (norms + 1e-8)

        # Determine speaker count from known speakers or estimate
        known_speakers = job.get("speakers", [])
        n_speakers = len(known_speakers) if known_speakers else None
        if not n_speakers or n_speakers < 2:
            n_speakers = min(5, max(2, len(valid_embeddings) // 15))

        clustering = AgglomerativeClustering(
            n_clusters=n_speakers,
            metric="cosine",
            linkage="average",
        )
        labels = clustering.fit_predict(emb_matrix)

        # Map cluster IDs to known speaker names
        speaker_names = {}
        if known_speakers:
            label_counts = Counter(labels)
            sorted_labels = [l for l, _ in label_counts.most_common()]
            for i, cluster_id in enumerate(sorted_labels):
                if i < len(known_speakers):
                    speaker_names[cluster_id] = known_speakers[i].get("name", f"Speaker {cluster_id + 1}")
                else:
                    speaker_names[cluster_id] = f"Speaker {cluster_id + 1}"
        else:
            for l in set(labels):
                speaker_names[l] = f"Speaker {l + 1}"

        # Apply labels
        label_idx = 0
        for i, seg in enumerate(segments):
            if embeddings[i] is not None:
                seg["speaker"] = speaker_names.get(labels[label_idx], f"Speaker {label_idx + 1}")
                label_idx += 1

        transcript["diarization"] = "onnx_ecapa"
        unique = len(set(s.get("speaker", "") for s in segments))
        logger.info("ONNX diarization complete: %d speakers across %d segments", unique, len(segments))
        return True

    except ImportError:
        logger.info("onnxruntime not available — using heuristic")
        return False
    except Exception as e:
        logger.warning("ONNX diarization failed: %s — falling back to heuristic", e)
        return False


def _assign_speakers_heuristic(job: dict):
    """Assign speaker labels to Whisper output that has no diarization.

    Uses timing gaps, known speaker count, and content patterns to determine
    when speaker changes occur. Then assigns labels from the job's known speakers.

    This is not perfect — but it's dramatically better than blank labels.
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return

    segments = transcript["segments"]

    # Skip if segments already have real speaker labels
    has_speakers = any(s.get("speaker", "").strip() for s in segments)
    if has_speakers:
        return

    known_speakers = job.get("speakers", [])
    # Build speaker rotation — court proceedings alternate predictably
    speaker_labels = []
    for ks in known_speakers:
        name = ks.get("name", "")
        if name:
            speaker_labels.append(name)

    if not speaker_labels:
        # Default: Judge + 2 attorneys
        speaker_labels = ["Speaker 1", "Speaker 2", "Speaker 3"]

    # Heuristic speaker change detection:
    # 1. Gap > 1.5 seconds between segments = likely speaker change
    # 2. Segment starts with Q./A. = known alternation
    # 3. Short segment after a long one = likely a response
    # 4. Content cues: "Your Honor", "Objection", "Sustained", "Overruled"

    current_speaker_idx = 0  # Start with first speaker (usually judge)
    prev_end = 0

    # Court content cues for speaker assignment
    judge_cues = {"sustained", "overruled", "you may proceed", "call your",
                  "the court will", "court is", "this is case",
                  "let the record", "so ordered", "motion is", "please be seated",
                  "we're here on", "case number", "calling case"}
    # Cues that indicate this is NOT the judge (responding to judge)
    attorney_cues = {"your honor", "morning, your honor", "yes, judge", "no, judge",
                     "appearing for", "on behalf of", "for the state", "for the defense",
                     "bar number", "my bar number"}
    qa_q_cues = {"did you", "were you", "can you", "would you", "is it",
                 "what happened", "please tell", "describe", "explain"}

    for i, seg in enumerate(segments):
        text = seg.get("text", "").strip().lower()
        start = seg.get("start", 0)
        gap = (start - prev_end) / 1000 if prev_end else 0  # gap in seconds

        # Determine if speaker changed
        changed = False

        if i == 0:
            # First segment — assign to judge/first speaker
            current_speaker_idx = 0
            changed = True
        elif gap > 1.5:
            # Significant pause — likely speaker change
            changed = True
        elif text.startswith("q.") or text.startswith("q "):
            # Questioning attorney
            changed = True
            # Find a non-judge, non-witness speaker
            for j, label in enumerate(speaker_labels):
                if "court" not in label.lower() and "witness" not in label.lower():
                    current_speaker_idx = j
                    break
        elif text.startswith("a.") or text.startswith("a "):
            # Witness answering
            changed = True
            # Find or create witness label
            for j, label in enumerate(speaker_labels):
                if "witness" in label.lower():
                    current_speaker_idx = j
                    break
            else:
                if len(speaker_labels) < 6:
                    speaker_labels.append("The Witness")
                    current_speaker_idx = len(speaker_labels) - 1

        # Content-based speaker detection
        if changed:
            if any(cue in text for cue in attorney_cues):
                # This is an attorney/non-judge (responding to or addressing the judge)
                # Find the next non-judge speaker
                for j, label in enumerate(speaker_labels):
                    if "court" not in label.lower() and "judge" not in label.lower() and "witness" not in label.lower():
                        # Try to match by last name if the text mentions a known speaker
                        for k, lbl in enumerate(speaker_labels):
                            last = lbl.split()[-1].lower() if lbl.split() else ""
                            if last and len(last) > 2 and last in text:
                                current_speaker_idx = k
                                break
                        else:
                            current_speaker_idx = j
                        break
            elif any(cue in text for cue in judge_cues):
                # This is the judge
                for j, label in enumerate(speaker_labels):
                    if "court" in label.lower() or "judge" in label.lower():
                        current_speaker_idx = j
                        break
            elif not text.startswith("q.") and not text.startswith("a."):
                # Generic speaker change — rotate to next non-current speaker
                if gap > 1.5:
                    current_speaker_idx = (current_speaker_idx + 1) % len(speaker_labels)

        # Assign
        if current_speaker_idx < len(speaker_labels):
            seg["speaker"] = speaker_labels[current_speaker_idx]
        else:
            seg["speaker"] = f"Speaker {current_speaker_idx + 1}"

        prev_end = seg.get("end", start)

    # Mark as heuristically assigned
    transcript["diarization"] = "heuristic"
    assigned = len(set(s.get("speaker", "") for s in segments))
    logger.info("Heuristic diarization: assigned %d unique speakers across %d segments",
                assigned, len(segments))


def _identify_speakers_from_appearances(job: dict):
    """Auto-identify speakers from court appearance announcements.

    At the start of every court proceeding, participants state their names
    for the record. This function scans the first portion of the transcript
    for these announcements and maps AssemblyAI's generic speaker labels
    (Speaker A, Speaker B) to real names.

    Patterns detected:
      - "John Smith appearing for the plaintiff/defendant/state"
      - "John Smith on behalf of the plaintiff/defendant"
      - "John Smith for the state/defense/plaintiff"
      - "Judge Smith presiding"
      - "The Court: ..." (judge speaking first)
      - Name + "appearing" or "present"
    """
    import re

    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return

    segments = transcript["segments"]
    speaker_map = {}  # Speaker A -> "MR. SMITH"
    identified = 0

    # Pre-seed speaker map from job's known speakers (extracted from documents)
    known_speakers = job.get("speakers", [])
    if known_speakers:
        # Build a lookup of names we already know about
        _known_names = []
        for ks in known_speakers:
            name = ks.get("name", "")
            rep = ks.get("representing", "")
            if name and "court" not in name.lower():  # Skip "The Court (Judge X)"
                _known_names.append({
                    "name": name,
                    "last_name": name.split()[-1].lower() if name.split() else "",
                    "representing": rep,
                })

        # Scan transcript for mentions of known speakers' last names
        # and map the generic speaker label to the real name
        for i, seg in enumerate(segments[:100]):
            text_lower = seg.get("text", "").lower()
            speaker = seg.get("speaker", "")
            if not speaker or speaker in speaker_map:
                continue
            for kn in _known_names:
                if kn["last_name"] and kn["last_name"] in text_lower:
                    last = kn["name"].split()[-1].upper()
                    first = kn["name"].split()[0].lower() if kn["name"].split() else ""
                    prefix = "MS." if first.endswith(('a','ie','ey','ah','na','ne','ia')) else "MR."
                    rep = kn["representing"]
                    if rep:
                        designation = f"{prefix} {last} ({rep})"
                    else:
                        designation = f"{prefix} {last}"
                    speaker_map[speaker] = designation
                    identified += 1
                    logger.info("Speaker pre-matched from documents: %s → %s (found '%s' in text)",
                                speaker, designation, kn["last_name"])
                    break

        # Also assign the judge from known speakers
        for ks in known_speakers:
            name = ks.get("name", "")
            if "court" in name.lower() or "judge" in name.lower():
                # Find the first/second speaker (usually the judge)
                for i, seg in enumerate(segments[:10]):
                    speaker = seg.get("speaker", "")
                    if speaker and speaker not in speaker_map:
                        speaker_map[speaker] = name
                        identified += 1
                        logger.info("Judge pre-matched from documents: %s → %s", speaker, name)
                        break
                break

    # Appearance patterns — order matters, most specific first
    patterns = [
        # "Jane Doe appearing on behalf of the defendant"
        re.compile(
            r"(?:my name is |this is |i'm |i am )?([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)"
            r"\s*,?\s*(?:appearing|here)\s+(?:on behalf of|for)\s+(?:the\s+)?"
            r"(plaintiff|defendant|state|defense|prosecution|people|respondent|petitioner|appellee|appellant)",
            re.IGNORECASE),
        # "Jane Doe for the state/defendant"
        re.compile(
            r"([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)\s+for\s+(?:the\s+)?"
            r"(plaintiff|defendant|state|defense|prosecution|people|respondent|petitioner)",
            re.IGNORECASE),
        # "Jane Doe, defense/state/counsel" (shorthand announcement)
        re.compile(
            r"([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)\s*,\s*"
            r"(defense|state|prosecution|plaintiff|defendant|counsel for the \w+)",
            re.IGNORECASE),
        # "Jane Doe representing the defendant/Mr. Grant"
        re.compile(
            r"([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)\s+representing\s+(?:the\s+)?"
            r"(plaintiff|defendant|state|defense|mr\.\s+\w+|ms\.\s+\w+)",
            re.IGNORECASE),
        # "deputy district attorney Jane Doe" / "public defender Jane Doe"
        re.compile(
            r"(?:deputy\s+)?(?:district attorney|public defender|defense (?:attorney|counsel))\s+"
            r"([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)",
            re.IGNORECASE),
        # "Judge Smith presiding"
        re.compile(
            r"(?:Judge|Justice|Honorable|Hon\.?)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)"
            r"\s*(?:presiding|on the bench)?",
            re.IGNORECASE),
        # "Jane Doe appearing" (no party specified)
        re.compile(
            r"([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)\s*,?\s*(?:appearing|present|here)",
            re.IGNORECASE),
    ]

    # Judge patterns — the court is usually the first or second speaker
    judge_patterns = [
        re.compile(r"\b(?:Judge|Justice|Honorable|Hon\.?)\s+(\w+(?:\s+\w+)?)", re.IGNORECASE),
        re.compile(r"\b(?:the court|court)\b", re.IGNORECASE),
        re.compile(r"\bgood morning\b.*\bcall(?:ing)?\b.*\bcase\b", re.IGNORECASE),
    ]

    # Scan first ~80 segments (covers appearances + early proceeding)
    scan_limit = min(80, len(segments))

    for i in range(scan_limit):
        seg = segments[i]
        text = seg.get("text", "")
        speaker = seg.get("speaker", "")

        if not text:
            continue
        if not speaker:
            speaker = f"_unknown_{i}"  # Temp label for blank speakers

        # Check appearance patterns
        for p_idx, pattern in enumerate(patterns):
            match = pattern.search(text)
            if match:
                name = match.group(1).strip()

                if p_idx == 2:
                    # Judge pattern
                    designation = f"THE COURT (Judge {name})"
                elif p_idx <= 1 and match.lastindex >= 2:
                    # Has party info
                    party = match.group(2).strip().upper()
                    # Format as court convention
                    if party in ("STATE", "PROSECUTION", "PEOPLE"):
                        designation = f"MR. {name.split()[-1].upper()} (State)"
                    elif party == "DEFENDANT" or party == "DEFENSE":
                        designation = f"MR. {name.split()[-1].upper()} (Defense)"
                    elif party == "PLAINTIFF":
                        designation = f"MR. {name.split()[-1].upper()} (Plaintiff)"
                    else:
                        designation = f"MR. {name.split()[-1].upper()} ({party.title()})"

                    # Use Ms. if name sounds feminine (imperfect but common convention)
                    # Reporter can always fix this
                    first = name.split()[0].lower()
                    if first.endswith(('a', 'ie', 'ey', 'ah', 'na', 'ne', 'ia')):
                        designation = designation.replace("MR.", "MS.")
                else:
                    designation = name.upper()

                speaker_map[speaker] = designation
                identified += 1
                logger.info("Speaker identified: %s → %s (from: '%s')",
                            speaker, designation, text[:80])
                break

        # Check if this is the judge (first speaker calling the case)
        if i < 5 and speaker not in speaker_map:
            for jp in judge_patterns:
                if jp.search(text):
                    jmatch = judge_patterns[0].search(text)
                    if jmatch:
                        speaker_map[speaker] = f"THE COURT (Judge {jmatch.group(1)})"
                    else:
                        speaker_map[speaker] = "THE COURT"
                    identified += 1
                    logger.info("Judge identified: %s → %s", speaker, speaker_map[speaker])
                    break

    # Apply the mapping to ALL segments
    if speaker_map:
        renamed = 0
        for seg in segments:
            speaker = seg.get("speaker", "")
            if speaker in speaker_map:
                seg["speaker"] = speaker_map[speaker]
                renamed += 1

        transcript["speaker_map"] = speaker_map
        transcript["speakers_identified"] = identified
        logger.info("Speaker identification: %d speakers identified, %d segments renamed",
                    identified, renamed)


def _run_transcription_whisper(job: dict):
    """Transcribe using local Whisper — no cloud, no API key, no cost."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        job["status"] = "error"
        job["error"] = "faster-whisper not installed. Run: pip install faster-whisper"
        return

    job["progress"] = 5
    job["progress_message"] = "Preparing audio..."

    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"

    # Convert .trm files
    _convert_trm_files(job, audio_dir)

    # Convert non-WAV formats
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
    for media_file in sorted(audio_dir.glob("*")):
        if media_file.suffix.lower() in (".webm", ".mp4", ".m4a", ".aac", ".flac", ".javs"):
            wav_out = media_file.with_suffix(".wav")
            if not wav_out.exists():
                try:
                    subprocess.run([ffmpeg_bin, "-y", "-i", str(media_file),
                                   "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                                   str(wav_out)], capture_output=True, text=True, timeout=600)
                except Exception:
                    pass

    audio_files = sorted(audio_dir.glob("*.wav")) + sorted(audio_dir.glob("*.mp3"))

    if not audio_files:
        job["status"] = "error"
        job["error"] = "No audio files found"
        return

    # Concatenate multiple files if needed (preserve channels for multi-channel WAV)
    if len(audio_files) > 1 and len(job.get("speakers", [])) <= 1:
        concat_path = audio_dir / "full_session.wav"
        try:
            ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
            concat_list = audio_dir / "_concat.txt"
            with open(concat_list, "w") as f:
                for af in audio_files:
                    f.write(f"file '{af.as_posix()}'\n")
            r = subprocess.run([ffmpeg_bin, "-y", "-f", "concat", "-safe", "0",
                               "-i", str(concat_list), "-acodec", "pcm_s16le",
                               "-ar", "16000", str(concat_path)],
                              capture_output=True, text=True, timeout=1800)
            if r.returncode == 0:
                audio_files = [concat_path]
            concat_list.unlink(missing_ok=True)
        except Exception as e:
            logger.warning("Concat failed: %s", e)

    # Detect multi-channel audio — channels = speakers (e.g. FTR Manager export)
    _multichannel = 0
    if len(audio_files) == 1 and audio_files[0].suffix.lower() == ".wav":
        try:
            import wave
            with wave.open(str(audio_files[0]), "rb") as wf:
                _multichannel = wf.getnchannels()
            if _multichannel > 1:
                logger.info("Multi-channel WAV detected (Whisper path): %d channels", _multichannel)
                job["audio_channels"] = _multichannel
                job["progress_message"] = f"Multi-channel audio detected ({_multichannel} channels)"
                _save_job(job)
                # Route to per-channel transcription
                _transcribe_trm_multichannel(job, audio_files[0], _multichannel)
                return
        except Exception as e:
            logger.warning("Channel detection failed in Whisper path: %s", e)

    # Load Whisper model
    job["progress"] = 15
    model_size = SETTINGS.get("whisper_model", "small.en")
    job["progress_message"] = f"Loading Whisper {model_size}..."

    # Ensure VAD model is findable — PyInstaller may bundle it in _internal
    # but faster-whisper looks for it relative to its package directory
    try:
        import faster_whisper as _fw
        _fw_assets = Path(_fw.__file__).parent / "assets"
        _vad_file = _fw_assets / "silero_vad_v6.onnx"
        if not _vad_file.exists():
            # Search common locations
            for search in [
                BASE_DIR / "_internal" / "faster_whisper" / "assets" / "silero_vad_v6.onnx",
                BASE_DIR / "faster_whisper" / "assets" / "silero_vad_v6.onnx",
            ]:
                if search.exists():
                    _fw_assets.mkdir(parents=True, exist_ok=True)
                    import shutil as _sh
                    _sh.copy2(str(search), str(_vad_file))
                    logger.info("Copied VAD model to %s", _vad_file)
                    break
    except Exception:
        pass

    try:
        model = WhisperModel(model_size, device="cuda", compute_type="float16")
        device = "cuda"
    except Exception as cuda_err:
        logger.info("CUDA not available (%s) — using CPU for Whisper", str(cuda_err)[:60])
        try:
            model = WhisperModel(model_size, device="cpu", compute_type="int8")
            device = "cpu"
        except Exception as e:
            job["status"] = "error"
            job["error"] = f"Whisper transcription failed: {e}"
            _save_job(job)
            return

    job["progress"] = 25
    job["progress_message"] = "Transcribing with Whisper..."

    # Transcribe — retry on CPU if CUDA libs missing at inference time
    wav_path = str(audio_files[0])
    try:
        try:
            segments_iter, info = model.transcribe(
                wav_path, language="en", beam_size=5,
                word_timestamps=True, vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=200),
            )
        except Exception as cuda_lib_err:
            if "cublas" in str(cuda_lib_err).lower() or "cuda" in str(cuda_lib_err).lower() or "not found" in str(cuda_lib_err).lower():
                logger.info("CUDA library error during transcription — reloading on CPU")
                from faster_whisper import WhisperModel
                model = WhisperModel(model_size, device="cpu", compute_type="int8")
                device = "cpu"
                segments_iter, info = model.transcribe(
                    wav_path, language="en", beam_size=5,
                    word_timestamps=True, vad_filter=True,
                    vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=200),
                )
            else:
                raise

        segments = []
        for seg in segments_iter:
            seg_data = {
                "start": round(seg.start * 1000),  # Convert to ms for consistency
                "end": round(seg.end * 1000),
                "text": seg.text.strip(),
                "avg_logprob": round(seg.avg_logprob, 4),
                "no_speech_prob": round(seg.no_speech_prob, 4),
                "speaker": "",
            }
            if seg.words:
                seg_data["words"] = [
                    {"word": w.word, "start": round(w.start * 1000),
                     "end": round(w.end * 1000),
                     "confidence": round(w.probability, 3)}
                    for w in seg.words
                ]
                seg_data["confidence"] = round(
                    sum(w.probability for w in seg.words) / len(seg.words), 3)
            segments.append(seg_data)

            # Update progress
            if info.duration > 0:
                pct = min(90, 25 + int(65 * seg.end / info.duration))
                job["progress"] = pct
                job["progress_message"] = f"Transcribing... {int(seg.end)}s / {int(info.duration)}s"

        job["transcript"] = {
            "segments": segments,
            "full_text": " ".join(s["text"] for s in segments),
            "duration": round(info.duration * 1000),
            "language": info.language,
            "engine": f"whisper-{model_size}",
            "device": device,
        }
        job["audio_file"] = Path(wav_path).name

    except Exception as e:
        job["status"] = "error"
        job["error"] = f"Whisper transcription failed: {e}"
        return

    # Speaker identification — fallback chain: pyannote → ONNX → heuristic
    job["progress_message"] = "Analyzing speakers..."
    _save_job(job)
    try:
        if not _diarize_with_pyannote(job):
            if not _diarize_audio(job):
                _assign_speakers_heuristic(job)
    except Exception as e:
        logger.warning("Diarization failed: %s", e)

    job["progress_message"] = "Identifying speakers from announcements..."
    _save_job(job)
    try:
        _identify_speakers_from_appearances(job)
    except Exception as e:
        logger.warning("Appearance scan failed: %s", e)

    try:
        _apply_channel_speaker_mapping(job)
    except Exception as e:
        logger.warning("Channel mapping failed: %s", e)

    try:
        _cleanup_speaker_names(job)
    except Exception as e:
        logger.warning("Name cleanup failed: %s", e)

    # Save transcript
    if job.get("transcript"):
        with open(job_dir / "transcript.json", "w", encoding="utf-8") as f:
            json.dump(job["transcript"], f, indent=2)

    # Auto-flag and proofing
    _auto_flag_issues(job)
    _auto_detect_styles(job)
    _apply_proofing_rules(job)

    job["status"] = "complete"
    _feed_word_live_on_complete(job)
    job["progress"] = 100
    job["progress_message"] = "Complete"
    _save_job(job)
    logger.info("Job %s complete (Whisper): %d segments",
                job["id"], len(job.get("transcript", {}).get("segments", [])))


# ---------------------------------------------------------------------------
# Deepgram Engine
# ---------------------------------------------------------------------------

def _run_transcription_deepgram(job: dict):
    """Transcribe using Deepgram API — fast, accurate, good diarization."""
    api_key = SETTINGS.get("api_key", "")
    if not api_key:
        logger.info("No Deepgram API key, falling back to Whisper")
        return _run_transcription_whisper(job)

    job["progress"] = 5
    job["progress_message"] = "Preparing audio for Deepgram..."

    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    _convert_trm_files(job, audio_dir)

    wav_files = sorted(audio_dir.glob("*.wav")) + sorted(audio_dir.glob("*.mp3")) + \
                sorted(audio_dir.glob("*.m4a")) + sorted(audio_dir.glob("*.webm"))
    if not wav_files:
        job["status"] = "error"
        job["error"] = "No audio files found"
        _save_job(job)
        return

    all_segments = []
    for fi, audio_file in enumerate(wav_files):
        job["progress"] = 10 + int(fi / len(wav_files) * 70)
        job["progress_message"] = f"Transcribing with Deepgram ({fi+1}/{len(wav_files)})..."
        _save_job(job)

        try:
            import httpx

            with open(audio_file, "rb") as f:
                audio_data = f.read()

            # Determine mimetype
            suffix = audio_file.suffix.lower()
            mimetype = {
                ".wav": "audio/wav", ".mp3": "audio/mp3",
                ".m4a": "audio/mp4", ".webm": "audio/webm",
                ".flac": "audio/flac",
            }.get(suffix, "audio/wav")

            response = httpx.post(
                "https://api.deepgram.com/v1/listen",
                headers={
                    "Authorization": f"Token {api_key}",
                    "Content-Type": mimetype,
                },
                params={
                    "model": "nova-3",
                    "smart_format": "true",
                    "diarize": "true",
                    "punctuate": "true",
                    "utterances": "true",
                    "language": "en",
                },
                content=audio_data,
                timeout=300,
            )
            response.raise_for_status()
            result = response.json()

            # Parse utterances (with speaker labels and timestamps)
            for utt in result.get("results", {}).get("utterances", []):
                words = []
                for w in utt.get("words", []):
                    words.append({
                        "word": w.get("punctuated_word", w.get("word", "")),
                        "start": int(w["start"] * 1000),
                        "end": int(w["end"] * 1000),
                        "confidence": round(w.get("confidence", 0), 3),
                    })

                all_segments.append({
                    "text": utt.get("transcript", ""),
                    "speaker": f"Speaker {utt.get('speaker', '?')}",
                    "start": int(utt["start"] * 1000),
                    "end": int(utt["end"] * 1000),
                    "confidence": round(utt.get("confidence", 0), 3),
                    "words": words,
                })

        except Exception as e:
            logger.error("Deepgram transcription error: %s", e)
            job["progress_message"] = f"Deepgram error: {e} — falling back to Whisper"
            _save_job(job)
            return _run_transcription_whisper(job)

    if not all_segments:
        job["status"] = "error"
        job["error"] = "Deepgram returned no results"
        _save_job(job)
        return

    job["transcript"] = {
        "segments": all_segments,
        "full_text": " ".join(s["text"] for s in all_segments),
        "duration": max((s["end"] for s in all_segments), default=0),
        "engine": "deepgram",
    }
    job["audio_file"] = wav_files[0].name if wav_files else ""
    job["progress"] = 90
    job["progress_message"] = "Finalizing..."
    _save_job(job)

    logger.info("Job %s complete (Deepgram): %d segments",
                job["id"], len(all_segments))


# ---------------------------------------------------------------------------
# Rev.ai Engine
# ---------------------------------------------------------------------------

def _run_transcription_rev(job: dict):
    """Transcribe using Rev.ai API — built for legal and media transcription."""
    api_key = SETTINGS.get("api_key", "")
    if not api_key:
        logger.info("No Rev.ai API key, falling back to Whisper")
        return _run_transcription_whisper(job)

    job["progress"] = 5
    job["progress_message"] = "Preparing audio for Rev.ai..."

    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    _convert_trm_files(job, audio_dir)

    wav_files = sorted(audio_dir.glob("*.wav")) + sorted(audio_dir.glob("*.mp3")) + \
                sorted(audio_dir.glob("*.m4a")) + sorted(audio_dir.glob("*.webm"))
    if not wav_files:
        job["status"] = "error"
        job["error"] = "No audio files found"
        _save_job(job)
        return

    all_segments = []
    for fi, audio_file in enumerate(wav_files):
        job["progress"] = 10 + int(fi / len(wav_files) * 70)
        job["progress_message"] = f"Transcribing with Rev.ai ({fi+1}/{len(wav_files)})..."
        _save_job(job)

        try:
            import httpx

            # Submit job
            with open(audio_file, "rb") as f:
                submit_resp = httpx.post(
                    "https://api.rev.ai/speechtotext/v1/jobs",
                    headers={"Authorization": f"Bearer {api_key}"},
                    files={"media": (audio_file.name, f)},
                    data={
                        "options": json.dumps({
                            "skip_diarization": False,
                            "skip_punctuation": False,
                            "language": "en",
                        })
                    },
                    timeout=60,
                )
                submit_resp.raise_for_status()
                rev_job = submit_resp.json()
                rev_job_id = rev_job["id"]

            # Poll for completion
            import time as _time
            for _ in range(120):  # Up to 10 minutes
                _time.sleep(5)
                status_resp = httpx.get(
                    f"https://api.rev.ai/speechtotext/v1/jobs/{rev_job_id}",
                    headers={"Authorization": f"Bearer {api_key}"},
                    timeout=30,
                )
                status_data = status_resp.json()
                if status_data["status"] == "transcribed":
                    break
                elif status_data["status"] == "failed":
                    raise RuntimeError(f"Rev.ai job failed: {status_data.get('failure_detail', 'unknown')}")

            # Fetch transcript
            transcript_resp = httpx.get(
                f"https://api.rev.ai/speechtotext/v1/jobs/{rev_job_id}/transcript",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Accept": "application/vnd.rev.transcript.v1.0+json",
                },
                timeout=60,
            )
            transcript_resp.raise_for_status()
            rev_transcript = transcript_resp.json()

            # Parse monologues into segments
            for mono in rev_transcript.get("monologues", []):
                speaker_id = mono.get("speaker", 0)
                elements = mono.get("elements", [])

                # Build segment text from elements
                seg_text = ""
                seg_words = []
                seg_start = None
                seg_end = None

                for elem in elements:
                    if elem["type"] == "text":
                        word = elem["value"]
                        seg_text += word
                        ts = int(elem.get("ts", 0) * 1000)
                        end_ts = int(elem.get("end_ts", 0) * 1000)
                        if seg_start is None:
                            seg_start = ts
                        seg_end = end_ts
                        seg_words.append({
                            "word": word,
                            "start": ts,
                            "end": end_ts,
                            "confidence": round(elem.get("confidence", 0), 3),
                        })
                    elif elem["type"] == "punct":
                        seg_text += elem["value"]

                if seg_text.strip():
                    all_segments.append({
                        "text": seg_text.strip(),
                        "speaker": f"Speaker {speaker_id}",
                        "start": seg_start or 0,
                        "end": seg_end or 0,
                        "confidence": round(
                            sum(w["confidence"] for w in seg_words) / len(seg_words), 3
                        ) if seg_words else 0.0,
                        "words": seg_words,
                    })

        except Exception as e:
            logger.error("Rev.ai transcription error: %s", e)
            job["progress_message"] = f"Rev.ai error: {e} — falling back to Whisper"
            _save_job(job)
            return _run_transcription_whisper(job)

    if not all_segments:
        job["status"] = "error"
        job["error"] = "Rev.ai returned no results"
        _save_job(job)
        return

    # Sort by timestamp (monologues may not be in order)
    all_segments.sort(key=lambda s: s["start"])

    job["transcript"] = {
        "segments": all_segments,
        "full_text": " ".join(s["text"] for s in all_segments),
        "duration": max((s["end"] for s in all_segments), default=0),
        "engine": "rev",
    }
    job["audio_file"] = wav_files[0].name if wav_files else ""
    job["progress"] = 90
    job["progress_message"] = "Finalizing..."
    _save_job(job)

    logger.info("Job %s complete (Rev.ai): %d segments",
                job["id"], len(all_segments))


def _convert_trm_files(job, audio_dir):
    """Attempt .trm to WAV conversion. FTR is proprietary — may fail. Shared by both engines."""
    trm_files = sorted(audio_dir.glob("*.trm")) + sorted(audio_dir.glob("*.TRM"))
    if not trm_files:
        return
    job["progress_message"] = f"Attempting to convert {len(trm_files)} FTR .trm file(s)..."
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"
    converted = 0
    for trm in trm_files:
        wav_out = trm.with_suffix(".wav")
        try:
            r = subprocess.run([ffmpeg_bin, "-y", "-i", str(trm),
                               "-acodec", "pcm_s16le", "-ar", "16000",
                               str(wav_out)],
                              capture_output=True, text=True, timeout=600)
            if r.returncode == 0 and wav_out.exists() and wav_out.stat().st_size > 1000:
                logger.info("Converted %s -> %s", trm.name, wav_out.name)
                converted += 1
        except Exception as e:
            logger.warning("TRM conversion error: %s", e)
    if converted == 0 and trm_files:
        job["status"] = "error"
        job["error"] = (
            f"Could not convert {len(trm_files)} FTR .trm file(s). "
            "The FTR format is proprietary and may not be supported. "
            "Please export from FTR Manager as WAV, then upload the WAV.")
        _save_job(job)


def _cleanup_speaker_names(job: dict):
    """Post-process speaker labels — map ASR-garbled names to known speakers.

    Strategy:
    1. Known speakers from documents have roles (Judge, Plaintiff/State, Defense)
    2. ASR-generated labels are garbled versions of real names
    3. Map by pattern: most frequent speaker = judge, speakers who say "Your Honor" = attorneys
    4. Clean up garbage names (common words promoted to labels)
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return

    segments = transcript["segments"]
    known_speakers = job.get("speakers", [])
    if not known_speakers:
        return  # Nothing to map to

    from collections import Counter

    # Count speaker label usage
    label_counts = Counter(s.get("speaker", "") for s in segments)

    # Build known speaker lookup by role
    judge_name = None
    attorney_names = []
    for ks in known_speakers:
        name = ks.get("name", "")
        rep = ks.get("representing", "").lower()
        if "court" in name.lower() or "judge" in name.lower() or "court" in rep:
            judge_name = name
        elif name:
            attorney_names.append(name)

    # Analyze each ASR label — determine its role from content
    label_roles = {}  # label -> "judge" | "attorney" | "unknown"
    for label in label_counts:
        if not label:
            continue
        # Check what this speaker says
        label_segs = [s for s in segments if s.get("speaker") == label]
        combined_text = " ".join(s.get("text", "").lower() for s in label_segs[:20])

        judge_signals = sum(1 for cue in [
            "please be seated", "you may proceed", "sustained", "overruled",
            "so ordered", "the court will", "i'm going to", "motion is",
            "i am going to exercise", "calling case", "we're here on",
            "i see there was", "i'll allow", "court is"
        ] if cue in combined_text)

        attorney_signals = sum(1 for cue in [
            "your honor", "yes, judge", "no, judge", "bar number",
            "appearing for", "on behalf of", "for the state", "for the defense",
            "my client", "we anticipate", "we'll be ready"
        ] if cue in combined_text)

        if judge_signals > attorney_signals and judge_signals >= 2:
            label_roles[label] = "judge"
        elif attorney_signals > 0:
            label_roles[label] = "attorney"
        else:
            # Most frequent speaker in court is usually the judge
            if label == label_counts.most_common(1)[0][0]:
                label_roles[label] = "judge"
            else:
                label_roles[label] = "unknown"

    # Build the mapping: ASR label -> known speaker name
    rename_map = {}
    used_known = set()

    # Map judge first
    if judge_name:
        for label, role in label_roles.items():
            if role == "judge" and label != judge_name:
                rename_map[label] = judge_name
                used_known.add(judge_name)
                break

    # Map attorneys — by segment count (more segments = likely the more active attorney)
    attorney_labels = [(l, label_counts[l]) for l, r in label_roles.items()
                       if r == "attorney" and l not in rename_map]
    attorney_labels.sort(key=lambda x: -x[1])

    for label, count in attorney_labels:
        # Find best matching known attorney
        for atty in attorney_names:
            if atty not in used_known:
                rename_map[label] = atty
                used_known.add(atty)
                break

    # Map remaining unknown labels to remaining known speakers
    for label in label_counts:
        if label and label not in rename_map:
            # Check if it's already a known speaker name
            if any(label.lower() == ks.get("name", "").lower() for ks in known_speakers):
                continue
            # Check if it's garbage
            if label.lower() in {"not be", "okay", "all right", "so", "yes", "no", "well",
                                  "right", "um", "uh"}:
                # Map to most common real label
                real = [v for v in rename_map.values()]
                if real:
                    rename_map[label] = real[0]
                continue
            # Map to remaining known speakers
            for atty in attorney_names:
                if atty not in used_known:
                    rename_map[label] = atty
                    used_known.add(atty)
                    break

    # Apply the mapping
    if rename_map:
        renamed = 0
        for seg in segments:
            old = seg.get("speaker", "")
            if old in rename_map:
                seg["speaker"] = rename_map[old]
                renamed += 1

        logger.info("Speaker name cleanup: %d segments renamed. Map: %s",
                    renamed, {k: v for k, v in rename_map.items()})

    # (Garbage label cleanup handled inline above in the mapping loop)


def _apply_channel_speaker_mapping(job: dict):
    """Map channel assignments to transcript speaker labels."""
    channels = job.get("channels", [])
    if not channels or not job.get("transcript"):
        return
    ch_speakers = {}
    for ch in channels:
        idx = ch.get("index", 0)
        spk = ch.get("speakers", [])
        if spk:
            ch_speakers[idx] = spk
    if not ch_speakers:
        return
    for seg in job["transcript"].get("segments", []):
        ch_idx = seg.get("channel")
        if ch_idx is not None and ch_idx in ch_speakers:
            ch_spk = ch_speakers[ch_idx]
            if len(ch_spk) == 1:
                seg["speaker"] = ch_spk[0]
            elif len(ch_spk) > 1 and seg.get("speaker") not in ch_spk:
                seg["speaker"] = " / ".join(ch_spk)
                seg["speaker_ambiguous"] = True
                seg["possible_speakers"] = ch_spk


def _auto_flag_issues(job: dict):
    """Auto-flag segments with confidence below 90%, speaker issues, and context problems."""
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return

    segments = transcript["segments"]
    flags = job.setdefault("flags", [])
    flagged = 0

    for i, seg in enumerate(segments):
        text = seg.get("text", "")
        conf = seg.get("confidence", seg.get("avg_word_confidence", 1.0))
        speaker = seg.get("speaker", "")
        timestamp = seg.get("start", 0)

        # Flag low confidence (below 90%)
        if conf < 0.9 and conf > 0:
            severity = "low" if conf >= 0.7 else "medium" if conf >= 0.5 else "high"
            flags.append({
                "segment_index": i,
                "timestamp": timestamp,
                "text": text[:80],
                "type": f"confidence_{severity}",
                "detail": f"Word confidence: {conf:.0%}",
                "created_at": datetime.now().isoformat(),
                "auto": True,
            })
            seg["flagged"] = True
            flagged += 1

        # Flag missing or generic speaker labels
        if not speaker or speaker == "—":
            flags.append({
                "segment_index": i,
                "timestamp": timestamp,
                "text": text[:80],
                "type": "speaker_missing",
                "detail": "No speaker identified for this segment",
                "created_at": datetime.now().isoformat(),
                "auto": True,
            })
            seg["flagged"] = True
            flagged += 1
        elif speaker.startswith("Speaker ") or speaker.startswith("speaker_"):
            flags.append({
                "segment_index": i,
                "timestamp": timestamp,
                "text": text[:80],
                "type": "speaker_unresolved",
                "detail": f"Generic speaker label: {speaker} — needs manual assignment",
                "created_at": datetime.now().isoformat(),
                "auto": True,
            })
            seg["flagged"] = True
            flagged += 1

        # Flag ambiguous speaker (multiple possible on shared channel)
        if seg.get("speaker_ambiguous"):
            flags.append({
                "segment_index": i,
                "timestamp": timestamp,
                "text": text[:80],
                "type": "speaker_ambiguous",
                "detail": f"Multiple speakers possible: {', '.join(seg.get('possible_speakers', []))}",
                "created_at": datetime.now().isoformat(),
                "auto": True,
            })
            seg["flagged"] = True
            flagged += 1

        # Flag potential context issues
        import re as _re
        # Incomplete sentences (very short with no punctuation)
        if len(text.split()) <= 2 and not text.strip().endswith(('.', '?', '!')):
            flags.append({
                "segment_index": i,
                "timestamp": timestamp,
                "text": text,
                "type": "context_fragment",
                "detail": "Very short segment — possible fragment or cutoff",
                "created_at": datetime.now().isoformat(),
                "auto": True,
            })
            seg["flagged"] = True
            flagged += 1

        # Flag words that commonly indicate ASR confusion
        asr_artifacts = ['[inaudible]', '[music]', '[applause]', '[laughter]',
                        'um um um', 'uh uh uh', '...']
        for artifact in asr_artifacts:
            if artifact.lower() in text.lower():
                flags.append({
                    "segment_index": i,
                    "timestamp": timestamp,
                    "text": text[:80],
                    "type": "asr_artifact",
                    "detail": f"Possible ASR artifact: '{artifact}'",
                    "created_at": datetime.now().isoformat(),
                    "auto": True,
                })
                seg["flagged"] = True
                flagged += 1
                break

    transcript["auto_flags"] = flagged
    logger.info("Auto-flagging: %d issues flagged across %d segments", flagged, len(segments))


# ---------------------------------------------------------------------------
# Context Review — catches high-confidence ASR mistakes
# ---------------------------------------------------------------------------

# Common legal term mishears that ASR gets "confident" about
_LEGAL_CONFUSED_PAIRS = {
    "council": "counsel", "counsel": None,  # council is almost never right in court
    "statue": "statute", "statute": None,
    "president": "precedent", "precedent": None,
    "trail": "trial", "trial": None,
    "here say": "hearsay", "hearsay": None,
    "bare": "bear", "site": "cite", "sight": "cite",
    "waste": "waist",  # less common but happens
    "motion in limine": None,  # correct — don't flag
    "in limine": None,
    "probable cause": None,
    "corpus": None,
    "habeas": None,
    "voir dire": None,
    "amicus": None,
    "pro se": None,
    "sustained": None,
    "overruled": None,
}

# Words that almost never appear in court transcripts — likely ASR artifacts
_UNLIKELY_IN_COURT = {
    "subscribe", "notification", "like and subscribe", "click below",
    "welcome back", "hey guys", "what's up",
}


def _context_review(job: dict):
    """Semantic context review — catches mistakes ASR is confident about.

    Two passes:
    1. Rule-based: known legal term confusions, proper noun inconsistency,
       unlikely words in court context
    2. LLM-based (if available): reads chunks of transcript and flags
       contextually suspicious words
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return

    segments = transcript["segments"]
    flags = job.setdefault("flags", [])
    context_flags = 0

    # --- Pass 1: Rule-based context checks ---

    # 1a. Known legal term confusions
    for i, seg in enumerate(segments):
        text = seg.get("text", "")
        text_lower = text.lower()

        for confused, correct in _LEGAL_CONFUSED_PAIRS.items():
            if correct is None:
                continue  # This is the correct form, skip
            if confused in text_lower and correct not in text_lower:
                flags.append({
                    "segment_index": i,
                    "timestamp": seg.get("start", 0),
                    "text": text[:80],
                    "type": "context_legal_term",
                    "detail": f'"{confused}" — did you mean "{correct}"?',
                    "created_at": datetime.now().isoformat(),
                    "auto": True,
                })
                seg["flagged"] = True
                context_flags += 1

        # 1b. Unlikely words in court context
        for unlikely in _UNLIKELY_IN_COURT:
            if unlikely in text_lower:
                flags.append({
                    "segment_index": i,
                    "timestamp": seg.get("start", 0),
                    "text": text[:80],
                    "type": "context_unlikely_word",
                    "detail": f'"{unlikely}" is unusual in a court transcript — verify',
                    "created_at": datetime.now().isoformat(),
                    "auto": True,
                })
                seg["flagged"] = True
                context_flags += 1
                break

    # 1c. Proper noun consistency — names that appear multiple ways
    name_variants = {}
    for i, seg in enumerate(segments):
        speaker = seg.get("speaker", "")
        if speaker and speaker not in ("—", ""):
            # Normalize and track
            key = speaker.upper().strip()
            name_variants.setdefault(key, []).append(i)

    # Check transcript text for names that appear as speakers
    all_text = " ".join(s.get("text", "") for s in segments)
    for speaker_name in name_variants:
        if len(speaker_name.split()) < 2:
            continue  # Skip single-word labels like "THE COURT"
        # Look for similar but different spellings in the text
        parts = speaker_name.split()
        last_name = parts[-1]
        if len(last_name) < 4:
            continue
        # Find near-misses: same first 3 chars but different ending
        import re as _re
        pattern = _re.escape(last_name[:3]) + r"[a-z]+"
        matches = set(_re.findall(pattern, all_text, _re.IGNORECASE))
        for match in matches:
            if match.upper() != last_name and len(match) >= 4:
                # Potential misspelling
                for i, seg in enumerate(segments):
                    if match.lower() in seg.get("text", "").lower():
                        flags.append({
                            "segment_index": i,
                            "timestamp": seg.get("start", 0),
                            "text": seg.get("text", "")[:80],
                            "type": "context_name_variant",
                            "detail": f'"{match}" may be a misspelling of "{last_name}" (speaker: {speaker_name})',
                            "created_at": datetime.now().isoformat(),
                            "auto": True,
                        })
                        seg["flagged"] = True
                        context_flags += 1
                        break  # One flag per variant is enough

    # --- Pass 2: LLM context review (chunks of 20 segments) ---
    if len(segments) >= 5:
        try:
            _llm_context_review(job, segments, flags)
        except Exception as e:
            logger.warning("LLM context review failed: %s", e)

    logger.info("Context review: %d issues flagged", context_flags)


def _llm_context_review(job: dict, segments: list, flags: list):
    """Use a local LLM to review transcript chunks for contextual errors.

    Sends chunks of ~20 segments to the model and asks it to identify
    words that look wrong in context, even if ASR was confident.
    """
    import urllib.request

    CHUNK_SIZE = 20
    total_llm_flags = 0

    for chunk_start in range(0, len(segments), CHUNK_SIZE):
        chunk = segments[chunk_start:chunk_start + CHUNK_SIZE]

        # Build chunk text with segment numbers
        chunk_text = ""
        for j, seg in enumerate(chunk):
            idx = chunk_start + j
            speaker = seg.get("speaker", "—")
            text = seg.get("text", "")
            chunk_text += f"[{idx}] {speaker}: {text}\n"

        if len(chunk_text.strip()) < 50:
            continue

        prompt = (
            "You are a court transcript proofreader. Review this transcript excerpt "
            "and identify words or phrases that are likely ASR (speech recognition) errors — "
            "words that LOOK correct but DON'T FIT the legal context.\n\n"
            "Common ASR mistakes in court:\n"
            "- Legal terms: 'council' instead of 'counsel', 'statue' instead of 'statute'\n"
            "- Proper nouns: names misspelled or substituted with common words\n"
            "- Homophones: 'site/cite/sight', 'hear/here', 'their/there'\n"
            "- Hallucinated words: filler words the speaker didn't say\n"
            "- Context mismatches: a word that makes no sense in this sentence\n\n"
            "For each error found, respond with EXACTLY this format (one per line):\n"
            "FLAG [segment_number]: \"wrong word\" -> \"likely correct\" (reason)\n\n"
            "If nothing looks wrong, respond with: CLEAN\n\n"
            f"Transcript:\n{chunk_text}\n"
            "/no_think"
        )

        try:
            payload = json.dumps({
                "model": SETTINGS.get("whisper_model", "small.en").replace(".en", "").replace("small", "qwen3:14b").replace("base", "qwen3:14b").replace("tiny", "qwen3:14b").replace("medium", "qwen3:14b").replace("large-v3", "qwen3:14b") if "qwen" not in SETTINGS.get("whisper_model", "") else "qwen3:14b",
                "prompt": prompt,
                "stream": False,
                "options": {"num_predict": 500, "temperature": 0.1},
            }).encode("utf-8")

            # Try local Ollama
            req = urllib.request.Request(
                "http://localhost:11434/api/generate",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST")
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode("utf-8"))

            response = result.get("response", "")
            if "CLEAN" in response.upper():
                continue

            # Parse FLAG lines
            for line in response.strip().split("\n"):
                line = line.strip()
                if not line.upper().startswith("FLAG"):
                    continue
                try:
                    # Parse: FLAG [42]: "council" -> "counsel" (legal term)
                    import re as _re
                    m = _re.match(
                        r'FLAG\s*\[(\d+)\]:\s*["\'](.+?)["\']\s*->\s*["\'](.+?)["\']\s*\((.+?)\)',
                        line, _re.IGNORECASE)
                    if m:
                        seg_idx = int(m.group(1))
                        wrong = m.group(2)
                        correct = m.group(3)
                        reason = m.group(4)

                        if 0 <= seg_idx < len(segments):
                            seg = segments[seg_idx]
                            # Verify the word actually appears in the segment
                            if wrong.lower() in seg.get("text", "").lower():
                                flags.append({
                                    "segment_index": seg_idx,
                                    "timestamp": seg.get("start", 0),
                                    "text": seg.get("text", "")[:80],
                                    "type": "context_llm_review",
                                    "detail": f'"{wrong}" → "{correct}" ({reason})',
                                    "created_at": datetime.now().isoformat(),
                                    "auto": True,
                                    "suggestion": correct,
                                })
                                seg["flagged"] = True
                                total_llm_flags += 1
                except Exception:
                    continue

        except Exception:
            # Ollama not available or timed out — skip LLM review
            break

    if total_llm_flags:
        logger.info("LLM context review: %d additional flags", total_llm_flags)


def _auto_detect_styles(job: dict):
    """Auto-detect transcript formatting styles from content context.

    Analyzes each segment's text to determine whether it should be formatted as:
    - qa: Question and Answer (examination)
    - colloquy: Multi-party discussion (court proceedings, objections)
    - parenthetical: Stage directions, actions, notes

    Runs after transcription, before export. Does not require pre-assigned speaker roles.
    """
    transcript = job.get("transcript")
    if not transcript or not transcript.get("segments"):
        return

    segments = transcript["segments"]

    # Patterns for detection
    _QUESTION_STARTS = re.compile(
        r'^\s*(?:did|do|does|can|could|would|will|shall|should|may|might|'
        r'is|are|was|were|have|has|had|'
        r'who|what|when|where|why|how|'
        r'isn\'t|aren\'t|wasn\'t|weren\'t|don\'t|doesn\'t|didn\'t|'
        r'wouldn\'t|couldn\'t|shouldn\'t|haven\'t|hasn\'t|hadn\'t)\b',
        re.IGNORECASE
    )
    _QUESTION_END = re.compile(r'\?\s*$')
    _ANSWER_PATTERNS = re.compile(
        r'^\s*(?:yes|no|correct|that\'s correct|that is correct|'
        r'I do|I did|I don\'t|I didn\'t|I have|I was|I am|'
        r'it is|it was|it does|it did|'
        r'right|no sir|no ma\'am|yes sir|yes ma\'am|'
        r'approximately|about|around|I believe|I think|'
        r'that\'s right|absolutely|exactly)\b',
        re.IGNORECASE
    )
    _COLLOQUY_PATTERNS = re.compile(
        r'\b(?:objection|sustained|overruled|'
        r'let the record (?:reflect|show)|'
        r'move to (?:strike|admit)|'
        r'may it please the court|'
        r'your honor|the court (?:will|has|is)|'
        r'counsel (?:approach|may)|'
        r'at this time|for the record|'
        r'so (?:stipulated|ordered)|'
        r'note (?:my|the) objection|'
        r'continuing objection)\b',
        re.IGNORECASE
    )
    _PARENTHETICAL_PATTERNS = re.compile(
        r'^\s*\(.*\)\s*$|'
        r'\b(?:off the record|back on the record|'
        r'recess (?:taken|was taken)|'
        r'(?:the |a )?(?:witness|deponent|deposition) (?:was |is )?(?:excused|sworn|affirmed)|'
        r'(?:exhibit|document) (?:was |is )?(?:marked|admitted|identified|offered|received)|'
        r'(?:thereupon|whereupon)|'
        r'(?:proceedings? )?(?:concluded|adjourned|recessed)|'
        r'(?:end of|conclusion of) (?:proceedings?|deposition|examination))\b',
        re.IGNORECASE
    )

    # Track speaker alternation for Q&A detection
    prev_speaker = ""
    alternation_count = 0
    qa_active = False

    for i, seg in enumerate(segments):
        text = seg.get("text", "").strip()
        speaker = seg.get("speaker", "")

        if not text:
            continue

        # Check for parenthetical first (strongest signal)
        if _PARENTHETICAL_PATTERNS.search(text) or (text.startswith("(") and text.endswith(")")):
            seg["style"] = "parenthetical"
            continue

        # Check for colloquy (procedural language)
        if _COLLOQUY_PATTERNS.search(text):
            seg["style"] = "colloquy"
            qa_active = False
            continue

        # Check for questions
        is_question = bool(_QUESTION_END.search(text)) or bool(_QUESTION_STARTS.match(text))

        # Check for answers (short affirmative/negative responses)
        is_answer = bool(_ANSWER_PATTERNS.match(text))

        # Speaker alternation tracking
        if speaker and speaker != prev_speaker:
            alternation_count += 1
            prev_speaker = speaker
        else:
            alternation_count = 0

        # Q&A detection: question followed by answer, or sustained alternation
        if is_question:
            seg["style"] = "qa"
            seg["qa_role"] = "Q"
            qa_active = True
        elif qa_active and (is_answer or (alternation_count > 0 and speaker != prev_speaker)):
            seg["style"] = "qa"
            seg["qa_role"] = "A"
        elif qa_active and alternation_count == 0:
            # Same speaker continuing — still in Q&A
            seg["style"] = "qa"
            seg["qa_role"] = seg.get("qa_role", "A")
        else:
            # Default to colloquy
            seg["style"] = "colloquy"

        # Reset Q&A if we hit a long stretch without questions
        if i > 0 and not is_question:
            # Look back — if no questions in last 5 segments, exit Q&A mode
            recent_questions = sum(
                1 for j in range(max(0, i - 5), i)
                if segments[j].get("style") == "qa" and segments[j].get("qa_role") == "Q"
            )
            if recent_questions == 0:
                qa_active = False

    # Second pass: smooth out isolated style changes
    for i in range(1, len(segments) - 1):
        prev_style = segments[i - 1].get("style", "")
        curr_style = segments[i].get("style", "")
        next_style = segments[i + 1].get("style", "")
        # If this segment is different from both neighbors, adopt the neighbor style
        if curr_style != prev_style and curr_style != next_style and prev_style == next_style:
            segments[i]["style"] = prev_style
            if prev_style == "qa":
                segments[i]["qa_role"] = "A"  # Default to answer for smoothed segments

    logger.info("Style auto-detection: %d segments processed",
                len([s for s in segments if s.get("style")]))


def _apply_proofing_rules(job: dict):
    """Apply proofing rules — built-in universal rules first, then profile-specific."""
    import re

    if not job.get("transcript"):
        return

    # --- Built-in universal proofing (always runs) ---
    # These are standard court transcript corrections that apply regardless of jurisdiction.

    # Informal speech → formal written
    _universal_replacements = {
        "gonna": "going to",
        "gotta": "got to",
        "wanna": "want to",
        "kinda": "kind of",
        "sorta": "sort of",
        "coulda": "could have",
        "woulda": "would have",
        "shoulda": "should have",
        "oughta": "ought to",
        "outta": "out of",
        "lotsa": "lots of",
        "lemme": "let me",
        "gimme": "give me",
        "dunno": "don't know",
        "tryna": "trying to",
        "hafta": "have to",
        "y'all": "you all",
        "ain't": "is not",
        "'cause": "because",
        "cuz": "because",
        "'em": "them",
        "til": "until",
        "'til": "until",
        "gotcha": "got you",
    }

    # Default capitalizations — ONLY honorifics and titles that are ALWAYS capitalized
    # Court terms like "objection", "the witness", "the clerk" etc. are NOT auto-capitalized
    # in body text — they are only capitalized when used as speaker designations (handled
    # separately in _format_speaker_label_export). Capitalizing them in body text is a
    # court reporting error that creates more correction work than it saves.
    _default_capitalizations = {
        "your honor": "Your Honor",
        "mr.": "Mr.",
        "mrs.": "Mrs.",
        "ms.": "Ms.",
        "dr.": "Dr.",
        "esq.": "Esq.",
    }

    # Check profile for custom settings
    profile = job.get("profile", {})
    rules = profile.get("proofing_rules", {})

    # Use profile's custom capitalizations if provided, otherwise defaults
    _title_capitalizations = rules.get("capitalizations", _default_capitalizations)

    # Use profile's custom informal replacements if provided, otherwise defaults
    if rules.get("informal_replacements"):
        _universal_replacements = rules["informal_replacements"]

    # Profile can disable built-in rules entirely
    skip_informal = rules.get("skip_informal_replacements", False)
    skip_capitalization = rules.get("skip_capitalization", False)
    skip_punctuation = rules.get("skip_punctuation_fixes", False)

    for seg in job["transcript"].get("segments", []):
        text = seg.get("text", "")

        # Apply informal → formal replacements
        if not skip_informal:
            for find, replace in _universal_replacements.items():
                text = re.sub(r'\b' + re.escape(find) + r'\b', replace, text, flags=re.IGNORECASE)

        # Apply title/legal term capitalization
        if not skip_capitalization:
            for find, replace in _title_capitalizations.items():
                text = re.sub(r'\b' + re.escape(find) + r'\b', replace, text, flags=re.IGNORECASE)

        # Punctuation and spacing fixes
        if not skip_punctuation:
            # Ensure space after terminal punctuation
            text = re.sub(r'([.?!])([A-Z])', r'\1 \2', text)
            # Ensure space after commas
            text = re.sub(r',([A-Za-z])', r', \1', text)
            # Fix double spaces
            text = re.sub(r'  +', ' ', text)
            # Ensure sentences end with punctuation
            stripped = text.rstrip()
            if (len(stripped.split()) >= 3 and
                    stripped and stripped[-1] not in '.?!,;:—-"\''):
                text = stripped + '.'
            # Fix spacing artifacts
            text = text.replace(" ,", ",")
            text = text.replace(" .", ".")
            text = text.replace(" ?", "?")
            text = text.replace(" !", "!")
            text = text.replace(" ;", ";")
            text = text.replace(" :", ":")

        # Context-aware legal term formatting
        # "Exhibit" capitalized only when followed by a number or letter identifier
        text = re.sub(r'\bexhibit\s+(?=\d+|[A-Z]\b)', 'Exhibit ', text, flags=re.IGNORECASE)
        # "Count" capitalized only when followed by a number
        text = re.sub(r'\bcount\s+(?=\d+)', 'Count ', text, flags=re.IGNORECASE)

        # Juror number: spelled-out → numeral (Juror number one → Juror number 1)
        _number_words = {
            'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
            'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10',
            'eleven': '11', 'twelve': '12', 'thirteen': '13', 'fourteen': '14',
            'fifteen': '15', 'sixteen': '16',
        }
        def _replace_juror_num(m):
            num = m.group(1).lower()
            return f"Juror number {_number_words.get(num, num)}"
        text = re.sub(
            r'\bjuror\s+number\s+(' + '|'.join(_number_words.keys()) + r')\b',
            _replace_juror_num, text, flags=re.IGNORECASE
        )
        # Count with spelled-out numbers
        def _replace_count_num(m):
            num = m.group(1).lower()
            return f"Count {_number_words.get(num, num)}"
        text = re.sub(
            r'\bCount\s+(' + '|'.join(_number_words.keys()) + r')\b',
            _replace_count_num, text, flags=re.IGNORECASE
        )

        # Undo over-capitalization of compound words
        text = re.sub(r'\bCourtroom\b', 'courtroom', text)
        text = re.sub(r'\bCourthouse\b', 'courthouse', text)
        text = re.sub(r'\bStatement\b', 'statement', text)

        # "okay," → "okay." and "all right," → "all right."
        text = re.sub(r'\bokay,', 'okay.', text, flags=re.IGNORECASE)
        text = re.sub(r'\ball right,', 'all right.', text, flags=re.IGNORECASE)
        # Fix double periods from the above
        text = re.sub(r'\bokay\.\.+', 'okay.', text, flags=re.IGNORECASE)
        text = re.sub(r'\ball right\.\.+', 'all right.', text, flags=re.IGNORECASE)

        # % → "percent"
        text = re.sub(r'%', ' percent', text)

        seg["text"] = text.strip()

    # --- Profile-specific proofing rules ---
    profile = job.get("profile", {})
    rules = profile.get("proofing_rules", {})
    if not rules:
        return
    replacements = rules.get("replacements", {})
    for seg in job["transcript"].get("segments", []):
        text = seg.get("text", "")
        for find, replace in replacements.items():
            text = re.sub(r'\b' + re.escape(find) + r'\b', replace, text)
        seg["text"] = text
    if rules.get("no_ellipsis"):
        for seg in job["transcript"].get("segments", []):
            seg["text"] = seg["text"].replace("...", " --")


# ---------------------------------------------------------------------------
# Full-Text Search Across All Jobs
# ---------------------------------------------------------------------------

@app.get("/api/search")
async def search_transcripts(q: str = "", limit: int = 50):
    """Search across all jobs' transcript text. Returns matches with context."""
    if not q or len(q.strip()) < 2:
        return JSONResponse({"results": [], "query": q})

    query = q.strip()
    query_lower = query.lower()
    results = []

    for job_id, job in JOBS.items():
        transcript = job.get("transcript")
        if not transcript:
            continue
        segments = transcript.get("segments", [])
        for idx, seg in enumerate(segments):
            text = seg.get("text", "")
            text_lower = text.lower()
            if query_lower not in text_lower:
                continue

            # Highlight matches with <mark> tags
            import re as _re_search
            highlighted = _re_search.sub(
                f"({_re_search.escape(query)})",
                lambda m: f"<mark>{m.group(0)}</mark>",
                text,
                flags=_re_search.IGNORECASE
            )

            # Score: exact case match > case-insensitive
            score = 2 if query in text else 1

            results.append({
                "job_id": job_id,
                "case_caption": job.get("case_caption", ""),
                "case_number": job.get("case_number", ""),
                "segment_index": idx,
                "text": highlighted,
                "original_text": text,
                "timestamp": _fmt_time(seg.get("start", 0)),
                "speaker": seg.get("speaker", ""),
                "score": score,
            })

    # Sort by relevance (exact match first), then by job
    results.sort(key=lambda r: -r["score"])
    results = results[:limit]

    return JSONResponse({"results": results, "query": q, "total": len(results)})


# ---------------------------------------------------------------------------
# Transcript Delivery / Share Links (post-proceeding sharing)
# ---------------------------------------------------------------------------

@app.post("/api/job/{job_id}/share")
async def create_transcript_share(job_id: str, request: Request):
    """Generate a share link for a finished transcript."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    data = await request.json()
    permissions = data.get("permissions", ["view"])  # view, download, print
    expires_days = data.get("expires_days", None)  # None = no expiry

    token = _secrets.token_urlsafe(32)
    expires_at = None
    if expires_days:
        from datetime import timedelta
        expires_at = (datetime.now() + timedelta(days=int(expires_days))).isoformat()

    TRANSCRIPT_SHARES[token] = {
        "job_id": job_id,
        "created_at": datetime.now().isoformat(),
        "expires_at": expires_at,
        "permissions": permissions,
        "created_by": job.get("reporter_name", ""),
        "acknowledged": False,
        "acknowledged_at": None,
    }
    _save_shares()

    url = f"/static/shared_view.html?token={token}"
    logger.info("Transcript share created for job %s: token=%s...", job_id, token[:8])
    return JSONResponse({"ok": True, "token": token, "url": url})


@app.get("/api/shared/{token}")
async def view_shared_transcript(token: str):
    """View a shared transcript (read-only). Returns transcript data."""
    share = TRANSCRIPT_SHARES.get(token)
    if not share:
        return JSONResponse({"error": "Invalid share link"}, status_code=404)

    # Check expiry
    if share.get("expires_at"):
        expires = datetime.fromisoformat(share["expires_at"])
        if datetime.now() > expires:
            return JSONResponse({"error": "This share link has expired"}, status_code=410)

    job = JOBS.get(share["job_id"])
    if not job or not job.get("transcript"):
        return JSONResponse({"error": "Transcript not found"}, status_code=404)

    permissions = share.get("permissions", ["view"])

    return JSONResponse({
        "job_id": share["job_id"],
        "case_caption": job.get("case_caption", ""),
        "case_number": job.get("case_number", ""),
        "court_name": job.get("court_name", ""),
        "date": job.get("date", ""),
        "proceeding_type": job.get("proceeding_type", ""),
        "reporter_name": job.get("reporter_name", ""),
        "speakers": job.get("speakers", []),
        "segments": job["transcript"].get("segments", []),
        "permissions": permissions,
        "acknowledged": share.get("acknowledged", False),
        "acknowledged_at": share.get("acknowledged_at"),
    })


@app.post("/api/shared/{token}/acknowledge")
async def acknowledge_shared_transcript(token: str):
    """Mark a shared transcript as reviewed (witness read-and-sign)."""
    share = TRANSCRIPT_SHARES.get(token)
    if not share:
        return JSONResponse({"error": "Invalid share link"}, status_code=404)
    share["acknowledged"] = True
    share["acknowledged_at"] = datetime.now().isoformat()
    _save_shares()
    logger.info("Transcript acknowledged: token=%s...", token[:8])
    return JSONResponse({"ok": True, "acknowledged_at": share["acknowledged_at"]})


# ---------------------------------------------------------------------------
# Exhibit Hyperlinking
# ---------------------------------------------------------------------------

@app.post("/api/job/{job_id}/exhibit")
async def add_exhibit(job_id: str, request: Request):
    """Add an exhibit link to a job. Professional tier required."""
    gate = _require_pro("Exhibit uploads")
    if gate:
        return gate
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    data = await request.json()
    exhibit_id = data.get("exhibit_id", "").strip()
    if not exhibit_id:
        return JSONResponse({"error": "exhibit_id required (e.g., 'Exhibit A')"}, status_code=400)

    exhibit = {
        "exhibit_id": exhibit_id,
        "description": data.get("description", ""),
        "file_reference": data.get("file_reference", ""),
        "linked_segments": data.get("linked_segments", []),
        "created_at": datetime.now().isoformat(),
    }

    if job_id not in EXHIBITS:
        EXHIBITS[job_id] = []
    # Update if same exhibit_id exists, else append
    existing = next((i for i, e in enumerate(EXHIBITS[job_id])
                     if e["exhibit_id"] == exhibit_id), None)
    if existing is not None:
        EXHIBITS[job_id][existing] = exhibit
    else:
        EXHIBITS[job_id].append(exhibit)

    _save_exhibits()
    logger.info("Exhibit '%s' added to job %s", exhibit_id, job_id)
    return JSONResponse({"ok": True, "exhibit": exhibit})


@app.get("/api/job/{job_id}/exhibits")
async def list_exhibits(job_id: str):
    """List all exhibits for a job."""
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    exhibits = EXHIBITS.get(job_id, [])
    return JSONResponse({"exhibits": exhibits, "job_id": job_id})


@app.delete("/api/job/{job_id}/exhibit/{exhibit_id}")
async def delete_exhibit(job_id: str, exhibit_id: str):
    """Remove an exhibit from a job."""
    if job_id not in EXHIBITS:
        return JSONResponse({"error": "No exhibits for this job"}, status_code=404)
    before = len(EXHIBITS[job_id])
    EXHIBITS[job_id] = [e for e in EXHIBITS[job_id] if e["exhibit_id"] != exhibit_id]
    if len(EXHIBITS[job_id]) == before:
        return JSONResponse({"error": "Exhibit not found"}, status_code=404)
    _save_exhibits()
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=" * 50)
    print("  NOTARE — Legal Transcription Platform")
    print("  http://localhost:8080")
    print("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8080, log_level="info")
