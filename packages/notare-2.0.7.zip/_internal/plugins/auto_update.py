"""Auto-update plugin — pulls patches from the remote update server on startup.

This plugin runs ONCE at load time (not per-request). It checks the remote
server, downloads any available update zip, and extracts patchable files
over the local install.

Patchable paths:
  - _internal/plugins/   (plugin code)
  - _internal/static/    (frontend HTML/CSS/JS)
  - static/              (frontend mirror)
  - templates/           (Jinja templates)
  - app.py               (main application)
  - _internal/app.py     (frozen application copy)
"""
import json
import logging
import sys
import os
from pathlib import Path

logger = logging.getLogger("notare")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

BASE_DIR = _app.BASE_DIR
SETTINGS = _app.SETTINGS
# Primary and fallback update servers — if primary is down, try fallback
UPDATE_SERVERS = [
    "https://notarelegal.com",
    "https://notare-updates.onrender.com",
]
UPDATE_SERVER = UPDATE_SERVERS[0]  # default for backward compat

# Marker file to track that this updated plugin has run at least once
_MIGRATION_MARKER = BASE_DIR / "_internal" / ".ota_v2"


def _mirror_internal_to_root():
    """Mirror _internal/static, _internal/plugins, _internal/app.py to their root
    counterparts when those root locations exist. Some exe builds serve static
    files and load app.py from the root paths rather than _internal/, so a patch
    that only lands in _internal leaves the served copy stale. Only mirror onto
    paths the build already uses (file must already exist at root) to avoid
    surprise new files. Runs every startup as a heal step even when no update
    was pulled this cycle."""
    import shutil as _sh_sync
    synced = 0
    internal_root = BASE_DIR / "_internal"
    for sub in ("static", "plugins"):
        src_dir = internal_root / sub
        dst_dir = BASE_DIR / sub
        if not src_dir.exists() or not dst_dir.exists():
            continue
        for src in src_dir.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(src_dir)
            dst = dst_dir / rel
            if not dst.exists():
                continue  # only mirror paths the old build already serves
            try:
                # Skip when already identical (avoid needless disk writes)
                if src.stat().st_size == dst.stat().st_size and \
                   src.read_bytes() == dst.read_bytes():
                    continue
                _sh_sync.copy2(str(src), str(dst))
                synced += 1
            except Exception as _se:
                logger.debug("OTA: sync failed for %s: %s", dst, _se)
    int_app = internal_root / "app.py"
    root_app = BASE_DIR / "app.py"
    if int_app.exists() and root_app.exists():
        try:
            if int_app.read_bytes() != root_app.read_bytes():
                _sh_sync.copy2(str(int_app), str(root_app))
                synced += 1
        except Exception as _se:
            logger.debug("OTA: sync failed for app.py: %s", _se)
    if synced:
        logger.info("OTA: mirrored %d files from _internal to root paths", synced)
    return synced


def _run_update(force=False):
    local_version = SETTINGS.get("version", "0.0.0")

    import urllib.request as _ur

    # Check for update
    check_version = "0.0.0" if force else local_version

    # Try each update server until one responds
    data = None
    for server in UPDATE_SERVERS:
        try:
            check_url = f"{server}/api/update?current={check_version}"
            with _ur.urlopen(check_url, timeout=10) as resp:
                data = json.loads(resp.read())
            UPDATE_SERVER = server  # remember which one worked
            break
        except Exception as e:
            logger.warning("OTA: server %s unreachable (%s), trying next...", server, e)
            continue

    if data is None:
        logger.warning("OTA: all update servers unreachable — skipping update check")
        return

    if not data.get("update_available"):
        logger.info("OTA: up to date (v%s)", local_version)
        return

    server_version = data.get("version", "0.0.0")
    download_url = data.get("url", "")
    if download_url.startswith("/"):
        download_url = UPDATE_SERVER + download_url
    elif not download_url.startswith("http"):
        download_url = f"{UPDATE_SERVER}/api/update/download/{server_version}"

    # Validate download URL — must be from a trusted domain
    from urllib.parse import urlparse
    parsed = urlparse(download_url)
    trusted_domains = {"notarelegal.com", "notare-updates.onrender.com",
                       "github.com", "objects.githubusercontent.com"}
    if parsed.hostname not in trusted_domains:
        logger.error("OTA: BLOCKED — download URL points to untrusted domain: %s", parsed.hostname)
        return

    logger.info("OTA: update available v%s -> v%s, downloading...", local_version, server_version)

    # Download
    import tempfile as _tf
    import hashlib as _hl
    tmp = Path(_tf.mktemp(suffix=".zip", prefix="notare_update_"))
    _ur.urlretrieve(download_url, str(tmp))
    logger.info("OTA: downloaded %s (%d bytes)", tmp.name, tmp.stat().st_size)

    # Verify integrity — checksum from server must match download
    expected_checksum = data.get("checksum", "")
    expected_size = data.get("size", 0)
    if expected_checksum:
        actual_checksum = _hl.sha256(tmp.read_bytes()).hexdigest()
        if actual_checksum != expected_checksum:
            logger.error("OTA: CHECKSUM MISMATCH — download corrupted or tampered. Aborting.")
            logger.error("  Expected: %s", expected_checksum[:16])
            logger.error("  Got:      %s", actual_checksum[:16])
            tmp.unlink(missing_ok=True)
            return
        logger.info("OTA: checksum verified")
    if expected_size and tmp.stat().st_size != expected_size:
        logger.warning("OTA: size mismatch (expected %d, got %d) — proceeding with caution",
                       expected_size, tmp.stat().st_size)

    # Extract everything EXCEPT user data — blacklist, not whitelist.
    # Whatever is in the patch gets delivered. No more missing files.
    import zipfile as _zf
    _never_overwrite = (
        "license.json",         # User's license key
        "admin_data.json",      # Local license database
        "settings.json",        # User's preferences and API keys
        "install_manifest.json", # Smart installer hardware profile
        "sessions/",            # User's job data
        "uploads/",             # User's uploaded files
        "exports/",             # User's exported files
        "templates/",           # User's Word templates (custom)
    )
    # Backup current files before overwriting — enables rollback
    _backup_dir = BASE_DIR / "_internal" / "_rollback" / f"v{local_version}"
    _backup_dir.mkdir(parents=True, exist_ok=True)

    extracted = 0
    skipped = []
    backed_up = 0
    with _zf.ZipFile(str(tmp), "r") as zf:
        for member in zf.namelist():
            # Security: no absolute paths, directory traversal, or executable content
            if member.startswith("/") or ".." in member:
                continue
            # Only allow known safe file types
            allowed_ext = ('.py', '.html', '.css', '.js', '.json', '.txt', '.md',
                          '.png', '.ico', '.svg', '.woff', '.woff2', '.ttf', '.eot')
            if not any(member.lower().endswith(ext) for ext in allowed_ext) and not member.endswith('/'):
                logger.warning("OTA: blocked file with disallowed extension: %s", member)
                skipped.append(member)
                continue
            # Plugins must be in _internal/plugins/ only; also allow both
            # root app.py and _internal/app.py (different exe builds load from
            # different locations, so we need to deliver both).
            if member.endswith('.py') and 'plugins/' not in member \
                    and member not in ('app.py', '_internal/app.py'):
                logger.warning("OTA: blocked .py outside plugins dir: %s", member)
                skipped.append(member)
                continue
            # Skip directories (just create them)
            if member.endswith("/"):
                (BASE_DIR / member).mkdir(parents=True, exist_ok=True)
                continue
            # Never overwrite user data
            protected = any(member == p or member.startswith(p) for p in _never_overwrite)
            if protected:
                skipped.append(member)
                continue
            # Backup existing file before overwriting
            target = BASE_DIR / member
            if target.exists():
                backup_target = _backup_dir / member
                backup_target.parent.mkdir(parents=True, exist_ok=True)
                try:
                    import shutil as _sh
                    _sh.copy2(str(target), str(backup_target))
                    backed_up += 1
                except:
                    pass
            # Extract
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as src, open(target, "wb") as dst:
                dst.write(src.read())
            extracted += 1

    logger.info("OTA: extracted %d files from v%s (backed up %d)", extracted, server_version, backed_up)
    if skipped:
        logger.info("OTA: skipped %d files not in safe list: %s", len(skipped), skipped)

    # Verify plugins load before committing the update
    _plugin_ok = True
    plugins_dir = BASE_DIR / "_internal" / "plugins"
    for py in plugins_dir.glob("*.py"):
        try:
            content = py.read_text(encoding='utf-8')
            compile(content, str(py), 'exec')  # syntax check only
        except SyntaxError as e:
            logger.error("OTA: ROLLBACK — new plugin %s has syntax error: %s", py.name, e)
            _plugin_ok = False
            break

    if not _plugin_ok:
        # Rollback: restore all backed up files
        for member in _backup_dir.rglob("*"):
            if member.is_file():
                rel = member.relative_to(_backup_dir)
                target = BASE_DIR / rel
                try:
                    import shutil as _sh
                    _sh.copy2(str(member), str(target))
                except:
                    pass
        logger.error("OTA: rolled back to v%s — update v%s had broken plugins", local_version, server_version)
        try:
            tmp.unlink()
        except:
            pass
        return

    _mirror_internal_to_root()

    # Verify the zip actually delivered the version it claimed to. Since v2.0.5,
    # every bundle carries _internal/_notare_version.txt with the version string.
    # If absent, we tolerate it (older bundles). If present and mismatched,
    # that's a clear tampering/mis-upload signal — roll back.
    stamp_path = BASE_DIR / "_internal" / "_notare_version.txt"
    if stamp_path.exists():
        try:
            stamped = stamp_path.read_text(encoding="utf-8").strip()
            if stamped != server_version:
                logger.error("OTA: ROLLBACK — zip stamp %r does not match manifest version %r",
                             stamped, server_version)
                for member in _backup_dir.rglob("*"):
                    if member.is_file():
                        rel = member.relative_to(_backup_dir)
                        tgt = BASE_DIR / rel
                        try:
                            import shutil as _sh_rb
                            _sh_rb.copy2(str(member), str(tgt))
                        except Exception:
                            pass
                return
        except Exception as _ve:
            logger.debug("OTA: version stamp check failed: %s", _ve)

    # Update version
    SETTINGS["version"] = server_version
    SETTINGS["last_update"] = __import__("datetime").datetime.now().isoformat()
    SETTINGS["updated_silently"] = True
    SETTINGS["previous_version"] = local_version  # for manual rollback reference
    _app._save_settings()

    try:
        tmp.unlink()
    except Exception:
        pass

    logger.info("OTA: updated to v%s successfully (rollback available at %s)", server_version, _backup_dir)


# Run on plugin load — errors are non-fatal
try:
    # Migration: if this is the first time the v2 plugin runs, force a full
    # re-download to pick up app.py (which the old plugin couldn't extract).
    if not _MIGRATION_MARKER.exists():
        logger.info("OTA: first run of updated plugin — forcing full re-download")
        _run_update(force=True)
        try:
            _MIGRATION_MARKER.parent.mkdir(parents=True, exist_ok=True)
            _MIGRATION_MARKER.write_text("v2")
        except Exception:
            pass
    else:
        _run_update()
except Exception as e:
    logger.debug("OTA: update check failed (non-critical): %s", e)

# Always heal the root mirror — even when no update was pulled this cycle.
# This rescues installs that previously downloaded a patch that only landed
# in _internal/ while the exe was serving from the root paths.
try:
    _mirror_internal_to_root()
except Exception as e:
    logger.debug("OTA: mirror heal failed (non-critical): %s", e)

print("Plugin loaded: auto_update.py — OTA auto-update active")
