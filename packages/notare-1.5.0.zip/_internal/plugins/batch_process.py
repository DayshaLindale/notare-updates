"""Batch Processing — Process entire case folders with auto speaker detection.

Adds a /api/batch endpoint and /static/batch.html page that lets users
point at a case folder and process all audio files with shared case info.

Auto-detects speakers from clerk log HTM files in the Documentation folder.
Creates one Notare job per audio file, queues them for sequential processing.

Designed for the Oregon court workflow:
  E:/Oregon Cases/{case}/Audio/         ← audio files
  E:/Oregon Cases/{case}/Documentation/ ← clerk logs, legal docs
  E:/Oregon Cases/{case}/Documentation/ASR/ ← output
"""
import json
import logging
import os
import re
import sys
import threading
import uuid
from pathlib import Path

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

logger = logging.getLogger("notare")


# ─────────────────────────────────────────────
# Clerk log parser (same logic as asr_plus.py Part 3)
# ─────────────────────────────────────────────

def _parse_clerk_log_for_speakers(htm_path, case_keywords=None):
    """Parse an HTM clerk log for attorney names. Returns speaker list or empty."""
    try:
        with open(htm_path, 'r', encoding='utf-8', errors='ignore') as f:
            html = f.read()
    except Exception:
        return []

    rows_raw = re.findall(r'<tr.*?</tr>', html, re.DOTALL | re.IGNORECASE)
    rows = []
    for row in rows_raw:
        cells = re.findall(r'<td.*?>(.*?)</td>', row, re.DOTALL | re.IGNORECASE)
        cells = [re.sub(r'<[^>]+>', '', c).replace('&nbsp;', ' ').strip() for c in cells]
        if len(cells) == 3:
            rows.append(tuple(cells))

    if not rows:
        return []

    speakers = [{"name": "THE COURT", "representing": "The Court", "hotkey": "Alt+U"}]
    suffixes = {'jr', 'sr', 'ii', 'iii', 'iv', 'esq'}

    def clean(name):
        name = re.sub(r'\s*OSB[#:\s]+[\d]+', '', name)
        name = re.sub(r'\s*\([\d]+\)', '', name)
        name = re.sub(r'\s+\d+$', '', name)
        name = re.sub(r'\s+(Plea|Sent|Trial|Hearing|Further|Arraignment).*$', '', name, flags=re.IGNORECASE)
        return name.strip(' .;,')

    def last_name(full):
        parts = full.strip().split()
        while parts and parts[-1].lower().rstrip('.') in suffixes:
            parts.pop()
        return parts[-1] if parts else full

    def to_label(name):
        c = clean(name)
        ln = last_name(c).upper()
        first = c.split()[0].lower() if c.split() else ""
        prefix = "MS." if first.endswith(('a', 'ie', 'ey', 'ah', 'na', 'ne', 'ia', 'ly', 'yn')) else "MR."
        return f"{prefix} {ln}", c

    # Method 1: Called entry with DA/Defense fields
    for time_val, speaker, note in rows:
        if speaker.lower().rstrip(':') != 'called':
            continue
        if case_keywords and not any(kw.lower() in note.lower() for kw in case_keywords):
            continue

        da = re.search(r'District Attorney:\s*(.+?)(?=\s*Defense Attorney|$)', note, re.IGNORECASE)
        df = re.search(r'Defense Attorney:\s*(.+?)(?=\s*;?\s*Defendant|\s*Attorney for|$)', note, re.IGNORECASE)

        if da:
            for n in da.group(1).split(','):
                n = clean(n)
                if n:
                    label, full = to_label(n)
                    speakers.append({"name": label, "representing": "Plaintiff/State", "hotkey": "", "_full_name": full})
        if df:
            for n in df.group(1).split(','):
                n = clean(n)
                if n:
                    label, full = to_label(n)
                    speakers.append({"name": label, "representing": "Defense", "hotkey": "", "_full_name": full})

        if len(speakers) > 1:
            # Add standard extras
            speakers.extend([
                {"name": "THE WITNESS", "representing": "", "hotkey": "Alt+W"},
                {"name": "THE DEFENDANT", "representing": "", "hotkey": "Alt+D"},
            ])
            return speakers

    # Method 2: Speaker column scan
    skip = {'judge', 'called', 'called:', 'recess', 'return', 'lunch',
            'end', 'break', 'clerk', 'bailiff', 'interpreter', 'witness',
            'jury', 'sidebar', '', ' '}

    seen = set()
    for time_val, speaker, note in rows:
        s = speaker.strip().rstrip(':').lower()
        if not s or s in skip or 'audio' in s or 'cleanup' in s:
            continue
        if s not in seen:
            seen.add(s)
            label, full = to_label(speaker.strip().rstrip(':'))
            speakers.append({"name": label, "representing": "", "hotkey": "", "_full_name": full})

    if len(speakers) > 1:
        speakers.extend([
            {"name": "THE WITNESS", "representing": "", "hotkey": "Alt+W"},
            {"name": "THE DEFENDANT", "representing": "", "hotkey": "Alt+D"},
        ])
        return speakers

    return []


def _find_clerk_log(doc_folder, audio_filename):
    """Match audio filename date to a clerk log HTM file."""
    date_match = re.match(r'(\d{4})[._](\d{2})[._](\d{2})', os.path.basename(audio_filename))
    if not date_match:
        return None
    yyyy, mm, dd = date_match.groups()
    log_name = f"{yyyy}.{mm}.{dd}.htm"
    log_path = os.path.join(doc_folder, log_name)
    return log_path if os.path.exists(log_path) else None


# ─────────────────────────────────────────────
# Batch processing endpoint
# ─────────────────────────────────────────────

from fastapi import Request
from fastapi.responses import JSONResponse as _JSONResponse, HTMLResponse

@_app.app.post("/api/batch")
async def batch_process(request: Request):
    """Create and queue batch jobs from a case folder.

    Body: {
        "case_folder": "E:/Oregon Cases/Case Name",
        "profile": "Oregon courts",
        "auto_speakers": true
    }
    """
    data = await request.json()
    case_folder = data.get("case_folder", "").strip()
    profile_name = data.get("profile", "")
    auto_speakers = data.get("auto_speakers", True)

    if not case_folder:
        return _JSONResponse({"error": "Case folder path required"}, status_code=400)

    case_path = Path(case_folder)
    audio_folder = case_path / "Audio"
    doc_folder = case_path / "Documentation"
    asr_folder = doc_folder / "ASR"

    # Validate paths
    if not case_path.exists():
        return _JSONResponse({"error": f"Case folder not found: {case_folder}"}, status_code=400)
    if not audio_folder.exists():
        return _JSONResponse({"error": f"Audio folder not found: {audio_folder}"}, status_code=400)

    # Find audio files
    audio_files = sorted(
        [f for f in audio_folder.iterdir() if f.suffix.lower() in ('.mp3', '.wav', '.m4a', '.flac')]
    )
    if not audio_files:
        return _JSONResponse({"error": "No audio files found in Audio folder"}, status_code=400)

    # Ensure ASR output folder exists
    asr_folder.mkdir(parents=True, exist_ok=True)

    # Get profile
    profile = _app.PROFILES.get(profile_name, {})

    # Extract case name keywords for clerk log scoping
    case_name = case_path.name
    case_keywords = re.findall(r'\b([A-Z][a-z]+)\b', case_name)

    # Create batch record
    batch_id = str(uuid.uuid4())[:8]
    job_ids = []
    results = []

    for audio_file in audio_files:
        # Auto-detect speakers from clerk log
        speakers = []
        clerk_log_used = False
        if auto_speakers and doc_folder.exists():
            log_path = _find_clerk_log(str(doc_folder), audio_file.name)
            if log_path:
                speakers = _parse_clerk_log_for_speakers(log_path, case_keywords)
                if speakers:
                    clerk_log_used = True
                    logger.info("Batch: Found %d speakers from clerk log for %s", len(speakers), audio_file.name)

        # Create the job
        job_id = str(uuid.uuid4())[:8]
        job_dir = _app.SESSION_DIR / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        audio_dir = job_dir / "audio"
        audio_dir.mkdir(exist_ok=True)

        # Copy or symlink audio file
        import shutil
        dest = audio_dir / audio_file.name
        shutil.copy2(str(audio_file), str(dest))

        # Build title from filename
        title = audio_file.stem
        if case_name:
            title = f"{case_name} — {audio_file.stem}"

        job = {
            "id": job_id,
            "title": title,
            "capture_mode": "D",
            "court_name": profile.get("court_name", ""),
            "case_number": "",
            "case_caption": case_name,
            "proceeding_type": "Hearing",
            "date": "",
            "location": profile.get("location", ""),
            "reporter_name": profile.get("reporter_name", ""),
            "reporter_credential": profile.get("reporter_credential", ""),
            "time_in": "",
            "time_out": "",
            "job_number": "",
            "jurisdiction_profile": profile_name,
            "profile": profile,
            "speakers": speakers,
            "channels": [],
            "files": [str(dest)],
            "status": "queued",
            "created_at": __import__("datetime").datetime.now().isoformat(),
            "transcript": None,
            "flags": [],
            "dir": str(job_dir),
            "_batch_id": batch_id,
            "_source_audio": str(audio_file),
            "_asr_output_dir": str(asr_folder),
            "_clerk_log_used": clerk_log_used,
        }
        _app.JOBS[job_id] = job
        _app._save_job(job)
        job_ids.append(job_id)
        results.append({
            "job_id": job_id,
            "audio_file": audio_file.name,
            "speakers_detected": len(speakers),
            "clerk_log_used": clerk_log_used,
        })

    # Queue sequential processing in background
    def _process_batch():
        for jid in job_ids:
            job = _app.JOBS.get(jid)
            if not job:
                continue
            job["status"] = "processing"
            _app._save_job(job)
            logger.info("Batch %s: processing %s", batch_id, job.get("title", jid))
            try:
                _app._run_transcription(job)
            except Exception as e:
                job["status"] = "error"
                job["error"] = str(e)
                logger.error("Batch %s: error on %s: %s", batch_id, jid, e)
            _app._save_job(job)

    threading.Thread(target=_process_batch, daemon=True, name=f"batch-{batch_id}").start()

    return _JSONResponse({
        "batch_id": batch_id,
        "jobs": results,
        "total_files": len(audio_files),
        "profile": profile_name,
        "case_folder": case_folder,
    })


@_app.app.get("/api/batch/{batch_id}/status")
async def batch_status(batch_id: str):
    """Get status of all jobs in a batch."""
    jobs = []
    for jid, job in _app.JOBS.items():
        if job.get("_batch_id") == batch_id:
            jobs.append({
                "job_id": jid,
                "title": job.get("title", ""),
                "status": job.get("status", ""),
                "progress": job.get("progress", 0),
                "progress_message": job.get("progress_message", ""),
                "error": job.get("error", ""),
            })
    if not jobs:
        return _JSONResponse({"error": "Batch not found"}, status_code=404)

    total = len(jobs)
    complete = sum(1 for j in jobs if j["status"] == "complete")
    errors = sum(1 for j in jobs if j["status"] == "error")
    processing = sum(1 for j in jobs if j["status"] == "processing")

    return _JSONResponse({
        "batch_id": batch_id,
        "total": total,
        "complete": complete,
        "processing": processing,
        "errors": errors,
        "done": complete + errors == total,
        "jobs": jobs,
    })


# ─────────────────────────────────────────────
# Batch UI page
# ─────────────────────────────────────────────

_BATCH_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notare — Batch Processing</title>
    <link rel="icon" href="/static/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="header">
        <a href="https://notarelegal.com" target="_blank" style="text-decoration:none;"><h1 style="margin:0;display:flex;align-items:center;gap:6px;"><img src="/static/quill_icon_only.png" style="height:24px;" alt=""><span style="font-family:Palatino,Georgia,serif;letter-spacing:1px;font-style:italic;color:var(--gold,#c8a55c);">Notare</span></h1></a>
        <nav>
            <a href="/static/index.html">Dashboard</a>
            <a href="/static/new_job.html">New Job</a>
            <a href="/static/batch.html">Batch</a>
            <a href="/static/cases.html">Cases</a>
            <a href="/static/profiles.html">Profiles</a>
            <a href="/static/settings.html">Settings</a>
            <a href="/static/help.html">Help</a>
        </nav>
    </div>

    <div class="container">
        <h2 class="page-title">Batch Processing</h2>
        <p style="color:var(--text-muted); margin-bottom:24px;">Process an entire case folder at once. Notare will find the audio files, auto-detect speakers from clerk logs, and transcribe everything sequentially.</p>

        <div class="card" id="setupCard">
            <h3>Case Folder</h3>
            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600;">Folder Path</label>
                <input type="text" id="caseFolderInput" placeholder="E:/Oregon Cases/Case Name" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:6px; font-size:14px; background:var(--bg-secondary); color:var(--text-body);">
                <small style="color:var(--text-muted);">Must contain an Audio/ subfolder with .mp3 or .wav files</small>
            </div>

            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600;">Profile</label>
                <select id="profileSelect" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:6px; font-size:14px; background:var(--bg-secondary); color:var(--text-body);">
                    <option value="">None</option>
                </select>
            </div>

            <div style="margin-bottom:16px;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="checkbox" id="autoSpeakers" checked>
                    <span>Auto-detect speakers from clerk log</span>
                </label>
            </div>

            <button onclick="startBatch()" class="btn btn-primary" id="startBtn" style="padding:12px 32px; font-size:16px;">Start Batch</button>
        </div>

        <div class="card" id="progressCard" style="display:none;">
            <h3>Batch Progress</h3>
            <div id="batchSummary" style="margin-bottom:16px; font-size:14px; color:var(--text-muted);"></div>
            <div id="jobList"></div>
        </div>
    </div>

    <script>
    // Load profiles
    fetch('/api/profiles').then(r => r.json()).then(profiles => {
        const sel = document.getElementById('profileSelect');
        for (const name of Object.keys(profiles)) {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            sel.appendChild(opt);
        }
    });

    let currentBatchId = null;
    let pollInterval = null;

    async function startBatch() {
        const folder = document.getElementById('caseFolderInput').value.trim();
        if (!folder) { alert('Please enter a case folder path.'); return; }

        const btn = document.getElementById('startBtn');
        btn.disabled = true;
        btn.textContent = 'Starting...';

        try {
            const resp = await fetch('/api/batch', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    case_folder: folder,
                    profile: document.getElementById('profileSelect').value,
                    auto_speakers: document.getElementById('autoSpeakers').checked,
                }),
            });
            const data = await resp.json();
            if (data.error) {
                alert(data.error);
                btn.disabled = false;
                btn.textContent = 'Start Batch';
                return;
            }

            currentBatchId = data.batch_id;
            document.getElementById('setupCard').style.display = 'none';
            document.getElementById('progressCard').style.display = 'block';
            document.getElementById('batchSummary').innerHTML =
                `<strong>${data.total_files} files</strong> queued from <code>${folder}</code>` +
                (data.profile ? ` using profile <strong>${data.profile}</strong>` : '');

            // Show initial job list
            renderJobs(data.jobs.map(j => ({...j, status: 'queued', progress: 0, progress_message: 'Queued'})));

            // Start polling
            pollInterval = setInterval(pollBatch, 3000);

        } catch (e) {
            alert('Error: ' + e.message);
            btn.disabled = false;
            btn.textContent = 'Start Batch';
        }
    }

    async function pollBatch() {
        if (!currentBatchId) return;
        try {
            const resp = await fetch(`/api/batch/${currentBatchId}/status`);
            const data = await resp.json();
            renderJobs(data.jobs);
            document.getElementById('batchSummary').innerHTML =
                `<strong>${data.complete}/${data.total}</strong> complete` +
                (data.errors ? `, <span style="color:#e74c3c;">${data.errors} error(s)</span>` : '') +
                (data.processing ? `, ${data.processing} processing...` : '');
            if (data.done) {
                clearInterval(pollInterval);
                document.getElementById('batchSummary').innerHTML += ' — <strong style="color:var(--gold,#c8a55c);">Batch complete!</strong>';
            }
        } catch (e) {}
    }

    function renderJobs(jobs) {
        const container = document.getElementById('jobList');
        container.innerHTML = jobs.map(j => {
            const statusColor = j.status === 'complete' ? '#27ae60' :
                               j.status === 'error' ? '#e74c3c' :
                               j.status === 'processing' ? '#3498db' : '#95a5a6';
            const link = j.status === 'complete' ? `<a href="/static/editor.html?id=${j.job_id}" style="color:var(--gold);">Open</a>` : '';
            const progress = j.status === 'processing' ? `<div style="background:var(--bg-secondary);border-radius:4px;height:6px;margin-top:4px;"><div style="background:#3498db;height:6px;border-radius:4px;width:${j.progress||0}%;"></div></div>` : '';
            return `<div style="padding:12px;border:1px solid var(--border);border-radius:8px;margin-bottom:8px;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <strong>${j.audio_file || j.title || j.job_id}</strong>
                    <span style="color:${statusColor};font-size:13px;font-weight:600;">${j.status.toUpperCase()}</span>
                </div>
                <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">${j.progress_message || j.error || (j.speakers_detected ? j.speakers_detected + ' speakers detected' : '')}</div>
                ${progress}
                <div style="margin-top:4px;font-size:12px;">${link}</div>
            </div>`;
        }).join('');
    }
    </script>
</body>
</html>"""


@_app.app.get("/static/batch.html")
async def batch_page():
    return HTMLResponse(_BATCH_HTML)


# Add Batch link to nav in existing pages
_original_index = getattr(_app, "_static_index_override", None)

logger.info("Batch: batch processing endpoint active at /api/batch")
print("Plugin loaded: batch_process.py — batch case folder processing active")
