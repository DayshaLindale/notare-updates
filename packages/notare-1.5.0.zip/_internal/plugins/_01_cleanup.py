"""One-time cleanup — removes renamed plugin files from prior versions."""
import os
import sys
from pathlib import Path

_app = sys.modules.get("app")
if _app:
    _plugins_dir = Path(getattr(_app, "BASE_DIR", ".")) / "_internal" / "plugins"
    _stale = ["beth_asr_upgrade.py"]
    for name in _stale:
        target = _plugins_dir / name
        if target.exists():
            try:
                target.unlink()
                print(f"Cleanup: removed stale plugin {name}")
            except Exception:
                pass
    # Also clear any stale .pyc
    cache_dir = _plugins_dir / "__pycache__"
    if cache_dir.exists():
        for pyc in cache_dir.glob("beth_asr*"):
            try:
                pyc.unlink()
            except Exception:
                pass
