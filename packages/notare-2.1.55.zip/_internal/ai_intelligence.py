"""Notare AI Intelligence Layer — Phase 3.

Provides:
  3.1 AI page-line summary
  3.2 AI narrative summary
  3.3 AI Chat against transcript (RAG)
  3.4 Contradiction detection
  3.5 Bluebook citation linking

LLM access:
  - Default: local Ollama at http://localhost:11434 (model: qwen2.5:14b).
    Free, no API cost, no data egress. The model is already available on
    the user's box because the Alma corpus pipeline uses it.
  - Optional: Anthropic Claude (set ANTHROPIC_API_KEY in settings/env).

Embeddings:
  - sentence-transformers/all-MiniLM-L6-v2 (CPU-friendly, ~80MB, no GPU).
  - Embeddings cached per job at job_dir/embeddings.npz.

Citation lookups:
  - CourtListener public API for case lookups (free, no auth needed for
    basic citation queries).
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# LLM client — local Ollama by default, Anthropic fallback
# ---------------------------------------------------------------------------

OLLAMA_URL = "http://localhost:11434/api/chat"
DEFAULT_OLLAMA_MODEL = "qwen2.5:14b"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-4-6"


def llm_chat(messages: list[dict], settings: dict | None = None,
             temperature: float = 0.4, max_tokens: int = 1500) -> str:
    """Send a chat completion request. Returns the assistant message text.

    Tries local Ollama first; falls back to Anthropic if ANTHROPIC_API_KEY
    is set. Returns empty string on total failure (caller handles).
    """
    settings = settings or {}
    # 1) Local Ollama
    try:
        import requests
        model = settings.get("ai_local_model") or DEFAULT_OLLAMA_MODEL
        r = requests.post(OLLAMA_URL, json={
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
                "top_p": 0.92,
            },
        }, timeout=180)
        if r.status_code == 200:
            data = r.json()
            text = (data.get("message") or {}).get("content", "")
            if text:
                return text.strip()
    except Exception as e:
        logger.debug("ollama call failed: %s", e)

    # 2) Anthropic fallback
    api_key = settings.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if api_key:
        try:
            import requests
            model = settings.get("ai_remote_model") or DEFAULT_ANTHROPIC_MODEL
            # Convert OpenAI-style messages to Anthropic format
            system_parts = [m["content"] for m in messages if m.get("role") == "system"]
            user_assistant = [m for m in messages if m.get("role") in ("user", "assistant")]
            r = requests.post(ANTHROPIC_URL, json={
                "model": model,
                "max_tokens": max_tokens,
                "system": "\n\n".join(system_parts) or None,
                "messages": user_assistant,
                "temperature": temperature,
            }, headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }, timeout=180)
            if r.status_code == 200:
                data = r.json()
                content = data.get("content") or []
                for blk in content:
                    if blk.get("type") == "text":
                        return blk.get("text", "").strip()
        except Exception as e:
            logger.warning("anthropic call failed: %s", e)

    return ""


def llm_available(settings: dict | None = None) -> dict:
    """Quick health check — returns which providers are reachable."""
    settings = settings or {}
    out = {"ollama": False, "anthropic": False}
    try:
        import requests
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        if r.status_code == 200:
            tags = (r.json() or {}).get("models", [])
            out["ollama"] = bool(tags)
            out["ollama_models"] = [m.get("name", "") for m in tags]
    except Exception:
        pass
    if settings.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", ""):
        out["anthropic"] = True
    return out


# ---------------------------------------------------------------------------
# 3.1 — page-line summary
# ---------------------------------------------------------------------------

def chunk_transcript_by_page(segments: list[dict], lines_per_page: int = 25,
                             chars_per_line: int = 63) -> list[dict]:
    """Approximate NCRA pagination — returns [{page, start_idx, end_idx, lines}]."""
    pages = []
    current = {"page": 1, "start_idx": 0, "end_idx": 0, "lines": []}
    line_count = 0
    for i, seg in enumerate(segments):
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        # Roughly count lines this segment spans
        seg_lines = max(1, len(text) // chars_per_line + (1 if len(text) % chars_per_line else 0))
        if seg.get("speaker"):
            seg_lines += 1  # speaker label adds a line
        if line_count + seg_lines > lines_per_page and current["lines"]:
            current["end_idx"] = i - 1
            pages.append(current)
            current = {"page": current["page"] + 1, "start_idx": i, "end_idx": i, "lines": []}
            line_count = 0
        current["lines"].append({
            "line": line_count + 1,
            "speaker": seg.get("speaker", ""),
            "text": text,
            "seg_idx": i,
        })
        line_count += seg_lines
        current["end_idx"] = i
    if current["lines"]:
        pages.append(current)
    return pages


def generate_page_line_summary(segments: list[dict], settings: dict | None = None,
                              progress_cb=None) -> list[dict]:
    """3.1: per-page summary. Returns [{page, summary, key_lines: [int,...]}]."""
    pages = chunk_transcript_by_page(segments)
    out = []
    for i, page in enumerate(pages):
        page_text = "\n".join(
            f"L{L['line']:>2}: {L['speaker']+': ' if L['speaker'] else ''}{L['text']}"
            for L in page["lines"]
        )
        prompt = (
            "You are summarizing one page of a deposition transcript for a "
            "lawyer reviewing the proceeding.\n\n"
            f"Page {page['page']}:\n{page_text}\n\n"
            "Write a 1-2 sentence summary capturing the substantive testimony "
            "on this page. Cite specific line numbers like (L3, L7) when a "
            "fact comes from a specific line. Skip pleasantries. Output the "
            "summary only — no preamble."
        )
        text = llm_chat([
            {"role": "system", "content": "You are a deposition page summarizer for legal professionals."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.2, max_tokens=300)
        # Pull out cited lines
        cited = sorted(set(int(m.group(1)) for m in re.finditer(r'L\s*(\d+)', text)))
        out.append({
            "page": page["page"],
            "start_idx": page["start_idx"],
            "end_idx": page["end_idx"],
            "summary": text or "(summary unavailable — LLM unreachable)",
            "key_lines": cited,
        })
        if progress_cb:
            progress_cb(i + 1, len(pages))
    return out


# ---------------------------------------------------------------------------
# 3.2 — narrative summary
# ---------------------------------------------------------------------------

def generate_narrative_summary(segments: list[dict], settings: dict | None = None,
                               case_info: dict | None = None) -> str:
    """3.2: single 400-600 word narrative summary covering the whole depo."""
    # Compress segments — sample evenly if very long
    LIMIT_CHARS = 25000
    blocks = []
    total = 0
    for seg in segments:
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        spk = seg.get("speaker") or ""
        line = (f"{spk}: " if spk else "") + text
        if total + len(line) > LIMIT_CHARS:
            break
        blocks.append(line)
        total += len(line) + 1
    body = "\n".join(blocks)
    case_line = ""
    if case_info:
        c = case_info
        parts = [c.get("case_caption"), c.get("case_number"), c.get("court_name")]
        case_line = " | ".join([p for p in parts if p])
    prompt = (
        "Write a 400-600 word narrative summary of this deposition. Organize "
        "by topic (not chronologically). Capture: who the witness is, what "
        "the substantive disputes are, key admissions, areas of "
        "uncertainty, and any contradictions or impeachment moments. Use "
        "active voice. No bullet points; flowing prose.\n\n"
        + (f"Case: {case_line}\n\n" if case_line else "")
        + f"Transcript (excerpt):\n{body}"
    )
    return llm_chat([
        {"role": "system", "content": "You are a deposition summarizer for trial lawyers. Write clear, concise narrative summaries."},
        {"role": "user", "content": prompt},
    ], settings=settings, temperature=0.3, max_tokens=2000) or "(summary unavailable — LLM unreachable)"


# ---------------------------------------------------------------------------
# 3.3 — RAG chat against transcript
# ---------------------------------------------------------------------------

_EMBED_MODEL = None


def _get_embed_model():
    """Lazy-load sentence-transformers all-MiniLM-L6-v2."""
    global _EMBED_MODEL
    if _EMBED_MODEL is None:
        try:
            from sentence_transformers import SentenceTransformer
            _EMBED_MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        except Exception as e:
            logger.warning("sentence-transformers not available: %s", e)
            return None
    return _EMBED_MODEL


def _chunk_for_embedding(segments: list[dict], chunk_tokens: int = 200,
                         overlap: int = 30) -> list[dict]:
    """Window the transcript into ~200-token chunks with 30-token overlap."""
    chunks = []
    buf_text = ""
    buf_segs = []
    buf_tokens = 0
    for i, seg in enumerate(segments):
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        spk = seg.get("speaker") or ""
        line = (f"{spk}: " if spk else "") + text
        # Rough token count: chars/4
        line_toks = max(1, len(line) // 4)
        if buf_tokens + line_toks > chunk_tokens and buf_segs:
            chunks.append({
                "text": buf_text.strip(),
                "first_idx": buf_segs[0],
                "last_idx": buf_segs[-1],
            })
            # Overlap window
            keep = max(1, len(buf_segs) // 5)
            buf_segs = buf_segs[-keep:]
            buf_text = " ... ".join(
                ((segments[j].get("speaker") + ": ") if segments[j].get("speaker") else "")
                + (segments[j].get("text") or "") for j in buf_segs
            ) + "\n"
            buf_tokens = sum(max(1, len(segments[j].get("text") or "") // 4) for j in buf_segs)
        buf_text += line + "\n"
        buf_segs.append(i)
        buf_tokens += line_toks
    if buf_segs:
        chunks.append({
            "text": buf_text.strip(),
            "first_idx": buf_segs[0],
            "last_idx": buf_segs[-1],
        })
    return chunks


def build_embedding_index(job_dir: Path, segments: list[dict],
                          force: bool = False) -> dict | None:
    """Build (or load) per-job embedding index. Returns {chunks, embeddings}.

    Cached at job_dir/embeddings.npz (numpy format) + chunks at
    job_dir/embeddings_chunks.json.
    """
    import numpy as np
    cache_npz = job_dir / "embeddings.npz"
    cache_json = job_dir / "embeddings_chunks.json"
    if not force and cache_npz.exists() and cache_json.exists():
        try:
            arr = np.load(cache_npz)
            chunks = json.loads(cache_json.read_text(encoding="utf-8"))
            return {"chunks": chunks, "embeddings": arr["embeddings"]}
        except Exception:
            pass

    model = _get_embed_model()
    if model is None:
        return None

    chunks = _chunk_for_embedding(segments)
    if not chunks:
        return None
    texts = [c["text"] for c in chunks]
    embs = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    np.savez_compressed(cache_npz, embeddings=embs)
    cache_json.write_text(json.dumps(chunks), encoding="utf-8")
    return {"chunks": chunks, "embeddings": embs}


def retrieve_top_k(index: dict, query: str, k: int = 6) -> list[dict]:
    import numpy as np
    model = _get_embed_model()
    if model is None or not index:
        return []
    qe = model.encode([query], normalize_embeddings=True)[0]
    sims = index["embeddings"] @ qe
    top = np.argsort(-sims)[:k]
    return [{**index["chunks"][int(i)], "score": float(sims[int(i)])} for i in top]


def chat_with_transcript(job_dir: Path, segments: list[dict], question: str,
                        history: list[dict] | None = None,
                        settings: dict | None = None) -> dict:
    """3.3: answer a question using RAG. Returns {answer, citations: [seg_idx,...]}."""
    index = build_embedding_index(job_dir, segments)
    if not index:
        # Fallback — pass the whole transcript (truncated) without retrieval
        body = "\n".join(
            (s.get("speaker", "") + ": " if s.get("speaker") else "") + (s.get("text") or "")
            for s in segments[:300]
        )
        prompt = (
            f"Question: {question}\n\nTranscript:\n{body}\n\n"
            "Answer the question using only the transcript. Cite segment "
            "numbers like [seg N] for every claim."
        )
        text = llm_chat([
            {"role": "system", "content": "You are a deposition Q&A assistant. Cite segments for every claim."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.2, max_tokens=1500)
        return {"answer": text or "(unable to answer — LLM unreachable)", "citations": []}

    hits = retrieve_top_k(index, question, k=6)
    context = "\n\n".join(
        f"[chunk @ segments {h['first_idx']}-{h['last_idx']}] {h['text']}"
        for h in hits
    )
    msgs = [
        {"role": "system", "content": (
            "You are answering questions about a specific deposition transcript. "
            "Use only the supplied excerpts. Every factual claim MUST be "
            "followed by a citation in the form [seg N] where N is the "
            "segment index. If the answer is not in the excerpts, say so."
        )},
    ]
    if history:
        msgs.extend(history)
    msgs.append({"role": "user", "content": f"Question: {question}\n\nRelevant excerpts:\n{context}"})

    answer = llm_chat(msgs, settings=settings, temperature=0.2, max_tokens=1500)
    citations = sorted(set(int(m.group(1)) for m in re.finditer(r'\[seg\s+(\d+)\]', answer or "")))
    return {"answer": answer or "(unable to answer — LLM unreachable)", "citations": citations}


# ---------------------------------------------------------------------------
# 3.4 — contradiction detection
# ---------------------------------------------------------------------------

def detect_contradictions(job_dir: Path, segments: list[dict],
                         settings: dict | None = None,
                         threshold: float = 0.62) -> list[dict]:
    """3.4: find within-deposition contradictions. Returns
    [{idx_a, idx_b, type, confidence, explanation}].
    """
    import numpy as np
    index = build_embedding_index(job_dir, segments)
    if not index:
        return []
    embs = index["embeddings"]
    chunks = index["chunks"]
    candidates = []
    # Pairs above similarity threshold but with surface-form contradiction signals
    sim_matrix = embs @ embs.T
    for i in range(len(chunks)):
        for j in range(i + 1, len(chunks)):
            sim = float(sim_matrix[i, j])
            if sim < threshold:
                continue
            # Quick filter: the two chunks shouldn't be adjacent
            if abs(chunks[i]["first_idx"] - chunks[j]["first_idx"]) < 5:
                continue
            ti = chunks[i]["text"]
            tj = chunks[j]["text"]
            # Surface-form signal: negation flip
            negs_i = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t|can'?t|isn'?t|haven'?t|wouldn'?t)\b", ti, re.I))
            negs_j = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t|can'?t|isn'?t|haven'?t|wouldn'?t)\b", tj, re.I))
            if negs_i != negs_j:
                candidates.append({"i": i, "j": j, "sim": sim, "signal": "negation_flip"})
            # Number/date mismatch signal
            nums_i = set(re.findall(r"\b\d+\b", ti))
            nums_j = set(re.findall(r"\b\d+\b", tj))
            if nums_i and nums_j and nums_i.isdisjoint(nums_j) and (nums_i ^ nums_j):
                candidates.append({"i": i, "j": j, "sim": sim, "signal": "number_mismatch"})
    # Dedup pairs
    seen = set()
    unique = []
    for c in candidates:
        key = (c["i"], c["j"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(c)
    # LLM-validate top candidates (cap at 12 to control cost)
    out = []
    for c in unique[:12]:
        ti = chunks[c["i"]]["text"]
        tj = chunks[c["j"]]["text"]
        prompt = (
            "Are these two excerpts from the same deposition contradictory or "
            "inconsistent? Answer in JSON: "
            '{"contradiction": true|false, "type": "negation"|"number"|"date"|"semantic"|"none", '
            '"explanation": "..."}\n\n'
            f"A (segments {chunks[c['i']]['first_idx']}-{chunks[c['i']]['last_idx']}):\n{ti}\n\n"
            f"B (segments {chunks[c['j']]['first_idx']}-{chunks[c['j']]['last_idx']}):\n{tj}"
        )
        resp = llm_chat([
            {"role": "system", "content": "Output ONLY the JSON object, nothing else."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.1, max_tokens=400)
        try:
            m = re.search(r'\{.*?\}', resp or "", re.S)
            j_obj = json.loads(m.group()) if m else None
        except Exception:
            j_obj = None
        if j_obj and j_obj.get("contradiction"):
            out.append({
                "idx_a": chunks[c["i"]]["first_idx"],
                "idx_b": chunks[c["j"]]["first_idx"],
                "range_a": [chunks[c["i"]]["first_idx"], chunks[c["i"]]["last_idx"]],
                "range_b": [chunks[c["j"]]["first_idx"], chunks[c["j"]]["last_idx"]],
                "type": j_obj.get("type", c["signal"]),
                "confidence": float(c["sim"]),
                "explanation": j_obj.get("explanation", ""),
            })
    out.sort(key=lambda x: -x["confidence"])
    return out


# ---------------------------------------------------------------------------
# 3.5 — Bluebook citation linking
# ---------------------------------------------------------------------------

# Common citation formats (Bluebook 21st ed.)
CITATION_PATTERNS = [
    # 410 U.S. 113
    (r'\b(\d{1,4})\s+(U\.S\.|U\.\s*S\.)\s+(\d+)\b', "us"),
    # 123 F.3d 456
    (r'\b(\d{1,4})\s+F\.\s*(\d?d?)\s+(\d+)\b', "f"),
    # 123 F. Supp. 2d 456
    (r'\b(\d{1,4})\s+F\.\s*Supp\.?\s*(\d?d?)\s+(\d+)\b', "fsupp"),
    # 123 S. Ct. 456
    (r'\b(\d{1,4})\s+S\.\s*Ct\.\s+(\d+)\b', "sct"),
    # 123 L. Ed. 2d 456
    (r'\b(\d{1,4})\s+L\.\s*Ed\.\s*(\d?d?)\s+(\d+)\b', "led"),
    # State reporters: 123 P.3d 456 / 123 N.E.2d 456 / 123 Cal. 4th 456 / etc.
    (r'\b(\d{1,4})\s+([A-Z]\.[A-Za-z\.]*\d*\w*)\s+(\d+)\b', "state"),
]


def detect_citations(text: str) -> list[dict]:
    """Return [{citation, span: [start, end], type, key}] for all detected citations."""
    out = []
    for pat, kind in CITATION_PATTERNS:
        for m in re.finditer(pat, text):
            out.append({
                "citation": m.group(0),
                "start": m.start(),
                "end": m.end(),
                "type": kind,
            })
    # Dedup overlapping
    out.sort(key=lambda x: (x["start"], -x["end"]))
    deduped = []
    for c in out:
        if deduped and c["start"] < deduped[-1]["end"]:
            continue
        deduped.append(c)
    return deduped


def lookup_citation_courtlistener(citation: str, timeout: float = 5.0) -> dict | None:
    """Look up a citation via the CourtListener public API. Returns {url, name} or None."""
    try:
        import requests
        # Use the citation lookup endpoint
        r = requests.get(
            "https://www.courtlistener.com/api/rest/v3/search/",
            params={"q": citation, "type": "o"},
            timeout=timeout,
        )
        if r.status_code == 200:
            results = (r.json() or {}).get("results") or []
            if results:
                first = results[0]
                return {
                    "case_name": first.get("caseName") or first.get("caseNameShort"),
                    "url": "https://www.courtlistener.com" + (first.get("absolute_url") or ""),
                    "court": first.get("court", ""),
                    "date_filed": first.get("dateFiled", ""),
                }
    except Exception as e:
        logger.debug("courtlistener lookup failed for %s: %s", citation, e)
    return None


def link_citations_in_transcript(segments: list[dict],
                                 lookup: bool = False) -> list[dict]:
    """3.5: detect Bluebook citations in transcript text. Returns
    [{seg_idx, citation, start, end, type, case_name?, url?}].
    """
    out = []
    for i, seg in enumerate(segments):
        text = seg.get("text") or ""
        if not text:
            continue
        for cit in detect_citations(text):
            entry = {"seg_idx": i, **cit}
            if lookup:
                meta = lookup_citation_courtlistener(cit["citation"])
                if meta:
                    entry.update(meta)
            out.append(entry)
    return out


# ---------------------------------------------------------------------------
# Phase 4.1 — exhibit direct-to-page sync
# ---------------------------------------------------------------------------

# Match patterns like:
#   "Exhibit 3, page 14"        "page 14 of Exhibit 3"
#   "Exhibit A page 7"          "Exhibit A, p. 7"
#   "turn to page 14 of Exhibit B"
EXHIBIT_PAGE_PATTERNS = [
    re.compile(r'\b[Ee]xhibit\s+([A-Za-z0-9]+)[\s,]*(?:page|p\.?)\s*(\d+)\b'),
    re.compile(r'\b(?:page|p\.?)\s*(\d+)[\s,]+(?:of\s+)?[Ee]xhibit\s+([A-Za-z0-9]+)\b'),
    re.compile(r'\b[Ee]xhibit\s+([A-Za-z0-9]+)\s+(\d+)\b'),  # "Exhibit 3 14" — ambiguous, low-conf
]


def detect_exhibit_page_references(segments: list[dict]) -> list[dict]:
    """Phase 4.1: scan segments for 'Exhibit X page Y' references.

    Returns [{seg_idx, exhibit_id, page, span: [start,end], confidence}].
    """
    refs = []
    for i, seg in enumerate(segments):
        text = seg.get("text") or ""
        if not text:
            continue
        for pat_idx, pat in enumerate(EXHIBIT_PAGE_PATTERNS):
            for m in pat.finditer(text):
                # Normalize group order — first pattern: (exhibit, page)
                # second: (page, exhibit). Third: (exhibit, page) low-conf.
                if pat_idx == 1:
                    page, exhibit_id = m.group(1), m.group(2)
                else:
                    exhibit_id, page = m.group(1), m.group(2)
                refs.append({
                    "seg_idx": i,
                    "exhibit_id": exhibit_id,
                    "page": int(page),
                    "span": [m.start(), m.end()],
                    "match_text": m.group(0),
                    "confidence": 0.9 if pat_idx < 2 else 0.5,
                })
    # Dedup by (seg_idx, span_start)
    seen = set()
    deduped = []
    for r in refs:
        key = (r["seg_idx"], r["span"][0])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    return deduped


# ---------------------------------------------------------------------------
# Phase 4.2 — cross-deposition intelligence (case-level analysis)
# ---------------------------------------------------------------------------

def cross_deposition_search(jobs: list[dict], query: str,
                            settings: dict | None = None,
                            top_k_per_depo: int = 3) -> list[dict]:
    """Phase 4.2: semantic search across all depositions in a case.

    Returns ranked matches across jobs:
      [{job_id, witness_name, seg_idx, text, score}, ...]
    """
    import numpy as np
    model = _get_embed_model()
    if model is None:
        return []
    qe = model.encode([query], normalize_embeddings=True)[0]
    out = []
    for job in jobs:
        if not job.get("transcript"):
            continue
        segs = job["transcript"].get("segments", [])
        if not segs:
            continue
        index = build_embedding_index(Path(job["dir"]), segs)
        if not index:
            continue
        sims = index["embeddings"] @ qe
        top = np.argsort(-sims)[:top_k_per_depo]
        for i in top:
            i = int(i)
            chunk = index["chunks"][i]
            out.append({
                "job_id": job.get("id") or job.get("job_id"),
                "witness_name": job.get("witness_name") or job.get("title", ""),
                "case_caption": job.get("case_caption", ""),
                "seg_idx": chunk["first_idx"],
                "range": [chunk["first_idx"], chunk["last_idx"]],
                "text": chunk["text"],
                "score": float(sims[i]),
            })
    out.sort(key=lambda x: -x["score"])
    return out


def cross_deposition_contradictions(jobs: list[dict],
                                    settings: dict | None = None,
                                    threshold: float = 0.65) -> list[dict]:
    """Phase 4.2: find contradictions BETWEEN depositions in the same case.

    Useful for impeaching a witness whose later testimony contradicts an
    earlier deposition, or contrasting two witnesses' accounts of the same
    event.
    """
    import numpy as np
    model = _get_embed_model()
    if model is None or len(jobs) < 2:
        return []

    indices = []
    for job in jobs:
        if not job.get("transcript"):
            continue
        segs = job["transcript"].get("segments", [])
        if not segs:
            continue
        idx = build_embedding_index(Path(job["dir"]), segs)
        if not idx:
            continue
        indices.append({"job": job, "index": idx})

    if len(indices) < 2:
        return []

    candidates = []
    for a_i in range(len(indices)):
        for b_i in range(a_i + 1, len(indices)):
            A = indices[a_i]
            B = indices[b_i]
            sim_matrix = A["index"]["embeddings"] @ B["index"]["embeddings"].T
            for i in range(sim_matrix.shape[0]):
                for j in range(sim_matrix.shape[1]):
                    sim = float(sim_matrix[i, j])
                    if sim < threshold:
                        continue
                    ti = A["index"]["chunks"][i]["text"]
                    tj = B["index"]["chunks"][j]["text"]
                    negs_i = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t)\b", ti, re.I))
                    negs_j = bool(re.search(r"\b(no|not|never|don'?t|didn'?t|wasn'?t)\b", tj, re.I))
                    nums_i = set(re.findall(r"\b\d+\b", ti))
                    nums_j = set(re.findall(r"\b\d+\b", tj))
                    has_signal = (negs_i != negs_j) or (
                        nums_i and nums_j and nums_i.isdisjoint(nums_j)
                    )
                    if has_signal:
                        candidates.append({
                            "job_a": A["job"].get("id") or A["job"].get("job_id"),
                            "witness_a": A["job"].get("witness_name") or A["job"].get("title", ""),
                            "range_a": [A["index"]["chunks"][i]["first_idx"], A["index"]["chunks"][i]["last_idx"]],
                            "text_a": ti,
                            "job_b": B["job"].get("id") or B["job"].get("job_id"),
                            "witness_b": B["job"].get("witness_name") or B["job"].get("title", ""),
                            "range_b": [B["index"]["chunks"][j]["first_idx"], B["index"]["chunks"][j]["last_idx"]],
                            "text_b": tj,
                            "confidence": sim,
                        })

    # LLM-validate top candidates
    candidates.sort(key=lambda c: -c["confidence"])
    out = []
    for c in candidates[:10]:
        prompt = (
            "Are these two excerpts from different depositions in the same "
            "case substantively contradictory or inconsistent? Reply JSON: "
            '{"contradiction": true|false, "type": "...", "explanation": "..."}\n\n'
            f"From {c['witness_a']}:\n{c['text_a']}\n\n"
            f"From {c['witness_b']}:\n{c['text_b']}"
        )
        resp = llm_chat([
            {"role": "system", "content": "Output ONLY JSON."},
            {"role": "user", "content": prompt},
        ], settings=settings, temperature=0.1, max_tokens=400)
        try:
            m = re.search(r'\{.*?\}', resp or "", re.S)
            j_obj = json.loads(m.group()) if m else None
        except Exception:
            j_obj = None
        if j_obj and j_obj.get("contradiction"):
            out.append({**c, "type": j_obj.get("type", "semantic"), "explanation": j_obj.get("explanation", "")})
    return out


# ---------------------------------------------------------------------------
# Phase 4.3 — real-time follow-up question suggestion (attorney aid)
# ---------------------------------------------------------------------------

def suggest_follow_up_questions(recent_segments: list[dict],
                                case_topics: list[str] | None = None,
                                covered_topics: list[str] | None = None,
                                settings: dict | None = None) -> dict:
    """Phase 4.3: surface attorney suggestions based on recent testimony.

    Inputs:
      recent_segments: last ~15 segments (live tail)
      case_topics: topics the attorney wants to cover (optional)
      covered_topics: topics already addressed (optional)

    Returns:
      {
        "suggestions": [{"question": str, "rationale": str, "topic": str}, ...],
        "missed_topics": [str, ...]
      }
    """
    if not recent_segments:
        return {"suggestions": [], "missed_topics": []}
    tail = "\n".join(
        ((s.get("speaker") or "") + ": " if s.get("speaker") else "")
        + (s.get("text") or "")
        for s in recent_segments
    )
    topics_hint = ""
    if case_topics:
        topics_hint += "\nTopics to cover: " + ", ".join(case_topics)
    if covered_topics:
        topics_hint += "\nAlready covered: " + ", ".join(covered_topics)

    prompt = (
        "You are assisting an attorney conducting a deposition. Based on "
        "the witness's last few answers, suggest up to 3 follow-up "
        "questions that would be worth asking — questions that probe "
        "inconsistency, request specifics, anchor a fact for trial, or "
        "fill a gap. Output JSON:\n"
        '{"suggestions": [{"question": "...", "rationale": "...", "topic": "..."}], '
        '"missed_topics": ["..."]}\n\n'
        f"Recent testimony:\n{tail}{topics_hint}"
    )
    resp = llm_chat([
        {"role": "system", "content": "You are a deposition strategy assistant. Output ONLY valid JSON."},
        {"role": "user", "content": prompt},
    ], settings=settings, temperature=0.5, max_tokens=900)
    try:
        m = re.search(r'\{.*\}', resp or "", re.S)
        if not m:
            return {"suggestions": [], "missed_topics": []}
        return json.loads(m.group())
    except Exception:
        return {"suggestions": [], "missed_topics": [], "raw": resp}
