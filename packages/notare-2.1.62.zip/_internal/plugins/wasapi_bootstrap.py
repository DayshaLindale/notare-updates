"""WASAPI Bootstrap — ensures pyaudiowpatch is importable for loopback capture.

Runs at startup (background thread). pyaudiowpatch is what enables true WASAPI
loopback ("System Audio") capture — capturing directly off a playback device,
the way OBS does — so Zoom/Teams audio works WITHOUT Stereo Mix or any Windows
sound-settings fiddling.

New builds bundle pyaudiowpatch into the frozen app (see Notare.spec). For
EXISTING installs that are missing it (older build, or a first launch with no
internet), this self-heals: it installs pyaudiowpatch into the app's OWN import
directory — the dir app.py lives in, which the frozen process actually imports
from — NOT into _cpu_env (which only the diarization subprocess sees; the old
bug). Falls back to downloading the matching wheel and extracting it directly
when there's no venv/pip. Takes effect on the next restart.
"""

import sys
import os
import subprocess
import logging
import threading

logger = logging.getLogger("notare.plugin.wasapi_bootstrap")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

BASE_DIR = getattr(_app, 'BASE_DIR', None)


def _import_target_dir():
    """Directory the frozen app imports packages from (where app.py + the
    bundled packages live, e.g. _internal/). Installing here makes the main
    process able to `import pyaudiowpatch` — _cpu_env does not."""
    try:
        d = os.path.dirname(os.path.abspath(_app.__file__))
        if d and os.path.isdir(d):
            return d
    except Exception:
        pass
    return str(BASE_DIR) if BASE_DIR else None


def _find_venv_python():
    """Find a real Python (for pip). Never sys.executable in a frozen exe —
    that's Notare.exe itself and would fork-bomb."""
    if not BASE_DIR:
        return None
    candidates = []
    override = os.environ.get('WHISPER_ENV_PATH', '').strip()
    if override:
        candidates.append(os.path.join(override, 'Scripts', 'python.exe'))
    for root in [str(BASE_DIR), os.path.dirname(str(BASE_DIR))]:
        for env_name in ['_gpu_env', '_cpu_env', 'notare_venv', 'Notare_venv']:
            candidates.append(os.path.join(root, env_name, 'Scripts', 'python.exe'))
    candidates.append(os.path.join(str(BASE_DIR), '_pyannote_env', 'Scripts', 'python.exe'))
    return next((p for p in candidates if os.path.exists(p)), None)


def _install_from_wheel(target):
    """pip-free fallback: download the cp<ver>-win_amd64 PyAudioWPatch wheel
    from PyPI and extract its package + compiled extension into `target`.
    Needs internet once; no venv required."""
    try:
        import urllib.request
        import json as _json
        import zipfile
        import tempfile
        tag = f"cp{sys.version_info.major}{sys.version_info.minor}"
        with urllib.request.urlopen("https://pypi.org/pypi/PyAudioWPatch/json", timeout=25) as r:
            meta = _json.loads(r.read())
        url = None
        for ver in sorted(meta.get("releases", {}), reverse=True):
            for f in meta["releases"][ver]:
                fn = f.get("filename", "")
                if fn.endswith(".whl") and tag in fn and "win_amd64" in fn:
                    url = f.get("url")
                    break
            if url:
                break
        if not url:
            logger.warning("wheel fallback: no %s-win_amd64 PyAudioWPatch wheel found on PyPI", tag)
            return False
        tmp = os.path.join(tempfile.gettempdir(), os.path.basename(url))
        urllib.request.urlretrieve(url, tmp)
        with zipfile.ZipFile(tmp) as z:
            for m in z.namelist():
                if m.startswith(("pyaudiowpatch/", "_portaudio")) or m.lower().endswith((".pyd", ".dll")):
                    z.extract(m, target)
        try:
            os.unlink(tmp)
        except Exception:
            pass
        return os.path.isdir(os.path.join(target, "pyaudiowpatch"))
    except Exception as e:
        logger.warning("wheel fallback failed: %s", e)
        return False


def _check_and_install():
    try:
        import pyaudiowpatch
        logger.info("pyaudiowpatch available (v%s)", getattr(pyaudiowpatch, '__version__', '?'))
        return
    except ImportError:
        pass

    target = _import_target_dir()
    if not target:
        logger.warning("pyaudiowpatch missing and no import dir resolved — System Audio capture disabled")
        return

    # Already placed on a previous run? It only imports after a restart.
    if os.path.isdir(os.path.join(target, "pyaudiowpatch")):
        logger.info("pyaudiowpatch present in %s but not yet imported — RESTART Notare to enable System Audio capture", target)
        return

    installed = False
    py = _find_venv_python()
    if py:
        logger.info("pyaudiowpatch missing — installing into app dir %s via %s", target, py)
        try:
            r = subprocess.run(
                [py, '-m', 'pip', 'install', 'PyAudioWPatch', '--target', target,
                 '--upgrade', '--no-deps', '--quiet', '--no-warn-script-location'],
                capture_output=True, text=True, timeout=180,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            )
            installed = (r.returncode == 0) and os.path.isdir(os.path.join(target, "pyaudiowpatch"))
            if not installed:
                logger.warning("pip --target install failed (code %s): %s", r.returncode, (r.stderr or '')[:400])
        except Exception as e:
            logger.warning("pip --target install error: %s", e)

    if not installed:
        logger.info("pyaudiowpatch: trying pip-free wheel install into %s", target)
        installed = _install_from_wheel(target)

    if installed:
        logger.info("pyaudiowpatch installed into %s — RESTART Notare to enable System Audio capture", target)
    else:
        logger.warning(
            "Could not install pyaudiowpatch — System Audio (loopback) capture unavailable. "
            "Use the Share-audio screen-share path in Mode A, or reinstall the latest build."
        )


# Run in background so it doesn't block startup.
threading.Thread(target=_check_and_install, daemon=True, name="wasapi-bootstrap").start()
logger.info("WASAPI bootstrap started (background)")
