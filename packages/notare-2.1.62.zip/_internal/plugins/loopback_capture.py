"""Plugin: WASAPI loopback capture — mic + system audio for Zoom/Teams depositions.

Replaces ffmpeg-based device enumeration with pyaudiowpatch which exposes
WASAPI loopback devices on EVERY Windows machine — no Stereo Mix needed.

Mode A captures two streams simultaneously:
  - Mic (reporter) via standard WASAPI input
  - System audio (Zoom/Teams/WebEx) via WASAPI loopback on the selected output device

Mixed into one PCM stream and transcribed in real time.
"""

import threading
import logging
import sys
import time
import queue as _stdlib_queue
from pathlib import Path

logger = logging.getLogger("notare.plugin.loopback")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded — loopback plugin requires app")

BASE_DIR = _app.BASE_DIR
JOBS = _app.JOBS


def _get_pyaudio():
    """Import pyaudiowpatch, falling back to pyaudio."""
    try:
        import pyaudiowpatch as pyaudio
        return pyaudio, True
    except ImportError:
        try:
            import pyaudio
            return pyaudio, False
        except ImportError:
            return None, False


def _list_devices_wasapi():
    """List audio devices using pyaudiowpatch with robust loopback detection.

    Loopback ("System Audio") devices are what let a reporter capture remote
    Zoom/Teams audio. On most machines they surface in the standard device scan
    with isLoopbackDevice=True — but on some they DON'T, and the reporter then
    sees her mic with no System Audio device (mics-but-no-speakers). So after
    the standard scan we ALSO pull every loopback device explicitly via
    pyaudiowpatch's loopback generator (the authoritative source), and as a
    last resort expose the default output's loopback. De-duplicated by index.
    """
    pyaudio, has_wpatch = _get_pyaudio()
    if pyaudio is None:
        return []

    p = pyaudio.PyAudio()
    devices = []
    seen = set()

    def _add(dev, idx, force_loopback=False):
        if idx is None or idx in seen:
            return
        is_loopback = bool(force_loopback or dev.get("isLoopbackDevice", False))
        if not (dev.get("maxInputChannels", 0) > 0 or is_loopback):
            return
        name = dev.get("name", f"Device {idx}")
        display_name = name.replace(" [Loopback]", "")
        if is_loopback:
            display_name = f"{display_name} (System Audio)"
        devices.append({
            "id": idx,
            "name": display_name,
            "raw_name": name,
            "channels": max(dev.get("maxInputChannels", 0), dev.get("maxOutputChannels", 0)) or 2,
            "sample_rate": int(dev.get("defaultSampleRate", 48000) or 48000),
            "is_loopback": is_loopback,
        })
        seen.add(idx)

    try:
        # Find WASAPI host API
        wasapi_idx = None
        for i in range(p.get_host_api_count()):
            info = p.get_host_api_info_by_index(i)
            if "WASAPI" in info.get("name", ""):
                wasapi_idx = i
                break

        if wasapi_idx is None:
            # No WASAPI host API — list inputs, flag stereo-mix/loopback by name.
            for i in range(p.get_device_count()):
                dev = p.get_device_info_by_index(i)
                if dev["maxInputChannels"] > 0:
                    nm = dev["name"].lower()
                    _add(dev, i, force_loopback=("stereo mix" in nm or "loopback" in nm))
            return devices

        # 1) Standard WASAPI scan — inputs + any already-flagged loopback.
        for i in range(p.get_device_count()):
            dev = p.get_device_info_by_index(i)
            if dev.get("hostApi") != wasapi_idx:
                continue
            _add(dev, i)

        # 2) Robust: explicitly enumerate every loopback device. This is what
        #    fixes "I see my mic but no System Audio" — on machines where the
        #    flag doesn't surface in step 1, the generator still finds them.
        if has_wpatch and hasattr(p, "get_loopback_device_info_generator"):
            try:
                for lb in p.get_loopback_device_info_generator():
                    _add(lb, lb.get("index"), force_loopback=True)
            except Exception as e:
                logger.warning("loopback generator enumeration failed: %s", e)

        # 3) Last resort: if STILL no loopback surfaced, expose the default
        #    output device's loopback so system audio is always capturable.
        if not any(d["is_loopback"] for d in devices) and has_wpatch \
                and hasattr(p, "get_loopback_device_info_generator"):
            try:
                winfo = p.get_host_api_info_by_index(wasapi_idx)
                out_idx = winfo.get("defaultOutputDevice", -1)
                if out_idx is not None and int(out_idx) >= 0:
                    out_name = p.get_device_info_by_index(int(out_idx)).get("name", "")
                    for lb in p.get_loopback_device_info_generator():
                        if out_name and out_name in lb.get("name", ""):
                            _add(lb, lb.get("index"), force_loopback=True)
                            break
            except Exception as e:
                logger.warning("default-output loopback fallback failed: %s", e)
    finally:
        p.terminate()

    return devices


async def _patched_list_audio_devices():
    """List audio devices using WASAPI with proper loopback support.

    No params (no Request needed) — FastAPI handles the no-param GET fine.
    """
    from starlette.responses import JSONResponse
    try:
        devices = _list_devices_wasapi()
        if devices:
            n_loop = sum(1 for d in devices if d["is_loopback"])
            n_inp = sum(1 for d in devices if not d["is_loopback"])
            logger.info("WASAPI device enumeration: %d total (%d loopback, %d input)",
                        len(devices), n_loop, n_inp)
            # Detail at debug level for triage when the UI shows wrong devices
            for d in devices:
                logger.debug("  device id=%s loopback=%s ch=%s name=%s",
                             d.get("id"), d.get("is_loopback"),
                             d.get("channels"), d.get("name"))
            return JSONResponse({"devices": devices})

        # Fallback to ffmpeg enumeration if pyaudiowpatch unavailable
        logger.warning("WASAPI enumeration returned 0 devices, falling back to ffmpeg")
        return await _original_list_devices()
    except Exception as e:
        logger.error("Device enumeration error: %s", e)
        return JSONResponse({"devices": [], "error": str(e)})


def _patched_server_side_capture(job_id, job, state):
    """Server-side capture with WASAPI loopback for Mode A."""
    import numpy as np

    SAMPLE_RATE = 16000
    # 2.0s chunks give small.en CPU enough headroom (~0.8-1.2s inference)
    # to keep up under CPU contention without the ffmpeg stdout pipe filling
    # and stalling capture. 1.5s was tight; 2.0s gives ~0.8s of slack.
    SEGMENT_SECONDS = 2.0
    SEGMENT_SAMPLES = int(SAMPLE_RATE * SEGMENT_SECONDS)

    device_name = state.get("device_name", "")
    loopback_name = state.get("loopback_name", "")
    loopback_id = state.get("loopback_id")
    device_id = state.get("device_id", 0)
    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    recording_path = audio_dir / "live_recording.wav"

    # Get streaming model
    model = None
    if hasattr(_app, '_get_streaming_model'):
        try:
            model = _app._get_streaming_model()
        except Exception as e:
            logger.error("Failed to get streaming model: %s", e)
    if not model:
        logger.error("Could not load streaming model for live capture")
        state["running"] = False
        return

    # Streaming speaker diarization (online cosine clustering against ECAPA
    # embeddings). Falls back to SPEAKER_00 if ECAPA isn't available.
    state["ecapa_session"] = None
    state["speaker_centroids"] = []  # list of {"label", "emb", "count"}
    try:
        _ecapa_path = BASE_DIR / "_speaker_models" / "ecapa_tdnn.onnx"
        if not _ecapa_path.exists():
            _ecapa_path = BASE_DIR / "_internal" / "_speaker_models" / "ecapa_tdnn.onnx"
        if _ecapa_path.exists():
            import onnxruntime as _ort
            state["ecapa_session"] = _ort.InferenceSession(
                str(_ecapa_path), providers=['CPUExecutionProvider'])
            logger.info("Streaming diarization: ECAPA loaded")
        else:
            logger.info("Streaming diarization: ECAPA not found — single-speaker mode")
    except Exception as _ee:
        logger.warning("Streaming diarization init failed: %s", _ee)

    pyaudio_mod, has_wpatch = _get_pyaudio()

    # Mode B (multi-mic): if the selected device exposes >1 input channel,
    # use the per-channel capture path so each mic on the device gets its
    # own speaker label. No diarization needed since channel == speaker.
    #
    # Read mode from job["live_mode"] as the source of truth — the original
    # /api/live/start handler in app.py sets this. The plugin's wrapped
    # endpoint also sets state["mode"], but FastAPI's route.endpoint swap
    # doesn't always rewire the actual called handler (route.app is built
    # at route-creation time from endpoint, not re-evaluated per request),
    # so we may be running with the original handler's state dict that
    # lacks mode/num_channels. Job is reliable.
    mode = state.get("mode") or (job or {}).get("live_mode") or "C"
    num_channels = int(state.get("num_channels") or 0)
    if mode == "B" and num_channels < 2:
        # State didn't carry channels — detect them now via pyaudiowpatch.
        num_channels = _detect_device_channels(device_name)
        state["num_channels"] = num_channels  # cache for any downstream readers
    if mode == "B" and num_channels >= 2:
        logger.info("Multichannel capture: device='%s', %d channels",
                    device_name, num_channels)
        _ffmpeg_multichannel_capture(model, state, device_name,
                                      SAMPLE_RATE, SEGMENT_SECONDS, recording_path,
                                      job_id, num_channels)
        return

    # Mode A validation: mic and loopback must be DIFFERENT devices. The
    # original v2.1.43 validation lived in _wrapped_start_live but FastAPI
    # route.endpoint swap doesn't always rewire — so we re-validate here at
    # the actual capture-dispatch site, which IS reached because we patch
    # _app._server_side_capture (module attr) rather than a route.
    if mode == "A":
        same_id = (loopback_id is not None and device_id is not None
                   and int(loopback_id) == int(device_id))
        same_name = (loopback_name and device_name and loopback_name == device_name)
        if same_id or same_name:
            logger.warning(
                "Mode A capture rejected: mic and loopback are the SAME device "
                "(id=%s/%s, name='%s'/'%s'). Mode A needs distinct mic + system-audio "
                "sources. Falling back to single-mic capture (Mode C behavior).",
                device_id, loopback_id, device_name, loopback_name)
            # Fall through to mono _ffmpeg_capture (Mode C single-mic) so the
            # session at least produces a usable mic-only transcript instead
            # of nonsense duplicate-channel garbage.
            _ffmpeg_capture(model, state, device_name, "",
                            SAMPLE_RATE, SEGMENT_SECONDS, recording_path, job_id)
            return

    # Mode A (Zoom remote / Teams / WebEx): mic + system loopback as separate
    # channels. WASAPI loopback devices are NOT readable by ffmpeg dshow —
    # they only exist in the WASAPI host API. So if the user picked a real
    # WASAPI loopback (name contains "[Loopback]" or "(System Audio)"),
    # capture must go through pyaudiowpatch's dual-stream path. The ffmpeg
    # amerge path is preserved as a fallback for legacy Stereo Mix devices
    # that DO live in dshow.
    if mode == "A" and loopback_name and device_name:
        is_wasapi_loopback = (
            "[Loopback]" in loopback_name
            or "(System Audio)" in loopback_name
        )
        if is_wasapi_loopback and has_wpatch and loopback_id is not None:
            logger.info("Mode A WASAPI dual-source: mic='%s' + loopback='%s' (id=%s)",
                        device_name, loopback_name, loopback_id)
            _wasapi_dual_capture(pyaudio_mod, model, state, device_id, loopback_id,
                                 SAMPLE_RATE, SEGMENT_SAMPLES, recording_path, job_id)
            return
        elif not is_wasapi_loopback:
            logger.info("Mode A ffmpeg dual-source (legacy/Stereo Mix path): mic='%s', loopback='%s'",
                        device_name, loopback_name)
            _ffmpeg_dual_source_capture(model, state, device_name, loopback_name,
                                         SAMPLE_RATE, SEGMENT_SECONDS, recording_path, job_id)
            return
        else:
            logger.warning("Mode A with WASAPI loopback name '%s' but pyaudiowpatch unavailable — "
                           "falling back to mono mic capture", loopback_name)
            _ffmpeg_capture(model, state, device_name, "",
                            SAMPLE_RATE, SEGMENT_SECONDS, recording_path, job_id)
            return

    # Try WASAPI loopback capture if we have pyaudiowpatch and a loopback device
    if has_wpatch and loopback_id is not None:
        logger.info("WASAPI dual capture: mic_id=%s + loopback_id=%s", device_id, loopback_id)
        _wasapi_dual_capture(pyaudio_mod, model, state, device_id, loopback_id,
                             SAMPLE_RATE, SEGMENT_SAMPLES, recording_path, job_id)
        return

    # Fallback to ffmpeg capture (single device or Stereo Mix)
    logger.info("Falling back to ffmpeg capture: device='%s', loopback='%s'", device_name, loopback_name)
    _ffmpeg_capture(model, state, device_name, loopback_name,
                    SAMPLE_RATE, SEGMENT_SECONDS, recording_path, job_id)


def _wasapi_dual_capture(pyaudio_mod, model, state, mic_id, loopback_id,
                          sample_rate, segment_samples, recording_path, job_id):
    """Capture mic + WASAPI loopback, mix, transcribe.

    Parity with _ffmpeg_capture: Whisper-first + per-segment ECAPA on tight
    speech windows, segments persisted to job.transcript via
    _app._append_segment_to_job, audio_file attached on stop, configurable
    initial_prompt, ms-based segment timestamps."""
    from pathlib import Path as _Path
    import numpy as np
    import wave

    job = JOBS.get(job_id)
    p = pyaudio_mod.PyAudio()

    try:
        mic_info = p.get_device_info_by_index(int(mic_id))
        lb_info = p.get_device_info_by_index(int(loopback_id))
    except Exception as e:
        logger.error("Failed to get device info: %s", e)
        state["running"] = False
        p.terminate()
        return

    mic_rate = int(mic_info["defaultSampleRate"])
    lb_rate = int(lb_info["defaultSampleRate"])
    lb_channels = max(lb_info.get("maxInputChannels", 2), 1)

    logger.info("Mic: '%s' @ %dHz | Loopback: '%s' @ %dHz %dch",
                mic_info["name"], mic_rate, lb_info["name"], lb_rate, lb_channels)

    # Buffers for mixing
    mic_buffer = bytearray()
    lb_buffer = bytearray()
    lock = threading.Lock()

    def mic_callback(in_data, frame_count, time_info, status):
        with lock:
            mic_buffer.extend(in_data)
        return (None, pyaudio_mod.paContinue)

    def lb_callback(in_data, frame_count, time_info, status):
        with lock:
            lb_buffer.extend(in_data)
        return (None, pyaudio_mod.paContinue)

    try:
        mic_stream = p.open(
            format=pyaudio_mod.paInt16,
            channels=1,
            rate=mic_rate,
            input=True,
            input_device_index=int(mic_id),
            frames_per_buffer=1024,
            stream_callback=mic_callback,
        )

        lb_stream = p.open(
            format=pyaudio_mod.paInt16,
            channels=lb_channels,
            rate=lb_rate,
            input=True,
            input_device_index=int(loopback_id),
            frames_per_buffer=1024,
            stream_callback=lb_callback,
        )
    except Exception as e:
        logger.error("Failed to open audio streams: %s", e)
        state["running"] = False
        p.terminate()
        return

    mic_stream.start_stream()
    lb_stream.start_stream()
    logger.info("WASAPI dual capture started (mic + loopback)")

    # Save 2-channel WAV (mic on ch0, loopback on ch1). Post-stop offline
    # _diarize_audio reads the saved WAV; with 2 channels it gets the same
    # source separation as our live processing.
    wav_file = None
    try:
        wav_file = wave.open(str(recording_path), 'wb')
        wav_file.setnchannels(2)  # NEW: 2-channel for separated mic+loopback
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
    except Exception as e:
        logger.warning("Could not open WAV file for saving: %s", e)

    segment_seconds = segment_samples / sample_rate  # derived from caller (1.5s default)
    mic_bytes_per_segment = int(mic_rate * 2 * segment_seconds)
    lb_bytes_per_segment = int(lb_rate * 2 * lb_channels * segment_seconds)

    # ── Multi-worker ASR pipeline ──
    # Channel labels closure used by both inline and pipeline paths.
    channel_labels = (job or {}).get("channel_labels") or []
    def _label(ch, _labels=channel_labels):
        if ch < len(_labels) and _labels[ch]:
            return _labels[ch]
        return "Reporter" if ch == 0 else "Remote (Zoom)"

    # Initialize per-channel gains from saved settings (last-used values
    # carry forward; default 1.0 = no change). Reporter adjusts via the
    # sliders next to each live level meter.
    try:
        state["mic_gain"] = float(_app.SETTINGS.get("mic_gain_default", 1.0))
        state["lb_gain"]  = float(_app.SETTINGS.get("lb_gain_default",  1.0))
    except Exception:
        state["mic_gain"] = 1.0
        state["lb_gain"]  = 1.0

    asr_input_q, asr_shutdown = _start_asr_pipeline(
        state, model, state.get("ecapa_session"),
        sample_rate, segment_seconds,
        _label, job, diarize_channels={1},
    )
    seg_id = 0

    try:
        while state["running"]:
            time.sleep(0.5)

            # Live-level monitoring — peek at the last ~200ms of audio in
            # each buffer and stash RMS on state so /api/live/level can serve
            # it to the client. Without this, the mic / platform activity
            # bars in live.html stay at 0% during server-side capture (the
            # browser doesn't have the mic stream — the server does).
            #
            # Apply per-channel GAIN here so the meter reflects what Whisper
            # will actually hear (gain is also applied at extraction below).
            try:
                _mic_g = float(state.get("mic_gain", 1.0))
                _lb_g  = float(state.get("lb_gain",  1.0))
                with lock:
                    peek_mic_n = min(len(mic_buffer), int(mic_rate * 2 * 0.2))
                    peek_lb_n  = min(len(lb_buffer),  int(lb_rate * 2 * lb_channels * 0.2))
                    peek_mic_bytes = bytes(mic_buffer[-peek_mic_n:]) if peek_mic_n else b''
                    peek_lb_bytes  = bytes(lb_buffer[-peek_lb_n:])  if peek_lb_n  else b''
                if peek_mic_bytes:
                    mic_peek = np.frombuffer(peek_mic_bytes, dtype=np.int16).astype(np.float32) / 32768.0
                    mic_peek = np.clip(mic_peek * _mic_g, -1.0, 1.0)
                    state["mic_rms"] = float(np.sqrt(np.mean(mic_peek ** 2) + 1e-12))
                else:
                    state["mic_rms"] = 0.0
                if peek_lb_bytes:
                    lb_peek = np.frombuffer(peek_lb_bytes, dtype=np.int16).astype(np.float32) / 32768.0
                    if lb_channels > 1 and len(lb_peek) > 0:
                        lb_peek = lb_peek.reshape(-1, lb_channels).mean(axis=1)
                    lb_peek = np.clip(lb_peek * _lb_g, -1.0, 1.0)
                    state["lb_rms"] = float(np.sqrt(np.mean(lb_peek ** 2) + 1e-12))
                else:
                    state["lb_rms"] = 0.0
            except Exception:
                pass

            with lock:
                has_mic = len(mic_buffer) >= mic_bytes_per_segment
                has_lb = len(lb_buffer) >= lb_bytes_per_segment
                if not (has_mic or has_lb):
                    continue

                # Extract segments
                if has_mic:
                    mic_data = bytes(mic_buffer[:mic_bytes_per_segment])
                    del mic_buffer[:mic_bytes_per_segment]
                else:
                    mic_data = b'\x00' * mic_bytes_per_segment

                if has_lb:
                    lb_data = bytes(lb_buffer[:lb_bytes_per_segment])
                    del lb_buffer[:lb_bytes_per_segment]
                else:
                    lb_data = b'\x00' * lb_bytes_per_segment

            # Convert to numpy
            mic_np = np.frombuffer(mic_data, dtype=np.int16).astype(np.float32) / 32768.0
            lb_np = np.frombuffer(lb_data, dtype=np.int16).astype(np.float32) / 32768.0

            # Apply per-channel gain (set via /api/live/gain/{job_id}). Default
            # 1.0 = no change. Clipped to [-1, 1] to prevent overdrive — reporter
            # gets the volume balance they want without distorting the audio
            # going into Whisper or the saved WAV.
            mic_gain = float(state.get("mic_gain", 1.0))
            lb_gain  = float(state.get("lb_gain",  1.0))
            if mic_gain != 1.0:
                mic_np = np.clip(mic_np * mic_gain, -1.0, 1.0)
            if lb_gain != 1.0:
                lb_np  = np.clip(lb_np  * lb_gain,  -1.0, 1.0)

            # Downmix loopback to mono if stereo
            if lb_channels > 1:
                lb_np = lb_np.reshape(-1, lb_channels).mean(axis=1)

            # Resample both to target sample rate if needed
            if mic_rate != sample_rate:
                mic_np = np.interp(
                    np.linspace(0, len(mic_np), segment_samples),
                    np.arange(len(mic_np)), mic_np
                )
            if lb_rate != sample_rate:
                lb_np = np.interp(
                    np.linspace(0, len(lb_np), segment_samples),
                    np.arange(len(lb_np)), lb_np
                )

            # Trim to same length and stack as 2-channel
            min_len = min(len(mic_np), len(lb_np))
            mic_np = mic_np[:min_len]
            lb_np = lb_np[:min_len]
            per_channel = np.column_stack([mic_np, lb_np]).astype(np.float32)

            # Manual mute toggle override + smart duck gate (Mode A only —
            # mic should be silent when its only content is system-audio leak).
            if state.get("mic_muted"):
                per_channel[:, 0] = 0.0
            else:
                per_channel[:, 0] = _duck_mic_when_system_audible(
                    per_channel[:, 0], per_channel[:, 1], sample_rate)

            # Save 2-channel interleaved [L, R, L, R, ...]
            if wav_file:
                try:
                    interleaved = (per_channel * 32768).astype(np.int16)
                    wav_file.writeframes(interleaved.tobytes())
                except Exception:
                    pass

            rms_per_ch = [
                float(np.sqrt(np.mean(per_channel[:, ci] ** 2) + 1e-12))
                for ci in range(2)
            ]
            logger.info("WASAPI dual ch RMS: ch0=%.4f (mic) ch1=%.4f (loopback) qlen=%d",
                        rms_per_ch[0], rms_per_ch[1], asr_input_q.qsize())

            # Push segment to the multi-worker ASR pipeline. Workers run
            # Whisper in parallel; reassembler emits in seg_id order with
            # streaming-ECAPA speaker labels + broadcast. Queue is unbounded
            # so audio is never dropped; if workers fall behind, queue grows
            # but eventually catches up (2-3 workers handle long sessions).
            asr_input_q.put({
                "seg_id": seg_id,
                "total_ms_at_capture": state["total_ms"],
                "per_channel": per_channel,
                "rms_per_ch": rms_per_ch,
                "num_channels": 2,
            })
            seg_id += 1
            state["total_ms"] += int(segment_seconds * 1000)

    finally:
        try: mic_stream.stop_stream(); mic_stream.close()
        except Exception: pass
        try: lb_stream.stop_stream(); lb_stream.close()
        except Exception: pass
        try: p.terminate()
        except Exception: pass
        if wav_file:
            try: wav_file.close()
            except Exception: pass
        # Drain ASR pipeline cleanly — waits for queue to empty so no
        # captured segment is lost. Idempotent with /api/live/stop's drain.
        try:
            asr_shutdown(timeout=20)
        except Exception as _se:
            logger.warning("ASR shutdown error: %s", _se)
        state["running"] = False
        # Attach saved 2-channel WAV to job for editor playback / post-stop diarization
        try:
            _rp = _Path(str(recording_path))
            if _rp.exists() and _rp.stat().st_size > 1000 and job is not None:
                job["audio_file"] = _rp.name
                job["audio_channels"] = 2
                _app._save_job(job)
                logger.info("Live recording saved (WASAPI 2ch): %s (%d bytes)",
                            _rp, _rp.stat().st_size)
        except Exception as _se:
            logger.debug("audio_file attach failed: %s", _se)
        logger.info("WASAPI dual capture stopped for job %s", job_id)


_DEPOSITION_PROMPT = (
    "The following is a deposition transcript. Speakers include attorneys, "
    "witnesses, the court, and the court reporter. Use proper legal terminology, "
    "names, and case-related vocabulary."
)


def _live_initial_prompt(job=None):
    """Return the prompt to bias Whisper's live decoding, or None for unbiased.

    Priorities (highest first):
      1. Matter-intake vocabulary — when the active job has filled-in
         attorneys / witness / case_caption / court_name / reporter, we
         build a short 'expected terms' prompt so Whisper biases toward
         those names. This is the strongest accuracy lever for live
         capture (case-specific names are the most-mistranscribed words).
      2. SETTINGS['live_initial_prompt'] override — explicit text wins
         over auto-generated.
      3. SETTINGS['live_initial_prompt'] = 'deposition' — built-in legal.
      4. None — unbiased.

    The deposition prompt is intentionally avoided for general content
    because it makes Whisper wedge 'court' / 'attorney' into unrelated
    speech.
    """
    p = (_app.SETTINGS.get("live_initial_prompt") or "").strip()
    if p:
        if p.lower() == "deposition":
            return _DEPOSITION_PROMPT
        return p

    # Auto-build from matter intake on the job
    if job:
        terms = []
        # Witness
        w = (job.get("witness") or "").strip()
        if w:
            terms.append(w)
        # Reporter
        r = (job.get("reporter_name") or "").strip()
        if r:
            terms.append(r)
        # Court / case caption — full strings (Whisper handles them OK as prompt)
        cap = (job.get("case_caption") or "").strip()
        if cap:
            terms.append(cap)
        court = (job.get("court_name") or "").strip()
        if court:
            terms.append(court)
        # Attorneys list — names + firms
        atts = job.get("attorneys") or job.get("speakers") or []
        if isinstance(atts, list):
            for a in atts:
                if not isinstance(a, dict):
                    continue
                nm = (a.get("name") or "").strip()
                if nm: terms.append(nm)
                fm = (a.get("firm") or "").strip()
                if fm: terms.append(fm)
        if terms:
            # Cap length — Whisper's prompt buffer is ~224 tokens.
            joined = ", ".join(dict.fromkeys(terms))  # dedup, preserve order
            if len(joined) > 600:
                joined = joined[:600]
            return (
                "Court proceeding. Expected speakers and terms: "
                + joined + "."
            )
    return None


def _assign_streaming_speaker(audio_np, sample_rate, state):
    """Compute ECAPA embedding for this audio chunk and assign a speaker label.

    Online cosine clustering with three structural fixes after observing
    centroid drift + label flip-flop in production:
      1) Warmup-only centroid updates — the first 5 high-confidence matches
         define the centroid, then it freezes. Prevents borderline-match
         drift toward the midpoint between two voices.
      2) Continuity hysteresis — if the previous segment's speaker scores
         within 0.08 of the best match, stick with it. Stops oscillation
         when two speakers' similarities to the embedding are close.
      3) Tri-banded thresholds — clear-match (>0.70) updates centroid,
         borderline (0.50-0.70) labels-only-no-update, ambiguous (0.40-0.50)
         inherits last_speaker, distinct (<0.40) creates new speaker.
    """
    import numpy as np
    session = state.get("ecapa_session")
    last_speaker = state.get("last_speaker")
    fallback = last_speaker or "SPEAKER_00"
    if session is None:
        return fallback
    if len(audio_np) < int(sample_rate * 0.5):
        return fallback
    try:
        feats = _app._compute_mel_fbank(audio_np, sample_rate)
        feats = feats.reshape(1, feats.shape[0], feats.shape[1])
        emb = session.run(None, {'feats': feats})[0][0]
        emb = emb / (np.linalg.norm(emb) + 1e-8)

        centroids = state["speaker_centroids"]
        if not centroids:
            label = "SPEAKER_00"
            centroids.append({"label": label, "emb": emb, "count": 1})
            state["last_speaker"] = label
            logger.info("diar: first speaker — %s", label)
            return label

        # Score against all centroids
        scored = [(c, float(np.dot(emb, c["emb"]))) for c in centroids]
        scored.sort(key=lambda x: -x[1])
        best_c, best_sim = scored[0]
        last_sim = next((s for c, s in scored if c["label"] == last_speaker), -1.0)

        # Tuned to observed distribution: same-speaker noise floor is ~0.55,
        # different-speaker ceiling is ~0.45. Three bands separate "definitely
        # same / drift centroid" from "borderline / use continuity" from
        # "definitely new / split".
        HIGH_CONFIDENCE = 0.70
        BORDERLINE = 0.50
        NEW_SPEAKER_BELOW = 0.40
        WARMUP_COUNT = 5
        CONTINUITY_TOLERANCE = 0.08
        MAX_SPEAKERS = 8

        if best_sim >= HIGH_CONFIDENCE:
            # Clear match — update centroid only during its warmup window
            if best_c["count"] < WARMUP_COUNT:
                new_emb = (best_c["emb"] * best_c["count"] + emb) / (best_c["count"] + 1)
                best_c["emb"] = new_emb / (np.linalg.norm(new_emb) + 1e-8)
            best_c["count"] += 1
            label = best_c["label"]
            logger.info("diar: %s (sim=%.3f, n=%d) [match]",
                        label, best_sim, best_c["count"])
        elif best_sim >= BORDERLINE:
            # Borderline — favor continuity if last speaker scored close
            if last_speaker and last_sim >= best_sim - CONTINUITY_TOLERANCE:
                label = last_speaker
                logger.info("diar: %s (sim=%.3f, last=%.3f) [continuity]",
                            label, best_sim, last_sim)
            else:
                label = best_c["label"]
                logger.info("diar: %s (sim=%.3f) [borderline-no-update]",
                            label, best_sim)
            # Don't update centroid — keeps it pure
        elif best_sim < NEW_SPEAKER_BELOW and len(centroids) < MAX_SPEAKERS:
            # Distinct — new speaker
            label = f"SPEAKER_{len(centroids):02d}"
            centroids.append({"label": label, "emb": emb, "count": 1})
            logger.info("diar: NEW %s (best prior sim=%.3f)", label, best_sim)
        else:
            # Ambiguous middle — inherit last speaker rather than guess
            label = last_speaker or best_c["label"]
            logger.info("diar: %s (sim=%.3f) [inherit-last]", label, best_sim)

        state["last_speaker"] = label
        return label
    except Exception as e:
        logger.warning("diar: step failed: %s", e)
        return fallback


def _detect_device_channels(device_name):
    """Query the actual input-channel count of a named device via pyaudiowpatch.

    Single-input mics report 1; multi-input audio interfaces (e.g. M-Track Duo HD
    with two mics plugged in) report 2+. Falls back to 1 if pyaudiowpatch isn't
    available or the device can't be located."""
    try:
        pyaudio_mod, _has_wp = _get_pyaudio()
        if pyaudio_mod is None:
            return 1
        p = pyaudio_mod.PyAudio()
        try:
            device_lower = (device_name or "").lower()
            best_match_ch = 1
            for i in range(p.get_device_count()):
                info = p.get_device_info_by_index(i)
                name = info.get("name", "")
                if not name:
                    continue
                # Match on device-name substring (dshow names sometimes have
                # adapter prefixes like "(2- M-Track...)" — pyaudio names match
                # the friendly name without the dshow prefix)
                if device_lower and (device_lower in name.lower() or name.lower() in device_lower):
                    nch = int(info.get("maxInputChannels", 1) or 1)
                    if nch > best_match_ch:
                        best_match_ch = nch
            return best_match_ch
        finally:
            p.terminate()
    except Exception as _e:
        logger.debug("Channel detect failed for %r: %s", device_name, _e)
        return 1


def _duck_mic_when_system_audible(mic_audio, loopback_audio, sample_rate,
                                    window_ms=100,
                                    loopback_floor=0.005,
                                    leak_xcorr_thresh=0.45):
    """Mode A smart duck gate: mute mic only in windows where the mic signal
    is correlated with the loopback (= pure leak). When the reporter is
    speaking during system audio, the mic carries independent voice content
    on top of any leak, so the cross-correlation drops and the mic stays open.

    Three states, decided per ~100 ms window:
      1) System silent → keep mic (no need to gate; reporter audible)
      2) System loud + mic ≈ scaled loopback → pure leak → mute mic
      3) System loud + mic has independent content → reporter speaking
         through it → keep mic intact (transcribes correctly; cross-talk
         dedup downstream still catches anything that genuinely duplicates)

    `loopback_floor` (RMS): below this the system is "silent enough" that
    we don't gate at all.
    `leak_xcorr_thresh`: normalized correlation above which mic is treated
    as pure leak. 0.45 is empirically a clean separator — same-signal
    typically scores 0.5-0.9, mic-with-reporter-voice scores 0.1-0.3.
    """
    import numpy as np
    n = len(mic_audio)
    if n != len(loopback_audio):
        return mic_audio
    win = max(1, int(sample_rate * window_ms / 1000))
    out = mic_audio.astype(np.float32).copy()
    muted_windows = 0
    total_windows = 0
    for start in range(0, n, win):
        end = min(start + win, n)
        m = mic_audio[start:end]
        l = loopback_audio[start:end]
        l_rms = float(np.sqrt(np.mean(l * l) + 1e-12))
        if l_rms < loopback_floor:
            continue  # System silent — leave mic alone
        m_norm = float(np.linalg.norm(m))
        l_norm = float(np.linalg.norm(l))
        total_windows += 1
        if m_norm < 1e-6 or l_norm < 1e-6:
            continue
        # Normalized cross-correlation at lag 0 (windows are short enough that
        # acoustic delay across the room is small relative to window size)
        xcorr = float(abs(np.dot(m, l)) / (m_norm * l_norm))
        if xcorr > leak_xcorr_thresh:
            # Mic is correlated with loopback in this window → pure leak
            out[start:end] = 0.0
            muted_windows += 1
    if total_windows:
        logger.debug("smart-duck: muted %d/%d windows of leak (system was playing)",
                     muted_windows, total_windows)
    return out


def _ffmpeg_dual_source_capture(model, state, device_name, loopback_name,
                                 sample_rate, segment_seconds, recording_path, job_id):
    """Mode A separate-channel capture: mic (ch0=reporter) + system loopback
    (ch1=remote Zoom/Teams audio) merged via ffmpeg amerge so they stay on
    distinct channels rather than being acoustically mixed.

    Architectural advantage over the legacy amix path:
      - Reporter audio and remote audio are never blended — no need to
        acoustically separate them; they're on different channels by source.
      - Reuses the multichannel transcribe path (Whisper-per-channel +
        three-stage crosstalk gate + text dedup) so any acoustic leak
        from the reporter's speakers back into their mic gets caught
        the same way as Mode B mic-bleed.
      - Saved 2-channel WAV lets post-stop offline _diarize_audio split
        the loopback channel into distinct remote speakers (Witness,
        Counsel, etc.) via global ECAPA clustering.
    """
    import subprocess
    import numpy as np
    from pathlib import Path as _Path

    NUM_CH = 2
    job = JOBS.get(job_id)
    channel_labels = (job or {}).get("channel_labels") or []
    def _label(ch):
        if ch < len(channel_labels) and channel_labels[ch]:
            return channel_labels[ch]
        return "Reporter" if ch == 0 else "Remote (Zoom)"

    SEGMENT_BYTES = int(sample_rate * 2 * NUM_CH * segment_seconds)
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"

    # amerge places mic on ch0, loopback on ch1 (downmixed to mono internally
    # if loopback is stereo). Different from amix which would blend them.
    ffmpeg_cmd = [
        ffmpeg_bin, "-y",
        "-f", "dshow", "-i", f"audio={device_name}",
        "-f", "dshow", "-i", f"audio={loopback_name}",
        "-filter_complex",
        "[0:a]aformat=channel_layouts=mono[a0];"
        "[1:a]aformat=channel_layouts=mono[a1];"
        "[a0][a1]amerge=inputs=2[out]",
        "-map", "[out]",
        "-ar", str(sample_rate), "-ac", str(NUM_CH),
        "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1",
    ]
    save_cmd = [
        ffmpeg_bin, "-y",
        "-f", "dshow", "-i", f"audio={device_name}",
        "-f", "dshow", "-i", f"audio={loopback_name}",
        "-filter_complex",
        "[0:a]aformat=channel_layouts=mono[a0];"
        "[1:a]aformat=channel_layouts=mono[a1];"
        "[a0][a1]amerge=inputs=2[out]",
        "-map", "[out]",
        "-ar", str(sample_rate), "-ac", str(NUM_CH),
        "-acodec", "pcm_s16le", str(recording_path),
    ]

    save_proc = None
    try:
        proc = subprocess.Popen(
            ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        save_proc = subprocess.Popen(
            save_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except Exception as e:
        logger.error("Failed to start dual-source ffmpeg: %s", e)
        state["running"] = False
        return

    logger.info("Dual-source capture started: mic='%s', loopback='%s', labels=[%s, %s]",
                device_name, loopback_name, _label(0), _label(1))

    # Spin up the multi-worker ASR pipeline. Workers run Whisper in
    # parallel; reassembler applies labels + broadcasts in order.
    # Worker count comes from state (tier-aware) or defaults to 2.
    asr_input_q, asr_shutdown = _start_asr_pipeline(
        state, model, state.get("ecapa_session"),
        sample_rate, segment_seconds,
        _label, job, diarize_channels={1},
    )

    audio_buffer = bytearray()
    seg_id = 0
    try:
        while state["running"]:
            chunk = proc.stdout.read(8192)
            if not chunk:
                break
            audio_buffer.extend(chunk)

            if len(audio_buffer) >= SEGMENT_BYTES:
                segment_data = bytes(audio_buffer[:SEGMENT_BYTES])
                audio_buffer = audio_buffer[SEGMENT_BYTES:]
                interleaved = (np.frombuffer(segment_data, dtype=np.int16)
                                 .astype(np.float32) / 32768.0)
                per_channel = interleaved.reshape(-1, NUM_CH)

                # If reporter has hit the manual mute toggle, hard-zero the
                # mic channel (overrides the smart duck gate). Loopback
                # keeps capturing normally.
                if state.get("mic_muted"):
                    ducked_mic = np.zeros_like(per_channel[:, 0])
                else:
                    # Smart duck gate: mute mic where it's correlated with
                    # loopback (= leak), keep mic intact when reporter
                    # speaks independently.
                    ducked_mic = _duck_mic_when_system_audible(
                        per_channel[:, 0], per_channel[:, 1], sample_rate)
                per_channel = np.column_stack([ducked_mic, per_channel[:, 1]])

                rms_per_ch = []
                for ch_idx in range(NUM_CH):
                    ch = per_channel[:, ch_idx]
                    rms_per_ch.append(float(np.sqrt(np.mean(ch * ch) + 1e-12)))
                logger.info("dual ch RMS (post-duck): ch0=%.4f (mic) ch1=%.4f (loopback) qlen=%d",
                            rms_per_ch[0], rms_per_ch[1], asr_input_q.qsize())

                # Push to ASR pipeline — never blocks, never drops audio.
                # Workers transcribe in parallel; reassembler emits in order.
                asr_input_q.put({
                    "seg_id": seg_id,
                    "total_ms_at_capture": state["total_ms"],
                    "per_channel": per_channel,
                    "rms_per_ch": rms_per_ch,
                    "num_channels": NUM_CH,
                })
                seg_id += 1
                state["total_ms"] += int(segment_seconds * 1000)
    finally:
        try:
            proc.terminate(); proc.wait(timeout=5)
        except Exception:
            try: proc.kill()
            except Exception: pass
        if save_proc is not None:
            try:
                save_proc.terminate(); save_proc.wait(timeout=5)
            except Exception:
                try: save_proc.kill()
                except Exception: pass
        # Drain ASR pipeline cleanly — waits for queue to empty so no
        # captured segment is lost, then signals workers + reassembler.
        try:
            asr_shutdown(timeout=20)
        except Exception as _se:
            logger.warning("ASR shutdown error: %s", _se)
        state["running"] = False
        try:
            _rp = _Path(str(recording_path))
            if _rp.exists() and _rp.stat().st_size > 1000 and job is not None:
                job["audio_file"] = _rp.name
                job["audio_channels"] = NUM_CH
                _app._save_job(job)
                logger.info("Dual-source recording saved: %s (%d bytes, 2 ch)",
                            _rp, _rp.stat().st_size)
        except Exception as _se:
            logger.debug("audio_file attach failed: %s", _se)
        logger.info("Dual-source capture stopped for job %s", job_id)


# ─────────────────────────────────────────────────────────────────────────
# MULTI-WORKER ASR PIPELINE
# ─────────────────────────────────────────────────────────────────────────
# Court reporting cannot afford to drop audio. Whisper on CPU is slower
# than real-time on long sessions; the old single-thread inline pipeline
# accumulated lag indefinitely. This pipeline runs N parallel workers off
# an unbounded queue (no audio is ever dropped) with a single in-order
# reassembler that handles all state mutation + ECAPA streaming labels +
# broadcast.
#
# Threading model per capture session:
#   capture loop ──→ [input queue, unbounded] ──→ N transcribe workers
#                                                       │
#                                                       ▼
#                                                 [result queue]
#                                                       │
#                                                       ▼
#                                                 reassembler (serial,
#                                                  in seg_id order):
#                                                  ECAPA + dedup-finalize
#                                                  + state["segments"]
#                                                  + broadcast
#
# Worker count default: 2. Configurable per tier (cpu-1.5b → 2,
# gpu-7b → 3+) via state["asr_worker_count"].

def _transcribe_segment_phase(work_item, model, ecapa_sess, sample_rate,
                              segment_seconds, live_prompt,
                              diarize_channels=None):
    """Parallel-safe per-segment transcription. Pure function over the
    work_item; mutates nothing except local variables. Workers call this
    in parallel with seg_id-tagged items."""
    if diarize_channels is None:
        diarize_channels = set()
    import numpy as np

    per_channel    = work_item["per_channel"]
    rms_per_ch     = work_item["rms_per_ch"]
    num_channels   = work_item["num_channels"]

    # Stage 1: RMS / silence gating
    ABSOLUTE_SILENCE = 0.001
    STAGE1_DB = 12.0
    max_rms = max(rms_per_ch) if rms_per_ch else 0.0
    stage1_floor = max_rms * (10 ** (-STAGE1_DB / 20.0))
    active_channels = []
    for ch_idx in range(num_channels):
        ch_audio = per_channel[:, ch_idx]
        if float(np.abs(ch_audio).mean()) < ABSOLUTE_SILENCE:
            continue
        if max_rms > 0.005 and rms_per_ch[ch_idx] < stage1_floor:
            continue
        active_channels.append(ch_idx)

    # Stage 1.5: cross-correlation crosstalk
    if len(active_channels) >= 2:
        XCORR_LEAK_THRESH = 0.45
        MAX_LAG_SAMPLES = 320
        drop_xcorr = set()
        for ai in range(len(active_channels)):
            for bi in range(ai + 1, len(active_channels)):
                a_idx = active_channels[ai]; b_idx = active_channels[bi]
                if a_idx in drop_xcorr or b_idx in drop_xcorr:
                    continue
                a_sig = per_channel[:, a_idx].astype(np.float32)
                b_sig = per_channel[:, b_idx].astype(np.float32)
                n_a = len(a_sig)
                if n_a < MAX_LAG_SAMPLES * 4:
                    continue
                a_c = a_sig - a_sig.mean(); b_c = b_sig - b_sig.mean()
                a_norm = float(np.linalg.norm(a_c)); b_norm = float(np.linalg.norm(b_c))
                if a_norm < 1e-6 or b_norm < 1e-6:
                    continue
                a_n = a_c / a_norm; b_n = b_c / b_norm
                try:
                    fft_size = 1
                    while fft_size < 2 * n_a:
                        fft_size <<= 1
                    A = np.fft.rfft(a_n, fft_size)
                    B = np.fft.rfft(b_n, fft_size)
                    xc = np.fft.irfft(A * np.conj(B), fft_size)
                    pos = xc[:MAX_LAG_SAMPLES + 1]
                    neg = xc[-MAX_LAG_SAMPLES:]
                    max_xcorr = max(float(np.max(np.abs(pos))), float(np.max(np.abs(neg))))
                except Exception:
                    continue
                if max_xcorr >= XCORR_LEAK_THRESH:
                    quieter = b_idx if rms_per_ch[a_idx] >= rms_per_ch[b_idx] else a_idx
                    drop_xcorr.add(quieter)
        if drop_xcorr:
            active_channels = [c for c in active_channels if c not in drop_xcorr]

    # Stage 2: ECAPA same-voice (read-only — uses shared session)
    if len(active_channels) >= 2 and ecapa_sess is not None:
        SAME_SPEAKER_SIM = 0.65
        embeddings = {}
        for ch_idx in active_channels:
            try:
                ch_audio = per_channel[:, ch_idx]
                feats = _app._compute_mel_fbank(ch_audio, sample_rate)
                feats = feats.reshape(1, feats.shape[0], feats.shape[1])
                emb = ecapa_sess.run(None, {'feats': feats})[0][0]
                emb = emb / (np.linalg.norm(emb) + 1e-8)
                embeddings[ch_idx] = emb
            except Exception:
                pass
        drop = set()
        pairs = sorted(active_channels)
        for i in range(len(pairs)):
            for j in range(i + 1, len(pairs)):
                a, b = pairs[i], pairs[j]
                if a in drop or b in drop:
                    continue
                if a not in embeddings or b not in embeddings:
                    continue
                sim = float(np.dot(embeddings[a], embeddings[b]))
                if sim >= SAME_SPEAKER_SIM:
                    quieter = b if rms_per_ch[a] >= rms_per_ch[b] else a
                    drop.add(quieter)
        active_channels = [c for c in active_channels if c not in drop]

    # Whisper transcribe per active channel (parallel-safe — model is
    # thread-safe per faster-whisper docs)
    segs_per_ch = {ch_idx: [] for ch_idx in active_channels}
    _min_speech_samples = int(sample_rate * 0.5)
    for ch_idx in active_channels:
        ch_audio = per_channel[:, ch_idx]
        try:
            segments_out, _info = model.transcribe(
                ch_audio, language="en",
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300},
                initial_prompt=live_prompt,
            )
            for s in segments_out:
                text = s.text.strip() if hasattr(s, 'text') else str(s).strip()
                if text and text not in ("", ".", "...", "(silence)"):
                    rel_start = float(getattr(s, 'start', 0))
                    rel_end   = float(getattr(s, 'end', segment_seconds))
                    s_a = max(0, int(rel_start * sample_rate))
                    s_b = min(len(ch_audio), int(rel_end * sample_rate))
                    needs_diarize = (ch_idx in diarize_channels) and (s_b - s_a >= _min_speech_samples)
                    segs_per_ch[ch_idx].append({
                        "text": text,
                        "rel_start": rel_start,
                        "rel_end": rel_end,
                        "channel": ch_idx,
                        "confidence": round(getattr(s, 'avg_logprob', 0.85), 3),
                        "audio_start": s_a,
                        "audio_end": s_b,
                        "needs_diarize": needs_diarize,
                    })
        except Exception as e:
            logger.warning("Worker transcribe error (ch %d, seg %d): %s",
                           ch_idx, work_item.get("seg_id", -1), e)

    # Text-similarity dedup
    drop_keys = set()
    if len([c for c in segs_per_ch if segs_per_ch[c]]) >= 2:
        from difflib import SequenceMatcher
        TEXT_SIM_THRESH = 0.62
        OVERLAP_TOL_S = 0.4
        chs = sorted(segs_per_ch.keys())
        for i in range(len(chs)):
            for j in range(i + 1, len(chs)):
                ca, cb = chs[i], chs[j]
                for ia, sa in enumerate(segs_per_ch[ca]):
                    for ib, sb in enumerate(segs_per_ch[cb]):
                        if sa["rel_end"] + OVERLAP_TOL_S < sb["rel_start"]:
                            continue
                        if sb["rel_end"] + OVERLAP_TOL_S < sa["rel_start"]:
                            continue
                        ratio = SequenceMatcher(None, sa["text"].lower(), sb["text"].lower()).ratio()
                        if ratio >= TEXT_SIM_THRESH:
                            quieter_ch = cb if rms_per_ch[ca] >= rms_per_ch[cb] else ca
                            quieter_idx = ib if quieter_ch == cb else ia
                            drop_keys.add((quieter_ch, quieter_idx))

    return {
        "seg_id": work_item["seg_id"],
        "total_ms_at_capture": work_item["total_ms_at_capture"],
        "per_channel": per_channel,  # needed by reassembler for streaming-ECAPA audio slices
        "segs_per_ch": segs_per_ch,
        "drop_keys": drop_keys,
    }


def _finalize_segment_phase(work_result, state, label_fn, sample_rate,
                            segment_seconds, job, diarize_channels=None):
    """Serial-only: streaming-ECAPA speaker assignment + state mutation +
    broadcast. Reassembler calls this in seg_id order. Mutates state and
    job — must NEVER run in parallel."""
    if diarize_channels is None:
        diarize_channels = set()
    per_channel  = work_result["per_channel"]
    segs_per_ch  = work_result["segs_per_ch"]
    drop_keys    = work_result["drop_keys"]
    total_ms     = work_result["total_ms_at_capture"]

    # Speaker-rename mapping — when reporter manually renames a speaker
    # mid-session via update_segment ("Reporter" → "MR. TAYLOR"), the
    # rename propagates here so every FUTURE segment from the same
    # cluster / channel inherits the new label automatically.
    rename_map = (state.get("speaker_label_mapping") or {})
    # Reporter's live "current speaker" override (set via hotkey macro or by
    # clicking a label in the live view). Once set it takes precedence over the
    # diarizer for every NEW segment, until the reporter marks a different
    # speaker — this is how a multi-speaker record is built by hand when
    # streaming diarization collapses every voice into one cluster.
    live_override = state.get("live_current_speaker")

    for ch_idx, segs in segs_per_ch.items():
        for i, raw in enumerate(segs):
            if (ch_idx, i) in drop_keys:
                continue
            # Resolve speaker label
            if raw.get("needs_diarize"):
                ch_audio = per_channel[:, ch_idx]
                speaker = _assign_streaming_speaker(
                    ch_audio[raw["audio_start"]:raw["audio_end"]],
                    sample_rate, state)
            elif ch_idx in diarize_channels:
                speaker = state.get("last_speaker") or "SPEAKER_00"
            else:
                speaker = label_fn(ch_idx)
            # Reporter has final authority on speaker labels mid-session: a
            # live "current speaker" override wins outright; otherwise apply any
            # per-label rename the reporter set.
            if live_override:
                speaker = live_override
            elif speaker in rename_map:
                speaker = rename_map[speaker]
            seg = {
                "text": raw["text"],
                "start": total_ms + int(raw["rel_start"] * 1000),
                "end":   total_ms + int(raw["rel_end"]   * 1000),
                "speaker": speaker,
                "channel": ch_idx,
                "confidence": raw["confidence"],
            }
            state["segments"].append(seg)
            if job is not None:
                try:
                    _app._append_segment_to_job(job, seg)
                except Exception:
                    pass


def _start_asr_pipeline(state, model, ecapa_sess, sample_rate, segment_seconds,
                       label_fn, job, diarize_channels=None,
                       worker_count=None):
    """Spin up the ASR worker pool + reassembler for one capture session.

    Returns (input_queue, shutdown_fn). Push work items via input_queue.put;
    call shutdown_fn() on session stop to drain and join cleanly.

    worker_count defaults to state['asr_worker_count'] or 2. The hardware
    tier sets this — gpu-7b can run 3-4, cpu-1.5b should stay at 2.
    """
    if worker_count is None:
        worker_count = int(state.get("asr_worker_count", 2))
    worker_count = max(1, min(worker_count, 6))  # safety bounds

    input_q  = _stdlib_queue.Queue()  # UNBOUNDED — never drops audio
    result_q = _stdlib_queue.Queue()

    def _worker(wid):
        while True:
            item = input_q.get()
            if item is None:
                input_q.task_done()
                break
            try:
                live_prompt = None
                try:
                    live_prompt = _live_initial_prompt(job)
                except Exception:
                    pass
                result = _transcribe_segment_phase(
                    item, model, ecapa_sess, sample_rate, segment_seconds,
                    live_prompt, diarize_channels,
                )
                result_q.put(result)
            except Exception as e:
                logger.exception("ASR worker %d crashed on seg %d: %s",
                                 wid, item.get("seg_id", -1), e)
                # Push a stub so the reassembler doesn't deadlock waiting
                result_q.put({
                    "seg_id": item["seg_id"],
                    "total_ms_at_capture": item.get("total_ms_at_capture", 0),
                    "per_channel": item.get("per_channel"),
                    "segs_per_ch": {},
                    "drop_keys": set(),
                    "error": str(e),
                })
            finally:
                input_q.task_done()

    def _reassembler():
        pending = {}
        next_seg = 0
        while True:
            r = result_q.get()
            if r is None:
                break
            pending[r["seg_id"]] = r
            while next_seg in pending:
                cur = pending.pop(next_seg)
                try:
                    if "error" not in cur:
                        _finalize_segment_phase(
                            cur, state, label_fn, sample_rate, segment_seconds,
                            job, diarize_channels,
                        )
                except Exception as e:
                    logger.exception("Reassembler error on seg %d: %s", next_seg, e)
                next_seg += 1

    workers = []
    for i in range(worker_count):
        t = threading.Thread(target=_worker, args=(i,), daemon=True,
                             name=f"asr-worker-{i}")
        t.start()
        workers.append(t)
    re_thread = threading.Thread(target=_reassembler, daemon=True,
                                  name="asr-reassembler")
    re_thread.start()

    state["_asr_input_q"]  = input_q
    state["_asr_result_q"] = result_q
    state["_asr_workers"]  = workers
    state["_asr_reassembler"] = re_thread
    state["_asr_shutdown_done"] = False

    logger.info("ASR pipeline started: %d workers + reassembler", worker_count)

    def shutdown_fn(timeout=15):
        # Idempotent — the API can call this from /api/live/stop AND the
        # capture loop's finally block calls it as a safety net. Second
        # call is a no-op so threads aren't double-joined.
        if state.get("_asr_shutdown_done"):
            return
        state["_asr_shutdown_done"] = True
        try:
            input_q.join()  # wait for queue to drain — no audio dropped
        except Exception:
            pass
        for _ in workers:
            input_q.put(None)
        for w in workers:
            w.join(timeout=timeout)
        result_q.put(None)
        re_thread.join(timeout=timeout)
        logger.info("ASR pipeline shut down cleanly")

    state["_asr_shutdown"] = shutdown_fn
    return input_q, shutdown_fn


def _process_multichannel_segments(per_channel, rms_per_ch, num_channels,
                                    sample_rate, segment_seconds,
                                    state, model, live_prompt, label_fn, job,
                                    diarize_channels=None):
    """Shared per-chunk processing for multichannel + dual-source paths.

    Three-stage crosstalk gate (RMS / xcorr / ECAPA) + per-channel Whisper +
    text-similarity dedup. Persists surviving segments to state and job.

    `diarize_channels` (optional set of channel indices): for these channels,
    each Whisper-detected segment runs through `_assign_streaming_speaker` to
    pick a SPEAKER_NN label via online ECAPA clustering, instead of using the
    fixed `label_fn(ch_idx)`. Used for Mode A's loopback channel where
    multiple remote Zoom participants share one stream and need to be
    distinguished from each other in real time.
    """
    if diarize_channels is None:
        diarize_channels = set()
    import numpy as np
    ABSOLUTE_SILENCE = 0.001
    STAGE1_DB = 12.0
    max_rms = max(rms_per_ch) if rms_per_ch else 0.0
    stage1_floor = max_rms * (10 ** (-STAGE1_DB / 20.0))

    active_channels = []
    for ch_idx in range(num_channels):
        ch_audio = per_channel[:, ch_idx]
        if float(np.abs(ch_audio).mean()) < ABSOLUTE_SILENCE:
            continue
        if max_rms > 0.005 and rms_per_ch[ch_idx] < stage1_floor:
            continue
        active_channels.append(ch_idx)

    # Stage 1.5: cross-correlation
    if len(active_channels) >= 2:
        XCORR_LEAK_THRESH = 0.45
        MAX_LAG_SAMPLES = 320
        drop_xcorr = set()
        for ai in range(len(active_channels)):
            for bi in range(ai + 1, len(active_channels)):
                a_idx = active_channels[ai]
                b_idx = active_channels[bi]
                if a_idx in drop_xcorr or b_idx in drop_xcorr:
                    continue
                a_sig = per_channel[:, a_idx].astype(np.float32)
                b_sig = per_channel[:, b_idx].astype(np.float32)
                n_a = len(a_sig)
                if n_a < MAX_LAG_SAMPLES * 4:
                    continue
                a_c = a_sig - a_sig.mean()
                b_c = b_sig - b_sig.mean()
                a_norm = float(np.linalg.norm(a_c))
                b_norm = float(np.linalg.norm(b_c))
                if a_norm < 1e-6 or b_norm < 1e-6:
                    continue
                a_n = a_c / a_norm
                b_n = b_c / b_norm
                try:
                    fft_size = 1
                    while fft_size < 2 * n_a:
                        fft_size <<= 1
                    A = np.fft.rfft(a_n, fft_size)
                    B = np.fft.rfft(b_n, fft_size)
                    xc = np.fft.irfft(A * np.conj(B), fft_size)
                    pos = xc[: MAX_LAG_SAMPLES + 1]
                    neg = xc[-MAX_LAG_SAMPLES:]
                    max_xcorr = max(float(np.max(np.abs(pos))), float(np.max(np.abs(neg))))
                except Exception:
                    continue
                if max_xcorr >= XCORR_LEAK_THRESH:
                    quieter = b_idx if rms_per_ch[a_idx] >= rms_per_ch[b_idx] else a_idx
                    drop_xcorr.add(quieter)
                    logger.info("xcorr-leak: ch%d/ch%d corr=%.3f, dropping ch%d",
                                 a_idx, b_idx, max_xcorr, quieter)
        if drop_xcorr:
            active_channels = [c for c in active_channels if c not in drop_xcorr]

    # Stage 2: ECAPA same-voice
    ecapa_sess = state.get("ecapa_session")
    if len(active_channels) >= 2 and ecapa_sess is not None:
        SAME_SPEAKER_SIM = 0.65
        embeddings = {}
        for ch_idx in active_channels:
            try:
                ch_audio = per_channel[:, ch_idx]
                feats = _app._compute_mel_fbank(ch_audio, sample_rate)
                feats = feats.reshape(1, feats.shape[0], feats.shape[1])
                emb = ecapa_sess.run(None, {'feats': feats})[0][0]
                emb = emb / (np.linalg.norm(emb) + 1e-8)
                embeddings[ch_idx] = emb
            except Exception:
                pass
        drop = set()
        pairs = sorted(active_channels)
        for i in range(len(pairs)):
            for j in range(i + 1, len(pairs)):
                a, b = pairs[i], pairs[j]
                if a in drop or b in drop:
                    continue
                if a not in embeddings or b not in embeddings:
                    continue
                sim = float(np.dot(embeddings[a], embeddings[b]))
                if sim >= SAME_SPEAKER_SIM:
                    quieter = b if rms_per_ch[a] >= rms_per_ch[b] else a
                    drop.add(quieter)
                    logger.info("crosstalk: ch%d/ch%d sim=%.3f same-voice, dropping ch%d",
                                 a, b, sim, quieter)
        active_channels = [c for c in active_channels if c not in drop]

    # Per-channel transcribe with text-dedup. For channels in diarize_channels,
    # run streaming ECAPA per Whisper segment to assign SPEAKER_NN labels.
    segs_per_ch = {ch_idx: [] for ch_idx in active_channels}
    _min_speech_samples = int(sample_rate * 0.5)
    for ch_idx in active_channels:
        ch_audio = per_channel[:, ch_idx]
        try:
            segments_out, _info = model.transcribe(
                ch_audio, language="en",
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300},
                initial_prompt=live_prompt,
            )
            for s in segments_out:
                text = s.text.strip() if hasattr(s, 'text') else str(s).strip()
                if text and text not in ("", ".", "...", "(silence)"):
                    if ch_idx in diarize_channels:
                        # Per-segment ECAPA on the speech window (post-VAD)
                        s_a = max(0, int(getattr(s, 'start', 0) * sample_rate))
                        s_b = min(len(ch_audio),
                                  int(getattr(s, 'end', segment_seconds) * sample_rate))
                        if s_b - s_a >= _min_speech_samples:
                            speaker = _assign_streaming_speaker(
                                ch_audio[s_a:s_b], sample_rate, state)
                        else:
                            speaker = state.get("last_speaker") or "SPEAKER_00"
                    else:
                        speaker = label_fn(ch_idx)
                    seg_start = state["total_ms"] + int(getattr(s, 'start', 0) * 1000)
                    seg_end = state["total_ms"] + int(getattr(s, 'end', segment_seconds) * 1000)
                    seg = {
                        "text": text,
                        "start": seg_start,
                        "end": seg_end,
                        "speaker": speaker,
                        "channel": ch_idx,
                        "confidence": round(getattr(s, 'avg_logprob', 0.85), 3),
                    }
                    segs_per_ch[ch_idx].append(seg)
        except Exception as e:
            logger.warning("Multichannel transcribe error (ch %d): %s", ch_idx, e)

    drop_keys = set()
    if len([c for c in segs_per_ch if segs_per_ch[c]]) >= 2:
        from difflib import SequenceMatcher
        TEXT_SIM_THRESH = 0.62
        OVERLAP_TOLERANCE_MS = 400
        chs = sorted(segs_per_ch.keys())
        for i in range(len(chs)):
            for j in range(i + 1, len(chs)):
                ca, cb = chs[i], chs[j]
                for ia, sa in enumerate(segs_per_ch[ca]):
                    for ib, sb in enumerate(segs_per_ch[cb]):
                        if sa["end"] + OVERLAP_TOLERANCE_MS < sb["start"]:
                            continue
                        if sb["end"] + OVERLAP_TOLERANCE_MS < sa["start"]:
                            continue
                        ratio = SequenceMatcher(
                            None, sa["text"].lower(), sb["text"].lower()
                        ).ratio()
                        if ratio >= TEXT_SIM_THRESH:
                            quieter_ch = cb if rms_per_ch[ca] >= rms_per_ch[cb] else ca
                            quieter_idx = ib if quieter_ch == cb else ia
                            drop_keys.add((quieter_ch, quieter_idx))
                            logger.info("text-dedup: ch%d/ch%d ratio=%.2f, dropping ch%d (%r)",
                                         ca, cb, ratio, quieter_ch,
                                         (sa if quieter_ch == ca else sb)["text"][:40])

    for ch_idx, segs in segs_per_ch.items():
        for i, seg in enumerate(segs):
            if (ch_idx, i) in drop_keys:
                continue
            state["segments"].append(seg)
            if job is not None:
                try:
                    _app._append_segment_to_job(job, seg)
                except Exception:
                    pass


def _ffmpeg_multichannel_capture(model, state, device_name,
                                  sample_rate, segment_seconds, recording_path,
                                  job_id, num_channels):
    """Multi-channel capture for Mode B (multi-mic). Captures N interleaved
    channels from a single device, splits per chunk into per-channel mono
    streams, transcribes each separately, and assigns each channel to a fixed
    speaker label (job['channel_labels'][i] if provided, else 'Channel N').

    Multi-mic per-channel-per-speaker is the cleanest path: each mic IS one
    speaker by definition, so no diarization is needed. ECAPA streaming
    diarization is skipped on this path.
    """
    import subprocess
    import numpy as np
    from pathlib import Path as _Path

    if num_channels < 2:
        # Defensive — caller should have routed us to mono _ffmpeg_capture
        logger.warning("multichannel_capture invoked with num_channels=%d, falling back",
                       num_channels)
        return _ffmpeg_capture(model, state, device_name, "",
                               sample_rate, segment_seconds, recording_path, job_id)

    job = JOBS.get(job_id)
    channel_labels = (job or {}).get("channel_labels") or []
    def _label(ch):
        if ch < len(channel_labels) and channel_labels[ch]:
            return channel_labels[ch]
        return f"Channel {ch + 1}"

    SEGMENT_BYTES = int(sample_rate * 2 * num_channels * segment_seconds)
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"

    ffmpeg_cmd = [
        ffmpeg_bin, "-y",
        "-f", "dshow", "-i", f"audio={device_name}",
        "-ar", str(sample_rate), "-ac", str(num_channels),
        "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1",
    ]
    # Save the full multi-channel WAV — post-stop offline diarization /
    # full-quality transcription can split channels from this file.
    save_cmd = [
        ffmpeg_bin, "-y",
        "-f", "dshow", "-i", f"audio={device_name}",
        "-ar", str(sample_rate), "-ac", str(num_channels),
        "-acodec", "pcm_s16le", str(recording_path),
    ]

    save_proc = None
    try:
        proc = subprocess.Popen(
            ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        save_proc = subprocess.Popen(
            save_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except Exception as e:
        logger.error("Failed to start multichannel ffmpeg: %s", e)
        state["running"] = False
        return

    logger.info("Multichannel capture started: %d channels, labels=%s",
                num_channels, [_label(i) for i in range(num_channels)])

    # Multi-worker ASR pipeline — same as Mode A WASAPI dual capture.
    # Multi-mic per-channel-per-speaker is the cleanest path: each mic IS one
    # speaker by definition, so no diarization needed (diarize_channels=set()).
    asr_input_q, asr_shutdown = _start_asr_pipeline(
        state, model, state.get("ecapa_session"),
        sample_rate, segment_seconds,
        _label, job, diarize_channels=set(),
    )
    seg_id_mc = 0

    audio_buffer = bytearray()
    try:
        while state["running"]:
            chunk = proc.stdout.read(8192)
            if not chunk:
                break
            audio_buffer.extend(chunk)

            if len(audio_buffer) >= SEGMENT_BYTES:
                segment_data = bytes(audio_buffer[:SEGMENT_BYTES])
                audio_buffer = audio_buffer[SEGMENT_BYTES:]
                # Split interleaved [L,R,L,R,...] into per-channel mono
                interleaved = (np.frombuffer(segment_data, dtype=np.int16)
                                 .astype(np.float32) / 32768.0)
                per_channel = interleaved.reshape(-1, num_channels)

                # Compute per-channel RMS for the worker's gating logic
                rms_per_ch = []
                for ch_idx in range(num_channels):
                    ch = per_channel[:, ch_idx]
                    rms_per_ch.append(float(np.sqrt(np.mean(ch * ch) + 1e-12)))
                logger.info("multichannel ch RMS: " + ", ".join(
                    f"ch{i}={rms_per_ch[i]:.4f}" for i in range(num_channels)))

                # Push to multi-worker ASR pipeline. Workers run the same
                # Stage 1 / 1.5 / 2 gating + Whisper transcribe + dedup that
                # used to run inline; the reassembler emits in seg_id order
                # with state mutation + broadcast.
                asr_input_q.put({
                    "seg_id": seg_id_mc,
                    "total_ms_at_capture": state["total_ms"],
                    "per_channel": per_channel,
                    "rms_per_ch": rms_per_ch,
                    "num_channels": num_channels,
                })
                seg_id_mc += 1
                state["total_ms"] += int(segment_seconds * 1000)
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try: proc.kill()
            except Exception: pass
        if save_proc is not None:
            try:
                save_proc.terminate()
                save_proc.wait(timeout=5)
            except Exception:
                try: save_proc.kill()
                except Exception: pass
        # Drain ASR pipeline cleanly (idempotent with /api/live/stop drain)
        try:
            asr_shutdown(timeout=20)
        except Exception as _se:
            logger.warning("ASR shutdown error: %s", _se)
        state["running"] = False
        try:
            _rp = _Path(str(recording_path))
            if _rp.exists() and _rp.stat().st_size > 1000 and job is not None:
                job["audio_file"] = _rp.name
                job["audio_channels"] = num_channels
                _app._save_job(job)
                logger.info("Multichannel recording saved: %s (%d bytes, %d ch)",
                            _rp, _rp.stat().st_size, num_channels)
        except Exception as _se:
            logger.debug("audio_file attach failed: %s", _se)
        logger.info("Multichannel capture stopped for job %s", job_id)


def _ffmpeg_capture(model, state, device_name, loopback_name,
                     sample_rate, segment_seconds, recording_path, job_id):
    """Fallback: ffmpeg-based capture. Runs two ffmpeg processes in parallel —
    one piping PCM out for live transcription, one writing the full WAV to disk
    for post-stop editor playback. Live segments are persisted to the job's
    transcript so stop_live_capture sees them and skips re-transcription."""
    import subprocess
    import numpy as np
    from pathlib import Path as _Path

    SEGMENT_BYTES = int(sample_rate * 2 * segment_seconds)
    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"

    if loopback_name and device_name:
        ffmpeg_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-f", "dshow", "-i", f"audio={loopback_name}",
            "-filter_complex", "[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0[mixed]",
            "-map", "[mixed]",
            "-ar", str(sample_rate), "-ac", "1",
            "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1",
        ]
        save_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-f", "dshow", "-i", f"audio={loopback_name}",
            "-filter_complex", "[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0[mixed]",
            "-map", "[mixed]",
            "-ar", str(sample_rate), "-ac", "1",
            "-acodec", "pcm_s16le", str(recording_path),
        ]
    else:
        ffmpeg_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-ar", str(sample_rate), "-ac", "1",
            "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1",
        ]
        save_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-ar", str(sample_rate), "-ac", "1",
            "-acodec", "pcm_s16le", str(recording_path),
        ]

    save_proc = None
    try:
        proc = subprocess.Popen(
            ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        save_proc = subprocess.Popen(
            save_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except Exception as e:
        logger.error("Failed to start ffmpeg: %s", e)
        state["running"] = False
        return

    job = JOBS.get(job_id)

    # Single-mic Mode C — Whisper transcribes one channel; per-segment ECAPA
    # streaming label-assignment for SPEAKER_NN clustering. Uses the multi-
    # worker pipeline so a long session doesn't accumulate lag.
    def _label_single(ch):
        return "Speaker"  # ignored when diarize_channels={0}; SPEAKER_NN wins

    asr_input_q, asr_shutdown = _start_asr_pipeline(
        state, model, state.get("ecapa_session"),
        sample_rate, segment_seconds,
        _label_single, job, diarize_channels={0},
    )
    seg_id_sm = 0

    audio_buffer = bytearray()
    try:
        while state["running"]:
            chunk = proc.stdout.read(8192)
            if not chunk:
                break
            audio_buffer.extend(chunk)

            if len(audio_buffer) >= SEGMENT_BYTES:
                segment_data = bytes(audio_buffer[:SEGMENT_BYTES])
                audio_buffer = audio_buffer[SEGMENT_BYTES:]
                audio_np = np.frombuffer(segment_data, dtype=np.int16).astype(np.float32) / 32768.0

                # Reshape to (samples, 1) so the pipeline's per_channel logic
                # treats this as a 1-channel feed. RMS computed across the
                # whole segment so the worker's gating sees the right value.
                per_channel = audio_np.reshape(-1, 1)
                rms = float(np.sqrt(np.mean(audio_np * audio_np) + 1e-12))
                asr_input_q.put({
                    "seg_id": seg_id_sm,
                    "total_ms_at_capture": state["total_ms"],
                    "per_channel": per_channel,
                    "rms_per_ch": [rms],
                    "num_channels": 1,
                })
                seg_id_sm += 1
                state["total_ms"] += int(segment_seconds * 1000)
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try: proc.kill()
            except Exception: pass
        if save_proc is not None:
            try:
                save_proc.terminate()
                save_proc.wait(timeout=5)
            except Exception:
                try: save_proc.kill()
                except Exception: pass
        # Drain ASR pipeline cleanly (idempotent with /api/live/stop drain)
        try:
            asr_shutdown(timeout=20)
        except Exception as _se:
            logger.warning("ASR shutdown error: %s", _se)
        state["running"] = False
        # Attach saved WAV to job for editor playback / post-stop processing
        try:
            _rp = _Path(str(recording_path))
            if _rp.exists() and _rp.stat().st_size > 1000 and job is not None:
                job["audio_file"] = _rp.name
                _app._save_job(job)
                logger.info("Live recording saved: %s (%d bytes)", _rp, _rp.stat().st_size)
        except Exception as _se:
            logger.debug("audio_file attach failed: %s", _se)
        logger.info("FFmpeg capture stopped for job %s", job_id)


# === MONKEY PATCHES ===
#
# IMPORTANT: FastAPI does NOT re-dispatch through `route.endpoint` after
# route registration. Each APIRoute caches a `route.app` callable built from
# `endpoint` at registration time. Setting `route.endpoint = X` post-hoc
# updates the attribute but does NOT change which function the request
# actually routes to — `route.app` still calls the original.
#
# To genuinely replace a route's behavior we have to either (a) replace the
# whole APIRoute object in `app.routes`, or (b) overwrite `route.app` with
# a new ASGI callable that delegates to our patched endpoint.
#
# We use approach (a) — construct a new APIRoute with the patched endpoint
# and put it where the old route was. This is the only reliable way to
# replace a FastAPI handler at runtime.

def _replace_route(path, new_endpoint, methods):
    """Swap out the APIRoute at `path` for one calling `new_endpoint`.

    Construct via _app.app.add_api_route + manual list mutation rather than
    direct APIRoute() to inherit the app's response_class, dependencies,
    and FastAPI's normal dependant-analysis (which needs the endpoint's
    type hints to bind params correctly)."""
    from fastapi.routing import APIRoute
    target_idx = None
    target_old = None
    for i, route in enumerate(_app.app.routes):
        if hasattr(route, 'path') and route.path == path:
            if methods is None or any(m in (route.methods or set()) for m in methods):
                target_idx = i
                target_old = route
                break
    if target_idx is None:
        logger.warning("Route patch: %s not found in app.routes", path)
        return False
    # Use the app's add_api_route to build a properly-initialized APIRoute
    # (with response_class default, dependant rebuilt from new endpoint's
    # type hints, etc.), then move it into the slot of the old route.
    _app.app.add_api_route(
        path=path,
        endpoint=new_endpoint,
        methods=list((target_old.methods or set()) if methods is None else methods),
        name=target_old.name,
    )
    # add_api_route appends to .routes; move it to the original slot and
    # remove the old route. Order matters: middlewares scan in list order.
    new_route = _app.app.routes.pop()  # the freshly added route
    _app.app.routes[target_idx] = new_route  # replace old in place
    logger.info("Replaced route %s (%s) with patched handler",
                path, ",".join(new_route.methods))
    return True


# 1. Replace device-listing route (GET)
_original_list_devices = _app.list_audio_devices
_replace_route('/api/audio-devices', _patched_list_audio_devices, ["GET"])

# 2. Replace capture function (module attribute — this one DOES propagate
# because callers look up `_app._server_side_capture` each time)
_app._server_side_capture = _patched_server_side_capture

# 3. (placeholder — _wrapped_start_live is defined below and route is
# replaced after that definition to avoid forward-reference)
_original_start = None
for route in _app.app.routes:
    if hasattr(route, 'path') and route.path == '/api/live/start':
        _original_start = route.endpoint
        break


async def _wrapped_start_live(request: "Request"):
    """Start live capture with WASAPI loopback support.

    `request: Request` annotation is required because we now register this
    via a fresh APIRoute (not a runtime attribute swap), and FastAPI's
    dependency analyzer needs the type hint to know `request` is the
    Request object — without it the param is treated as a body field and
    every request fails with 422.
    """
    from starlette.responses import JSONResponse
    from datetime import datetime

    data = await request.json()
    job_id = data.get("job_id")
    loopback_name = data.get("loopback_name", "")
    loopback_id = data.get("loopback_id")
    device_name = data.get("device_name", "")
    device_id = data.get("device_id")
    mode = data.get("mode", "C")

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    # Validation: Mode A requires mic + loopback to be DIFFERENT devices.
    # Selecting the same device for both produces an amerge of mic+mic (the
    # exact same audio on both channels) which makes diarization meaningless
    # and triggers the crosstalk gate constantly. Reject early with a clear
    # error so the user gets a real message instead of a confusing log.
    if mode == "A":
        if loopback_id is not None and device_id is not None and int(loopback_id) == int(device_id):
            logger.warning(
                "Mode A start rejected: mic and loopback are the same device "
                "(id=%s, name='%s'). Pick a System Audio loopback device "
                "(suffix '(System Audio)' in the dropdown), not the mic itself.",
                device_id, device_name)
            return JSONResponse({
                "error": "Mode A requires the System Audio source to be a DIFFERENT device "
                         "from the microphone. The dropdown should show entries with "
                         "'(System Audio)' suffix — pick the one your Zoom/playback is using. "
                         "If only mic devices appear in the System Audio list, restart Notare "
                         "to refresh the device enumeration."
            }, status_code=400)
        if loopback_name and device_name and loopback_name == device_name:
            logger.warning(
                "Mode A start rejected: mic and loopback have the same name '%s'.",
                device_name)
            return JSONResponse({
                "error": "Mode A requires the System Audio source to be a DIFFERENT device "
                         "from the microphone. Currently both are '" + device_name + "'."
            }, status_code=400)

    job["status"] = "recording"
    job["live_mode"] = mode
    job["recording_start"] = datetime.now().isoformat()
    if data.get("channel_labels"):
        job["channel_labels"] = data["channel_labels"]
    _app._save_job(job)

    if device_name or device_id is not None:
        # Mode B: detect actual input-channel count of the device. A 2-mic
        # interface like the M-Track Duo HD reports 2; allows the multichannel
        # capture path to split per-mic and label each channel as its own speaker.
        detected_channels = _detect_device_channels(device_name) if mode == "B" else 1
        if mode == "B" and detected_channels < 2:
            logger.warning("Mode B requested but device '%s' reports %d channel(s) — "
                           "treating as single-mic. Plug additional mics or check device.",
                           device_name, detected_channels)

        capture_state = {
            "running": True,
            "device_id": int(device_id) if device_id is not None else 0,
            "device_name": device_name,
            "loopback_id": int(loopback_id) if loopback_id is not None else None,
            "loopback_name": loopback_name,
            "mode": mode,
            "num_channels": detected_channels,
            "segments": [],
            "buffer": bytearray(),
            "total_ms": 0,
        }
        _app._live_capture[job_id] = capture_state

        threading.Thread(
            target=_patched_server_side_capture,
            args=(job_id, job, capture_state),
            daemon=True, name=f"live-capture-{job_id}"
        ).start()
        logger.info("Capture started: mic='%s'(%s), loopback=%s, mode=%s, channels=%d",
                     device_name, device_id, loopback_id, mode, detected_channels)

    return JSONResponse({"ok": True, "status": "recording", "server_capture": device_id is not None})


_replace_route('/api/live/start', _wrapped_start_live, ["POST"])


# ─────────────────────────────────────────────────────────────────────────
# Mic mute toggle
# ─────────────────────────────────────────────────────────────────────────
# Reporter clicks mute when remote-room audio is bleeding into their mic.
# Hard-zeros the mic channel while still capturing the loopback so remote
# speakers keep transcribing. The smart duck gate runs by default; this is
# the manual override for when the duck doesn't catch something or the
# reporter needs to step out / cough / clear throat without polluting the
# transcript.
from fastapi import Request as _MicMuteRequest

@_app.app.post("/api/live/mic/mute")
async def toggle_mic_mute(request: _MicMuteRequest):
    try:
        data = await request.json()
    except Exception:
        data = {}
    job_id = data.get("job_id")
    if not job_id:
        return JSONResponse({"error": "job_id required"}, status_code=400)
    state = (getattr(_app, "_live_capture", None) or {}).get(job_id)
    if not state:
        return JSONResponse(
            {"error": f"No active capture for job {job_id}"},
            status_code=404,
        )
    desired = data.get("muted")
    if desired is None:
        state["mic_muted"] = not bool(state.get("mic_muted", False))
    else:
        state["mic_muted"] = bool(desired)
    return JSONResponse({"ok": True, "muted": state["mic_muted"], "job_id": job_id})


@_app.app.get("/api/live/mic/state/{job_id}")
async def mic_mute_state(job_id: str):
    state = (getattr(_app, "_live_capture", None) or {}).get(job_id)
    if not state:
        return JSONResponse(
            {"error": f"No active capture for job {job_id}"},
            status_code=404,
        )
    return JSONResponse({"muted": bool(state.get("mic_muted", False))})


# Activity-level endpoint — the live.html mic + platform meters poll this
# at ~5Hz during server-side capture (the browser doesn't have the mic
# stream so it can't compute its own levels). Mute toggle is also surfaced
# so the meter goes flat instantly when the reporter mutes.
@_app.app.get("/api/live/level/{job_id}")
async def live_level(job_id: str):
    state = (getattr(_app, "_live_capture", None) or {}).get(job_id)
    if not state:
        return JSONResponse(
            {"recording": False, "mic_rms": 0.0, "lb_rms": 0.0, "mic_muted": False},
            status_code=200,  # not 404 — let polling clients keep going gracefully
        )
    return JSONResponse({
        "recording": bool(state.get("running")),
        "mic_rms":   float(state.get("mic_rms", 0.0)),
        "lb_rms":    float(state.get("lb_rms", 0.0)),
        "mic_muted": bool(state.get("mic_muted", False)),
        "mic_gain":  float(state.get("mic_gain", 1.0)),
        "lb_gain":   float(state.get("lb_gain", 1.0)),
    })


# Per-channel gain control. Reporter adjusts via the small sliders next
# to each level meter in live.html. Range clamped to 0.25x–2.0x — below
# 0.25 the channel is effectively silenced (use Mute Mic instead);
# above 2.0 distortion becomes guaranteed even with clipping.
@_app.app.post("/api/live/gain")
async def set_live_gain(request: _MicMuteRequest):
    try:
        data = await request.json()
    except Exception:
        data = {}
    job_id = data.get("job_id")
    if not job_id:
        return JSONResponse({"error": "job_id required"}, status_code=400)
    state = (getattr(_app, "_live_capture", None) or {}).get(job_id)
    if not state:
        return JSONResponse(
            {"error": f"No active capture for job {job_id}"},
            status_code=404,
        )
    if "mic_gain" in data:
        try:
            state["mic_gain"] = max(0.25, min(2.0, float(data["mic_gain"])))
        except Exception:
            pass
    if "lb_gain" in data:
        try:
            state["lb_gain"] = max(0.25, min(2.0, float(data["lb_gain"])))
        except Exception:
            pass
    # Persist last-used gain in settings so the next live session inherits
    try:
        _app.SETTINGS["mic_gain_default"] = float(state.get("mic_gain", 1.0))
        _app.SETTINGS["lb_gain_default"]  = float(state.get("lb_gain", 1.0))
        _app._save_settings()
    except Exception:
        pass
    return JSONResponse({
        "ok": True,
        "mic_gain": float(state.get("mic_gain", 1.0)),
        "lb_gain":  float(state.get("lb_gain", 1.0)),
    })


logger.info("Loopback capture plugin loaded — WASAPI loopback on all Windows machines, no Stereo Mix needed")
