"""
proof_depo_direct.py
Deposition Transcription Proofing
Full Verbatim Standard (with um/uh/ah removal)

Usage (command line):
    py "proof_depo_direct.py" "path\\to\\transcript.docx"

Usage (interactive):
    py "proof_depo_direct.py"
    -> prompts for folder, then lets you pick the file

Output:
    transcript_PROOFED.docx in the same folder as the original.
    All changes and flags inserted as Word comments.

Verbatim standard: Full Verbatim
    - um / uh / ah removed (confirmed practice)
    - Filler words left in
    - Stutters capped at 3 repetitions

Body scope: paragraphs with styles Colloquy, QandA, Parenthetical, Quoted.
    Caption, appearances, index, and certificate pages are protected.
"""

import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from notare_shared import CommentEngine, get_text, set_text, get_style, prompt_for_file
from docx import Document


PROFILE_NAME   = "Full Verbatim — Deposition"
PROCESS_STYLES = {"Colloquy", "Q&A", "Parenthetical", "Quoted", "Normal"}


# ---------------------------------------------------------------------------
# AUTO-FIXES
# ---------------------------------------------------------------------------

def fix_mrs(t):
    n = re.sub(r'\bMrs\.', 'Ms.', t)
    return n, (["Auto-fixed: Mrs. → Ms."] if n != t else [])

def fix_miss(t):
    n = re.sub(r'\bMiss\b', 'Ms.', t)
    return n, (["Auto-fixed: Miss → Ms."] if n != t else [])

def fix_alright(t):
    def rep(m): return "All right" if m.group(0)[0].isupper() else "all right"
    n = re.sub(r'\b[Aa]lright\b', rep, t)
    return n, (["Auto-fixed: alright → all right"] if n != t else [])

def fix_okay(t):
    def rep(m): return "Okay" if m.group(0)[0].isupper() else "okay"
    n = re.sub(r'\b[Oo]k\b', rep, t)
    return n, (["Auto-fixed: ok → okay"] if n != t else [])

def fix_percent(t):
    n = re.sub(r'(\d)\s*%', r'\1 percent', t)
    return n, (["Auto-fixed: % → percent"] if n != t else [])

def fix_ellipsis(t):
    n = t.replace('...', '--')
    return n, (["Auto-fixed: ellipsis (...) → (--)"] if n != t else [])

def fix_title_space(t):
    n = re.sub(r'\b(Mr|Ms|Dr|St)\.  +', r'\1. ', t)
    return n, (["Auto-fixed: double space after title → single space"] if n != t else [])

def fix_um_uh_ah(t):
    """
    Remove um/uh/ah — verbatim practice.
    Confirmed by Liz Knittle; omitted from Lori's style guide revision.
    """
    original = t
    t = re.sub(r',\s*(um|uh|ah)\s*,', ',', t, flags=re.IGNORECASE)
    t = re.sub(r'^(Um|Uh|Ah),\s+', '', t, flags=re.IGNORECASE)
    t = re.sub(r'\s+\b(um|uh|ah)\b\s*\.', '.', t, flags=re.IGNORECASE)
    t = re.sub(r'(?<= )\b(um|uh|ah)\b(?= )', '', t, flags=re.IGNORECASE)
    return t, (["Auto-fixed: removed um/uh/ah (verbatim practice)"] if t != original else [])

def fix_stutter(t):
    """
    Cap stutters at 3 repetitions.
    Confirmed practice; omitted from Lori's style guide revision.
    """
    original = t
    def cap(m):
        parts = re.split(r'\s+--\s+', m.group(0))
        return ' -- '.join(parts[:3]) if len(parts) > 3 else m.group(0)
    t = re.sub(r'\b(\w+)(?:\s+--\s+\1){3,}', cap, t)
    return t, (["Auto-fixed: stutter capped at 3 repetitions"] if t != original else [])

def fix_smart_quotes(t):
    original = t
    t = t.replace('\u201c', '"').replace('\u201d', '"')
    t = t.replace('\u2018', "'").replace('\u2019', "'")
    return t, (["Auto-fixed: smart/curly quotes → straight quotes"] if t != original else [])

def fix_em_en_dash(t):
    """
    Em dash (—) and en dash (–) must never appear in these transcripts.
    Replace with double dash (--), with a space on each side.
    """
    original = t
    # Em dash (U+2014) and en dash (U+2013) — normalize spacing around them
    t = re.sub(r'\s*[\u2013\u2014]\s*', ' -- ', t)
    return t, (["Auto-fixed: em/en dash → double dash (--)"] if t != original else [])

def fix_council(t):
    def rep(m): return "Counsel" if m.group(0)[0].isupper() else "counsel"
    n = re.sub(r'\b[Cc]ouncil\b', rep, t)
    return n, (["Auto-fixed: Council → Counsel"] if n != t else [])

def fix_no_abbrev(t):
    n = re.sub(r'\bNo\.\s+(\d)', r'Number \1', t)
    return n, (["Auto-fixed: 'No.' → 'Number'"] if n != t else [])

def fix_extra_spaces_mid(t):
    """
    Fix 2+ spaces between words mid-sentence.
    Skips: start of line, after byline colon (e.g. 'MR. JONES:  '),
    and after terminal punctuation (handled separately).
    """
    original = t

    # Strip byline prefix before processing so we don't touch intentional two spaces
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s{2})', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
    else:
        prefix = ''
        rest = t

    # Fix 2+ spaces between words that are NOT after terminal punctuation
    # Terminal punctuation followed by spaces is handled by fix_terminal_spacing
    fixed = re.sub(r'(?<![.?!:,])\s{2,}(?=\S)', ' ', rest)

    n = prefix + fixed
    return n, (["Auto-fixed: extra space(s) between words removed"] if n != original else [])


def fix_terminal_spacing(t):
    """
    Normalize spaces after terminal punctuation to exactly 2.
    Handles . ? ! and also closing quotes that follow terminal punctuation,
    e.g. 'Thank you."  next sentence' must have two spaces after the quote.
    """
    original = t

    # Strip byline prefix
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s{2})', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
    else:
        prefix = ''
        rest = t

    # Fix 3+ spaces after terminal punctuation (with optional closing quote) → exactly 2
    fixed = re.sub(r'([.?!]["\'"]?)\s{3,}(?=\S)', r'\1  ', rest)
    # Fix 0 or 1 space after terminal punctuation followed by closing quote → exactly 2
    fixed = re.sub(r'([.?!]["\'"])\s{0,1}(?=\S)', r'\1  ', fixed)

    n = prefix + fixed
    return n, (["Auto-fixed: spacing after terminal punctuation (including closing quote) → 2 spaces"] if n != original else [])


def fix_colon_space(t):
    """
    Colon is treated as terminal punctuation: two spaces must follow.
    Skips the byline prefix (e.g., 'MR. CONRECODE:  ') at the start of
    Colloquy paragraphs — those are intentional and already correct.
    Only fixes colons followed by exactly one space mid-text.
    """
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s+)', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
        fixed_rest = re.sub(r':(?!\s{2})\s(?=\S)', ':  ', rest)
        n = prefix + fixed_rest
    else:
        n = re.sub(r':(?!\s{2})\s(?=\S)', ':  ', t)
    return n, (["Auto-fixed: single space after colon → two spaces (colon = terminal punctuation)"] if n != t else [])

ALL_FIXES = [
    fix_mrs, fix_miss, fix_alright, fix_okay, fix_percent,
    fix_ellipsis, fix_title_space, fix_colon_space,
    fix_extra_spaces_mid, fix_terminal_spacing,
    fix_um_uh_ah, fix_stutter, fix_smart_quotes, fix_em_en_dash,
    fix_council, fix_no_abbrev,
]

def apply_fixes(text):
    changes = []
    for fn in ALL_FIXES:
        text, c = fn(text)
        changes.extend(c)
    return text, changes


# ---------------------------------------------------------------------------
# FLAGS
# ---------------------------------------------------------------------------

def flag_mmhmm(t):
    """Flag affirmative interjections that must be transcribed per this profile's style."""
    if re.search(r'\b(mm-?hmm|mhm|mm\s+hmm|uh-?huh)\b', t, re.IGNORECASE):
        return ["FLAG — 'Mm-hmm' variant: verify correct this profile's spelling and formatting "
                "for affirmative interjection (typically: Mm-hmm)."]
    return []

def flag_strike_that(t):
    if re.search(r'\bstrike\s+that\b', t, re.IGNORECASE):
        return ["FLAG — 'Strike that': verify this is verbatim testimony and formatted correctly."]
    return []

def flag_underline(para):
    for r in para.runs:
        if r.underline:
            return ["FLAG — Underlined text: verify appropriate per this profile's style. "
                    "Underlines are rarely used in deposition transcripts."]
    return []

def flag_doctor(t):
    if re.search(r'\bDoctor\s+[A-Z]', t):
        return ["FLAG — 'Doctor' before a name: use 'Dr.' as title abbreviation. "
                "'doctor' lowercase as generic noun; 'Doctor' only as name substitute."]
    return []

def flag_semicolon(t):
    # Semicolons in certificate/notary language are standard — don't flag them
    if re.search(r'\bcertify\b|\bnotary\b|\bdisinterested\b|\bsubscribed\b', t, re.IGNORECASE):
        return []
    if ';' in t:
        return ["FLAG — Semicolon: verify appropriate use per this profile's style."]
    return []

def flag_phonetic_wrong(t):
    """This profile uses (ph), not (phonetic)."""
    if re.search(r'\(phonetic\)', t, re.IGNORECASE):
        return ["FLAG — '(phonetic)' found: this profile's style uses '(ph)', not '(phonetic)'. "
                "Please correct."]
    return []

def flag_ph(t):
    if re.search(r'\(ph\)', t, re.IGNORECASE):
        return ["FLAG — (ph) unresolved: research and confirm correct spelling. "
                "Record on case sheet once confirmed."]
    return []

def flag_sic(t):
    if re.search(r'\(sic\)', t, re.IGNORECASE):
        return ["FLAG — (sic): verify speaker actually misspoke and error is intentional."]
    return []

def flag_indiscernible(t):
    if re.search(r'\b(indiscernible|unintelligible|inaudible)\b', t, re.IGNORECASE):
        return ["FLAG — Indiscernible/unintelligible/inaudible: confirm correct term "
                "per this profile's style and that timestamp is present where required."]
    return []

def flag_exclamation(t):
    if '!' in t:
        return ["FLAG — Exclamation point: not used in these transcripts."]
    return []

def flag_smart_quotes_remaining(t):
    if any(c in t for c in ['\u201c', '\u201d', '\u2018', '\u2019']):
        return ["FLAG — Smart/curly quotes remain: disable in Word AutoCorrect settings."]
    return []

def flag_double_dash(t):
    if re.search(r'\S--\S|\S-- | --\S', t):
        return ["FLAG — Double dash (--): verify space on both sides; must not split across lines."]
    return []

def flag_date_ordinal(t):
    if re.search(
        r'\b(January|February|March|April|May|June|July|August|September|'
        r'October|November|December)\s+\d{1,2}(st|nd|rd|th),\s+\d{4}', t
    ):
        return ["FLAG — Date ordinal with year: omit ordinal ending "
                "(e.g., March 24, 2023 — not March 24th, 2023)."]
    return []

def flag_section_symbol(t):
    if re.search(r'\b[Ss]ection\s+\d|\b[Ss]tatute\b', t):
        return ["FLAG — 'Section'/'Statute' before a number: verify § symbol (Alt+21) "
                "is used for code sections per this profile's style."]
    return []

def flag_exhibit_cap(t):
    if re.search(r'\bexhibit\s+\d', t):
        return ["FLAG — 'exhibit' lowercase before a number: when exhibit has been "
                "named/numbered, 'Exhibit' should be capitalized."]
    return []

def flag_terminal_comma(t):
    """
    Flag paragraph ending with a comma, with or without a closing quote after it.
    e.g. 'word,' or 'word,"' at end of paragraph.
    """
    stripped = t.rstrip()
    if re.search(r',[\u201d"\u2019]?$', stripped):
        return ["FLAG — Paragraph ends with a comma: should this be a period or question mark?"]
    return []

def flag_comma_before_closing_quote(t):
    """
    Flag comma immediately before a closing quote anywhere in paragraph.
    Proofreader must verify whether the sentence continues after the quote.
    If nothing follows the quoted passage, comma should be a period.
    e.g. 'He said, "I did it,"' — flag for review.
    """
    if re.search(r',[\u201d"\u2019]', t):
        return ["FLAG — Comma before closing quote: verify sentence continues after the quote. "
                "If the quoted passage ends the sentence, comma should be a period."]
    return []

def flag_manual_indent(para):
    """
    Detect manual indent overrides — skip for Normal style since all Normal
    paragraphs lack style-driven indentation and would false-flag constantly.
    """
    if para.style.name == 'Normal':
        return []
    pf = para.paragraph_format
    if pf.left_indent is not None or pf.first_line_indent is not None:
        return ["FLAG — Manual indent override detected: this paragraph has indentation "
                "applied directly (not from the style), which may cause wrapped lines to "
                "indent incorrectly. Clear paragraph formatting: select the paragraph, "
                "then Home → Paragraph → reset indent to 0, or use 'Clear Formatting'."]
    return []


def collect_flags(para):
    t = get_text(para)
    flags = []
    flags.extend(flag_mmhmm(t))
    flags.extend(flag_strike_that(t))
    flags.extend(flag_underline(para))
    flags.extend(flag_doctor(t))
    flags.extend(flag_semicolon(t))
    flags.extend(flag_phonetic_wrong(t))
    flags.extend(flag_ph(t))
    flags.extend(flag_sic(t))
    flags.extend(flag_indiscernible(t))
    flags.extend(flag_exclamation(t))
    flags.extend(flag_smart_quotes_remaining(t))
    flags.extend(flag_double_dash(t))
    flags.extend(flag_date_ordinal(t))
    flags.extend(flag_section_symbol(t))
    flags.extend(flag_exhibit_cap(t))
    flags.extend(flag_terminal_comma(t))
    flags.extend(flag_comma_before_closing_quote(t))
    flags.extend(flag_manual_indent(para))
    return flags


# ---------------------------------------------------------------------------
# PARAGRAPH-LEVEL FIXES (run/XML manipulation)
# ---------------------------------------------------------------------------

def fix_superscript_ordinals(para):
    """
    Remove superscript formatting from ordinal suffixes (1st, 2nd, 3rd, 4th, etc.).
    Superscript is a run property (w:vertAlign w:val="superscript").
    Returns a list of change messages.
    """
    from docx.oxml.ns import qn as _qn
    changes = []
    for run in para.runs:
        rpr = run._r.find(_qn('w:rPr'))
        if rpr is None:
            continue
        vert = rpr.find(_qn('w:vertAlign'))
        if vert is not None and vert.get(_qn('w:val')) == 'superscript':
            # Only remove if this run looks like an ordinal suffix
            txt = run.text.strip().lower()
            if txt in ('st', 'nd', 'rd', 'th'):
                rpr.remove(vert)
                changes.append("Auto-fixed: superscript ordinal suffix removed")
    return changes


def bold_changed_words(para, original_text, new_text):
    """
    After set_text has been called, bold the words in new_text that differ
    from original_text.  Works by diffing word-by-word and then inserting
    a bold run for each changed token.

    Also bolds the words immediately surrounding a deleted space
    (i.e. when a word-boundary space was removed).

    This rebuilds the paragraph's run list so it must be called AFTER set_text.
    """
    from docx.oxml.ns import qn as _qn
    from docx.oxml import OxmlElement
    import difflib

    if original_text == new_text:
        return

    # Tokenize preserving whitespace tokens
    orig_tokens = re.split(r'(\s+)', original_text)
    new_tokens  = re.split(r'(\s+)', new_text)

    # Find which new tokens are changed/inserted
    sm = difflib.SequenceMatcher(None, orig_tokens, new_tokens, autojunk=False)
    bold_indices = set()
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ('replace', 'insert'):
            for j in range(j1, j2):
                bold_indices.add(j)
            # Also bold the word on either side of a deleted space
            if j1 > 0:
                bold_indices.add(j1 - 1)
            if j2 < len(new_tokens):
                bold_indices.add(j2)

    if not bold_indices:
        return

    # Rebuild paragraph runs: plain run for unchanged, bold run for changed
    p_elem = para._p

    # Collect existing rPr from first run for style inheritance
    existing_runs = para.runs
    base_rpr = None
    if existing_runs:
        base_rpr = existing_runs[0]._r.find(_qn('w:rPr'))

    # Remove all existing runs from the paragraph element
    for r in p_elem.findall(_qn('w:r')):
        p_elem.remove(r)

    # Insert new runs
    for idx, token in enumerate(new_tokens):
        r = OxmlElement('w:r')

        # Copy base run properties
        if base_rpr is not None:
            import copy
            new_rpr = copy.deepcopy(base_rpr)
        else:
            new_rpr = OxmlElement('w:rPr')

        if idx in bold_indices and token.strip():
            # Add or replace bold element
            existing_b = new_rpr.find(_qn('w:b'))
            if existing_b is None:
                b = OxmlElement('w:b')
                new_rpr.insert(0, b)

        r.append(new_rpr)
        t = OxmlElement('w:t')
        t.text = token
        if token.startswith(' ') or token.endswith(' '):
            t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        r.append(t)
        p_elem.append(r)


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def process(input_path):
    print(f"File: {os.path.basename(input_path)}")
    print()

    doc = Document(input_path)
    engine = CommentEngine(doc)

    fix_count = flag_count = touched = skipped = 0

    # Find the paragraph index where the proceeding body begins.
    proceeding_idx = None
    for i, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        if re.match(r'^P[\s]*R[\s]*O[\s]*C[\s]*E[\s]*E[\s]*D[\s]*I[\s]*N[\s]*G', text, re.IGNORECASE):
            proceeding_idx = i
            break

    if proceeding_idx is None:
        print("  ⚠️  No 'PROCEEDING' marker found — Normal paragraphs will be protected.")
        print("      Only Colloquy, Q&A, and Parenthetical styles will be processed.")
        print()

    for i, para in enumerate(doc.paragraphs):
        style = get_style(para)

        if style == 'Normal':
            if proceeding_idx is None or i <= proceeding_idx:
                skipped += 1
                continue

        if style not in PROCESS_STYLES:
            skipped += 1
            continue

        original = get_text(para)
        if not original.strip():
            continue

        # --- Superscript ordinal fix (run-level, before text fixes) ---
        sup_changes = fix_superscript_ordinals(para)
        fix_count += len(sup_changes)

        # --- Text-level auto-fixes ---
        new_text, changes = apply_fixes(original)
        all_changes = sup_changes + changes

        if new_text != original:
            set_text(para, new_text)
            # Bold the corrected words in the paragraph
            bold_changed_words(para, original, new_text)
            fix_count += len(changes)

        # --- Collect text flags ---
        flags = collect_flags(para)
        flag_count += len(flags)

        all_notes = all_changes + flags
        if all_notes:
            engine.add(para, "\n\n".join(all_notes))
            touched += 1

    engine.write_to_document(doc)

    base, ext = os.path.splitext(input_path)
    out_path = base + "_PROOFED" + ext
    doc.save(out_path)

    print(f"COMPLETE")
    print(f"  Paragraphs processed : {touched}")
    print(f"  Paragraphs protected : {skipped} (front matter + caption/appearances/index/cert)")
    print(f"  Auto-fixes applied   : {fix_count}")
    print(f"  Flags inserted       : {flag_count}")
    print(f"  Output file          : {os.path.basename(out_path)}")
    print(f"  Saved to             : {os.path.dirname(out_path)}")
    print()
    input("Press Enter to exit.")


if __name__ == "__main__":
    input_path = prompt_for_file("proof_depo_direct.py", PROFILE_NAME)
    process(input_path)
