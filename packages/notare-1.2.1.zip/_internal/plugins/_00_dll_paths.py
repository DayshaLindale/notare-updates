"""DLL Path Fix — adds ctranslate2 directory to DLL search path.

MUST load before any plugin that imports faster_whisper or ctranslate2.
Named _00_ to sort first alphabetically in the plugin loader.

Solves: In frozen PyInstaller exe, ctranslate2's .pyd can't find
ctranslate2.dll because it's in a subdirectory, not at _internal root.
"""
import os
import sys

# Find the _internal directory (where PyInstaller puts everything)
if getattr(sys, 'frozen', False):
    _internal = os.path.join(os.path.dirname(sys.executable), '_internal')
else:
    _internal = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(_internal) == 'plugins':
        _internal = os.path.dirname(_internal)

# Add ctranslate2 directory to DLL search path
_ct2_dir = os.path.join(_internal, 'ctranslate2')
if os.path.isdir(_ct2_dir):
    try:
        os.add_dll_directory(_ct2_dir)
        print(f"DLL path added: {_ct2_dir}")
    except (OSError, AttributeError):
        # add_dll_directory not available on older Python or failed
        # Fallback: add to PATH
        os.environ['PATH'] = _ct2_dir + os.pathsep + os.environ.get('PATH', '')
        print(f"DLL PATH fallback: {_ct2_dir}")

# Also add _internal root itself (belt and suspenders)
if os.path.isdir(_internal):
    try:
        os.add_dll_directory(_internal)
    except (OSError, AttributeError):
        pass

# Verify the fix worked
try:
    import ctranslate2
    from faster_whisper import WhisperModel
    print("DLL fix verified: ctranslate2 + WhisperModel importable")
except ImportError as e:
    print(f"DLL fix: import still failing — {e}")
except Exception as e:
    print(f"DLL fix: unexpected error — {e}")
