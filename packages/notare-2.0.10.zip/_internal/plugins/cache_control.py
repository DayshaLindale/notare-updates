"""Cache-Control plugin — forces fresh HTML on every load.

Prevents WebView2 from serving stale static HTML after OTA updates overwrite
files on disk. Without this, the user can see an old UI (e.g. the newCount
error) even after the patch landed on disk. Only applies to *.html so
JS/CSS/images still use normal ETag caching.
"""
import sys
import logging

logger = logging.getLogger("notare")

_app_module = sys.modules.get("app")
if not _app_module:
    raise RuntimeError("app module not loaded")

_app = _app_module.app


@_app.middleware("http")
async def _no_store_static_html(request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path.startswith("/static/") and path.endswith(".html"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


print("Plugin loaded: cache_control.py — no-store for static HTML")
