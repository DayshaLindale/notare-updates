"""notare_shared.py — Shared utilities for standalone Notare proofing scripts.

Provides:
  - CommentEngine: Insert Word comments into .docx paragraphs
  - get_text(para): Get full text from a paragraph's runs
  - set_text(para, text): Write text back preserving first run's formatting
  - get_style(para): Get paragraph style name
  - prompt_for_file(script_name, profile_name): Interactive file picker (CLI only)

When called from the Notare web UI, prompt_for_file is never invoked —
the API calls process(input_path) directly.
"""
import os
import re
from datetime import datetime, timezone

from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.opc.part import Part
from docx.opc.packuri import PackURI
import lxml.etree as etree


# ─────────────────────────────────────────────
# CommentEngine — Insert Word comments
# ─────────────────────────────────────────────

class CommentEngine:
    """Insert Word comments into a .docx document.

    Usage:
        engine = CommentEngine(doc)
        engine.add(paragraph, "Comment text here")
        engine.write_to_document(doc)
        doc.save(output_path)
    """

    def __init__(self, doc):
        self._comments = []
        self._doc = doc
        rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
        try:
            existing = doc.part.part_related_by(rel_type)
            ids = [int(c.get(qn("w:id"))) for c in existing._element.findall(qn("w:comment"))]
            self._id_offset = max(ids) + 1 if ids else 0
            self._use_existing = True
            self._existing_part = existing
        except Exception:
            self._id_offset = 0
            self._use_existing = False
            self._existing_part = None
        self._next_id = 0

    def add(self, paragraph, text):
        """Add a Word comment to a paragraph."""
        cid = self._next_id + self._id_offset
        self._next_id += 1
        self._comments.append({"id": cid, "text": text})

        p = paragraph._p
        sid = str(cid)

        crs = OxmlElement("w:commentRangeStart")
        crs.set(qn("w:id"), sid)
        cre = OxmlElement("w:commentRangeEnd")
        cre.set(qn("w:id"), sid)

        ref_run = OxmlElement("w:r")
        rpr = OxmlElement("w:rPr")
        rst = OxmlElement("w:rStyle")
        rst.set(qn("w:val"), "CommentReference")
        rpr.append(rst)
        ref_run.append(rpr)
        cref = OxmlElement("w:commentReference")
        cref.set(qn("w:id"), sid)
        ref_run.append(cref)

        runs = p.findall(qn("w:r"))
        if runs:
            runs[0].addprevious(crs)
            runs[-1].addnext(cre)
            cre.addnext(ref_run)
        else:
            p.append(crs)
            p.append(cre)
            p.append(ref_run)

    def write_to_document(self, doc):
        """Write all queued comments into the document XML."""
        if not self._comments:
            return

        rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        root = self._existing_part._element if self._use_existing else OxmlElement("w:comments")

        for c in self._comments:
            comment = OxmlElement("w:comment")
            comment.set(qn("w:id"), str(c["id"]))
            comment.set(qn("w:author"), "Notare Proofer")
            comment.set(qn("w:date"), date_str)
            comment.set(qn("w:initials"), "NP")

            cp = OxmlElement("w:p")
            cr = OxmlElement("w:r")
            ct = OxmlElement("w:t")
            ct.text = c["text"]
            ct.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            cr.append(ct)
            cp.append(cr)
            comment.append(cp)
            root.append(comment)

        xml_bytes = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)

        if self._use_existing:
            self._existing_part._blob = xml_bytes
        else:
            part = Part(
                PackURI("/word/comments.xml"),
                "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml",
                xml_bytes, doc.part.package,
            )
            doc.part.relate_to(part, rel_type)


# ─────────────────────────────────────────────
# Paragraph helpers
# ─────────────────────────────────────────────

def get_text(para):
    """Get the full text content of a paragraph by joining all runs."""
    return "".join(r.text for r in para.runs)


def set_text(para, text):
    """Write text back to a paragraph, preserving first run's formatting."""
    if para.runs:
        para.runs[0].text = text
        for r in para.runs[1:]:
            # Preserve runs with explicit formatting (bold, underline, color)
            has_fmt = r.bold or r.underline or (r.font.color and r.font.color.type is not None)
            if not has_fmt:
                r.text = ""


def get_style(para):
    """Get the style name of a paragraph."""
    try:
        return para.style.name.strip()
    except Exception:
        return ""


# ─────────────────────────────────────────────
# Interactive file picker (CLI use only)
# ─────────────────────────────────────────────

def prompt_for_file(script_name, profile_name):
    """Prompt the user to select a .docx file interactively.

    If a command-line argument is provided, uses that instead.
    Only used in standalone CLI mode — Notare web API calls process() directly.
    """
    import sys

    if len(sys.argv) > 1:
        path = sys.argv[1]
        if os.path.isfile(path):
            return path
        print(f"File not found: {path}")
        sys.exit(1)

    print(f"  {profile_name}")
    print()
    folder = input("  Enter folder path: ").strip().strip('"')
    if not os.path.isdir(folder):
        print(f"  Folder not found: {folder}")
        sys.exit(1)

    docx_files = sorted(f for f in os.listdir(folder) if f.lower().endswith(".docx"))
    if not docx_files:
        print("  No .docx files found in that folder.")
        sys.exit(1)

    print()
    for i, f in enumerate(docx_files, 1):
        print(f"  {i}. {f}")
    print()

    choice = input("  Select file number: ").strip()
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(docx_files):
            return os.path.join(folder, docx_files[idx])
    except ValueError:
        pass

    print("  Invalid selection.")
    sys.exit(1)
