"""
proof_legacy_texas.py
Legacy Transcription Services — Texas / Florida
Clean Verbatim Standard

Usage (command line):
    py "proof_legacy_texas.py" "path\\to\\transcript.docx"

Usage (interactive):
    py "proof_legacy_texas.py"
    -> prompts for folder, then lets you pick the file

Output:
    transcript_PROOFED.docx in the same folder as the original.
    All changes and flags inserted as Word comments.

Verbatim standard: Clean Verbatim
    - um / uh / ah removed (auto-fix)
    - Filler words (you know, like, I mean) flagged for removal
    - False starts under 4 words flagged for removal
    - Active listening responses flagged for removal
"""

import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from notare_shared import CommentEngine, get_text, set_text, get_style, prompt_for_file
from docx import Document


PROFILE_NAME = "Legacy Texas/Florida — Clean Verbatim"
BODY_START   = "(Proceedings convened at"
BODY_END     = "(Proceedings concluded at"


# ---------------------------------------------------------------------------
# AUTO-FIXES (identical to Oregon)
# ---------------------------------------------------------------------------

def fix_mrs(t):
    n = re.sub(r'\bMrs\.', 'Ms.', t)
    return n, (["Auto-fixed: Mrs. → Ms."] if n != t else [])

def fix_miss(t):
    n = re.sub(r'\bMiss\b', 'Ms.', t)
    return n, (["Auto-fixed: Miss → Ms."] if n != t else [])

def fix_alright(t):
    def rep(m): return "All right" if m.group(0)[0].isupper() else "all right"
    n = re.sub(r'\b[Aa]lright\b', rep, t)
    return n, (["Auto-fixed: alright → all right"] if n != t else [])

def fix_okay(t):
    def rep(m): return "Okay" if m.group(0)[0].isupper() else "okay"
    n = re.sub(r'\b[Oo]k\b', rep, t)
    return n, (["Auto-fixed: ok → okay"] if n != t else [])

def fix_percent(t):
    n = re.sub(r'(\d)\s*%', r'\1 percent', t)
    return n, (["Auto-fixed: % → percent"] if n != t else [])

def fix_ph_to_phonetic(t):
    n = re.sub(r'\(ph\)', '(phonetic)', t, flags=re.IGNORECASE)
    return n, (["Auto-fixed: (ph) → (phonetic)"] if n != t else [])

def fix_ellipsis(t):
    n = t.replace('...', '--')
    return n, (["Auto-fixed: ellipsis (...) → (--)"] if n != t else [])

def fix_title_space(t):
    n = re.sub(r'\b(Mr|Ms|Dr|St)\.  +', r'\1. ', t)
    return n, (["Auto-fixed: double space after title → single space"] if n != t else [])

def fix_um_uh_ah(t):
    original = t
    t = re.sub(r',\s*(um|uh|ah)\s*,', ',', t, flags=re.IGNORECASE)
    t = re.sub(r'^(Um|Uh|Ah),\s+', '', t, flags=re.IGNORECASE)
    t = re.sub(r'\s+\b(um|uh|ah)\b\s*\.', '.', t, flags=re.IGNORECASE)
    t = re.sub(r'(?<= )\b(um|uh|ah)\b(?= )', '', t, flags=re.IGNORECASE)
    return t, (["Auto-fixed: removed um/uh/ah (clean verbatim)"] if t != original else [])

def fix_stutter(t):
    original = t
    def cap(m):
        parts = re.split(r'\s+--\s+', m.group(0))
        return ' -- '.join(parts[:3]) if len(parts) > 3 else m.group(0)
    t = re.sub(r'\b(\w+)(?:\s+--\s+\1){3,}', cap, t)
    return t, (["Auto-fixed: stutter capped at 3 repetitions"] if t != original else [])

def fix_smart_quotes(t):
    original = t
    t = t.replace('\u201c', '"').replace('\u201d', '"')
    t = t.replace('\u2018', "'").replace('\u2019', "'")
    return t, (["Auto-fixed: smart/curly quotes → straight quotes"] if t != original else [])

def fix_council(t):
    def rep(m): return "Counsel" if m.group(0)[0].isupper() else "counsel"
    n = re.sub(r'\b[Cc]ouncil\b', rep, t)
    return n, (["Auto-fixed: Council → Counsel"] if n != t else [])

def fix_inaudible(t):
    n = re.sub(r'\binaudible\b', '(Indiscernible)', t, flags=re.IGNORECASE)
    return n, (["Auto-fixed: 'inaudible' → '(Indiscernible)'"] if n != t else [])

def fix_no_abbrev(t):
    n = re.sub(r'\bNo\.\s+(\d)', r'Number \1', t)
    return n, (["Auto-fixed: 'No.' → 'Number'"] if n != t else [])

def fix_colon_space(t):
    """
    Colon is treated as terminal punctuation: two spaces must follow.
    Skips the byline prefix (e.g., 'MR. CONRECODE:  ') at the start of
    Colloquy paragraphs — those are intentional and already correct.
    Only fixes colons followed by exactly one space mid-text.
    """
    byline_match = re.match(r'^([A-Z][A-Z\s.]+:\s+)', t)
    if byline_match:
        prefix = byline_match.group(1)
        rest = t[len(prefix):]
        fixed_rest = re.sub(r':(?!\s{2})\s(?=\S)', ':  ', rest)
        n = prefix + fixed_rest
    else:
        n = re.sub(r':(?!\s{2})\s(?=\S)', ':  ', t)
    return n, (["Auto-fixed: single space after colon → two spaces (colon = terminal punctuation)"] if n != t else [])

ALL_FIXES = [
    fix_mrs, fix_miss, fix_alright, fix_okay, fix_percent,
    fix_ph_to_phonetic, fix_ellipsis, fix_title_space, fix_colon_space,
    fix_um_uh_ah, fix_stutter, fix_smart_quotes,
    fix_council, fix_inaudible, fix_no_abbrev,
]

def apply_fixes(text):
    changes = []
    for fn in ALL_FIXES:
        text, c = fn(text)
        changes.extend(c)
    return text, changes


# ---------------------------------------------------------------------------
# FLAGS — shared
# ---------------------------------------------------------------------------

def flag_underline(para):
    for r in para.runs:
        if r.underline:
            return ["FLAG — Underlined text: verify case citations only. "
                    "Named cases only — not statutes, codes, or the case in chief."]
    return []

def flag_doctor(t):
    if re.search(r'\bDoctor\b', t):
        return ["FLAG — 'Doctor' capitalized: capitalize only as name substitute. "
                "Use 'Dr.' before a name; 'doctor' lowercase as generic noun."]
    return []

def flag_semicolon(t):
    if ';' in t:
        return ["FLAG — Semicolon: permitted only in tag questions or comma-laden lists."]
    return []

def flag_double_slash(t):
    if '//' in t:
        return ["FLAG — '//' notation: confirm header/BY line follows at top of next page."]
    return []

def flag_phonetic(t):
    if re.search(r'\(phonetic\)', t, re.IGNORECASE):
        return ["FLAG — (phonetic) unresolved: research and confirm before submission."]
    return []

def flag_sic(t):
    if re.search(r'\(sic\)', t, re.IGNORECASE):
        return ["FLAG — (sic): verify speaker actually misspoke and error is intentional."]
    return []

def flag_indiscernible(t):
    if re.search(r'\(indiscernible\)', t, re.IGNORECASE):
        return ["FLAG — (Indiscernible): confirm timestamp is present."]
    return []

def flag_exclamation(t):
    if '!' in t:
        return ["FLAG — Exclamation point: not used in Legacy transcripts."]
    return []

def flag_smart_quotes_remaining(t):
    if any(c in t for c in ['\u201c', '\u201d', '\u2018', '\u2019']):
        return ["FLAG — Smart/curly quotes remain: disable in Word AutoCorrect settings."]
    return []

def flag_witness_cap(t):
    if re.search(r'\bthe Witness\b', t):
        return ["FLAG — 'the Witness': lowercase unless used as name substitute."]
    return []

def flag_victim_cap(t):
    if re.search(r'\bthe Victim\b', t):
        return ["FLAG — 'the Victim': lowercase unless used as name substitute."]
    return []

def flag_double_dash(t):
    if re.search(r'\S--\S|\S-- | --\S', t):
        return ["FLAG — Double dash (--): verify space on both sides; must not split across lines."]
    return []

def flag_date_ordinal(t):
    if re.search(
        r'\b(January|February|March|April|May|June|July|August|September|'
        r'October|November|December)\s+\d{1,2}(st|nd|rd|th),\s+\d{4}', t
    ):
        return ["FLAG — Date ordinal with year: omit ordinal "
                "(e.g., August 1, 2024 — not August 1st, 2024)."]
    return []

def flag_fraction(t):
    if re.search(r'\bhalf an hour\b|\btwo and a half\b|\bone and a half\b', t, re.IGNORECASE):
        return ["FLAG — Fraction: needs hyphens (e.g., half-an-hour, two-and-a-half)."]
    return []


# ---------------------------------------------------------------------------
# FLAGS — Texas clean verbatim only
# ---------------------------------------------------------------------------

ACTIVE_LISTENING = re.compile(
    r'^\s*(Right|Okay|Sure|Uh-huh|Mm-hmm|All right|Got it|I see)\s*[.?]?\s*$',
    re.IGNORECASE
)
FILLER_WORDS = re.compile(r'\b(you know|I mean|like,)\b', re.IGNORECASE)
FALSE_START  = re.compile(r'\b(\w+(?:\s+\w+){0,2})\s+--\s+')

def flag_filler(t):
    if FILLER_WORDS.search(t):
        return ["FLAG (Clean Verbatim) — Filler word (you know / I mean / like): "
                "omit per clean verbatim standard."]
    return []

def flag_active_listening(para):
    if ACTIVE_LISTENING.match(get_text(para).strip()):
        return ["FLAG (Clean Verbatim) — Possible active listening response "
                "(Right. / Okay. / Sure. etc.): omit per clean verbatim standard."]
    return []

def flag_false_start(t):
    for phrase in FALSE_START.findall(t):
        if len(phrase.strip().split()) < 4:
            return ["FLAG (Clean Verbatim) — Possible false start under 4 words before '--': "
                    "omit unless substantive."]
    return []


def collect_flags(para):
    t = get_text(para)
    flags = []
    flags.extend(flag_underline(para))
    flags.extend(flag_doctor(t))
    flags.extend(flag_semicolon(t))
    flags.extend(flag_double_slash(t))
    flags.extend(flag_phonetic(t))
    flags.extend(flag_sic(t))
    flags.extend(flag_indiscernible(t))
    flags.extend(flag_exclamation(t))
    flags.extend(flag_smart_quotes_remaining(t))
    flags.extend(flag_witness_cap(t))
    flags.extend(flag_victim_cap(t))
    flags.extend(flag_double_dash(t))
    flags.extend(flag_date_ordinal(t))
    flags.extend(flag_fraction(t))
    flags.extend(flag_filler(t))
    flags.extend(flag_active_listening(para))
    flags.extend(flag_false_start(t))
    return flags


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def find_body_range(doc):
    start, end = None, None
    for i, p in enumerate(doc.paragraphs):
        t = get_text(p)
        if start is None and BODY_START in t:
            start = i
        if start is not None and BODY_END in t:
            end = i
            break
    return start, end


def process(input_path):
    print(f"File: {os.path.basename(input_path)}")
    print()

    doc = Document(input_path)
    engine = CommentEngine(doc)

    start, end = find_body_range(doc)

    if start is None:
        print(f"ERROR: Body start anchor not found.")
        print(f"  Looking for: '{BODY_START}'")
        input("\nPress Enter to exit.")
        sys.exit(1)

    if end is None:
        print(f"WARNING: Body end anchor not found. Processing to end of document.")
        end = len(doc.paragraphs) - 1

    print(f"Body range : paragraphs {start} to {end}")
    print(f"Processing...")

    fix_count = flag_count = touched = 0

    for i, para in enumerate(doc.paragraphs):
        if i < start or i > end:
            continue
        original = get_text(para)
        if not original.strip():
            continue

        new_text, changes = apply_fixes(original)
        if changes:
            set_text(para, new_text)
            fix_count += len(changes)

        flags = collect_flags(para)
        flag_count += len(flags)

        all_notes = changes + flags
        if all_notes:
            engine.add(para, "\n\n".join(all_notes))
            touched += 1

    engine.write_to_document(doc)

    base, ext = os.path.splitext(input_path)
    out_path = base + "_PROOFED" + ext
    doc.save(out_path)

    print()
    print(f"COMPLETE")
    print(f"  Auto-fixes applied : {fix_count}")
    print(f"  Flags inserted     : {flag_count}")
    print(f"  Paragraphs touched : {touched}")
    print(f"  Output file        : {os.path.basename(out_path)}")
    print(f"  Saved to           : {os.path.dirname(out_path)}")
    print()
    input("Press Enter to exit.")


if __name__ == "__main__":
    input_path = prompt_for_file("proof_legacy_texas.py", PROFILE_NAME)
    process(input_path)
