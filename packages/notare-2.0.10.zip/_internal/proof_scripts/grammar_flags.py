"""
grammar_flags.py
Notare / Legacy Transcription Services

Grammar and word-confusion flagging module.
Import this into any Notare proofing script — do not run directly.

Checks performed:
    1. Confusable words (there/their/they're, your/you're, etc.)
    2. Legal homophones (statute/statue, fiscal/physical, etc.)
    3. Suspicious ASR words (gonna, wanna, etc.)
    4. Number-word mismatch (digit 1-9 where style requires spelled-out)
    5. Sentence fragment detection (requires spacy — gracefully skipped if not installed)

Nothing is auto-corrected. All findings are returned as flag strings
for insertion as Word comments by the calling script.

spacy setup (one-time):
    py -m pip install spacy
    py -m spacy download en_core_web_sm
"""

import re

# ---------------------------------------------------------------------------
# spacy — optional; fragment detection only
# ---------------------------------------------------------------------------

_nlp = None
_SPACY_AVAILABLE = False

try:
    import spacy
    try:
        _nlp = spacy.load("en_core_web_sm")
        _SPACY_AVAILABLE = True
    except OSError:
        # Model not downloaded yet
        _SPACY_AVAILABLE = False
except ImportError:
    _SPACY_AVAILABLE = False


# ---------------------------------------------------------------------------
# 1. CONFUSABLE WORDS
# ---------------------------------------------------------------------------
# Strategy: flag the word when context strongly suggests it's wrong.
# Each pattern targets the *incorrect* usage so false positives stay low.
# Flag messages are explicit about what the likely error is.

def flag_confusables(text):
    flags = []

    # there → their  (there followed by a noun phrase: "there house", "there car")
    if re.search(r'\bthere\s+(house|home|car|truck|office|kids|children|family|dog|cat|phone|case|client|attorney|lawyer|money|property|land|business|company|work|job|name|wife|husband|son|daughter|brother|sister|mother|father|parents|friend)\b', text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'there' may be incorrect. "
            "If possessive is intended, the correct word is 'their' "
            "(e.g., 'their house', not 'there house'). Verify against audio."
        )

    # their → there  ("go their", "over their", "sit their")
    if re.search(r'\b(go|went|over|sit|stood|standing|lived|located|arrived|was|is|are|were)\s+their\b', text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'their' may be incorrect. "
            "If indicating a location or direction is intended, the correct word is 'there' "
            "(e.g., 'go there', not 'go their'). Verify against audio."
        )

    # they're → their or there  ("they're house", "they're car")
    if re.search(r"\bthey're\s+(house|home|car|truck|office|kids|children|family|dog|cat|property|business|company)\b", text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'they're' may be incorrect. "
            "'They're' is a contraction of 'they are'. "
            "If possessive is intended, use 'their'; if location, use 'there'. Verify against audio."
        )

    # your → you're  ("your going", "your saying", "your telling", "your asking")
    if re.search(r"\byour\s+(going|saying|telling|asking|trying|doing|being|getting|making|taking|coming|looking|thinking|talking|referring|suggesting|claiming|alleging|testifying)\b", text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'your' may be incorrect. "
            "If a contraction of 'you are' is intended, the correct word is 'you're' "
            "(e.g., 'you're saying', not 'your saying'). Verify against audio."
        )

    # you're → your  ("you're honor", "you're case", "you're client")
    if re.search(r"\byou're\s+(honor|case|client|attorney|lawyer|name|testimony|question|answer|statement|office|company|business|property)\b", text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'you're' may be incorrect. "
            "'You're' is a contraction of 'you are'. "
            "If possessive is intended, the correct word is 'your' "
            "(e.g., 'your Honor', not 'you're Honor'). Verify against audio."
        )

    # its → it's  ("its a", "its not", "its been", "its very", "its clear")
    if re.search(r"\bits\s+(a|an|the|not|been|very|clear|true|possible|likely|important|my|your|his|her|their|our)\b", text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'its' may be incorrect. "
            "If a contraction of 'it is' or 'it has' is intended, the correct word is 'it's' "
            "(e.g., 'it's not', not 'its not'). Verify against audio."
        )

    # it's → its  ("it's own", "it's purpose", "it's value", "it's contents")
    if re.search(r"\bit's\s+(own|purpose|value|contents|meaning|nature|scope|terms|effect|impact)\b", text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'it\\'s' may be incorrect. "
            "If possessive is intended, the correct word is 'its' "
            "(e.g., 'its own terms', not 'it\\'s own terms'). Verify against audio."
        )

    # could/would/should of → have
    if re.search(r'\b(could|would|should|must|might|may)\s+of\b', text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'of' after a modal verb may be incorrect. "
            "If 'could have', 'would have', or 'should have' is intended, "
            "use 'have', not 'of'. This is a common ASR and spoken-language error. Verify against audio."
        )

    # then → than  (comparative context: "more then", "less then", "better then", "rather then")
    if re.search(r'\b(more|less|better|worse|rather|other|greater|higher|lower|faster|slower|older|younger|bigger|smaller)\s+then\b', text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'then' may be incorrect. "
            "In a comparison, the correct word is 'than' "
            "(e.g., 'more than', not 'more then'). Verify against audio."
        )

    # than → then  (sequential context: "and than", "but than")
    if re.search(r'\b(and|but)\s+than\b', text, re.IGNORECASE):
        flags.append(
            "FLAG — Possible word confusion: 'than' may be incorrect. "
            "If indicating sequence or time is intended, the correct word is 'then' "
            "(e.g., 'and then', not 'and than'). Verify against audio."
        )

    return flags


# ---------------------------------------------------------------------------
# 2. LEGAL HOMOPHONES
# ---------------------------------------------------------------------------
# These are flagged whenever they appear — reporter confirms correct usage.

LEGAL_HOMOPHONES = [
    # High-signal only: words that are genuinely wrong in a legal transcript
    # and don't appear constantly in normal legal speech.
    ("statue",    "statute",   "'statue' is a sculpture; in legal context the correct word is likely 'statute'"),
    ("fiscal",    "physical",  "ASR commonly confuses these — verify which word was spoken"),
    ("disposed",  "deposed",   "'disposed' means dealt with; in legal context verify this is not 'deposed' (gave testimony)"),
    ("deposed",   "disposed",  "'deposed' means gave testimony; verify this is not 'disposed' (dealt with or discarded)"),
    ("capitol",   "capital",   "'capitol' is a government building; if referring to assets, punishment, or a city, the correct word is 'capital'"),
    ("capital",   "capitol",   "if referring to a government building or legislative seat, the correct word is 'capitol'"),
    ("principal", "principle", "if referring to a rule or standard, the correct word is 'principle'"),
    ("principle", "principal", "if referring to a person or a loan amount, the correct word is 'principal'"),
    ("plaintiff", "plaintive", "'plaintive' means sorrowful — in legal context, likely intended as 'plaintiff'"),
    ("plaintive", "plaintiff", "in legal proceedings, likely intended as 'plaintiff'"),
    ("precedent", "president", "if citing a prior ruling, the correct word is 'precedent'"),
    ("president", "precedent", "in a legal context citing prior rulings, verify this is not 'precedent'"),
    ("tort",      "torte",     "'torte' is a cake — in legal context, likely intended as 'tort' (civil wrong)"),
    ("torte",     "tort",      "in legal context, likely intended as 'tort' (civil wrong), not 'torte' (cake)"),
    ("perjure",   "perjury",   "verify correct form: 'perjure' (verb) vs. 'perjury' (noun) — ASR may swap these"),
]

def flag_homophones(text):
    flags = []
    for word, confused_with, context_note in LEGAL_HOMOPHONES:
        pattern = r'\b' + re.escape(word) + r'\b'
        if re.search(pattern, text, re.IGNORECASE):
            note = f" ({context_note})" if context_note else ""
            flags.append(
                f"FLAG — Possible homophone: '{word}' detected. "
                f"Verify this is not '{confused_with}'{note}. "
                f"Confirm correct word against audio."
            )
    return flags


# ---------------------------------------------------------------------------
# 3. SUSPICIOUS ASR WORDS
# ---------------------------------------------------------------------------

SUSPICIOUS_ASR = [
    ("gonna",   "going to"),
    ("wanna",   "want to"),
    ("kinda",   "kind of"),
    ("gotta",   "got to / have to"),
    ("sorta",   "sort of"),
    ("hafta",   "have to"),
    ("lemme",   "let me"),
    ("dunno",   "don't know"),
    ("coulda",  "could have"),
    ("woulda",  "would have"),
    ("shoulda", "should have"),
    ("musta",   "must have"),
    ("lotta",   "lot of"),
    ("outta",   "out of"),
    ("lotsa",   "lots of"),
    ("tryna",   "trying to"),
    ("oughta",  "ought to"),
]

def flag_suspicious_asr(text):
    flags = []
    for word, formal in SUSPICIOUS_ASR:
        if re.search(r'\b' + re.escape(word) + r'\b', text, re.IGNORECASE):
            flags.append(
                f"FLAG — Suspicious ASR word: '{word}' detected. "
                f"Likely intended as '{formal}'. "
                f"Verify against audio — transcribe exactly as spoken per verbatim standard."
            )
    return flags


# ---------------------------------------------------------------------------
# 4. NUMBER-WORD MISMATCH
# ---------------------------------------------------------------------------
# Style: digits 1-9 should be spelled out UNLESS in a date, time, address,
# identifier, dollar amount, percentage, measurement, or line/page/count context.

# Patterns that EXEMPT a digit from the rule:
_EXEMPT_PATTERNS = [
    r'\d{1,2}[:/]\d{2}',                          # time: 9:00, 10:30
    r'\d{1,2}/\d{1,2}/\d{2,4}',                   # date: 3/7/24
    r'\$\s*\d',                                    # dollar amount: $5
    r'\d\s*(percent|%)',                           # percentage: 5 percent
    r'\d\s*(feet|foot|ft|inches|inch|in|miles|mi|yards|yd|pounds|lbs|ounces|oz|grams|kilograms|kg|meters|cm|mm)\b',  # measurement
    r'\b(page|pages|line|lines|paragraph|count|item|exhibit|volume|chapter|section|article)\s*\d',  # identifiers
    r'\bA-?\d',                                    # case numbers
    r'\d(st|nd|rd|th)\b',                          # ordinals
    r'\b\d{3,}',                                   # 3+ digit numbers (always numerals)
]

_EXEMPT_RE = re.compile('|'.join(_EXEMPT_PATTERNS), re.IGNORECASE)

def flag_number_word_mismatch(text):
    flags = []
    # Find all standalone single digits 1-9
    for m in re.finditer(r'\b([1-9])\b', text):
        digit = m.group(1)
        start = m.start()
        # Check a window around the match for exempting context
        window = text[max(0, start - 20):start + 20]
        if not _EXEMPT_RE.search(window):
            flags.append(
                f"FLAG — Number-word mismatch: digit '{digit}' found. "
                f"Style requires numbers one through nine to be spelled out "
                f"unless used as an identifier, date, time, address, or measurement. "
                f"Verify correct usage."
            )
            break  # one flag per paragraph is enough; reporter will scan the line
    return flags


# ---------------------------------------------------------------------------
# 5. SENTENCE FRAGMENTS (spacy)
# ---------------------------------------------------------------------------

# Pattern for speaker labels: "THE COURT:", "MR. SMITH:", "THE WITNESS:", etc.
_SPEAKER_LABEL_RE = re.compile(
    r'^(THE\s+\w+|M[RS]\.|MRS\.|DR\.|MS\.)\s*[\w\s.]+:\s*',
    re.IGNORECASE
)

def flag_fragments(text):
    """
    Flag paragraphs that appear to contain no root verb — likely fragments.
    Skipped silently if spacy is not available.
    Filters aggressively to avoid noise on speaker labels and short utterances.
    """
    if not _SPACY_AVAILABLE:
        return []

    stripped = text.strip()

    # Skip short utterances (8 words or fewer) — too many false positives
    words = stripped.split()
    if len(words) <= 8:
        return []

    # Skip interrupted speech and false starts
    if stripped.endswith('--') or stripped.startswith('--'):
        return []

    # Skip parentheticals
    if stripped.startswith('(') and stripped.endswith(')'):
        return []

    # Strip speaker label before analysis so "THE COURT: Yes." doesn't flag
    analysis_text = _SPEAKER_LABEL_RE.sub('', stripped).strip()
    if not analysis_text or len(analysis_text.split()) <= 4:
        return []

    doc = _nlp(analysis_text)
    has_root_verb = any(
        token.dep_ == "ROOT" and token.pos_ in ("VERB", "AUX")
        for token in doc
    )

    if not has_root_verb:
        return [
            "FLAG — Possible sentence fragment: no main verb detected. "
            "If this reflects an interrupted thought or false start, no correction needed. "
            "If this is a complete utterance, verify against audio that no words were missed."
        ]
    return []




# ---------------------------------------------------------------------------
# 6. PUNCTUATION FLAGS
# ---------------------------------------------------------------------------

# Terminal punctuation characters that validly end a transcript paragraph.
# -- is an interruption, so it's a valid terminal mark.
# Closing paren covers (Indiscernible), (phonetic), etc.
_VALID_TERMINALS = ('.', '?', '!', '--', ')')

# Speaker label pattern — used to strip label before terminal-punctuation check
# and to exempt the double-space that follows speaker labels.
_SPEAKER_LABEL_STRIP_RE = re.compile(
    r'^(THE\s+\w[\w\s]*?|M[RS]\.|MRS\.|DR\.|MS\.\s*\w+)\s*:',
    re.IGNORECASE
)

# Coordinating conjunctions we check for missing comma
_COORD_CONJ_RE = re.compile(
    r'\b(and|but|so|yet|for|nor)\b',
    re.IGNORECASE
)

# Simple subject-verb detector: does a clause contain a pronoun/noun + common verb?
_HAS_SUBJECT_RE = re.compile(
    r'\b(I|you|he|she|it|we|they|the\s+\w+|this|that|these|those)\b',
    re.IGNORECASE
)
_HAS_VERB_RE = re.compile(
    r'\b(is|are|was|were|have|has|had|do|does|did|will|would|could|should|'
    r'can|may|might|must|said|told|asked|went|came|made|took|got|felt|'
    r'know|think|believe|understand|remember|heard|saw|found|want|need)\b',
    re.IGNORECASE
)


def flag_missing_terminal_punctuation(text):
    """
    Flag paragraphs that don't end with a valid terminal mark.
    Skips: headers, blank lines, speaker-label-only lines, parentheticals,
    index/exhibit lines, and lines ending with --.
    """
    stripped = text.strip()
    if not stripped:
        return []

    # Skip very short lines — single words, initials, headers
    if len(stripped.split()) <= 2:
        return []

    # Skip lines that are entirely a parenthetical
    if stripped.startswith('(') and stripped.endswith(')'):
        return []

    # Skip all-caps headers (DIRECT EXAMINATION, CROSS-EXAMINATION, etc.)
    if stripped.isupper():
        return []

    # Skip lines that are just a speaker label with no content after
    label_only = _SPEAKER_LABEL_STRIP_RE.sub('', stripped).strip()
    if not label_only:
        return []

    # Strip speaker label and check what the actual content ends with
    content = (label_only if label_only else stripped).rstrip()
    if not content:
        return []

    # Allow lines ending with -- (interruption), with or without trailing space
    if content.endswith('--') or content.endswith('-- '):
        return []

    # Check against valid terminals
    if not any(content.endswith(t) for t in _VALID_TERMINALS):
        return [
            "FLAG — Possible missing terminal punctuation: paragraph does not end with "
            "a period, question mark, or double dash. "
            "Verify correct punctuation against audio."
        ]
    return []


# Strips speaker label AND all whitespace immediately after it
_LABEL_AND_SPACE_RE = re.compile(
    r"^(?:THE\s+\w[\w\s]*?|(?:M[RS]|MRS|DR|MS)\.\s*[\w']+)\s*:\s+",
    re.IGNORECASE
)

def flag_double_space(text):
    """
    Flag double spaces between words in body text.
    Double spaces after a colon are standard transcript formatting and are ignored.
    Only fires on double spaces mid-sentence (e.g. after a comma, or between words).
    """
    # Remove all colon+spaces sequences first — standard after speaker labels
    # and also after terminal punctuation like "Q.  " or "A.  "
    # Strip colon+spaces and period+spaces (Q.  A.  format) — both are standard
    cleaned = re.sub(r'[:.]\s+', ': ', text)
    if '  ' in cleaned:
        return [
            "FLAG — Double space detected between words. "
            "Verify this is not a formatting artifact. "
            "Single space required between words."
        ]
    return []


def flag_missing_comma_before_conjunction(text):
    """
    Flag a coordinating conjunction (and/but/so/yet) that joins two full
    clauses without a preceding comma. Only fires when both sides of the
    conjunction appear to have a subject and a verb — keeps false positives low.
    """
    # Strip speaker label before analysis
    analysis = _SPEAKER_LABEL_STRIP_RE.sub('', text).strip()
    if not analysis:
        return []

    flags = []
    for m in _COORD_CONJ_RE.finditer(analysis):
        conj = m.group(0)
        before = analysis[:m.start()].strip()
        after = analysis[m.end():].strip()

        # Skip if there's already a comma immediately before the conjunction
        if before.endswith(','):
            continue

        # Both sides need to look like independent clauses
        before_has_clause = _HAS_SUBJECT_RE.search(before) and _HAS_VERB_RE.search(before)
        after_has_clause = _HAS_SUBJECT_RE.search(after) and _HAS_VERB_RE.search(after)

        if before_has_clause and after_has_clause:
            flags.append(
                f"FLAG — Possible missing comma before \'{conj}\': "
                f"both sides of \'{conj}\' appear to be independent clauses. "
                f"A comma is typically required before a coordinating conjunction "
                f"joining two complete sentences. Verify against audio and style."
            )
            break  # one flag per paragraph is enough

    return flags


# ---------------------------------------------------------------------------
# PUBLIC ENTRY POINT
# ---------------------------------------------------------------------------

def run_all(para_text):
    """
    Run all grammar and punctuation checks against a paragraph's text.
    Returns a flat list of flag strings.
    Call this from the proofing script's collect_flags() function.
    """
    flags = []
    flags.extend(flag_confusables(para_text))
    flags.extend(flag_homophones(para_text))
    flags.extend(flag_suspicious_asr(para_text))
    flags.extend(flag_number_word_mismatch(para_text))
    flags.extend(flag_fragments(para_text))
    flags.extend(flag_missing_terminal_punctuation(para_text))
    flags.extend(flag_double_space(para_text))
    flags.extend(flag_missing_comma_before_conjunction(para_text))
    return flags


# ---------------------------------------------------------------------------
# STATUS REPORT (called at startup by the proofing script)
# ---------------------------------------------------------------------------

def status():
    """Returns a one-line string describing spacy availability."""
    if _SPACY_AVAILABLE:
        return "grammar_flags: spacy loaded — fragment detection active."
    else:
        return (
            "grammar_flags: spacy not available — fragment detection inactive. "
            "Run: pip install spacy && py -m spacy download en_core_web_sm"
        )
