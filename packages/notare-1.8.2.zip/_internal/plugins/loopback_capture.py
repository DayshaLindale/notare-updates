"""Plugin: Mode A loopback capture — mix mic + system audio for Zoom/Teams depositions.

Monkey-patches _server_side_capture to support dual audio input when
a loopback device is selected in Mode A. Uses ffmpeg amix filter to
combine mic (reporter) + loopback (Zoom/Teams) into one stream for
real-time transcription.
"""

import subprocess
import logging
import sys
from pathlib import Path

logger = logging.getLogger("notare.plugin.loopback")

# Get reference to the app module — must be loaded before plugins
_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded — loopback plugin requires app")

BASE_DIR = _app.BASE_DIR
JOBS = _app.JOBS


def _patched_server_side_capture(job_id, job, state):
    """Server-side capture with optional loopback mixing for Mode A."""
    import numpy as np

    SAMPLE_RATE = 16000
    SEGMENT_SECONDS = 3
    SEGMENT_BYTES = SAMPLE_RATE * 2 * SEGMENT_SECONDS

    device_name = state.get("device_name", "")
    loopback_name = state.get("loopback_name", "")
    job_dir = Path(job["dir"])
    audio_dir = job_dir / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    recording_path = audio_dir / "live_recording.wav"

    # Get streaming model via the app module function
    model = None
    if hasattr(_app, '_get_streaming_model'):
        try:
            model = _app._get_streaming_model()
        except Exception as e:
            logger.error("Failed to get streaming model: %s", e)
    if not model:
        logger.error("Could not load streaming model for live capture")
        state["running"] = False
        return

    ffmpeg_bin = str(BASE_DIR / "ffmpeg.exe") if (BASE_DIR / "ffmpeg.exe").exists() else "ffmpeg"

    # Build ffmpeg command based on whether loopback is available
    if loopback_name and device_name:
        logger.info("Mode A dual capture: mic='%s' + loopback='%s'", device_name, loopback_name)
        ffmpeg_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-f", "dshow", "-i", f"audio={loopback_name}",
            "-filter_complex", "[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0[mixed]",
            "-map", "[mixed]",
            "-ar", str(SAMPLE_RATE), "-ac", "1",
            "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1",
        ]
        save_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-f", "dshow", "-i", f"audio={loopback_name}",
            "-filter_complex", "[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0[mixed]",
            "-map", "[mixed]",
            "-ar", str(SAMPLE_RATE), "-ac", "1",
            "-acodec", "pcm_s16le", str(recording_path),
        ]
    else:
        logger.info("Single device capture: '%s'", device_name)
        ffmpeg_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-ar", str(SAMPLE_RATE), "-ac", "1",
            "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1",
        ]
        save_cmd = [
            ffmpeg_bin, "-y",
            "-f", "dshow", "-i", f"audio={device_name}",
            "-ar", str(SAMPLE_RATE), "-ac", "1",
            "-acodec", "pcm_s16le", str(recording_path),
        ]

    try:
        proc = subprocess.Popen(
            ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        save_proc = subprocess.Popen(
            save_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except Exception as e:
        logger.error("Failed to start ffmpeg capture: %s", e)
        state["running"] = False
        return

    logger.info("FFmpeg capture started (PID %d)", proc.pid)
    audio_buffer = bytearray()

    try:
        while state["running"]:
            chunk = proc.stdout.read(8192)
            if not chunk:
                break
            audio_buffer.extend(chunk)

            if len(audio_buffer) >= SEGMENT_BYTES:
                segment_data = bytes(audio_buffer[:SEGMENT_BYTES])
                audio_buffer = audio_buffer[SEGMENT_BYTES:]
                audio_np = np.frombuffer(segment_data, dtype=np.int16).astype(np.float32) / 32768.0

                try:
                    result = model.transcribe(audio_np, language="en")
                    text = result.get("text", "").strip() if isinstance(result, dict) else str(result).strip()
                    if text and text not in ("", ".", "...", "(silence)"):
                        seg = {
                            "text": text,
                            "start": state["total_ms"] / 1000.0,
                            "end": (state["total_ms"] + SEGMENT_SECONDS * 1000) / 1000.0,
                            "speaker": "SPEAKER_00",
                        }
                        state["segments"].append(seg)
                except Exception as e:
                    logger.warning("Transcription error: %s", e)

                state["total_ms"] += SEGMENT_SECONDS * 1000
    finally:
        proc.terminate()
        save_proc.terminate()
        state["running"] = False
        logger.info("Live capture stopped for job %s", job_id)


# Monkey-patch: replace the original _server_side_capture
_app._server_side_capture = _patched_server_side_capture

# Monkey-patch: wrap the original start_live_capture to pass loopback_name
_original_start = _app.start_live_capture

async def _wrapped_start_live(request):
    """Wrapper that injects loopback_name into the capture state after the original handler runs."""
    from starlette.responses import JSONResponse
    import threading
    from datetime import datetime

    data = await request.json()
    job_id = data.get("job_id")
    loopback_name = data.get("loopback_name", "")
    device_name = data.get("device_name", "")
    device_id = data.get("device_id")
    mode = data.get("mode", "C")

    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)

    job["status"] = "recording"
    job["live_mode"] = mode
    job["recording_start"] = datetime.now().isoformat()
    if data.get("channel_labels"):
        job["channel_labels"] = data["channel_labels"]
    _app._save_job(job)

    if device_name or device_id is not None:
        loopback_id = data.get("loopback_id")
        capture_state = {
            "running": True,
            "device_id": int(device_id) if device_id is not None else 0,
            "device_name": device_name,
            "loopback_id": int(loopback_id) if loopback_id is not None else None,
            "loopback_name": loopback_name,
            "segments": [],
            "buffer": bytearray(),
            "total_ms": 0,
        }
        _app._live_capture[job_id] = capture_state

        threading.Thread(
            target=_patched_server_side_capture,
            args=(job_id, job, capture_state),
            daemon=True, name=f"live-capture-{job_id}"
        ).start()
        logger.info("Loopback capture started: mic='%s', loopback='%s'", device_name, loopback_name)

    return JSONResponse({"ok": True, "status": "recording", "server_capture": device_id is not None})


# Replace the route endpoint
for route in _app.app.routes:
    if hasattr(route, 'path') and route.path == '/api/live/start':
        route.endpoint = _wrapped_start_live
        logger.info("Patched /api/live/start with loopback support")
        break
else:
    # Fallback: patch the function directly on the module
    _app.start_live_capture = _wrapped_start_live
    logger.info("Patched start_live_capture function (fallback)")

logger.info("Loopback capture plugin loaded — Mode A now captures mic + system audio")
