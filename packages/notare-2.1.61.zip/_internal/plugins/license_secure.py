"""Plugin: Secure license validation — server-only with hardware binding.

Replaces local admin_data.json key lookup with server validation.
Caches valid license locally (encrypted with machine fingerprint) for offline use.
Never ships license keys in the installer.
"""

import sys
import os
import json
import hashlib
import logging
import uuid
import time
from pathlib import Path

logger = logging.getLogger("notare.plugin.license_secure")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

BASE_DIR = _app.BASE_DIR
UPDATE_SERVER = "https://notarelegal.com"

# ═══════════════════════════════════════════════════════════════════
# MACHINE FINGERPRINT — unique, hashed, not reversible
# ═══════════════════════════════════════════════════════════════════

def _get_machine_id():
    """Generate a hardware fingerprint anchored to Windows MachineGuid.

    MachineGuid is set at OS install and survives hardware changes.
    MAC and hostname are supplementary — prevent casual spoofing but
    the GUID is the anchor that can't be faked without registry access.
    """
    # Primary: Windows MachineGuid (immutable without admin registry access)
    guid = ""
    try:
        import subprocess
        result = subprocess.run(
            ['reg', 'query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
            capture_output=True, text=True, timeout=5,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        )
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if 'MachineGuid' in line:
                    guid = line.strip().split()[-1]
    except:
        pass

    if not guid:
        # Fallback: MAC + hostname if no registry access
        components = []
        try:
            components.append(str(uuid.getnode()))
        except:
            pass
        try:
            import socket
            components.append(socket.gethostname())
        except:
            pass
        return hashlib.sha256("|".join(components).encode()).hexdigest()

    # GUID is the primary anchor — MAC and hostname are salt
    components = [guid]
    try:
        components.append(str(uuid.getnode()))
    except:
        pass
    return hashlib.sha256("|".join(components).encode()).hexdigest()


MACHINE_ID = _get_machine_id()

# ═══════════════════════════════════════════════════════════════════
# LOCAL CACHE — encrypted with machine fingerprint
# ═══════════════════════════════════════════════════════════════════

_cache_path = BASE_DIR / "_internal" / ".license_cache"

def _encrypt_cache(data):
    """Simple XOR with machine ID — not cryptographically strong but prevents casual copying."""
    raw = json.dumps(data).encode('utf-8')
    key = MACHINE_ID.encode('utf-8')
    encrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(raw))
    return encrypted

def _decrypt_cache():
    """Decrypt the local license cache."""
    try:
        if not _cache_path.exists():
            return None
        encrypted = _cache_path.read_bytes()
        key = MACHINE_ID.encode('utf-8')
        decrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(encrypted))
        data = json.loads(decrypted.decode('utf-8'))
        # Check cache age — max 7 days offline
        cached_at = data.get("cached_at", 0)
        if time.time() - cached_at > 7 * 86400:
            logger.info("License cache expired (>7 days offline)")
            return None
        return data
    except:
        return None

def _save_cache(license_data):
    """Save validated license to local encrypted cache."""
    license_data["cached_at"] = time.time()
    license_data["machine_id"] = MACHINE_ID
    try:
        _cache_path.parent.mkdir(exist_ok=True)
        _cache_path.write_bytes(_encrypt_cache(license_data))
    except:
        pass

# ═══════════════════════════════════════════════════════════════════
# SERVER VALIDATION
# ═══════════════════════════════════════════════════════════════════

def validate_license(key):
    """Validate license against server with hardware binding. Falls back to cache."""
    import urllib.request

    # Try server first
    try:
        payload = json.dumps({"key": key, "machine_id": MACHINE_ID}).encode('utf-8')
        req = urllib.request.Request(
            f"{UPDATE_SERVER}/api/validate-license",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())

        if result.get("valid"):
            # Cache the successful validation
            _save_cache({
                "valid": True,
                "tier": result.get("tier", "solo"),
                "expires": result.get("expires", ""),
                "customer": result.get("customer", ""),
                "key_hash": hashlib.sha256(key.encode()).hexdigest(),
            })
            logger.info("License validated via server (tier: %s)", result.get("tier"))
            return result
        else:
            logger.warning("License rejected: %s", result.get("reason", "unknown"))
            # Clear cache if server explicitly rejects
            if _cache_path.exists():
                _cache_path.unlink(missing_ok=True)
            return result

    except Exception as e:
        logger.info("Server unreachable (%s) — checking local cache", e)

    # Fallback to cached validation
    cached = _decrypt_cache()
    if cached and cached.get("valid"):
        # Verify the key matches what was cached
        if cached.get("key_hash") == hashlib.sha256(key.encode()).hexdigest():
            logger.info("License validated from cache (offline mode, tier: %s)", cached.get("tier"))
            return {
                "valid": True,
                "tier": cached.get("tier", "solo"),
                "expires": cached.get("expires", ""),
                "customer": cached.get("customer", ""),
                "offline": True,
            }

    return {"valid": False, "reason": "server_unreachable_no_cache"}


# ═══════════════════════════════════════════════════════════════════
# PATCH: replace the local validation with server validation
# ═══════════════════════════════════════════════════════════════════

# Store the function for use by other plugins/endpoints
_app._validate_license_secure = validate_license
_app._get_machine_id = lambda: MACHINE_ID

logger.info("Secure license plugin loaded — server validation + hardware binding (machine: %s...)", MACHINE_ID[:12])
