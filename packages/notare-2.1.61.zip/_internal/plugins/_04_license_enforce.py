"""Plugin: License enforcement + full-gridlock gate (SELF-CONTAINED).

`license_secure.py` validates against the license server (hardware binding +
encrypted 7-day offline cache, wipes the cache on reject). This plugin USES that
to actually BLOCK the app when the server suspends this install — the wire that
was never connected — and it installs its OWN gate + middleware so it needs no
changes to app.py at all (ships as a plugin-only patch).

FULL GRIDLOCK when suspended: every page request returns a self-contained lock
screen; every API/data/WS request is refused. The app opens to a notice and does
nothing else — no jobs, no reads, no exports, nothing in or out. Existing files
are untouched on disk.

Sticky-blocked / fail-open: only an explicit server decision changes the gate. A
reachable server saying "valid" OPENS it; "suspended/inactive/expired/
wrong_machine" CLOSES it. An unreachable server never newly-blocks (so a Render
cold-start can't lock out a paying customer) and never silently un-blocks a
suspended one (so going offline can't bypass a suspension). Recovery is
automatic: clear the suspension server-side and the next check (or a restart)
reopens the gate.
"""

import sys
import json
import time
import threading
import logging

logger = logging.getLogger("notare.plugin.license_enforce")

_app = sys.modules.get("app")
if not _app:
    raise RuntimeError("app module not loaded")

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, HTMLResponse

BASE_DIR = _app.BASE_DIR
_STATE_PATH = BASE_DIR / "_internal" / ".license_gate.json"
_DEFAULT_MSG = "Licensing check failed — contact your administrator to restore service."
_RECHECK_SECONDS = 6 * 3600
# ONLY the deliberate operator levers close the gate:
#   "suspended" = the global suspend_all kill switch (what we flip on/off)
#   "inactive"  = a license whose status an admin set to non-active
# We deliberately EXCLUDE "expired" and "wrong_machine" so a stale expiry date
# or the first-run hardware binding can never lock someone by accident — and
# "invalid_key"/"no_database"/unknown are excluded so a transient server glitch
# never bricks a paying customer. The lock is 100% intentional or it doesn't fire.
_BLOCK_REASONS = {"suspended", "inactive"}

# Shared gate state. Mirrored onto the app module so anything else can read it.
_GATE = {"blocked": False, "message": _DEFAULT_MSG}
try:
    _app._LICENSE_GATE = _GATE
except Exception:
    pass

# Self-contained lock screen — no external CSS/JS so it renders with everything
# else blocked.
_LOCK_HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Notare</title><style>
html,body{height:100%;margin:0}
body{font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:#1b1b1d;
color:#ececec;display:flex;align-items:center;justify-content:center}
.box{max-width:440px;text-align:center;padding:40px}
h1{font-weight:600;font-size:19px;margin:0 0 12px}
p{color:#a9a9ad;line-height:1.55;font-size:14px;margin:0}
</style></head><body><div class="box">
<h1>Notare is currently unavailable</h1>
<p>A licensing check could not be completed. Please contact your administrator
to restore service.</p></div></body></html>"""


# ── gate state persistence ─────────────────────────────────────────────────
def _read_key():
    for name in ("license.json", "_internal/license.json"):
        p = BASE_DIR / name
        try:
            if p.exists():
                k = (json.loads(p.read_text(encoding="utf-8")).get("key") or "").strip()
                if k:
                    return k
        except Exception:
            pass
    return ""


def _load_state():
    try:
        if _STATE_PATH.exists():
            d = json.loads(_STATE_PATH.read_text(encoding="utf-8"))
            return bool(d.get("blocked", False)), d.get("message", _DEFAULT_MSG)
    except Exception:
        pass
    return False, _DEFAULT_MSG


def _save_state(blocked, message):
    try:
        _STATE_PATH.parent.mkdir(exist_ok=True)
        _STATE_PATH.write_text(json.dumps({
            "blocked": bool(blocked), "message": message, "checked_at": time.time(),
        }, indent=2), encoding="utf-8")
    except Exception:
        pass


def _apply(blocked, message):
    _GATE["blocked"] = bool(blocked)
    if message:
        _GATE["message"] = message


# ── server validation ──────────────────────────────────────────────────────
def _validate(key):
    """Validate via the secure plugin if it loaded, else a direct call. Returns
    the result dict, or None on unreachable/hard error."""
    fn = getattr(_app, "_validate_license_secure", None)
    if fn:
        try:
            return fn(key)
        except Exception as e:
            logger.info("secure validate raised: %s", e)
            return None
    try:
        import urllib.request
        mid = ""
        gm = getattr(_app, "_get_machine_id", None)
        if gm:
            try:
                mid = gm()
            except Exception:
                pass
        payload = json.dumps({"key": key, "machine_id": mid}).encode("utf-8")
        req = urllib.request.Request(
            "https://notarelegal.com/api/validate-license",
            data=payload, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        logger.info("license server unreachable: %s", e)
        return None


def _check_once():
    key = _read_key()
    if not key:
        return  # fresh/pre-activation — leave persisted state, don't block
    result = _validate(key)
    if result is None:
        return  # unreachable — fail OPEN, keep any existing block (sticky)
    if result.get("valid"):
        _apply(False, _DEFAULT_MSG)
        _save_state(False, _DEFAULT_MSG)
        logger.info("License OK — gate open (tier: %s)", result.get("tier"))
        return
    reason = (result.get("reason") or "").lower()
    if reason in _BLOCK_REASONS:
        msg = result.get("message") or _DEFAULT_MSG
        _apply(True, msg)
        _save_state(True, msg)
        logger.warning("License suspended by server (reason: %s) — gate CLOSED", reason)
    else:
        logger.info("License check inconclusive (reason: %s) — gate unchanged", reason)


def _loop():
    time.sleep(3)  # let sibling plugins (license_secure) finish loading first
    while True:
        try:
            _check_once()
        except Exception as e:
            logger.info("license check loop error: %s", e)
        time.sleep(_RECHECK_SECONDS)


# ── the gridlock middleware ────────────────────────────────────────────────
def _lock_allow(path):
    return path == "/favicon.ico"


class _LicenseGateMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        try:
            if _GATE.get("blocked"):
                path = request.url.path
                if not _lock_allow(path):
                    accept = request.headers.get("accept", "")
                    if request.method == "GET" and (
                            path == "/" or path.endswith(".html") or "text/html" in accept):
                        return HTMLResponse(_LOCK_HTML, status_code=503)
                    return JSONResponse(
                        {"status": "unavailable", "error": _GATE.get("message", _DEFAULT_MSG)},
                        status_code=503)
        except Exception:
            pass  # never let the gate itself crash a request
        return await call_next(request)


try:
    _app.app.add_middleware(_LicenseGateMiddleware)
    logger.info("license gate middleware attached")
except Exception as e:
    logger.warning("could not attach license gate middleware: %s", e)

# Instant enforcement from persisted state (no network wait on startup).
_b, _m = _load_state()
_apply(_b, _m)
if _b:
    logger.warning("License gate CLOSED from persisted state")

# Async refresh against the server now + on a timer.
try:
    threading.Thread(target=_loop, daemon=True, name="license-enforce").start()
except Exception as e:
    logger.info("could not start license enforce thread: %s", e)

logger.info("License enforcement plugin loaded (self-contained gate)")
